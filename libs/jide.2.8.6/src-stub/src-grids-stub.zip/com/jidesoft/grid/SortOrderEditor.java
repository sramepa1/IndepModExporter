/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An editor to customize the sort order which can be used in <code>SortableTableModel</code>. It has an interface to
 *  create two things. The first thing is the sort order - ascending or descending. The second one is the
 *  <code>ComparatorContext</code>. Different <code>Comparator</code>s will be used depending on the
 *  <code>ComparatorContext</code>.
 */
public class SortOrderEditor extends javax.swing.JPanel {

	/**
	 *  Creates a SortItemEditor.
	 */
	public SortOrderEditor() {
	}

	/**
	 *  Creates a SortOrderEditor with a specified type. The type will affect the options that will appear on the
	 *  editor.
	 * 
	 *  @param type the type.
	 */
	public SortOrderEditor(Class type) {
	}

	/**
	 *  Gets the type.
	 * 
	 *  @return the type.
	 */
	public Class getType() {
	}

	/**
	 *  Sets the type. Setting the type will change the editor.
	 * 
	 *  @param type the type.
	 */
	public void setType(Class type) {
	}

	protected void initComponents() {
	}

	/**
	 *  Creates a combobox based on the data type.
	 * 
	 *  @param type the data type.
	 *  @return a combobox.
	 */
	protected javax.swing.JComboBox createContextComboBox(Class type) {
	}

	/**
	 *  Gets the isAscending value.
	 * 
	 *  @return true if the ascending radio button is selected. Otherwise false.
	 */
	public boolean isAscending() {
	}

	/**
	 *  Sets the ascending flag.
	 * 
	 *  @param ascending true or false.
	 */
	public void setAscending(boolean ascending) {
	}

	/**
	 *  Gets the comparator context. This comparator context can be used with {@link
	 *  SortableTableModel#setColumnComparatorContextProvider(com.jidesoft.grid.SortableTableModel.ColumnComparatorContextProvider)}
	 *  to customize how the table is sorted.
	 * 
	 *  @return ComparatorContext.
	 */
	public ComparatorContext getComparatorContext() {
	}

	/**
	 *  Sets the ComparatorContext.
	 * 
	 *  @param comparatorContext a new ComparatorContext.
	 */
	public void setComparatorContext(ComparatorContext comparatorContext) {
	}
}
