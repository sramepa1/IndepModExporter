/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>ColumnIdentifierTableModel</code> provides a way to let TableModel define an unique identifier for each table
 *  column. As long as <code>JideTable</code> is used, the {@link javax.swing.table.TableColumn#getIdentifier()} will
 *  return the correct identifier returned from {@link #getColumnIdentifier(int)} method, even when the TableColumnModel
 *  is recreated.
 *  <p/>
 *  There are two use cases that this interface could be used. One is you need to localize the column names. You can
 *  return identifiers that are not localized for each column, while localizes getColumnName to return whatever localized
 *  string you want. The other case is you have duplicated column names. Several TableUtils's load/save methods and
 *  TableColumnChooser will use this feature to make sure the columns are uniquely identified.
 */
public interface ColumnIdentifierTableModel {

	/**
	 *  Returns the identifier of the column in the model. A <code>JideTable</code> uses this method to get the unique
	 *  identifier of this column.
	 * 
	 *  @param columnIndex the index of the column
	 *  @return the unique identifier of the column. Even though it is of an Object type, you should return String so
	 *          that it matches the return type of TableModel#getColumnName.
	 */
	public Object getColumnIdentifier(int columnIndex);
}
