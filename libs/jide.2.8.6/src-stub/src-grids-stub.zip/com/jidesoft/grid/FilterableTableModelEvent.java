/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An <code>AWTEvent</code> that adds support for <code>FilterableTableModel</code> objects as the event source when
 *  filter is added or removed.
 */
public class FilterableTableModelEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>FilterableTableModel</code> events.
	 */
	public static final int FILTERABLE_TABLE_MODEL_EVENT_FIRST = 7099;

	/**
	 *  The last number in the range of IDs used for <code>FilterableTableModel</code> events.
	 */
	public static final int FILTERABLE_TABLE_MODEL_EVENT_LAST = 7100;

	/**
	 *  This event is delivered when a <code>Filter</code> is added. You can call {@link #getColumn()} to find the column
	 *  where the filter is added and {@link #getFilter()} will tell you the filter that is added.
	 */
	public static final int FILTER_ADDED = 7099;

	/**
	 *  This event is delivered when a <code>Filter</code> is removed. You can call {@link #getColumn()} to find the
	 *  column where the filter is removed and {@link #getFilter()} will tell you the filter that is removed. It could
	 *  return null when removeFilters is called which means all filters for that particular columns are removed. In
	 *  particular,
	 */
	public static final int FILTER_REMOVED = 7100;

	/**
	 *  Specifies all columns. You can use this to apply a filter to all columns. All columns must satisfy the filter
	 *  condition in order for the row not to be filtered away.
	 */
	public static final int ALL_COLUMNS = -1;

	/**
	 *  Specifies any columns. You can use this to apply a filter to any columns. As long as there is one column
	 *  satisfies the filter condition, the row will not be filtered away.
	 */
	public static final int ANY_COLUMNS = -2;

	/**
	 *  Specifies any columns. You can use this to apply a filter to any columns. As long as there is one column
	 *  satisfies the filter condition, the row will not be filtered away.
	 */
	public static final int WHOLE_TABLE_MODEL = -3;

	/**
	 *  Constructs an <code>FilterEvent</code> object.
	 * 
	 *  @param source the <code>Filter</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 */
	public FilterableTableModelEvent(Object source, int id) {
	}

	public FilterableTableModelEvent(Object source, int id, int column, com.jidesoft.filter.Filter filter) {
	}

	public com.jidesoft.filter.Filter getFilter() {
	}

	/**
	 *  Gets the column index that this change event affects. It could be 0 to columnCount -1. Or -1 means ALL_COLUMNS.
	 *  -2, means ANY_COLUMN, or -3 means the whole table model. The last -3 case is only used when {@link
	 *  com.jidesoft.grid.FilterableTableModel#clearFilters()} is called.
	 * 
	 *  @return the column index.
	 */
	public int getColumn() {
	}
}
