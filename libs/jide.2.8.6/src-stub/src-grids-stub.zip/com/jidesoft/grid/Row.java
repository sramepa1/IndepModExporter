/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>Row</code> is an interface to represent a row in a table.
 */
public interface Row extends Node {
 {

	/**
	 *  Returns true if the cell at <code>columnIndex</code> is editable.  Otherwise, <code>setValueAt</code> on the cell
	 *  will not change the value of that cell.
	 * 
	 *  @param columnIndex the column whose value to be queried
	 *  @return true if the cell is editable
	 * 
	 *  @see #setValueAt
	 */
	public boolean isCellEditable(int columnIndex);

	/**
	 *  Gets the value for cell at <code>columnIndex</code>
	 * 
	 *  @param columnIndex the column whose value to be queried
	 *  @return the value at the specified cell.
	 */
	public Object getValueAt(int columnIndex);

	/**
	 *  Sets the value in the cell at <code>columnIndex</code>.
	 * 
	 *  @param value       the new value
	 *  @param columnIndex the column whose value is to be changed
	 *  @see #getValueAt
	 *  @see #isCellEditable
	 */
	public void setValueAt(Object value, int columnIndex);

	/**
	 *  Gets the converter context for the cell at <code>columnIndex</code>.
	 * 
	 *  @param columnIndex the column index
	 *  @return the converter context for the specified cell.
	 */
	public ConverterContext getConverterContextAt(int columnIndex);

	/**
	 *  Gets the editor context for the cell at <code>columnIndex</code>.
	 * 
	 *  @param columnIndex the column index
	 *  @return the editor context for the specified cell.
	 */
	public EditorContext getEditorContextAt(int columnIndex);

	/**
	 *  Gets the type for the cell at <code>columnIndex</code>.
	 * 
	 *  @param columnIndex the column index
	 *  @return the type for the specified cell.
	 */
	public Class getCellClassAt(int columnIndex);

	/**
	 *  Notifies the cell at the specified column is updated.
	 * 
	 *  @param columnIndex the column index the column index.
	 */
	public void cellUpdated(int columnIndex);

	/**
	 *  Notifies the row is updated. You can call this method if any of the cells are changed. But if you know exactly
	 *  which cell is changed, you should use {@link #cellUpdated(int)} instead.
	 */
	public void rowUpdated();
}
