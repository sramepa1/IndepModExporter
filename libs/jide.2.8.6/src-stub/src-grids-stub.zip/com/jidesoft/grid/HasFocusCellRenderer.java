/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a markup interface for cell renderers of the first column of <code>TreeTable</code> or
 *  <code>HierarchicalTable</code> to indicate whether the cell renderer should have the actual <code>hasFocus</code>
 *  value in <code>getTableCellRendererComponent</code>. If a cell renderer implements this interface, we will pass the
 *  actual value for <code>hasFocus</code>. Otherwise, we will always use false as we don't want the wrapped cell
 *  renderer to paint any focus indicator.
 */
public interface HasFocusCellRenderer {
}
