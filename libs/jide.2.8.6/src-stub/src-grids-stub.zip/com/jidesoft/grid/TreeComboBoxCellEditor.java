/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editor where one needs to choose value from a tree.
 *  It used TreeComboBox as the editor.
 */
public class TreeComboBoxCellEditor extends AbstractComboBoxCellEditor {

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public TreeComboBoxCellEditor(Object[] objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public TreeComboBoxCellEditor(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public TreeComboBoxCellEditor(java.util.Hashtable objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param root the tree root node
	 */
	public TreeComboBoxCellEditor(javax.swing.tree.TreeNode root) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 *  @param root the tree root node
	 *  @param asksAllowsChildren the flag indicating if allows children
	 */
	public TreeComboBoxCellEditor(javax.swing.tree.TreeNode root, boolean asksAllowsChildren) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param model the tree model
	 */
	public TreeComboBoxCellEditor(javax.swing.tree.TreeModel model) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	@java.lang.Override
	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	@java.lang.Override
	public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e) {
	}

	/**
	 *  Creates the tree combobox.
	 * 
	 *  @return the tree combobox.
	 */
	protected com.jidesoft.combobox.TreeComboBox createTreeComboBox() {
	}
}
