/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>ExpandableRow</code> combines expandable and row. It is used to implement TreeTable.
 */
public interface ExpandableRow extends Expandable, Row {
 {

	/**
	 *  Notifies the child is updated.
	 * 
	 *  @param child       the child which is updated
	 *  @param columnIndex the column index.
	 */
	public void notifyCellUpdated(Object child, int columnIndex);
}
