/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for FolderName.
 */
public class FolderNameCellEditor extends AbstractComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a FolderNameCellEditor.
	 */
	public FolderNameCellEditor() {
	}

	/**
	 *  Creates FolderNameChooserComboBox used by this cell editor.
	 * 
	 *  @return FolderNameChooserComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}
}
