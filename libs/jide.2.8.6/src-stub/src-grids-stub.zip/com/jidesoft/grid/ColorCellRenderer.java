/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellRenderer for Color.
 */
public class ColorCellRenderer extends com.jidesoft.combobox.ColorComboBox implements javax.swing.table.TableCellRenderer {
 {

	public ColorCellRenderer() {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}
}
