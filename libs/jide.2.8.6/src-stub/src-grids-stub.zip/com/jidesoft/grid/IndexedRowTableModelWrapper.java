/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is an interface extends RowTableModelWrapper to provide a more specific row table model wrapper implementation
 *  with index.
 */
public interface IndexedRowTableModelWrapper extends RowTableModelWrapper {
 {

	/**
	 *  Gets the indexes that maps from the visual row index to the actual row index. It should return a clone of the index
	 *  array, not the actual array that is being used.
	 * 
	 *  @return the indexes.
	 */
	public int[] getIndexes();

	/**
	 *  Sets the indexes of the row mapping. We exposed this method to allow quick access to the underlying indexes. The
	 *  method won't fire any table events. So once you change the indexes, you need to fire corresponding table event so
	 *  that table can update itself.
	 * 
	 *  @param indexes the new index array.
	 */
	public void setIndexes(int[] indexes);
}
