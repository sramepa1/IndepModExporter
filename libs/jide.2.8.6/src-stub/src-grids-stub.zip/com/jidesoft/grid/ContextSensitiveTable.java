/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  ContextSensitiveTable is a JTable which supports EditorContext. If you pass a regular TableModel, it just acts like
 *  JTable. However if the model is ContextSensitiveTableModel, it will use the editor context information to get the
 *  correct cell renderer and cell editor from CellRendererManager and CellEditorManager respectively. Please note cell
 *  editor/renderer assigned to table column has a higher priority. Only when the cell editor/renderer on the table
 *  column is null, the renderer/editor on CellRendererManager or CellEditorManager will then be used.
 *  <p/>
 *  By default, we use combobox as the cell editor for boolean. If you prefer to use the check box as in regular Swing
 *  table, you can call the code below when your application starts. It will affect all your tables. If you prefer to
 *  just change one table, you would need to return BooleanCheckBoxCellEditor.CONTEXT in
 *  ContextSensitiveTableModel#getEditorContextAt method for the paticular boolean column.
 *  <code><pre>
 *  CellEditorManager.initDefaultEditor();
 *  final CellEditorFactory cellEditorFactory = new CellEditorFactory() {
 *  public CellEditor create() {
 *       return new BooleanCheckBoxCellEditor();
 *  }
 *  };
 *  CellEditorManager.registerEditor(Boolean.class, cellEditorFactory);
 *  CellEditorManager.registerEditor(boolean.class, cellEditorFactory);
 *  <p/>
 *  CellRendererManager.initDefaultRenderer();
 *  BooleanCheckBoxCellRenderer booleanCheckBoxCellRenderer = new BooleanCheckBoxCellRenderer();
 *  CellRendererManager.registerRenderer(Boolean.class, booleanCheckBoxCellRenderer);
 *  CellRendererManager.registerRenderer(boolean.class, booleanCheckBoxCellRenderer);
 *  </pre></code>
 */
public class ContextSensitiveTable extends JideTable {

	public ContextSensitiveTable() {
	}

	public ContextSensitiveTable(int numRows, int numColumns) {
	}

	public ContextSensitiveTable(javax.swing.table.TableModel dm) {
	}

	public ContextSensitiveTable(Object[][] rowData, Object[] columnNames) {
	}

	public ContextSensitiveTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public ContextSensitiveTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public ContextSensitiveTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	/**
	 *  <code>ContextSensitiveTable</code> will use its own transfer handler called <code>ContextSensitiveTableTransferHandler</code>
	 *  which understands the ObjectConverter. So the string value copied to the clipboard is after the the conversion by
	 *  the converters. If you want to copy the raw value without conversion, you call this method to reset the transfer
	 *  handler to the default one created by JTable which doesn't use the converters.
	 */
	public void resetTransferHandler() {
	}

	/**
	 *  Returns an appropriate renderer for the cell specified by this row and column. First, it will check if
	 *  defaultCellRenderer is set using {@link #getDefaultCellRenderer()} method. If null, it will check is {@link
	 *  #isCellRendererManagerEnabled()} is true. If true, it will look for the cell renderer that assigned to the
	 *  specific column. Only if the renderer is still null, it will use the EditorContext information from
	 *  ContextSensitiveTableModel and get the correct CellRedenerer from the CellRendererManager. In any case, if we
	 *  can't determine a cell renderer, we will call super.getCellRenderer(row, column) just like regular JTable.
	 * 
	 *  @param row    the row of the cell to render, where 0 is the first row
	 *  @param column the column of the cell to render, where 0 is the first column
	 *  @return the renderer for the column and row.
	 */
	@java.lang.Override
	public javax.swing.table.TableCellRenderer getCellRenderer(int row, int column) {
	}

	/**
	 *  Gets the cell editor from the CellRendererManager based on the values returned from getCellClassAt and
	 *  getEditorContextAt.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return the cell renderer. Null if the cell editor is not registered in CellRendererManager.
	 */
	protected javax.swing.table.TableCellRenderer getCellRendererFromManager(int row, int column) {
	}

	/**
	 *  For the performance consideration, we cached the cell renderers after getting it from
	 *  <code>CellRendererManager</code>. Since usually <code>CellRendererManager</code>doesn't change dynamically in the
	 *  life span of a table, it should be fine. However if for whatever reason you have to change
	 *  <code>CellRendererManager</code> on fly, you can call this method to invalidate the cache.
	 */
	public void invalidateCellRendererCache() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns an appropriate cell editor for the cell specified by this row and column. First, we will check is {@link
	 *  #isCellEditorManagerEnabled()} is true. If true, it will look for the cell editor that assigned to the specific
	 *  column. Only if the editor is still null, it will use the EditorContext information from
	 *  ContextSensitiveTableModel and get the correct CellEditorfrom the CellRendererManager. In any case, if we can't
	 *  determine a cell editor, we will call super.getCellEditor(row, column) just like regular JTable.
	 * 
	 *  @param row    the row of the cell to edit, where 0 is the first row
	 *  @param column the column of the cell to edit, where 0 is the first column
	 *  @return the <code>TableCellEditor</code> that does the editing
	 * 
	 *  @see #cellEditor
	 */
	@java.lang.Override
	public javax.swing.table.TableCellEditor getCellEditor(int row, int column) {
	}

	/**
	 *  Gets the cell editor from the CellEditorManager based on the values returned from getCellClassAt and
	 *  getEditorContextAt.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return the cell editor. Null if the cell editor is not registered in CellEditorManager.
	 */
	protected javax.swing.table.TableCellEditor getCellEditorFromManager(int row, int column) {
	}

	/**
	 *  Checks if {@link CellEditorManager} is in enabled. Default is true.
	 * 
	 *  @return true if CellEditorManager is enabled. Otherwise false.
	 */
	public boolean isCellEditorManagerEnabled() {
	}

	/**
	 *  By default, ContextSensitiveTable will use cell editors that are registered in {@link CellEditorManager} if the
	 *  model is {@link ContextSensitiveTableModel}. However if for some reason you don't want this feature, you can call
	 *  this method to enable or disable it.
	 * 
	 *  @param cellEditorManagerEnabled true to enable <code>CellEditorManager</code>. False to disable it.
	 */
	public void setCellEditorManagerEnabled(boolean cellEditorManagerEnabled) {
	}

	/**
	 *  Checks if {@link CellRendererManager} is in enabled. Default is true.
	 * 
	 *  @return true if CellRendererManager is enabled. Otherwise false.
	 */
	public boolean isCellRendererManagerEnabled() {
	}

	/**
	 *  By default, ContextSensitiveTable will use cell renderers that are registered in {@link CellRendererManager} if
	 *  the model is {@link ContextSensitiveTableModel}. However if for some reason you don't want this feature, you can
	 *  call this method to enable or disable it.
	 * 
	 *  @param cellRendererManagerEnabled true to enable <code>CellRendererManager</code>. False to disable it.
	 */
	public void setCellRendererManagerEnabled(boolean cellRendererManagerEnabled) {
	}

	/**
	 *  Gets the default cell renderer. This is the first cell renderer {@link #getCellRenderer(int,int)} will look for.
	 *  In the other word, if you ever set it using {@link #setDefaultCellRenderer(javax.swing.table.TableCellRenderer)},
	 *  it will be guaranteed to be used (unless subclass of it overrides {@link #getCellRenderer(int,int)} to return
	 *  something else).
	 * 
	 *  @return the default cell renderer.
	 */
	public javax.swing.table.TableCellRenderer getDefaultCellRenderer() {
	}

	/**
	 *  Sets the default cell renderer.
	 * 
	 *  @param defaultCellRenderer the default cell renderer. This renderer will be used by all cells.
	 *  @see #getDefaultCellRenderer()
	 */
	public void setDefaultCellRenderer(javax.swing.table.TableCellRenderer defaultCellRenderer) {
	}

	/**
	 *  Gets the ConverterContext at the cell.
	 * 
	 *  @param row    the row index. It is the view row index.
	 *  @param column the column index. It is the view column index.
	 *  @return the ConverterContext at the specified cell.If the model is a ContextSensitiveTableModel, it will return
	 *          getConverterContextAt method of the model after converting the column to model column index. If not, it
	 *          will return null.
	 */
	public ConverterContext getConverterContextAt(int row, int column) {
	}

	/**
	 *  Gets the EditorContext at the cell.
	 * 
	 *  @param row    the row index. It is the view row index.
	 *  @param column the column index. It is the view column index.
	 *  @return the EditorContext at the specified cell. If the model is a ContextSensitiveTableModel, it will return
	 *          getEditorContextAt method of the model after converting the column to model column index. If not, it will
	 *          return null.
	 */
	public EditorContext getEditorContextAt(int row, int column) {
	}

	/**
	 *  Gets the cell class at the cell.
	 * 
	 *  @param row    the row index. It is the view row index.
	 *  @param column the column index. It is the view column index.
	 *  @return the cell class at the specified cell. If the model is a ContextSensitiveTableModel, it will return
	 *          getCellClassAt method of the model after converting the column to model column index. If not, it will
	 *          return getColumnClass at of the model.
	 */
	public Class getCellClassAt(int row, int column) {
	}

	@java.lang.Override
	protected String convertElementToString(Object value, int row, int column) {
	}
}
