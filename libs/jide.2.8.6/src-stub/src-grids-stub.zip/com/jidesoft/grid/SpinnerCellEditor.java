/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editors that need to use JSpinner. You need to let it know what's the type of the value so
 *  that it knows to use ConverterContext to converter it to/from string so that the value can be displayed in
 *  JTextField.
 *  <p/>
 *  We registered in CellEditorManager for type Number.class to use SpinnerCellEditor if the EditorContext is {@link
 *  SpinnerCellEditor#CONTEXT}. You can also register your own type with SpinnerCellEditor. The SpinnerCellEditor also
 *  has a contractor that takes a SpinnerModel as parameter so that you can define your own spinner model. For example,
 *  instead of the step size in spinner model to be 1, you can set a SpinnerNumberModel's stepSize to .01 to make a float
 *  cell editor. See code below for an example.
 *  <code><pre>
 *  SpinnerNumberModel model = new SpinnerNumberModel();
 *  model.setValue(new Float(0));
 *  model.setStepSize(0.01f);
 *  SpinnerCellEditor floatCellEditor = new SpinnerCellEditor(model);
 *  </pre></code>
 */
public class SpinnerCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor {
 {

	public static EditorContext CONTEXT;

	protected javax.swing.JSpinner _spinner;

	/**
	 *  Creates a CellEditor using JSpinner.
	 */
	public SpinnerCellEditor() {
	}

	public SpinnerCellEditor(javax.swing.SpinnerModel model) {
	}

	protected void customizeSpinner() {
	}

	/**
	 *  Creates a JSpinner used by the cell editor. Subclass can override it to return other type of JSpinner or further
	 *  customize the JSpinner before returning it.
	 * 
	 *  @param model the spinner model
	 *  @return a text field.
	 */
	protected javax.swing.JSpinner createSpinner(javax.swing.SpinnerModel model) {
	}

	public Object getCellEditorValue() {
	}

	public void setCellEditorValue(Object value) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	/**
	 *  Gets the spinner that is used as the cell editor.
	 * 
	 *  @return the spinner.
	 */
	public javax.swing.JSpinner getSpinner() {
	}
}
