/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The interface indicates the class who extends it can support EditorContext.
 * 
 *  @see EditorContext
 */
public interface EditorContextSupport {

	/**
	 *  Sets the editor context.
	 * 
	 *  @param context editor context
	 */
	public void setEditorContext(EditorContext context);

	/**
	 *  Gets the editor context.
	 * 
	 *  @return editor context
	 */
	public EditorContext getEditorContext();
}
