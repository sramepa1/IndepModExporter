/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A <code>TableHeaderPopupMenuCustomizer</code> to add menu items related to show or hide the columns to a popup menu.
 *  To use it, you can use the code like this. Please be noted that if you are going to install these menu items for
 *  AggregateTable, please use AggregateTableColumnChooserPopupMenuCustomizer instead.
 *  <code><pre>
 *  TableHeaderPopupMenuInstaller installer = new TableHeaderPopupMenuInstaller(aggregateTable)
 *  installer.addTableHeaderPopupMenuCustomizer(new TableColumnChooserPopupMenuCustomizer());
 *  </pre></code>
 */
public class TableColumnChooserPopupMenuCustomizer implements TableHeaderPopupMenuCustomizer {
 {

	/**
	 *  client property used to pass clicking column index to ActionListener
	 */
	public static final String CLIENT_PROPERTY_CLICK_COLUMN_INDEX = "TableColumnChooser.clickColumnIndex";

	/**
	 *  CONTEXT_MENU_... are the possible menu names displayed in the menu. You can use these string as name to locate
	 *  the existing menu items.
	 * 
	 *  @see #customizePopupMenu(javax.swing.table.JTableHeader, javax.swing.JPopupMenu, int)
	 */
	public static final String CONTEXT_MENU_HIDE = "TableColumnChooser.hide";

	public static final String CONTEXT_MENU_SHOW_ALL = "TableColumnChooser.showAll";

	public static final String CONTEXT_MENU_OTHER_COLUMNS = "TableColumnChooser.otherColumns";

	public static final String CONTEXT_MENU_RESET_COLUMNS = "TableColumnChooser.resetColumns";

	public static final String CONTEXT_MENU_MORE = "TableColumnChooser.more";

	protected java.util.Locale _locale;

	public TableColumnChooserPopupMenuCustomizer() {
	}

	/**
	 *  Gets the display column names set by {@link #setDisplayColumnNames(String[])}.
	 * 
	 *  @return the column names displayed on the popup menu. Or null if the setter is never called. In this case,
	 *          TableModel#getColumnName will be used to get the name and display on the popup menu.
	 */
	public String[] getDisplayColumnNames() {
	}

	/**
	 *  This method can be used to specify what column names to display on the popup menu. The value for it is of type
	 *  String[]. The length of the array should be the same as the table model's column count. Each item in the array
	 *  represents one column as in the order of the table model. If you didn't call this method,
	 *  TableModel#getColumnName will be used to get the name and display on the popup menu.
	 * 
	 *  @param displayColumnNames the display column names on the table model.
	 */
	public void setDisplayColumnNames(String[] displayColumnNames) {
	}

	/**
	 *  Gets the hidden columns. The hidden columns will not appear in the popup so that user can not show or hide those
	 *  columns. Please note, it doesn't mean the columns should be hidden on the table.
	 * 
	 *  @return the hidden columns.
	 */
	public int[] getHiddenColumns() {
	}

	/**
	 *  Sets the hidden columns. The hidden columns will not appear in the popup so that user can not show or hide those
	 *  columns. Please note, it doesn't mean the columns should be hidden on the table. It is an int array. Each int is
	 *  a column index as in the table model.
	 * 
	 *  @param hiddenColumns the hidden column indices.
	 */
	public void setHiddenColumns(int[] hiddenColumns) {
	}

	/**
	 *  Gets the fixed columns. The fixed columns will appear on the popup but as a disabled menu item so that user can
	 *  not show or hide those columns.
	 * 
	 *  @return the fixed columns.
	 */
	public int[] getFixedColumns() {
	}

	/**
	 *  Sets the fixed columns. The fixed columns will appear on the popup but as a disabled menu item so that user can
	 *  not show or hide those columns. It is an int array. Each int is a column index as in the table model.
	 * 
	 *  @param fixedColumns the hidden column indices.
	 */
	public void setFixedColumns(int[] fixedColumns) {
	}

	/**
	 *  Gets the favorite columns. The favorite columns will appear directly on the popup. And all non-favorite columns
	 *  will appear as a sub-menu so that the main popup is not so crowded with too many menu items.
	 * 
	 *  @return the favorite columns.
	 */
	public int[] getFavoriteColumns() {
	}

	/**
	 *  Sets the favorite columns. The favorite columns will appear directly on the popup. And all non-favorite columns
	 *  will appear as a sub-menu so that the main popup is not so crowded with too many menu items. If you don't call
	 *  this method, all columns will be treated as favorite columns which means they will be shown directly on the
	 *  popup.
	 * 
	 *  @param favoriteColumns the hidden column indices.
	 */
	public void setFavoriteColumns(int[] favoriteColumns) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grid.properties that begin with "TableColumnChooser.".
	 * 
	 *  @param key the resource string key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Gets the display column name to be displayed on the popup menu.
	 * 
	 *  @param table       the table
	 *  @param columnIndex the column index as in table model.
	 *  @return the display name for the column at the specified column index.
	 */
	protected String getDisplayColumnName(javax.swing.JTable table, int columnIndex) {
	}

	/**
	 *  Gets the identifier of the column.
	 * 
	 *  @param table       the table
	 *  @param columnIndex the column index as in table model.
	 *  @return the identifier at the specified column index.
	 */
	protected Object getIdentifier(javax.swing.JTable table, int columnIndex) {
	}

	/**
	 *  The method generates the context menu items by clickingColumn. After the process, the popup will contain all the
	 *  generated menu items. You can override the method to add some new menu items or delete some existing menu items
	 *  as you wish. You can use CONTEXT_MENU_... as the name to find the existing menu items.
	 *  <code><pre>
	 *       for (int i = 0; i < popup.getComponentCount(); i++) {
	 *           if (CONTEXT_MENU_HIDE.equals(popup.getComponent(i).getName())) {
	 *               popup.remove(popup.getComponent(i));
	 *           }
	 *       }
	 *  </pre></code>
	 * 
	 *  @param header         the table header
	 *  @param popup          the popup menu to be displayed
	 *  @param clickingColumn the column index clicked
	 */
	public void customizePopupMenu(javax.swing.table.JTableHeader header, javax.swing.JPopupMenu popup, int clickingColumn) {
	}

	/**
	 *  Create TableColumnChooserDialog instance while you choose "More..." option. By default, the dialog shows a CheckBoxList
	 *  of current column name for you to choose. You can override this method to change the layout of the dialog.
	 * 
	 *  @param owner the owner of the dialog
	 *  @param title the title of the dialog
	 *  @param table the JTable related to the dialog
	 *  @return a TableColumnChooserDialog instance.
	 */
	protected TableColumnChooserDialog createTableColumnChooserDialog(java.awt.Window owner, String title, javax.swing.JTable table) {
	}

	protected int getColumnCount(javax.swing.JTable table) {
	}

	protected void showAllColumns(javax.swing.JTable table) {
	}

	/**
	 *  Calls to TableColumnChooser.hideColumn to hide the column.
	 * 
	 *  @param table       the table
	 *  @param columnIndex the model column index.
	 */
	protected void hideColumn(javax.swing.JTable table, int columnIndex) {
	}

	/**
	 *  Calls to TableColumnChooser.showColumn to show the column.
	 * 
	 *  @param table       the table
	 *  @param columnIndex the model column index.
	 */
	protected void showColumn(javax.swing.JTable table, int columnIndex) {
	}
}
