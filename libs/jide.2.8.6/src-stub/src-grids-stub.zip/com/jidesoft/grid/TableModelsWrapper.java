/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableModelsWrapper</code> is a wrapper around several table models which are all referred
 *  as the actual table model or underlying table model. It can be used to provide a
 *  union view of several actual models. A typical use case is <code>JoinTableModel</code>.
 */
public interface TableModelsWrapper {

	/**
	 *  Gets the underlying table models. This is used in case a table model wraps several table models.
	 *  Then we have to ask each cell where the data is coming from.
	 * 
	 *  @param row    the row index.
	 *  @param column column index.
	 *  @return the underlying table models.
	 */
	public javax.swing.table.TableModel getActualModel(int row, int column);
}
