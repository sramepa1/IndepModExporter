/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The default implementation of RowTableModelWrapper.
 */
public class DefaultTableModelWrapper extends TableModelWrapperImpl implements IndexedRowTableModelWrapper {
 {

	protected int[] _indexes;

	/**
	 *  Creates a DefaultTableModelWrapper from any table model.
	 * 
	 *  @param model the actual table model.
	 */
	public DefaultTableModelWrapper(javax.swing.table.TableModel model) {
	}

	/**
	 *  Gets the actual row.
	 * 
	 *  @param row the row on the UI.
	 *  @return the actual row in the actual model. It will throw IllegalArgumentException if the row is out of range.
	 */
	public synchronized int getActualRowAt(int row) {
	}

	/**
	 *  Gets the visual row.
	 * 
	 *  @param actualRow the actual row in actual model.
	 *  @return the row on UI. -1 if cannot find the row.
	 */
	public synchronized int getVisualRowAt(int actualRow) {
	}

	@java.lang.Override
	public Object getValueAt(int row, int column) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int row, int column) {
	}

	@java.lang.Override
	public synchronized int getRowCount() {
	}

	@java.lang.Override
	public boolean isCellEditable(int row, int column) {
	}

	/**
	 *  Gets the converter context of the underlying table model. This will return a valid value only if underlying table
	 *  model is instance of <code>ContextSensitiveTableModel</code>. If not, it will return null.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return converter context of the underlying table model.
	 */
	@java.lang.Override
	public ConverterContext getConverterContextAt(int row, int column) {
	}

	/**
	 *  Gets the editor context of the underlying table model. This will return a valid value only if underlying table
	 *  model is instance of <code>ContextSensitiveTableModel</code>. If not, it will return null.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return editor context of the underlying table model.
	 */
	@java.lang.Override
	public EditorContext getEditorContextAt(int row, int column) {
	}

	/**
	 *  Gets the cell class of the underlying table model. This will return a valid value only if underlying table model
	 *  is instance of <code>ContextSensitiveTableModel</code>. If not, it will return underlying model's
	 *  getColumnClass(column).
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return cell class of the underlying table model.
	 */
	@java.lang.Override
	public Class getCellClassAt(int row, int column) {
	}

	/**
	 *  Checks if underlying table model row count changed.
	 * 
	 *  @return true if row count changed.
	 */
	public boolean isRowCountChanged() {
	}

	/**
	 *  Resets the index mapping.
	 */
	protected synchronized void reallocateIndexes() {
	}

	/**
	 *  Gets the indexes that maps from the visual row index to the actual row index. It will return a clone of the index
	 *  array, not the actual array that is being used.
	 * 
	 *  @return the indexes.
	 */
	public synchronized int[] getIndexes() {
	}

	/**
	 *  Sets the indexes of the row mapping. We exposed this method to allow quick access to the underlying indexes. The
	 *  method won't fire any table events. So once you change the indexes, you need to fire corresponding table event so
	 *  that table can update itself.
	 * 
	 *  @param indexes the new index array.
	 */
	public synchronized void setIndexes(int[] indexes) {
	}

	/**
	 *  Checks if cache is enabled. If cache is enabled, it will create another int array to keep the reverse indexes.
	 *  This will dramatically improve the speed of getRowAt().
	 * 
	 *  @return true if cache is enabled. Otherwise false.
	 */
	public boolean isCacheEnabled() {
	}

	/**
	 *  Enables or disables the cache. If cache is enabled, it will create another int array to keep the reverse indexes.
	 *  This will dramatically improve the speed of getRowAt(). However this performance only works when the values in
	 *  the index array map exactly with the indices themselves. For example, {2, 0, 1} can be cached but {3, 0, 1}
	 *  cannot because 3 is out of the index array's length. Because of this limitation, the only table model wrapper
	 *  will benefit from this is the SortableTableModel. FilterableTableModel and most likely all other table model
	 *  wrappers won't benefit from it. So we only turned this on for SortableTableModel.
	 *  <p/>
	 *  By default, the cache is disabled as it only makes sense to cache in the case of the SortableTableModel.
	 * 
	 *  @param cacheEnabled true or false.
	 */
	public void setCacheEnabled(boolean cacheEnabled) {
	}

	/**
	 *  Tells the TableModeWrapper that indexes is going to be changed. It will basically fire an INDEX_CHANGING_EVENT
	 *  event.
	 *  @return the event serial number for this call, to be used in its partner fireIndexChanged
	 */
	protected int fireIndexChanging() {
	}

	/**
	 *  Tells the TableModeWrapper that indexes is changed. It will basically fire an INDEX_CHANGED_EVENT event.
	 * 
	 *  @param eventSerialNumber the serial number indicating where this method is invoked, to be pair with
	 *                           fireIndexChanging
	 */
	@java.lang.Override
	protected void fireIndexChanged(int eventSerialNumber) {
	}

	/**
	 *  Gets cell span of the underlying table model.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index.
	 *  @return cell span of the underlying table model.
	 */
	@java.lang.Override
	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Called each time one or more contiguous rows are inserted into the underlying <code>TableModel</code>. This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was inserted
	 *  @param lastRow  the index of the last row that was inserted
	 */
	@java.lang.Override
	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time one or more contiguous rows are deleted from the underlying <code>TableModel</code>. This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was deleted
	 *  @param lastRow  the index of the last row that was deleted
	 */
	@java.lang.Override
	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time one or more contiguous rows are updated in the underlying <code>TableModel</code>. simply fires
	 *  a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was updated
	 *  @param lastRow  the index of the last row that was updated
	 */
	@java.lang.Override
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time the cells in <code>column</code> in the range [<code>firstRow</code>, <code>lastRow</code>] are
	 *  updated. This default implementation simply fires a corresponding <code> TableModelEvent</code> to the listeners
	 *  on this model.
	 * 
	 *  @param column   the index of the column that was updated
	 *  @param firstRow the index of the first row in the above <code> column</code> that was updated
	 *  @param lastRow  the index of the last row in the above <code> column</code> that was updated
	 */
	@java.lang.Override
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	/**
	 *  Called each time all of the data (i.e. all rows) is changed in the underlying<code>TableModel</code>.  This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 */
	@java.lang.Override
	protected void tableDataChanged() {
	}

	/**
	 *  Called each time the structure (<code>TableColumn</code>s, etc) of the underlying <code>TableModel</code>
	 *  changes. This default implementation simply fires a corresponding <code>TableModelEvent </code> to the listeners
	 *  on this model.
	 */
	@java.lang.Override
	protected void tableStructureChanged() {
	}
}
