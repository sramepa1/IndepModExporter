/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The basic data for each row in PropertyTable. The main function of this class is to be able to get/set value from/to
 *  somewhere. It is an abstract class. Users need to implementseverall methods such as getValue, setValue and hasValue.
 */
public abstract class Property extends DefaultExpandableRow implements ExpandableCell, EditorContextSupport, Comparable, java.io.Serializable {
 {

	/**
	 *  The name of the property. The name should be unique within the same property grid.
	 */
	protected String _name;

	/**
	 *  The display name of the property.
	 */
	protected String _displayName;

	/**
	 *  The description of the property.
	 */
	protected String _description;

	/**
	 *  The type of the property.
	 */
	protected Class _type;

	/**
	 *  The context of the converter.
	 */
	protected ConverterContext _converterContext;

	/**
	 *  The context of the editor.
	 */
	protected EditorContext _editorContext;

	/**
	 *  The category of the property.
	 */
	protected String _category;

	/**
	 *  true if the cell is a category row.
	 */
	protected boolean _isCategoryRow;

	/**
	 *  The "expert" flag is used to distinguish between properties that are intended for expert users from those that
	 *  are intended for normal users.
	 */
	protected boolean _expert;

	/**
	 *  The "hidden" flag is used to identify properties that are intended only for tool use, and which should not be
	 *  exposed to humans.
	 */
	protected boolean _hidden;

	/**
	 *  The "preferred" flag is used to identify properties that are particularly important for presenting to humans.
	 */
	protected boolean _preferred;

	/**
	 *  true if the property is editable.
	 */
	protected boolean _editable;

	protected ObjectConverter _converter;

	public static final String PROPERTY_NAME = "name";

	public static final String PROPERTY_DISPLAY_NAME = "displayName";

	public static final String PROPERTY_VALUE = "value";

	public static final String PROPERTY_TYPE = "type";

	public static final String PROPERTY_DESCRIPTION = "description";

	public static final String PROPERTY_DEPENDING_PROPERTIES = "dependingProperties";

	public static final String PROPERTY_CATEGORY = "category";

	public static final String PROPERTY_CONVERTER_CONTEXT = "converterContext";

	public static final String PROPERTY_EDITOR_CONTEXT = "editorContext";

	public static final String PROPERTY_EDITABLE = "editable";

	public static final String PROPERTY_EXPERT = "expert";

	public static final String PROPERTY_HIDDEN = "hidden";

	public static final String PROPERTY_PREFERRED = "preferred";

	protected boolean _indentNonCategoryRow;

	/**
	 *  Creates a Property.
	 * 
	 *  @param name            name of the property
	 *  @param description     description of the property
	 *  @param type            type of the property
	 *  @param category        which category this property belongs to
	 *  @param context         converter context used by this property
	 *  @param childProperties child properties of this property
	 */
	public Property(String name, String description, Class type, String category, ConverterContext context, java.util.List childProperties) {
	}

	/**
	 *  Creates a property if you don't need to specify child properties.
	 * 
	 *  @param name        name of the property
	 *  @param description description of the property
	 *  @param type        type of the property
	 *  @param category    which category this property belongs to
	 *  @param context     converter context used by this property
	 */
	public Property(String name, String description, Class type, String category, ConverterContext context) {
	}

	/**
	 *  Creates a property if you don't need to specify child properties and converter context.
	 * 
	 *  @param name        name of the property
	 *  @param description description of the property
	 *  @param type        type of the property
	 *  @param category    which category this property belongs to
	 */
	public Property(String name, String description, Class type, String category) {
	}

	/**
	 *  Creates a property if you don't need to specify child properties, converter context and category.
	 * 
	 *  @param name        name of the property
	 *  @param description description of the property
	 *  @param type        type of the property
	 */
	public Property(String name, String description, Class type) {
	}

	/**
	 *  Creates a property if you don't need to specify child properties, converter context, category and type.
	 * 
	 *  @param name        name of the property
	 *  @param description description of the property
	 */
	public Property(String name, String description) {
	}

	/**
	 *  Creates a property just using name. Empty string will be the description.
	 * 
	 *  @param name name of the property
	 */
	public Property(String name) {
	}

	protected Property() {
	}

	/**
	 *  Sets the value of the property. The method should call firePropertyChange(PROPERTY_VALUE, oldValue, newValue).
	 * 
	 *  @param value the new value
	 */
	public abstract void setValue(Object value) {
	}

	/**
	 *  Gets the value from the property.
	 * 
	 *  @return the value.
	 */
	public abstract Object getValue() {
	}

	/**
	 *  Checks if the property has value.
	 * 
	 *  @return if the property has value.
	 */
	public boolean hasValue() {
	}

	/**
	 *  Gets the name of the property.
	 * 
	 *  @return the name of the property
	 */
	public String getName() {
	}

	/**
	 *  Sets the name of the property.
	 * 
	 *  @param name the new name of the property
	 */
	public void setName(String name) {
	}

	/**
	 *  Gets the display name of the property. If display name is never set before, name will be used as display name.
	 * 
	 *  @return the display name of the property
	 */
	public String getDisplayName() {
	}

	/**
	 *  Sets the display name of the property.
	 * 
	 *  @param displayName the display name of the property.
	 */
	public void setDisplayName(String displayName) {
	}

	/**
	 *  Gets the description of the property.
	 * 
	 *  @return the description of the property
	 */
	public String getDescription() {
	}

	/**
	 *  Sets the description of the property.
	 * 
	 *  @param description the description of the property
	 */
	public void setDescription(String description) {
	}

	/**
	 *  Gets the type of the property.
	 * 
	 *  @return the type of the property
	 */
	public Class getType() {
	}

	/**
	 *  Sets the type of the property.
	 * 
	 *  @param type the type of the property
	 */
	public void setType(Class type) {
	}

	/**
	 *  Gets the category of the property.
	 * 
	 *  @return the category of the property
	 */
	public String getCategory() {
	}

	/**
	 *  Sets the category of the property.
	 * 
	 *  @param category the category of the property
	 */
	public void setCategory(String category) {
	}

	/**
	 *  Gets the full name of the property. The getName() will return you the short name. Since the several property can
	 *  form a hierarchy so the full name will keep start from its top level parent and concat all the names together
	 *  into a "." separated string which as the full name of a property. <br> If the property doesn't have any parent,
	 *  the full name equals the name.
	 * 
	 *  @return the full name of the property
	 */
	public String getFullName() {
	}

	/**
	 *  If the property is editable.
	 * 
	 *  @return if the property is editable
	 */
	public boolean isEditable() {
	}

	/**
	 *  Sets if the property is editable.
	 * 
	 *  @param editable if the property is editable
	 */
	public void setEditable(boolean editable) {
	}

	/**
	 *  If the property is a category row. Category row is different from normal row as it likes a header row for all its
	 *  child properties and shown as gray color.
	 * 
	 *  @return if the row is category
	 */
	public boolean isCategoryRow() {
	}

	/**
	 *  Sets the property as category row.
	 * 
	 *  @param categoryRow true or false.
	 */
	public void setCategoryRow(boolean categoryRow) {
	}

	/**
	 *  Gets the level of the property. If it's category row, it always returns 0. If not, property with no parent is
	 *  level 0 and all its children has level 1, etc.
	 * 
	 *  @return the level
	 */
	@java.lang.Override
	public int getLevel() {
	}

	/**
	 *  Gets the converter context.
	 * 
	 *  @return the converter context
	 */
	public ConverterContext getConverterContext() {
	}

	/**
	 *  Sets the converter context.
	 * 
	 *  @param converterContext the converter context
	 */
	public void setConverterContext(ConverterContext converterContext) {
	}

	/**
	 *  Gets the editor context.
	 * 
	 *  @return the editor context
	 */
	public EditorContext getEditorContext() {
	}

	/**
	 *  Sets the editor context.
	 * 
	 *  @param editorContext the editor context
	 */
	public void setEditorContext(EditorContext editorContext) {
	}

	/**
	 *  Gets the cell editor for this property. By default, the cell editor registered in CellEditorMangaer will be used.
	 *  User can override this method to have their own cell editor.
	 * 
	 *  @return the cell editor associate with this property.
	 */
	public javax.swing.CellEditor getCellEditor() {
	}

	/**
	 *  Gets the cell editor for this property. By default, the cell editor registered in CellEditorMangaer will be used.
	 *  User can override this method to have their own cell editor. For column 0, it will always return null.
	 * 
	 *  @param column the column index as in the table model.
	 *  @return the cell editor associate with this property.
	 */
	public javax.swing.CellEditor getCellEditor(int column) {
	}

	/**
	 *  Gets the cell renderer for this property. By default, the cell renderer registered in CellRendererMangaer will be
	 *  used. User can override this method to have their own cell renderer.
	 * 
	 *  @return the cell editor associate with this property.
	 */
	public javax.swing.table.TableCellRenderer getTableCellRenderer() {
	}

	/**
	 *  Gets the cell renderer for this property. By default, the cell renderer registered in CellRendererMangaer will be
	 *  used. User can override this method to have their own cell renderer.
	 * 
	 *  @param column the column index as in the table model
	 *  @return the cell editor associate with this property.
	 */
	public javax.swing.table.TableCellRenderer getTableCellRenderer(int column) {
	}

	/**
	 *  Gets the names of all depending properties. Depending properties are the properties whose value depending on this
	 *  property. in the case of PropertyTable, if property Foo depends on property Bar, it means when Bar value changes,
	 *  Foo will be recalculated.
	 * 
	 *  @return the list containing the names of all depending properties.
	 */
	public java.util.List getDependingProperties() {
	}

	/**
	 *  Adds a property specified by name as depending property.
	 * 
	 *  @param name the name of the property.
	 *  @return always true
	 */
	public boolean addDependingProperty(String name) {
	}

	/**
	 *  Adds several properties specified by names array as depending properties.
	 * 
	 *  @param names the names of all the properties.
	 *  @return always true.
	 */
	public boolean addDependingProperty(String[] names) {
	}

	/**
	 *  Removes the property specified by name from depending property.
	 * 
	 *  @param name the name of the property.
	 *  @return true if it is removed successfully. Otherwise false.
	 */
	public boolean removeDependingProperty(String name) {
	}

	/**
	 *  Removes all depending properties.
	 */
	public void clearDependingProperties() {
	}

	public int compareTo(Property property) {
	}

	/**
	 *  The "expert" flag is used to distinguish between those properties that are intended for expert users from those
	 *  that are intended for normal users.
	 * 
	 *  @return True if this property is intended for use by experts only.
	 */
	public boolean isExpert() {
	}

	/**
	 *  The "expert" flag is used to distinguish between properties that are intended for expert users from those that
	 *  are intended for normal users.
	 * 
	 *  @param expert True if this property is intended for use by experts only.
	 */
	public void setExpert(boolean expert) {
	}

	/**
	 *  The "hidden" flag is used to identify properties that are intended only for tool use, and which should not be
	 *  exposed to humans.
	 * 
	 *  @return True if this property should be hidden from human users.
	 */
	public boolean isHidden() {
	}

	/**
	 *  The "hidden" flag is used to identify properties that are intended only for tool use, and which should not be
	 *  exposed to humans.
	 * 
	 *  @param hidden True if this property should be hidden from human users.
	 */
	public void setHidden(boolean hidden) {
	}

	/**
	 *  The "preferred" flag is used to identify properties that are particularly important for presenting to humans.
	 * 
	 *  @return True if this property should be preferentially shown to human users.
	 */
	public boolean isPreferred() {
	}

	/**
	 *  The "preferred" flag is used to identify properties that are particularly important for presenting to humans.
	 * 
	 *  @param preferred True if this property should be preferentially shown to human users.
	 */
	public void setPreferred(boolean preferred) {
	}

	/**
	 *  Checks if the non-category row should indent. By default there is no indent of first level non-category row.
	 * 
	 *  @return true if non category row should indent.
	 */
	public boolean isIndentNonCategoryRow() {
	}

	/**
	 *  Sets if first level non-category row indent from category row. By default the first level non-category row has
	 *  the same indent as category row. We do this because we want to save the space.
	 * 
	 *  @param indent true or false.
	 */
	public void setIndentNonCategoryRow(boolean indent) {
	}

	public Object getValueAt(int columnIndex) {
	}
}
