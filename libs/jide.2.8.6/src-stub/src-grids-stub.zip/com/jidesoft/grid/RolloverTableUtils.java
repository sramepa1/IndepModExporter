/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class RolloverTableUtils {

	public static final String CLIENT_PROPERTY_ROLLOVER_MOUSE_LISTENER = "RolloverTableUtils.rolloverMouseListener";

	public RolloverTableUtils() {
	}

	public static void install(javax.swing.JTable table) {
	}

	public static void uninstall(javax.swing.JTable table) {
	}

	public static void prepareCellEditorComponent(java.awt.Component component, javax.swing.JTable table, int row, int column) {
	}
}
