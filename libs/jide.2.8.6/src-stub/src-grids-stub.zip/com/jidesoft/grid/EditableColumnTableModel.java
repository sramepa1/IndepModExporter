/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>EditableColumnTableModel</code> is am interface supports editable table column.
 *  You can implement this interface on your table model and <code>EditableTableHeader</code>
 *  will use it to decide which column is editable and what cell editor to use.
 */
public interface EditableColumnTableModel {

	/**
	 *  Checks if the column at the specified <code>columnIndex</code> is editable.
	 * 
	 *  @param columnIndex the column index
	 *  @return true if the column should be editable. Otherwise false.
	 */
	public boolean isColumnHeaderEditable(int columnIndex);

	/**
	 *  Gets the column header cell editor.
	 * 
	 *  @param columnIndex the column index
	 *  @return the column header cell editor. Returns null if you want to use the default cell editor registered on <code>EditableTableHeader</code>.
	 */
	public javax.swing.table.TableCellEditor getColumnHeaderCellEditor(int columnIndex);
}
