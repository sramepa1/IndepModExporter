/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Number.
 */
public class NumberCellEditor extends TextFieldCellEditor {

	public NumberCellEditor() {
	}

	public NumberCellEditor(Class clazz) {
	}

	@java.lang.Override
	protected void customizeTextField() {
	}

	public Number getMinInclusive() {
	}

	public void setMinInclusive(Number minInclusive) {
	}

	public Number getMaxInclusive() {
	}

	public void setMaxInclusive(Number maxInclusive) {
	}

	public Number getMinExclusive() {
	}

	public void setMinExclusive(Number minExclusive) {
	}

	public Number getMaxExclusive() {
	}

	public void setMaxExclusive(Number maxExclusive) {
	}

	public int getTotalDigits() {
	}

	public void setTotalDigits(int totalDigits) {
	}

	public int getFractionlDigits() {
	}

	public void setFractionlDigits(int fractionlDigits) {
	}
}
