/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableShrinkSearchableSupport</code> is a subclass of <code>ShrinkSearchableSupport</code> to make <code>TableSearchable</code>
 *  shrinkable while searching.
 */
public class TableShrinkSearchableSupport extends ShrinkSearchableSupport {

	public TableShrinkSearchableSupport(Searchable searchable) {
	}

	public void installFilterableModel() {
	}

	public void uninstallFilterableModel() {
	}

	protected void applyFilter(String searchingText) {
	}

	protected int getActualIndexAt(int viewIndex) {
	}

	protected int getVisualIndexAt(int actualIndex) {
	}
}
