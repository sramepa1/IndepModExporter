/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableRowModel</code> in an interface that implements both <code>RowModel</code> and <code>TableModel</code>.
 */
public interface TableRowModel extends RowModel, javax.swing.table.TableModel {
 {
}
