/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A <code>Filter</code> that uses filters away all values that are not in the object array.
 */
public class MultipleValuesFilter extends AbstractTableFilter implements com.jidesoft.filter.SqlFilterSupport {
 {

	/**
	 *  Creates MultipleValuesFilter.
	 * 
	 *  @param values the values that will not be filtered
	 */
	public MultipleValuesFilter(Object[] values) {
	}

	/**
	 *  Creates MultipleValuesFilter.
	 * 
	 *  @param name   name of the filter
	 *  @param values the values that will not be filtered
	 */
	public MultipleValuesFilter(String name, Object[] values) {
	}

	public boolean isValueFiltered(Object value) {
	}

	public ObjectGrouper getObjectGrouper() {
	}

	public void setObjectGrouper(ObjectGrouper objectGrouper) {
	}

	/**
	 *  Sets the only allowed value.
	 * 
	 *  @return the only allowed value.
	 */
	public Object[] getValues() {
	}

	/**
	 *  Sets the allowed values.
	 * 
	 *  @param values the allowed values.
	 */
	public void setValues(Object[] values) {
	}

	@java.lang.Override
	public String getName() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return TRUE if all value in this filter are also in the input filter. Otherwise false.
	 */
	public boolean stricterThan(com.jidesoft.filter.Filter inputFilter) {
	}

	/**
	 *  Gets the operator. It will return " IN " by default.
	 * 
	 *  @return the operator.
	 */
	public String getOperator() {
	}
}
