/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableScrollPane</code> is a special <code>JideScrollPane</code> that supports header and footer columns or
 *  rows. <code>JScrollPane</code> supports adding a component to top area and west area. <code>JideScrollPane</code>
 *  added the support to east area and bottom area. <code>TableScrollPane</code> further enhances it to handle the
 *  special case of table to allow you easily add header column(s), footer column(s), and footer to your table.
 *  <p/>
 *  To use it, you need to create a <code>MultiTableModel</code> instance first. Defining <code>MultiTableModel</code> is
 *  the same as defining TableModel except you can specify which columns are header and footer.
 *  <p/>
 *  After you create <code>MultiTableModel</code>, just pass it in to the constructor of TableScrollPane. You have an
 *  option to specify if the table is sortable. You also have an option to specify a table model for footer row. The
 *  table created from footer table model will appear at the bottom of the table and scroll horizontally along with the
 *  table above. The footer table model must have the same column count as the MultiTableModel excluding header and
 *  footer columns.
 *  <p/>
 *  Even though header columns and footer columns are added as separate components, they will work just like in one
 *  table. For example, row selection is synchronized. Tab key or left/right arrows will navigate across all three
 *  tables. If you scroll vertically, all three tables will scroll together. If you resize columns in any table, even the
 *  last column of the header column table and the first column of footer column table.
 *  <p/>
 *  <b>Note for users of TableScrollPane before v1.8.6:</b>In 1.8.6 release, there is a design change in TableScrollPane.
 *  The old constructor that takes six table models as parameter is removed. The new constructors only accept one or two
 *  MultiTableModels. If you use six table model constructor, you need to refactor your code to remove the usage of it.
 * 
 *  @see com.jidesoft.swing.JideScrollPane
 *  @see MultiTableModel
 */
public class TableScrollPane extends JideScrollPane implements TableAdapter {
 {

	protected MultiTableModel _originalTableModel;

	protected MultiTableModel _originalFooterTableModel;

	protected javax.swing.JTable _mainTable;

	protected javax.swing.JTable _rowHeaderTable;

	protected javax.swing.JTable _rowFooterTable;

	protected javax.swing.JTable _columnFooterTable;

	protected javax.swing.JTable _rowHeaderColumnFooterTable;

	protected javax.swing.JTable _rowFooterColumnFooterTable;

	/**
	 *  The client property name of all the tables created by TableScrollPane. The six possible values are defined below.
	 *  The value can be retrieved by table.getClientProperty(TableScrollPane.TABLE_KEY);
	 */
	public static final String TABLE_KEY = "TableScrollPane.TableKey";

	public static final String TABLESCROLLPANE_KEY = "TableScrollPane.Parent";

	public static final String MAIN_TABLE = "TableScrollPane.MainTable";

	public static final String ROWHEADER_TABLE = "TableScrollPane.RowHeaderTable";

	public static final String ROWFOOTER_TABLE = "TableScrollPane.RowFooterTable";

	public static final String COLUMNFOOTER_TABLE = "TableScrollPane.ColumnFooterTable";

	public static final String ROWHEADER_COLUMNFOOTER_TABLE = "TableScrollPane.RowHeaderColumnFooterTable";

	public static final String ROWFOOTER_COLUMNFOOTER_TABLE = "TableScrollPane.RowFooterColumnFooterTable";

	public static final String PROPERTY_TABLE_MODEL = "tableModel";

	/**
	 *  By default we will try to automatically update footer table when main table column is added, removed or moved. If
	 *  you want to handle the update yourself and don't want this auto-update to happen, you can call
	 *  getMainTable().putClientProperty(TableScrollPane.AUTO_UPDATE_FOOTER_TABLE_COLUMNS, Boolean.FALSE).
	 */
	public static final String AUTO_UPDATE_FOOTER_TABLE_COLUMNS = "TableScrollPane.AutoUpdateFooterTableColumns";

	/**
	 *  True if row selection is allowed in this table scroll pane.
	 */
	protected boolean _rowSelectionAllowed;

	/**
	 *  True if column selection is allowed in this table.
	 */
	protected boolean _columnSelectionAllowed;

	/**
	 *  True if non-contiguous selection is allowed in this table.
	 */
	protected boolean _nonContiguousCellSelectionAllowed;

	/**
	 *  Creates an empty <code>TableScrollPane</code>. You can call {@link #setTableModel(com.jidesoft.grid.MultiTableModel)}
	 *  to set a non-empty table model later.
	 */
	public TableScrollPane() {
	}

	/**
	 *  Creates a <code>TableScrollPane</code>. The tables will not be sortable.
	 * 
	 *  @param tableModel the MultiTableModel. This is the main table model that will be used to create upto three tables
	 *                    in TableScrollPane.
	 */
	public TableScrollPane(MultiTableModel tableModel) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with footer table. The tables will not be sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create upto three
	 *                          tables in TableScrollPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel footerTableModel) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create upto three
	 *                          tables in TableScrollPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel footerTableModel, boolean sortable) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> without footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel the MultiTableModel. This is the main table model that will be used to create upto three tables
	 *                    in TableScrollPane.
	 *  @param sortable   if the tables will be sortable.
	 */
	public TableScrollPane(MultiTableModel tableModel, boolean sortable) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create upto three
	 *                          tables in TableScrollPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 *  @param sync             if the tables will be synced. Usually you should call with sync set to true. However if
	 *                          you want to synchronize more tables which are not just in one TableScrollPane, you can
	 *                          set to false first, then call {@link com.jidesoft.grid.TableUtils#synchronizeTables(javax.swing.JTable[])}
	 *                          later.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel footerTableModel, boolean sortable, boolean sync) {
	}

	public TableScrollPane(MultiTableModel tableModel, MultiTableModel footerTableModel, boolean sortable, int tableIndex, boolean sync) {
	}

	/**
	 *  Sets the original table model and recreates all child tables.
	 * 
	 *  @param tableModel the new MultiTableModel
	 */
	public void setTableModel(MultiTableModel tableModel) {
	}

	/**
	 *  Creates a SortableTableModel or SortableTreeTableModel for the MultiTableModel if isSortable() is true.
	 *  Otherwise, tableModel itself will be returned.
	 *  <p/>
	 *  See below for the default code.
	 *  <code><pre>
	 *  TableModel actualTableModel;
	 *  if (tableModel instanceof TreeTableModel && sortable) {
	 *      actualTableModel = new SortableTreeTableModel(tableModel);
	 *  }
	 *  else if (!(tableModel instanceof ISortableTableModel) && sortable) {
	 *      actualTableModel = new SortableTableModel(tableModel);
	 *  }
	 *  else {
	 *      actualTableModel = tableModel;
	 *  }
	 *  return actualTableModel;
	 *  </pre></code>
	 * 
	 *  @param tableModel the MultiTableModel
	 *  @param sortable   true or false. If true, the tableModel should be wrapped into a SortableTableModel or
	 *                    SortableTreeTableModel.
	 *  @return a SortableTableModel or SortableTreeTableModel for the MultiTableModel if isSortable() is true.
	 */
	protected javax.swing.table.TableModel createSortableTableModel(MultiTableModel tableModel, boolean sortable) {
	}

	/**
	 *  Gets the original table model that is passed in constructors. It is the same as {@link #getModel()}.
	 * 
	 *  @return the original table model.
	 */
	public MultiTableModel getTableModel() {
	}

	/**
	 *  Gets the original table model that is passed in constructors. It is the same as {@link #getTableModel()}.
	 * 
	 *  @return the original table model.
	 */
	public MultiTableModel getModel() {
	}

	public void setFooterTableModel(MultiTableModel footerTableModel) {
	}

	public MultiTableModel getFooterTableModel() {
	}

	public boolean isSortable() {
	}

	public void setSortable(boolean sortable) {
	}

	/**
	 *  Customizes the table created by TableScrollPane. All tables has client property setup to identify. You can call
	 *  getClientProperty(TABLE_KEY) to find what table it is. The values are defined as {@link #MAIN_TABLE}, {@link
	 *  #ROWHEADER_TABLE}, {@link #ROWFOOTER_TABLE}, {@link #COLUMNFOOTER_TABLE}, {@link #ROWHEADER_COLUMNFOOTER_TABLE},
	 *  and {@link #ROWFOOTER_COLUMNFOOTER_TABLE}.
	 * 
	 *  @param table the child table
	 */
	protected void customizeTable(javax.swing.JTable table) {
	}

	/**
	 *  The main table. This is a table created from MultiTableModel's non-header and non-footer columns.
	 * 
	 *  @return the main table.
	 */
	public javax.swing.JTable getMainTable() {
	}

	/**
	 *  The row header table. This is a table created from MultiTableModel's header columns.
	 * 
	 *  @return the row header table.
	 */
	public javax.swing.JTable getRowHeaderTable() {
	}

	/**
	 *  The row footer table. This is a table created from MultiTableModel's footer columns.
	 * 
	 *  @return the row footer table.
	 */
	public javax.swing.JTable getRowFooterTable() {
	}

	/**
	 *  The column footer table. This is a table created from footerTableModel, the second parameter of TableScrollPane's
	 *  constructor.
	 * 
	 *  @return the column footer table.
	 */
	public javax.swing.JTable getColumnFooterTable() {
	}

	/**
	 *  Gets the row header of the column footer table.
	 * 
	 *  @return the row header of column footer table.
	 */
	public javax.swing.JTable getRowHeaderColumnFooterTable() {
	}

	/**
	 *  Gets the row footer of the column footer table.
	 * 
	 *  @return the row header of column footer table.
	 */
	public javax.swing.JTable getRowFooterColumnFooterTable() {
	}

	/**
	 *  @param model      the table model
	 *  @param sortable   if the table is sortable
	 *  @param type       the table type
	 *  @param tableIndex the table index
	 *  @return the created table.
	 * 
	 *  @deprecated We added a footer parameter to the createTable method. This method was left here for backward
	 *              compatible reason. Please change your code to override {@link #createTable(javax.swing.table.TableModel,
	 *              boolean, int)}  instead.
	 */
	@java.lang.Deprecated
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model, boolean sortable, int type, int tableIndex) {
	}

	/**
	 *  Creates the table. <code>TableScrollPane</code> will use this method to create all table instances.
	 *  <p/>
	 *  Please be noted that it is highly NOT recommended to override this method although you could do that. The reason
	 *  is that we did some client property registrations and some default setting here. So if you override this method
	 *  without taking care of that part, you will find the behavior of your new TableScrollPane is not as you are
	 *  actually expecting.
	 *  <p/>
	 *  If you want to create an instance with different table class, please try override {@link
	 *  #createTable(javax.swing.table.TableModel, boolean, int)} or {@link #createTable(javax.swing.table.TableModel,
	 *  boolean)}. If you will create different table classes for header table and main table, you would have to override
	 *  the first one, which has type as one of its three parameters. If you will create the same table class for every
	 *  table in your TableScrollPane, you could just override the second one with only two parameters.
	 *  <p/>
	 *  If you want to configure the tables which ares already created, please override {@link #getTableCustomizer()} to
	 *  create your own table customizer. You can refer our <code>TableScrollPaneDemo</code> for the details.
	 *  <p/>
	 *  Below is the default client property registrations and settings in this method. If you decided to override this
	 *  one, please also consider add those lines in.
	 *  <pre><code>
	 *  String tableKey = null;
	 *  switch (type) {
	 *      case MultiTableModel.REGULAR_COLUMN:
	 *          tableKey = columnFooter ? COLUMNFOOTER_TABLE : MAIN_TABLE;
	 *          break;
	 *      case MultiTableModel.HEADER_COLUMN:
	 *         tableKey = columnFooter ? ROWHEADER_COLUMNFOOTER_TABLE : ROWHEADER_TABLE;
	 *          break;
	 *      case MultiTableModel.FOOTER_COLUMN:
	 *          tableKey = columnFooter ? ROWFOOTER_COLUMNFOOTER_TABLE : ROWFOOTER_TABLE;
	 *          break;
	 *  }
	 *  table.putClientProperty(TABLE_KEY, tableKey);
	 *  table.putClientProperty(TableSplitPane.TABLE_INDEX, tableIndex);
	 *  table.putClientProperty(TABLESCROLLPANE_KEY, this);
	 *  table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	 *  if (table instanceof SortableTable) {
	 *      ((SortableTable) table).setSortable(sortable);
	 *  }
	 *  return table;
	 *  </code></pre>
	 * 
	 *  @param model        the table model.
	 *  @param sortable     if the table is sortable.
	 *  @param type         the valid values are {@link com.jidesoft.grid.MultiTableModel#REGULAR_COLUMN}, {@link
	 *                      com.jidesoft.grid.MultiTableModel#HEADER_COLUMN} and {@link com.jidesoft.grid.MultiTableModel#FOOTER_COLUMN}
	 *  @param columnFooter true if the table is for a column footer. Otherwise false.
	 *  @param tableIndex   the index of the table. THe value is returned from {@link com.jidesoft.grid.MultiTableModel#getTableIndex(int)}
	 *                      method.
	 *  @return the table.
	 */
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model, boolean sortable, int type, boolean columnFooter, int tableIndex) {
	}

	/**
	 *  Creates the table. Please consider override this method if you want to have your other tables implementing more
	 *  than just SortableTable. However, if you just want to configure the table it creates, please consider override
	 *  {@link #getTableCustomizer()}.
	 *  <p/>
	 *  The default implementation of this method is like below:
	 *  <code><pre>
	 *  return createTable(model, sortable);
	 *  </pre></code>
	 *  <p/>
	 *  As you can see at that method, it will return a SortableTable by default. If you want to use another table such
	 *  as TreeTable, you can override this method and use parameters type and table Index to determine it is row header
	 *  table, then return a TreeTable instead.
	 * 
	 *  @param model    the table model
	 *  @param sortable true or false.
	 *  @param type     the valid values are {@link com.jidesoft.grid.MultiTableModel#REGULAR_COLUMN}, {@link
	 *                  com.jidesoft.grid.MultiTableModel#HEADER_COLUMN} and {@link com.jidesoft.grid.MultiTableModel#FOOTER_COLUMN}
	 *  @return a table.
	 */
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model, boolean sortable, int type) {
	}

	/**
	 *  Creates the table. You can override this method or {@link #createTable(javax.swing.table.TableModel,boolean,int,boolean,int)}
	 *  if you just want to configure the table with no intention to create your own table.
	 *  <p/>
	 *  The default implementation is like below:
	 *  <code><pre>
	 *  return new SortableTable(model);
	 *  </pre></code>
	 *  <p/>
	 *  As you can see, it will return a SortableTable by default.
	 * 
	 *  @param model    the table model
	 *  @param sortable true or false.
	 *  @return a table.
	 */
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model, boolean sortable) {
	}

	public boolean isEditing() {
	}

	public javax.swing.JTable getEditingTable() {
	}

	/**
	 *  Gets all child tables in an array. The order is getMainTable(), getRowHeaderTable(), getRowFooterTable(),
	 *  getColumnFooterTable(), getRowHeaderColumnFooterTable, and getRowFooterColumnFooterTable. To tell which table is
	 *  which, you can use table.getClientProperty(TableScrollPane.TABLE_KEY) which will tell you the type of the table.
	 *  For example, if it returns TableScrollPane.MAIN_TABLE, it means the table is the main table.
	 * 
	 *  @return an array of all child tables.
	 */
	public javax.swing.JTable[] getAllChildTables() {
	}

	public javax.swing.table.TableCellEditor getCellEditor() {
	}

	/**
	 *  Removes extra columns from TableColumnModel that doesn't match with the type and tableIndex.
	 * 
	 *  @param table      the table
	 *  @param type       the table type such as REGULAR_COLUMN, FOOTER_COLUMN or HEADER_COLUMN.
	 *  @param tableIndex the table index
	 */
	protected void removeExtraColumns(javax.swing.JTable table, int type, int tableIndex) {
	}

	/**
	 *  Calls this method when getColumnType value changed in MultiTableModel.
	 */
	public void refreshColumns() {
	}

	/**
	 *  Resizes the row header table to fix the gap between the main table, if any.
	 */
	public void resizeRowHeaderTableToFit() {
	}

	/**
	 *  Gets the table customizer. It will use when create the tables used by this TableScrollPane.
	 * 
	 *  @return the table customizer.
	 */
	public TableCustomizer getTableCustomizer() {
	}

	/**
	 *  Sets the table customizer. It will use when create the tables used by this TableScrollPane.
	 * 
	 *  @param tableCustomizer the new table customizer.
	 */
	public void setTableCustomizer(TableCustomizer tableCustomizer) {
	}

	/**
	 *  Sets whether the rows in this model can be selected.
	 * 
	 *  @param rowSelectionAllowed true if this model will allow row selection
	 *  @see #getRowSelectionAllowed
	 */
	public void setRowSelectionAllowed(boolean rowSelectionAllowed) {
	}

	/**
	 *  Returns true if rows can be selected.
	 * 
	 *  @return true if rows can be selected, otherwise false
	 * 
	 *  @see #setRowSelectionAllowed
	 */
	public boolean getRowSelectionAllowed() {
	}

	/**
	 *  Sets whether the columns in this model can be selected.
	 * 
	 *  @param columnSelectionAllowed true if this model will allow column selection
	 *  @see #getColumnSelectionAllowed
	 */
	public void setColumnSelectionAllowed(boolean columnSelectionAllowed) {
	}

	/**
	 *  Returns true if columns can be selected.
	 * 
	 *  @return true if columns can be selected, otherwise false
	 * 
	 *  @see #setColumnSelectionAllowed
	 */
	public boolean getColumnSelectionAllowed() {
	}

	/**
	 *  Sets whether this table allows both a column selection and a row selection to exist simultaneously. When set, the
	 *  table treats the intersection of the row and column selection models as the selected cells. Override
	 *  <code>isCellSelected</code> to change this default behavior. This method is equivalent to setting both the
	 *  <code>rowSelectionAllowed</code> property and <code>columnSelectionAllowed</code> property of the
	 *  <code>columnModel</code> to the supplied value.
	 * 
	 *  @param cellSelectionEnabled true if simultaneous row and column selection is allowed
	 *  @see #getCellSelectionEnabled
	 */
	public void setCellSelectionEnabled(boolean cellSelectionEnabled) {
	}

	/**
	 *  Returns true if both row and column selection models are enabled. Equivalent to <code>getRowSelectionAllowed() &&
	 *  getColumnSelectionAllowed()</code>.
	 * 
	 *  @return true if both row and column selection models are enabled
	 * 
	 *  @see #setCellSelectionEnabled
	 */
	public boolean getCellSelectionEnabled() {
	}

	/**
	 *  Sets whether non-contiguous cell selection in this model can be selected. Please note, non-contiguous cell
	 *  selection is a feature in JideTable so you have to use JideTable or its subclasses in order to use this option.
	 *  Also please note, due to limitation of TableScrollPane, only one table can be selected at a time. In the other
	 *  words, you can't select a few cells in header table and a few cells in the main table.
	 * 
	 *  @param nonContiguousCellSelectionAllowed
	 *          true if this model will allow non-contiguous cell selection
	 *  @see #isNonContiguousCellSelectionAllowed
	 */
	public void setNonContiguousCellSelectionAllowed(boolean nonContiguousCellSelectionAllowed) {
	}

	/**
	 *  Returns true if non-contiguous cell selection can be selected.
	 * 
	 *  @return true if -contiguous cell selection is enabled, otherwise false
	 * 
	 *  @see #setNonContiguousCellSelectionAllowed
	 */
	public boolean isNonContiguousCellSelectionAllowed() {
	}

	protected void resynchronizeTablesSelection() {
	}

	/**
	 *  Gets the total row count of TableScrollPane.
	 * 
	 *  @return the total row count of TableScrollPane.
	 */
	public int getRowCount() {
	}

	/**
	 *  Gets the total column count of TableScrollPane.
	 * 
	 *  @return the total column count of TableScrollPane.
	 */
	public int getColumnCount() {
	}

	/**
	 *  Get the flag indicating if the TableScrollpane allow select multiple rows in different tables, including main
	 *  table and column footer table for example.
	 *  <p/>
	 *  The default setting is false, which means that if you select one row in main table, the current selection in
	 *  column footer table will be automatically cleared. You can set this flag to true if you don't like this
	 *  behavior.
	 * 
	 *  @return the flag
	 */
	public boolean isAllowMultiSelectionInDifferentTable() {
	}

	/**
	 *  Set the flag indicating if the TableScrollpane allow select multiple rows in different tables, including main
	 *  table and column footer table for example.
	 * 
	 *  @param allowMultiSelectionInDifferentTable
	 *          true if allow mutiple selection. Otherwise false.
	 */
	public void setAllowMultiSelectionInDifferentTable(boolean allowMultiSelectionInDifferentTable) {
	}

	/**
	 *  Gets the table as the specified column index.
	 * 
	 *  @param column the column index related to TableScrollPane.
	 *  @return a TablePosition. The table field in TablePosition is the child table and the column field is the
	 *          converted column index relative to the child table. The row field is always -1. Because the row index is
	 *          not specified, the table could only be the main table, the row header table or the row footer table. It
	 *          will never be one of the column footer tables.
	 */
	public TableScrollPane.TablePosition getTableAtColumn(int column) {
	}

	/**
	 *  Gets the table as the specified row index.
	 * 
	 *  @param row the row index related to TableScrollPane.
	 *  @return a TablePosition. The table field in TablePosition is the child table and the row field is the converted
	 *          row index relative to the child table. The column field is always -1. Because the column index is not
	 *          specified, the table could only be the main table or the column footer table. It will never be the row
	 *          header tables or the row footer table.
	 */
	public TableScrollPane.TablePosition getTableAtRow(int row) {
	}

	/**
	 *  Gets the table as the specified row and column index.
	 * 
	 *  @param row    the row index related to TableScrollPane.
	 *  @param column the column index related to TableScrollPane.
	 *  @return a TablePosition. The table field in TablePosition is the child table, the column field is the converted
	 *          column index relative to the child table and the row field is the converted row index relative to the
	 *          child table.
	 */
	public TableScrollPane.TablePosition getTableAtCell(int row, int column) {
	}

	/**
	 *  Returns the name of the column appearing in the view at column position <code>column</code>.
	 * 
	 *  @param column the column in the view being queried
	 *  @return the name of the column at position <code>column</code> in the view where the first column is column 0
	 */
	public String getColumnName(int column) {
	}

	/**
	 *  Returns the type of the column appearing in the view at column position <code>column</code>.
	 * 
	 *  @param column the column in the view being queried
	 *  @return the type of the column at position <code>column</code> in the view where the first column is column 0
	 */
	public Class getColumnClass(int column) {
	}

	/**
	 *  Returns the cell value at <code>row</code> and <code>column</code>.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 * 
	 *  @param row    the row whose value is to be queried
	 *  @param column the column whose value is to be queried
	 *  @return the Object at the specified cell
	 */
	public Object getValueAt(int row, int column) {
	}

	/**
	 *  Sets the value for the cell in the table model at <code>row</code> and <code>column</code>.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 *  <p/>
	 *  <code>aValue</code> is the new value.
	 * 
	 *  @param aValue the new value
	 *  @param row    the row of the cell to be changed
	 *  @param column the column of the cell to be changed
	 *  @see #getValueAt
	 */
	public void setValueAt(Object aValue, int row, int column) {
	}

	/**
	 *  Returns true if the cell at <code>row</code> and <code>column</code> is editable.  Otherwise, invoking
	 *  <code>setValueAt</code> on the cell will have no effect.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 * 
	 *  @param row    the row whose value is to be queried
	 *  @param column the column whose value is to be queried
	 *  @return true if the cell is editable
	 * 
	 *  @see #setValueAt
	 */
	public boolean isCellEditable(int row, int column) {
	}

	/**
	 *  Returns the index of the first selected row, -1 if no row is selected.
	 * 
	 *  @return the index of the first selected row
	 */
	public int getSelectedRow() {
	}

	/**
	 *  Returns the index of the first selected column, -1 if no column is selected.
	 * 
	 *  @return the index of the first selected column
	 */
	public int getSelectedColumn() {
	}

	/**
	 *  Returns the indices of all selected rows.
	 * 
	 *  @return an array of integers containing the indices of all selected rows, or an empty array if no row is
	 *          selected
	 * 
	 *  @see #getSelectedRow
	 */
	public int[] getSelectedRows() {
	}

	/**
	 *  Returns the indices of all selected columns.
	 * 
	 *  @return an array of integers containing the indices of all selected columns, or an empty array if no column is
	 *          selected
	 * 
	 *  @see #getSelectedColumn
	 */
	public int[] getSelectedColumns() {
	}

	/**
	 *  Returns the number of selected rows.
	 * 
	 *  @return the number of selected rows, 0 if no rows are selected
	 */
	public int getSelectedRowCount() {
	}

	/**
	 *  Returns the number of selected columns.
	 * 
	 *  @return the number of selected columns, 0 if no columns are selected
	 */
	public int getSelectedColumnCount() {
	}

	/**
	 *  Returns true if the specified index is in the valid range of rows, and the row at that index is selected.
	 * 
	 *  @return true if <code>row</code> is a valid index and the row at that index is selected (where 0 is the first
	 *          row)
	 */
	public boolean isRowSelected(int row) {
	}

	/**
	 *  Returns true if the specified index is in the valid range of columns, and the column at that index is selected.
	 * 
	 *  @param column the column in the column model
	 *  @return true if <code>column</code> is a valid index and the column at that index is selected (where 0 is the
	 *          first column)
	 */
	public boolean isColumnSelected(int column) {
	}

	/**
	 *  Returns true if the specified indices are in the valid range of rows and columns and the cell at the specified
	 *  position is selected.
	 * 
	 *  @param row    the row being queried
	 *  @param column the column being queried
	 *  @return true if <code>row</code> and <code>column</code> are valid indices and the cell at index <code>(row,
	 *          column)</code> is selected, where the first row and first column are at index 0
	 */
	public boolean isCellSelected(int row, int column) {
	}

	/**
	 *  Deselects all selected columns and rows.
	 */
	public void clearSelection() {
	}

	public void changeSelection(int rowIndex, int columnIndex, boolean toggle, boolean extend) {
	}

	/**
	 *  A class that define a table, a row index and a column index. This class is used by {@link
	 *  TableScrollPane#getTableAtCell(int, int)}, {@link TableScrollPane#getTableAtRow(int)} and {@link
	 *  TableScrollPane#getTableAtColumn(int)} to convert the row index and column index from the TableScrollPane to its
	 *  child tables.
	 */
	public static class TablePosition {


		public TableScrollPane.TablePosition(javax.swing.JTable table, int row, int column) {
		}

		/**
		 *  Get the table field in the class.
		 * 
		 *  @return the JTable.
		 */
		public javax.swing.JTable getTable() {
		}

		/**
		 *  Get the row in the table.
		 * 
		 *  @return the row index.
		 */
		public int getRow() {
		}

		/**
		 *  Get the column in the table.
		 * 
		 *  @return the column index.
		 */
		public int getColumn() {
		}
	}
}
