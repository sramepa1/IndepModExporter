/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is the Searchable class for JideTable when table's isNonContiguousCellSelection is true.
 *  Otherwise, {@link TableSearchable} should work just fine with JideTable.
 *  <p/>
 *  If JideTable's isNonContiguousCellSelection is true, we will assume it is cell based search. So
 *  it will search for all cells and ignore settings such as {@link #setMainIndex(int)}.
 */
public class JideTableSearchable extends TableSearchable {

	public JideTableSearchable(javax.swing.JTable table) {
	}

	protected boolean isNonContiguousCellSelection() {
	}

	@java.lang.Override
	protected void setSelectedIndex(int index, boolean incremental) {
	}

	@java.lang.Override
	protected int getSelectedIndex() {
	}

	@java.lang.Override
	protected Object getElementAt(int index) {
	}

	@java.lang.Override
	protected int getElementCount() {
	}
}
