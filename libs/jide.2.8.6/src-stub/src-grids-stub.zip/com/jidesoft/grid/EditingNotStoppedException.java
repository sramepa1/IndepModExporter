/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This exception is used to indicate the editor is not stopped in editingStopped method of
 *  JideTable. It means the getFailBehavior in ValidationResult is the ValidationResult.FAIL_BEHAVIOR_PERSIST.
 */
public class EditingNotStoppedException extends RuntimeException {

	public EditingNotStoppedException() {
	}

	public EditingNotStoppedException(String message) {
	}

	public EditingNotStoppedException(String message, Throwable cause) {
	}

	public EditingNotStoppedException(Throwable cause) {
	}

	public EditingNotStoppedException(javax.swing.CellEditor editor, ValidationResult result) {
	}

	public EditingNotStoppedException(String message, javax.swing.CellEditor editor, ValidationResult result) {
	}

	public javax.swing.CellEditor getCellEditor() {
	}

	public ValidationResult getValidationResult() {
	}
}
