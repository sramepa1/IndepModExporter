/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An abstract implements for ExpandableRow. It implements two methods in {@link Row} to achieve a read-only Row. In
 *  addition, it extends {@link AbstractExpandable} which implements most methods in {@link Expandable}.
 */
public abstract class DefaultExpandableRow extends DefaultExpandable implements ExpandableRow {
 {

	public DefaultExpandableRow() {
	}

	/**
	 *  Sets the value. The method will call cellUpdated to indicate the cell is changed.
	 * 
	 *  @param value       the new value.
	 *  @param columnIndex the column index.
	 */
	public void setValueAt(Object value, int columnIndex) {
	}

	public boolean isCellEditable(int columnIndex) {
	}

	public ConverterContext getConverterContextAt(int columnIndex) {
	}

	public EditorContext getEditorContextAt(int columnIndex) {
	}

	public Class getCellClassAt(int columnIndex) {
	}

	public void cellUpdated(int columnIndex) {
	}

	public void rowUpdated() {
	}

	public void notifyCellUpdated(Object child, int columnIndex) {
	}
}
