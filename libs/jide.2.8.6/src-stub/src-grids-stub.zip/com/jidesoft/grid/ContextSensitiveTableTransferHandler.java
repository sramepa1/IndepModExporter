/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  TransferHandler for ContextSensitiveTable. It will use the converter context information and use
 *  ObjectConverterManager to convert the value to String.
 */
public class ContextSensitiveTableTransferHandler extends javax.swing.TransferHandler {

	public ContextSensitiveTableTransferHandler() {
	}

	/**
	 *  Create a Transferable to use as the source for a data transfer.
	 * 
	 *  @param c The component holding the data to be transferred.  This argument is provided to enable sharing of
	 *           TransferHandlers by multiple components.
	 *  @return The representation of the data to be transferred.
	 */
	@java.lang.Override
	protected java.awt.datatransfer.Transferable createTransferable(javax.swing.JComponent c) {
	}

	/**
	 *  Converts the value at the specified cell to String.
	 * 
	 *  @param table       the table.
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @param value       the value
	 *  @return the converted String from the value. By default, if the table is an instance of ContextSensitiveTable and
	 *          table.getModel() is an instance of ContextSensitiveTableModel, we will use ObjectConverterManager to do
	 *          do the conversion. Otherwise, we will use value.toString() to do it.
	 */
	protected String convertElementToString(javax.swing.JTable table, int rowIndex, int columnIndex, Object value) {
	}

	@java.lang.Override
	public int getSourceActions(javax.swing.JComponent c) {
	}
}
