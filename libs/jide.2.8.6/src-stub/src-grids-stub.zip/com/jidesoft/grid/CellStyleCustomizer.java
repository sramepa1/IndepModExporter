/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This interface works with CellStyleTable to allow you to add extra non-default styles to CellStyle class and use this
 *  interface to read the style from CellStyle and customizes the renderer component or the editor component.
 */
public interface CellStyleCustomizer {

	/**
	 *  Customizes the renderer component based on the cell style.
	 * 
	 *  @param row               the row index for the renderer component.
	 *  @param column            the column index for the renderer component.
	 *  @param rendererComponent the renderer component.
	 *  @param cellStyle         the cell style.
	 */
	public void customizeRendererComponent(int row, int column, java.awt.Component rendererComponent, CellStyle cellStyle);

	/**
	 *  Releases the renderer component. This method should reset the property changed in this customizeRendererComponent
	 *  to its previous state.
	 *  <p/>
	 *  Please note, there is no releaseEditorComponent as a new editor component should be created for each cell editing
	 *  action.
	 * 
	 *  @param row               the row index for the renderer component.
	 *  @param column            the column index for the renderer component.
	 *  @param rendererComponent the renderer component.
	 */
	public void releaseRendererComponent(int row, int column, java.awt.Component rendererComponent);

	/**
	 *  Customizes the editor component based on the cell style.
	 * 
	 *  @param row             the row index for the editor component.
	 *  @param column          the column index for the editor component.
	 *  @param editorComponent the editor component.
	 *  @param cellStyle       the cell style.
	 */
	public void customizeEditorComponent(int row, int column, java.awt.Component editorComponent, CellStyle cellStyle);
}
