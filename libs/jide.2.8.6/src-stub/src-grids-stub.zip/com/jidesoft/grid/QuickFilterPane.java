/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>QuickFilterPane</code> works along with any TableModel to provide filtering feature.
 *  <p/>
 *  It is very simple to use it.
 *  <code><pre>
 *  QuickFilterPane quickFilterPane = new QuickFilterPane(new SortableTableModel(tableModel), new int[]{3, 1,
 *  2});</pre></code>
 *  Later on, when you display the table, instead using your original table model, use {@link #getDisplayTableModel()}.
 *  <code><pre>
 *  SortableTable table = new SortableTable(quickFilterPane.getDisplayTableModel());
 *  </pre></code>
 *  As you can see, the usage is the same as {@link QuickTableFilterField}. In fact, you can pass
 *  <code>quickTableFilterField.getDisplayTableModel()</code> to <code>QuickFilterPane</code> as input. Or you can take
 *  <code>quickFilterPane.getDisplayTableModel()</code> and pass it as input to <code>QuickTableFilterField</code>. You
 *  canimaginee as two pipes that connect. The input end is the raw table model. The output end is getDisplayTableModel()
 *  which you should use it to display in a JTable or SortableTable.
 *  <p/>
 *  <code>QuickFilterPane</code> has several JLists. The number of JList is determined by the length of columnIndices
 *  array. If you select an item from the list, a filter will be applied the underlying table model on corresponding
 *  column, so you will see less rows in the table as well as the following JLists. You can multiple select which will
 *  add more filters in OR relation. So just a few clicks, you can quick narrow down the table to have only the rows you
 *  are interested in.
 */
public class QuickFilterPane extends javax.swing.JPanel {

	protected IFilterableTableModel[] _models;

	protected javax.swing.JList[] _lists;

	protected final java.text.MessageFormat _allItemFormat;

	protected javax.swing.JTable _table;

	/**
	 *  Creates an empty <code>QuickFilterPane</code>. This method is useless since <code>QuickFilterPane</code> has to
	 *  have a table model in order to work correctly. So we have this method in place mainly to make it JavaBean
	 *  compatible. You must call {@link #setTableModel(javax.swing.table.TableModel)} after you create
	 *  <code>QuickFilterPane</code> using this constructor.
	 */
	public QuickFilterPane() {
	}

	/**
	 *  Creates a <code>QuickFilterPane</code> using the specified table model. Since it doesn't specify the columns to
	 *  be filtered, it will use all columns as filter columns.
	 * 
	 *  @param tableModel the table model. It could be any table model. We will automatically wrap it in
	 *                    FilterableTableModel.
	 */
	public QuickFilterPane(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Creates a <code>QuickFilterPane</code> using the specified table model and indices to the columns to be
	 *  filtered.
	 * 
	 *  @param tableModel    the table model. It could be any table model. We will automatically wrap it in
	 *                       FilterableTableModel.
	 *  @param columnIndices the indices to the columns to be filtered. You need to make sure all values in the index
	 *                       array are within the range. Otherwise, it will throw ArrayIndexOutOfBoundsException. The
	 *                       order also matters as it will determine the filter order. In the other words, it will apply
	 *                       filter to the first column index, then the second and so on.
	 *  @throws ArrayIndexOutOfBoundsException if the value in columnIndices array are out of the range of tableModel's
	 *                                         column count.
	 */
	public QuickFilterPane(javax.swing.table.TableModel tableModel, int[] columnIndices) {
	}

	/**
	 *  Creates a <code>QuickFilterPane</code> using the specified table model and indices to the columns to be
	 *  filtered.
	 * 
	 *  @param tableModel    the table model. It could be any table model. We will automatically wrap it in
	 *                       FilterableTableModel.
	 *  @param columnIndices the indices to the columns to be filtered. You need to make sure all values in the index
	 *                       array are within the range. Otherwise, it will throw ArrayIndexOutOfBoundsException. The
	 *                       order also matters as it will determine the filter order. In the other words, it will apply
	 *                       filter to the first column index, then the second and so on.
	 *  @param displayNames  the names used to label each list. If you don't specify this parameter, it will use column
	 *                       names in tableModel instead. In most cases, it should be fine.
	 *  @throws ArrayIndexOutOfBoundsException if the value in columnIndices array are out of the range of tableModel's
	 *                                         column count.
	 *  @throws IllegalArgumentException       if the length of columnIndices array is different from that of
	 *                                         displayNames array.
	 */
	public QuickFilterPane(javax.swing.table.TableModel tableModel, int[] columnIndices, String[] displayNames) {
	}

	/**
	 *  Creates the ListModel for the JList. Subclass can override this method to create their own ListModel.
	 * 
	 *  @param filterableTableModel the FilterableTableModel controlled by the JList.
	 *  @param column               the column index.
	 *  @return a ListModel. It contains all values from getPossibleValues(filterableTableModel, column) as well as (All)
	 *          as the first item.
	 */
	protected javax.swing.ListModel createListModel(IFilterableTableModel filterableTableModel, int column) {
	}

	/**
	 *  Apply filters to FilterableTableModel. This is called when the selection in the JList changes. Subclass can
	 *  override this method if they want to apply the selected values from JList to some other places. This is the only
	 *  method that a filter is added to the FilterableTableModel.
	 * 
	 *  @param list                 the list.
	 *  @param filterableTableModel the FilterableTableModel where filter will be added.
	 *  @param column               the column index.
	 */
	protected void applyFilter(javax.swing.JList list, IFilterableTableModel filterableTableModel, int column) {
	}

	/**
	 *  Gets all possible values at the specified column in the table model. By default, it will go through all rows,
	 *  find all the values in the specified column, sort them and return them as a List. Subclass can override it to
	 *  return a different list. For example, you can return the list without sorting them. Or if the list is predefined,
	 *  you can return it directly without looping through the table model. Or you can even find all possible values from
	 *  a database table.
	 * 
	 *  @param tableModel the table model
	 *  @param column     the column
	 *  @return a List of all possible values. Null value or empty string is not included.
	 */
	protected Object[] getPossibleValues(javax.swing.table.TableModel tableModel, int column) {
	}

	/**
	 *  Initialize this component.
	 */
	protected void initComponent() {
	}

	/**
	 *  Creates the list component that will be used for the quick filter.
	 * 
	 *  @param model FilterableTableModel
	 *  @param index the index of the list
	 *  @return A JList. It is a QuickFilterList by default or QuickFilterCheckBoxList is {@link
	 *          #setUseCheckBoxList(boolean)} is set to true.
	 */
	protected javax.swing.JList createQuickFilterList(IFilterableTableModel model, int index) {
	}

	/**
	 *  Creates the FilterableTableModel for the JList at the specified index. By default, it will create a
	 *  FilterableTableModel that wraps the table model passed in. You can subclass it to change the behavior. For
	 *  example if you want to do thing as http://www.jidesoft.com/forum/viewtopic.php?p=10350#10350, you can override it
	 *  and implement it as
	 *  <code><pre>
	 *  if(index == 0) {
	 *      return new FilterableTableModel(tableModel);
	 *  }
	 *  else {
	 *      return tableModel;
	 *  }
	 *  </pre></code>
	 * 
	 *  @param tableModel the table model. For the first JList, it is the the table model passed to the constructor of
	 *                    QuickFilterPane. For the following JLists, the table model is the FilterableTableModel returned
	 *                    from previous call of createFilterableTableModel.
	 *  @param index      the index of the JList.
	 *  @return FilterableTableModel.
	 */
	protected javax.swing.table.TableModel createFilterableTableModel(javax.swing.table.TableModel tableModel, int index) {
	}

	/**
	 *  Creates a component that contains all the lists.
	 * 
	 *  @param components the list of components. Each component contains a JList which is used as filter. The component
	 *                    is created by {@link #createListComponent(javax.swing.JList,String)}.
	 *  @return a component that contains all the lists. By default, it will create a JideSplitPane and add those
	 *          components into that split pane. Subclass can override to customize the layout. For example, if there are
	 *          too many lists, you can add them into a multiple-row grid layout. Or you can even add then to tabbed
	 *          pane.
	 */
	protected java.awt.Component createListsComponent(java.awt.Component[] components) {
	}

	/**
	 *  Creates a panel for the list which is used as filter for a column.
	 * 
	 *  @param list the list which is used as filter for a column.
	 *  @param name the name of the list. If you specify displayName, the name will be the display name. Otherwise, it
	 *              will be the corresponding column name.
	 *  @return a panel that contains the list. By default, the name is used in a JLabel and set as the column header of
	 *          the JList.
	 */
	protected java.awt.Component createListComponent(javax.swing.JList list, String name) {
	}

	/**
	 *  Resets the <code>QuickFilterPane</code> and selects the first row in all the lists.
	 */
	public void reset() {
	}

	/**
	 *  Updates the <code>QuickFilterPane</code> to refresh the data from the table model.
	 */
	public void update() {
	}

	/**
	 *  Gets the table model used by <code>QuickFilterPane</code>.
	 * 
	 *  @return the table model.
	 */
	public javax.swing.table.TableModel getTableModel() {
	}

	/**
	 *  Sets the table model. This method will reinitialize the component.
	 * 
	 *  @param tableModel the new table model
	 */
	public void setTableModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Gets the column indices.
	 * 
	 *  @return the column indices.
	 */
	public int[] getColumnIndices() {
	}

	/**
	 *  Sets the filter column indices. If the tableModel has been set at this point, this method will call reinitialize
	 *  the component.
	 *  <p/>
	 *  Please note, we will set the table's model to getDisplayTableModel() at the end of this method. However it won't
	 *  work if you didn't call {@link #setTable(javax.swing.JTable)} method before. If so, you just call
	 *  table.setModel(quickFilterPane.getDisplayTableModel() method yourself after the setColumnIndices call.
	 * 
	 *  @param columnIndices the indices to the columns to be filtered. You need to make sure all values in the index
	 *                       array are within the range. Otherwise, it will throw ArrayIndexOutOfBoundsException. The
	 *                       order also matters as it will determine the filter order. In the other words, it will apply
	 *                       filter to the first column index, then the second and so on.
	 *  @throws ArrayIndexOutOfBoundsException if the value in columnIndices array are out of the range of tableModel's
	 *                                         column count.
	 *  @throws IllegalArgumentException       if the length of columnIndices array is different from that of
	 *                                         displayNames array.
	 */
	public void setColumnIndices(int[] columnIndices) {
	}

	/**
	 *  Gets the label name for each list in an array.
	 * 
	 *  @return the array of labels for lists.
	 */
	public String[] getDisplayNames() {
	}

	/**
	 *  Sets the label name for each list. The name will appear as a label on top of each list.
	 * 
	 *  @param displayNames the names used to label each list. If you don't specify this parameter, it will use column
	 *                      names in tableModel instead. In most cases, it should be fine.
	 *  @throws IllegalArgumentException if the length of columnIndices array is different from that of displayNames
	 *                                   array.
	 */
	public void setDisplayNames(String[] displayNames) {
	}

	/**
	 *  Gets the display table model. <code>QuickFilterPane</code> doesn't modify the table model that you passed in but
	 *  wrap it in FilterableTableModel. So if you want to display the result after being filtered, you should use this
	 *  method to get the display table model and set it to your table.
	 * 
	 *  @return the table model to be displayed.
	 */
	public javax.swing.table.TableModel getDisplayTableModel() {
	}

	/**
	 *  Sets the preferred number of rows in the lists.
	 * 
	 *  @param visibleRowCount the new visible row count
	 */
	public void setVisibleRowCount(int visibleRowCount) {
	}

	/**
	 *  Returns the preferred number of visible rows.
	 * 
	 *  @return an integer indicating the preferred number of rows to display without using a scroll bar
	 */
	public int getVisibleRowCount() {
	}

	/**
	 *  Gets the JList at the specified index in <code>QuickFilterPane</code>. You should call this method after
	 *  <code>QuickFilterPane</code> having been initialized (after tableModel has been set).
	 * 
	 *  @param index the index.
	 *  @return the JList at the specified index in <code>QuickFilterPane</code>. It will return null if
	 *          <code>QuickFilterPane</code> has not been initialized.
	 * 
	 *  @throws IndexOutOfBoundsException if the index is less than 0 or larger than the number filtered columns.
	 */
	public javax.swing.JList getList(int index) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grid.properties that begin with "Search.".
	 * 
	 *  @param key the key for the resource string
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Gets the plural form. By default it will add "es" (if ends with "s" or "sh" or "ch") or "s" at the end of the
	 *  word since it's the most common case in English. Subclass can override it to provide the exact plural form for
	 *  the giving word if you know exactly what words will be used in your application.
	 * 
	 *  @param word the word
	 *  @return the plural form of the giving word.
	 */
	protected String getPluralForm(String word) {
	}

	/**
	 *  Gets the table where the display table model will be set.
	 * 
	 *  @return the table
	 */
	public javax.swing.JTable getTable() {
	}

	/**
	 *  Sets the table where the display table model will be set. Usually you don't need to call this method. The only
	 *  place the table could be used is at {@link #setColumnIndices(int[])} method so that you don't need to explicitly
	 *  set the display table model to the table after the call.
	 * 
	 *  @param table the table where the display table model will be set.
	 */
	public void setTable(javax.swing.JTable table) {
	}

	/**
	 *  Checks if the CheckBoxList is used as the filter JList.
	 * 
	 *  @return true or false.
	 */
	public boolean isUseCheckBoxList() {
	}

	/**
	 *  Uses the CheckBoxList as the filter JList.
	 * 
	 *  @param useCheckBoxList true to use CheckBoxList as the lists.
	 */
	public void setUseCheckBoxList(boolean useCheckBoxList) {
	}

	/**
	 *  Sets the auto-updated flag. If the flag is true, we will automatically update the JLists when the table model is
	 *  changed.
	 * 
	 *  @return true or false.
	 */
	public boolean isAutoUpdate() {
	}

	/**
	 *  Sets the autoUpdate flag. By default, this flag is true, meaning we will automatically update the JLists when the
	 *  table model is changed. However when your table model is updated very frequently, it will cause the JLists to
	 *  flicker. To avoid this problem, you can set the flag to false before the table model is updated. After the
	 *  updates are done, you set the flag back to true.
	 * 
	 *  @param autoUpdate true to update JList automatically when table model is updated.
	 */
	public void setAutoUpdate(boolean autoUpdate) {
	}

	public class QuickFilterList {


		protected javax.swing.event.TableModelListener _tableModelListener;

		protected javax.swing.event.ListSelectionListener _listSelectionListener;

		public QuickFilterPane.QuickFilterList(IFilterableTableModel tableModel, int column) {
		}

		public void updateList() {
		}

		public void reset() {
		}

		@java.lang.Override
		public int getNextMatch(String prefix, int startIndex, javax.swing.text.Position.Bias bias) {
		}

		protected void populateList() {
		}
	}

	public class QuickFilterCheckBoxList {


		protected javax.swing.event.TableModelListener _tableModelListener;

		protected javax.swing.event.ListSelectionListener _listSelectionListener;

		public QuickFilterPane.QuickFilterCheckBoxList(IFilterableTableModel tableModel, int column) {
		}

		public void updateList() {
		}

		public void reset() {
		}

		@java.lang.Override
		public int getNextMatch(String prefix, int startIndex, javax.swing.text.Position.Bias bias) {
		}

		protected void populateList() {
		}
	}
}
