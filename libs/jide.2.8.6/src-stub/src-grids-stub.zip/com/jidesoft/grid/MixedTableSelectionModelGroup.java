/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is used to create a multiple-exclusion scope for a set of Table's selectionModel so that only one
 *  table can have selected index at a time.
 *  <p/>
 *  To use this class, you just need to add the TableSelectionModel of the non-contiguous JideTable or ListSelectionModel
 *  of JTable depends on its current selection model to the group by calling {@link #add(Object)}. To remove from the
 *  group, call {@link #remove(Object)}.
 */
public class MixedTableSelectionModelGroup implements java.io.Serializable {
 {

	protected java.util.List _models;

	protected TableSelectionListener _tableSelectionListener;

	protected javax.swing.event.ListSelectionListener _listSelectionListener;

	/**
	 *  Creates a new <code>MixedTableSelectionModelGroup</code>.
	 */
	public MixedTableSelectionModelGroup() {
	}

	/**
	 *  Adds the TableSelectionModel or ListSelectionModel to the group.
	 * 
	 *  @param model the TableSelectionModel or ListSelectionModel to be added
	 */
	public void add(Object model) {
	}

	/**
	 *  Adds the TableSelectionModel or ListSelectionModel to the group.
	 * 
	 *  @param index the position
	 *  @param model the TableSelectionModel or ListSelectionModel to be added
	 */
	public void add(int index, Object model) {
	}

	/**
	 *  Removes the TableSelectionModel or ListSelectionModel from the group.
	 * 
	 *  @param model the TableSelectionModel or ListSelectionModel to be removed
	 */
	public void remove(Object model) {
	}

	/**
	 *  Returns all the TableSelectionModels or ListSelectionModels that are participating in this group.
	 * 
	 *  @return an array of all TableSelectionModels or ListSelectionModels
	 */
	public Object[] getTableModels() {
	}

	/**
	 *  Returns all the TableSelectionModels or ListSelectionModels that are participating in this group.
	 * 
	 *  @return an <code>Enumeration</code> of the selection models in this group
	 */
	public java.util.Enumeration getElements() {
	}

	/**
	 *  Returns the number of selectionModels in the group.
	 * 
	 *  @return the selectionModel count
	 * 
	 *  @since 1.3
	 */
	public int getModelCount() {
	}

	/**
	 *  Get the stay model which will not clear selection on other model's selection change.
	 *  <p/>
	 *  By default, the value is null if every table need to be synchronized. However, if you want to have a master/slave
	 *  kind of table combination, and you don't want the slave table's selection change affects the master table's selection
	 *  you can set the master table's selection model by using this method. We call it stay model.
	 * 
	 *  @return the stay model
	 */
	public Object getStayModel() {
	}

	/**
	 *  Set the stay model which will not clear selection on other model's selection change.
	 * 
	 *  @see #getStayModel()
	 *  @param stayModel the stay model
	 */
	public void setStayModel(Object stayModel) {
	}
}
