/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableHeaderPopupMenuInstaller</code> allows you to add a popup menu to table header and customize it. To use
 *  it, you just need to call
 *  <pre><code>
 *  TableHeaderPopupMenuInstaller installer = new TableHeaderPopupMenuInstaller(table);
 *  </code></pre>
 *  Or if you want to uninstall it, call
 *  <pre><code>
 *  TableHeaderPopupMenuInstaller.getTableHeaderPopupMenuInstaller(table).uninstallListeners();
 *  </code></pre>
 *  However <code>TableHeaderPopupMenuInstaller</code> has no menu items. You can use one of the existing
 *  <code>TableHeaderPopupMenuCustomizer</code>s to add more menu items or create your own
 *  <code>TableHeaderPopupMenuCustomizer</code> to do it.
 */
public class TableHeaderPopupMenuInstaller extends java.awt.event.MouseAdapter implements java.beans.PropertyChangeListener {
 {

	/**
	 *  Client property used by JTable to provide its own TableColumnPopupMenuCustomizer.
	 */
	public static final String CLIENT_PROPERTY_POPUP_MENU_INSTALLER = "TableHeaderPopupMenuInstaller";

	/**
	 *  Creates a TableColumnPopupMenuCustomizer.
	 * 
	 *  @param table the table.
	 */
	public TableHeaderPopupMenuInstaller(javax.swing.JTable table) {
	}

	public void addTableHeaderPopupMenuCustomizer(TableHeaderPopupMenuCustomizer customizer) {
	}

	public void removeTableHeaderPopupMenuCustomizer(TableHeaderPopupMenuCustomizer customizer) {
	}

	public TableHeaderPopupMenuCustomizer[] getTableHeaderPopupMenuCustomizers() {
	}

	@java.lang.Override
	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	@java.lang.Override
	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	protected javax.swing.JPopupMenu createPopupMenu() {
	}

	/**
	 *  Customizes the menu items for the popup menu.
	 * 
	 *  @param header         the table header.
	 *  @param popup          the popup menu.
	 *  @param clickingColumn the column that user right clicks.
	 */
	protected void customizeMenuItems(javax.swing.table.JTableHeader header, javax.swing.JPopupMenu popup, int clickingColumn) {
	}

	/**
	 *  Adds a separator to the popup menu if there are menu items on it already.
	 * 
	 *  @param popup the popup menu.
	 */
	public static void addSeparatorIfNecessary(javax.swing.JPopupMenu popup) {
	}

	/**
	 *  Installs the listeners needed in order to show the popup menu for the table header.
	 */
	public void installListeners() {
	}

	/**
	 *  Uninstalls the listeners needed in order to show the popup menu for the table header.
	 */
	public void uninstallListeners() {
	}

	/**
	 *  Gets the Searchable installed on the component. Null is no Searchable was installed.
	 * 
	 *  @param table the table
	 *  @return the Searchable installed. Null is no Searchable was installed.
	 */
	public static TableHeaderPopupMenuInstaller getTableHeaderPopupMenuInstaller(javax.swing.JTable table) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}
}
