/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A table header supporting nested table columns.
 */
public class NestedTableHeader extends DraggingTableHeader {

	protected java.util.Vector _columnGroups;

	public static final String PROPERTY_ORIGINAL_TABLE_HEADER_VISIBLE = "originalTableHeaderVisible";

	public NestedTableHeader(javax.swing.table.TableColumnModel model) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns a string that specifies the name of the L&F class that renders this component.
	 * 
	 *  @return the string "NestedTableHeaderUI"
	 * 
	 *  @see JComponent#getUIClassID
	 *  @see UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  Gets all the TableColumnGroups added to <code>NestedtableHeader</code> as an array.
	 * 
	 *  @return the all the TableColumnGroups as an array.
	 */
	public javax.swing.table.TableColumn[] getTableColumnGroups() {
	}

	/**
	 *  Adds a column group to table header. You only need to add the outermost table column group to table header.
	 * 
	 *  @param group TableColumnGroup to be added.
	 */
	public void addColumnGroup(TableColumnGroup group) {
	}

	/**
	 *  Removes a column group to table header.
	 * 
	 *  @param group TableColumnGroup to be removed.
	 */
	public void removeColumnGroup(TableColumnGroup group) {
	}

	/**
	 *  Removes all column groups.
	 */
	public void clearColumnGroups() {
	}

	/**
	 *  Gets the parent of the table column.
	 * 
	 *  @param column the TableColumn.
	 *  @return the parent of the table column.
	 */
	public Object getParent(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Gets an enumeration of table column groups.
	 * 
	 *  @param column the TableColumn.
	 *  @return the enumeration of the ancestors of table column.
	 */
	public java.util.Enumeration getColumnGroups(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Checks if the original table header is visible.
	 * 
	 *  @return true if visible. Otherwise false.
	 */
	public boolean isOriginalTableHeaderVisible() {
	}

	/**
	 *  Shows or hides the original table header visible. It is true by default. If you need hide the original table
	 *  header and only show the nested table header above it, you can call this method and set it to false.
	 * 
	 *  @param originalTableHeaderVisible true or false.
	 */
	public void setOriginalTableHeaderVisible(boolean originalTableHeaderVisible) {
	}

	/**
	 *  Check if the mouse point is on the original table header
	 * 
	 *  @param point mouse point
	 *  @return false if the point is on the group columns. Otherwise true.
	 */
	public boolean isMouseOnOriginalTableHeader(java.awt.Point point) {
	}

	/**
	 *  Get the corresponding TableColumnGroup in the designated row and column.
	 *  @param rowIndex the row index
	 *  @param columnIndex the column index
	 *  @return TableColumnGroup instance if it is a group. null if it is just a TableColumn or other objects.
	 */
	public TableColumnGroup getTableColumnGroup(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the row count since it has nested table header.
	 * 
	 *  @return the row count.
	 */
	public int getRowCount() {
	}

	public int getColumnCount() {
	}

	/**
	 *  Gets the cell span of the nested table header.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the cell span for the specified cell.
	 */
	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	public java.awt.Rectangle originalGetCellRect(int row, int column) {
	}

	public java.awt.Rectangle getCellRect(int row, int column) {
	}

	/**
	 *  Gets the header value at the specified cell.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the header value at the specified cell.
	 */
	public Object getHeaderValueAt(int rowIndex, int columnIndex) {
	}
}
