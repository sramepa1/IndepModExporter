/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to indicate something can be cached.
 *  See below for the default implementation. In most cases, you can copy it and put it
 *  into your code as the implementation of <code>Cacheable</code>.
 *  <p/>
 *  <code><pre>
 *      private int _filtered = INVALID_VALUE;
 *      public int getCachedValue() {
 *          return _filtered;
 *      }
 *      public void setCachedValue(int value) {
 *          _filtered = value;
 *      }
 *      public boolean isCacheValid() {
 *          return _filtered != INVALID_VALUE;
 *      }
 *      public void invalidateCache() {
 *          _filtered = INVALID_VALUE;
 *      }
 *  </pre></code>
 */
public interface Cacheable {

	/**
	 *  A constant for invalid cache.
	 */
	public static final int INVALID_VALUE = -2147483648;

	/**
	 *  Gets the cached value.
	 * 
	 *  @return the cached value.
	 */
	public int getCachedValue();

	/**
	 *  Sets the cached value.
	 * 
	 *  @param value the new cached value.
	 */
	public void setCachedValue(int value);

	/**
	 *  Checks if the cache is valid. {@link #invalidateCache()} will make this method return false.
	 * 
	 *  @return true if valid.
	 */
	public boolean isCacheValid();

	/**
	 *  Invalidates the cache. It just set the cached value to {@link #INVALID_VALUE}.
	 */
	public void invalidateCache();
}
