/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to indicate an object that has children and can be expanded and collapsed.
 */
public interface Expandable extends Node {
 {

	/**
	 *  Checks if it is expanded.
	 * 
	 *  @return true if it is expanded
	 */
	public boolean isExpanded();

	/**
	 *  Sets the expanded attribute.
	 * 
	 *  @param expanded true or false
	 */
	public void setExpanded(boolean expanded);

	/**
	 *  Checks if it is expandable. If it's not expandable, the expand icon should be grayed out.
	 * 
	 *  @return true if it is expandable
	 */
	public boolean isExpandable();

	/**
	 *  Sets the expandable attribute.
	 * 
	 *  @param expandable true or false.
	 */
	public void setExpandable(boolean expandable);

	/**
	 *  Checks if the expandable has children.
	 * 
	 *  @return true if it has children
	 */
	public boolean hasChildren();

	/**
	 *  Removes all children from this expandable.
	 */
	public void removeAllChildren();

	/**
	 *  Gets the children count.
	 * 
	 *  @return the children count.
	 */
	public int getChildrenCount();

	/**
	 *  Gets the children count after filtering. This method will only work if the <code>Row</code> implements
	 *  <code>Cachedable</code>. In the other word, this method will not do the filter. It will simply look at the cached
	 *  value after filtered was done by <code>FilterableTreeTableModel</code>.
	 * 
	 *  @return the children count after filtering.
	 */
	public int getAllVisibleChildrenCount();

	/**
	 *  Gets the list of children.
	 * 
	 *  @return the list of children
	 */
	public java.util.List getChildren();

	/**
	 *  Sets the list of children.
	 * 
	 *  @param children the list of children
	 */
	public void setChildren(java.util.List children);

	/**
	 *  Adds child to the list of children. It will be added to the last one in the list.
	 * 
	 *  @param child the child to be added.
	 *  @return the newly added child.
	 */
	public Object addChild(Object child);

	/**
	 *  Adds a child to the list of children at the specified index.
	 * 
	 *  @param index the index where the child will be added.
	 *  @param child the child to be added.
	 *  @return the newly added child.
	 */
	public Object addChild(int index, Object child);

	/**
	 *  Adds a list of children.
	 * 
	 *  @param index    the index where the children to be inserted.
	 *  @param children the children to be added.
	 */
	public void addChildren(int index, java.util.List children);

	/**
	 *  Removes child from the list of children.
	 * 
	 *  @param child the child to be removed.
	 *  @return true if child is removed. false if the child doesn't exist at all.
	 */
	public boolean removeChild(Object child);

	/**
	 *  Removes children from the list of children.
	 *  <p/>
	 *  It's not correct if you invoke this method without creating a new list. For example, the following line is incorrect.
	 *  <code><pre>
	 *  removeChildren(getChildren());
	 *  </pre></code>
	 *  You would use the following line to remove all children.
	 *  <code><pre>
	 *  List children = getChildren();
	 *  List<Row> cloneList = new ArrayList<Row>();
	 *  cloneList.addAll(children);
	 *  removeChildren(cloneList);
	 *  </pre></code>
	 * 
	 *  @param children the child to be removed.
	 *  @return true if children are all removed. false if no element of the children exists at all.
	 */
	public boolean removeChildren(java.util.List children);

	/**
	 *  Moves up the child in the children list.
	 * 
	 *  @param child the child to be moved up.
	 *  @return true if the child is moved up. Otherwise false.
	 */
	public boolean moveUpChild(Object child);

	/**
	 *  Moves down the child in the children list.
	 * 
	 *  @param child the child to be moved down.
	 *  @return true if the child is moved down. Otherwise false.
	 */
	public boolean moveDownChild(Object child);

	/**
	 *  Gets the index of the child if exists.
	 * 
	 *  @param child the child
	 *  @return the index of the child if it exists. Otherwise, return -1.
	 */
	public int getChildIndex(Object child);

	/**
	 *  Gets child at certain index.
	 * 
	 *  @param index the index of the child.
	 *  @return the child at the certain index.
	 */
	public Object getChildAt(int index);

	/**
	 *  Gets the number of visible expandable, include itself.
	 * 
	 *  @return the number of visible expandable
	 */
	public int getNumberOfVisibleExpandable();

	/**
	 *  Notifies the child is inserted as the specified index of this expandable.
	 * 
	 *  @param child      the child which is inserted.
	 *  @param childIndex the index where it is inserted. -1 if the child is inserted as the last one.
	 */
	public void notifyChildInserted(Object child, int childIndex);

	/**
	 *  Notifies the children are inserted as the specified index arrange of this expandable.
	 * 
	 *  @param children      the children which are inserted.
	 *  @param firstIndex    the first index where it is inserted.
	 */
	public void notifyChildrenInserted(java.util.List children, int firstIndex);

	/**
	 *  Notifies a child is deleted.
	 * 
	 *  @param child the child that is deleted
	 */
	public void notifyChildDeleted(Object child);

	/**
	 *  Notifies the children are deleted.
	 * 
	 *  @param children the children that are deleted
	 */
	public void notifyChildrenDeleted(java.util.List children);

	/**
	 *  Notifies the child is updated.
	 * 
	 *  @param child the child which is updated
	 */
	public void notifyChildUpdated(Object child);

	/**
	 *  Notifies the children are updated.
	 * 
	 *  @param children the children which are updated
	 */
	public void notifyChildrenUpdated(java.util.List children);
}
