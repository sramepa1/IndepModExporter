/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for a folder.
 */
public class FolderCellEditor extends AbstractComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a FolderCellEditor.
	 */
	public FolderCellEditor() {
	}

	/**
	 *  Creates FileChooserComboBox used by the cell editor.
	 * 
	 *  @return the FileChooserComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}
}
