/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CategoriedTableModel is used in CategorizedTable. It has information about
 *  which row is category row.
 */
public interface CategorizedTableModel {

	/**
	 *  Checks if the row at rowIndex is a category row.
	 * 
	 *  @param rowIndex the index of the row to be checked.
	 *  @return true if the row at rowIndex is a category row.
	 */
	public boolean isCategoryRow(int rowIndex);
}
