/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AbstractSpanTableModel</code> adds <code>SpanModel</code> support to <code>AbstractTableModel</code>.
 *  You can use it as replacement for <code>AbstractTableModel</code>. It implements both methods
 *  in {@link SpanModel} by returning false in {@link SpanModel#isCellSpanOn()} and returning null
 *  in {@link SpanModel#getCellSpanAt(int,int)}. Subclass can override the default
 *  implementation.
 */
public abstract class AbstractSpanTableModel extends javax.swing.table.AbstractTableModel implements SpanTableModel {
 {

	protected AbstractSpanTableModel() {
	}

	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	public boolean isCellSpanOn() {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change
	 *  to the span model occurs.
	 * 
	 *  @param l the SpanModelListener
	 */
	public void addSpanModelListener(SpanModelListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a
	 *  change to the data model occurs.
	 * 
	 *  @param l the SpanModelListener
	 */
	public void removeSpanModelListener(SpanModelListener l) {
	}

	/**
	 *  Returns an array of all the table model listeners
	 *  registered on this model.
	 * 
	 *  @return all of this model's <code>SpanModelListener</code>s
	 *          or an empty
	 *          array if no table model listeners are currently registered
	 *  @see #addSpanModelListener
	 *  @see #removeSpanModelListener
	 *  @since 1.4
	 */
	public SpanModelListener[] getSpanModelListeners() {
	}

	/**
	 *  Notifies all listeners that all span values in the table's
	 *  rows may have changed. The number of rows may also have changed
	 *  and the <code>JTable</code> should redraw the
	 *  table from scratch. The structure of the table (as in the order of the
	 *  columns) is assumed to be the same.
	 * 
	 *  @see SpanModelEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireTableSpanChanged() {
	}

	/**
	 *  Notifies all listeners that a cell span is added at
	 *  cell <code>(row, column)</code>.
	 * 
	 *  @param cellSpan
	 *  @see SpanModelEvent
	 */
	public void fireTableSpanAdded(CellSpan cellSpan) {
	}

	/**
	 *  Notifies all listeners that a cell span is removed at
	 *  cell <code>(row, column)</code>.
	 * 
	 *  @param cellSpan
	 *  @see SpanModelEvent
	 */
	public void fireTableSpanRemoved(CellSpan cellSpan) {
	}

	/**
	 *  Forwards the given notification event to all
	 *  <code>SpanModelListeners</code> that registered
	 *  themselves as listeners for this table model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addSpanModelListener
	 *  @see SpanModelEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireTableSpanChanged(SpanModelEvent e) {
	}
}
