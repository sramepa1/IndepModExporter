/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Collection of static methods providing default implementations for KeyStroke-related tests.
 */
public class KeyStrokeSupport {

	public KeyStrokeSupport() {
	}

	/**
	 *  Walk up the Swing Hierarchy starting at the specified JComponent and determine if any Container is likely to be
	 *  able to process a key binding for the specified keystroke.
	 *  <p/>
	 *  Modeled after part of JComponent's protected processKeyBindings method. Instead of asking each Container to
	 *  processKeyBinding, just ask if the binding is in the input/action map.
	 *  <p/>
	 *  Note that if nothing in the hierarchy is interested, we can't complete the process described in
	 *  JComponent.processKeyBindings by asking a JInternalFrame or Window to processKeyBindingsForAllComponents. That
	 *  method is protected and would be pretty complicated to work around.
	 * 
	 *  @param comp the component to start with and work upward from
	 *  @param ks   the specified keystroke
	 *  @return Is it in an ancestor's input/action map?
	 */
	public static boolean lookAheadHierarchyMightProcess(javax.swing.JComponent comp, javax.swing.KeyStroke ks) {
	}

	/**
	 *  Is the specified keystroke/condition in the specified JComponent's input and action maps?
	 * 
	 *  @param comp      the specified JComponent
	 *  @param ks        the specified keystroke
	 *  @param condition the specified condition (KeyEvent.WHEN_FOCUSED, KeyEvent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT,
	 *                   KeyEvent.WHEN_IN_FOCUSED_WINDOW)
	 *  @return Is it? Not necessarily the same as what will be returned by actually executing the action, which can fail.
	 */
	public static boolean canProcessKeyBinding(javax.swing.JComponent comp, javax.swing.KeyStroke ks, int condition) {
	}

	@java.lang.SuppressWarnings("ConstantConditions")
	public static boolean isValidKeyForDefaultTableEditor(java.awt.event.KeyEvent e, javax.swing.KeyStroke ks) {
	}

	public static boolean isModifierKey(java.awt.event.KeyEvent e) {
	}

	public static boolean isTableNavigationKey(javax.swing.KeyStroke ks) {
	}
}
