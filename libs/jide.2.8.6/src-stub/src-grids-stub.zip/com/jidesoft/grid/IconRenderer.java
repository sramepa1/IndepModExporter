/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A renderer to display an icon.
 * 
 *  @deprecated renamed to IconCellRenderer so please use IconCellRenderer instead.
 */
@java.lang.Deprecated
public class IconRenderer extends IconCellRenderer {

	public IconRenderer() {
	}
}
