/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AutoFilterBox</code> is used as the cell editor component for <code>AutoFilterTableHeader</code>.
 */
public class AutoFilterBox extends HeaderBox implements SortListener, FilterableTableModelListener, java.awt.event.MouseListener, java.awt.event.MouseMotionListener {
 {

	public static final String PROPERTY_TITLE = "title";

	public static final String PROPERTY_ICON = "icon";

	public static final String PROPERTY_SORT_ARROW_VISIBLE = "sortArrowVisible";

	public static final String PROPERTY_FILTER_INDICATOR_VISIBLE = "filterIndicatorVisible";

	public static final String PROPERTY_FILTER_BUTTON_VISIBLE = "filterButtonVisible";

	public static final String PROPERTY_ASCENDING = "ascending";

	public static final String PROPERTY_SORTED = "sorted";

	public static final String PROPERTY_POSSIBLE_VALUES = "possibleValues";

	protected Object HIDE_POPUP_KEY;

	/**
	 *  Creates a button with no set text or icon.
	 */
	public AutoFilterBox() {
	}

	/**
	 *  Sets the table model onto <code>AutoFilterBox</code>.
	 * 
	 *  @param tableModel   the table model.
	 *  @param columnIndex  the column index for this auto filter, this is the view column index.
	 *  @param isCellEditor whether this is used as cell editor. The opposite is to be used as cell renderer.
	 */
	public void setTableModel(javax.swing.table.TableModel tableModel, int columnIndex, boolean isCellEditor) {
	}

	public void sortChanging(SortEvent event) {
	}

	public void sortChanged(SortEvent event) {
	}

	public void filterableTableModelChanged(FilterableTableModelEvent event) {
	}

	/**
	 *  Gets the table column index of this AutoFilterBox.
	 * 
	 *  @return the table column index.
	 */
	public int getTableColumnIndex() {
	}

	/**
	 *  Gets the table column index of this AutoFilterBox.
	 * 
	 *  @return the table column index.
	 */
	public int getModelColumnIndex() {
	}

	/**
	 *  Updates the filter indicator. By default, we will set the text and set a filter icon if isShowFilterName returns
	 *  true and isShowFilterIcon returns true respectively.
	 * 
	 *  @param filterableTableModel the FilterableTableModel. You can use it to find out if the column is filtered and
	 *                              what the filters are. The column index can be got from getTabelColumnIndex method.
	 */
	protected void updateFilterIndicator(IFilterableTableModel filterableTableModel) {
	}

	/**
	 *  Formats the string when the filter name is displayed. By default, we will display the column name first, followed
	 *  by ": " then the filter name. You can use {@link #setFilterTitleFormatter(com.jidesoft.grid.AutoFilterBox.FilterTitleFormatter)}
	 *  to format it using your own way.
	 * 
	 *  @param columnName the name for the column.
	 *  @param filters    the filters on the column
	 *  @return the string after formatted.
	 */
	protected String formatColumnTitle(String columnName, com.jidesoft.filter.Filter[] filters) {
	}

	/**
	 *  Gets the formatter that will format the title for the AutoFilterBox. This formatter will be used, when
	 *  isShowFilterName is true, to format the title including column name and filter names.
	 * 
	 *  @return the formatted title.
	 */
	public AutoFilterBox.FilterTitleFormatter getFilterTitleFormatter() {
	}

	/**
	 *  Sets the formatter that will format the title for the AutoFilterBox.
	 * 
	 *  @param filterTitleFormatter the new FilterTitleFormatter.
	 */
	public void setFilterTitleFormatter(AutoFilterBox.FilterTitleFormatter filterTitleFormatter) {
	}

	protected boolean isFiltered() {
	}

	protected void initComponents(String text, javax.swing.Icon icon, boolean sortArrowVisible, boolean filterButtonVisible, boolean isCellEditor) {
	}

	protected void installListeners() {
	}

	public boolean isSortArrowVisible() {
	}

	public void setSortArrowVisible(boolean sortArrowVisible) {
	}

	public boolean isFilterIndicatorVisible() {
	}

	public void setFilterIndicatorVisible(boolean filterIndicatorVisible) {
	}

	public boolean isFilterButtonVisible() {
	}

	public void setFilterButtonVisible(boolean filterButtonVisible) {
	}

	@java.lang.Override
	public void setText(String title) {
	}

	@java.lang.Override
	public void setToolTipText(String tooltipText) {
	}

	@java.lang.Override
	public String getText() {
	}

	@java.lang.Override
	public void setIcon(javax.swing.Icon icon) {
	}

	public boolean isAscending() {
	}

	public void toggleSortOrder() {
	}

	public void toggleSortOrder(boolean extend) {
	}

	public void setAscending(boolean ascending) {
	}

	public boolean isSorted() {
	}

	public void setSorted(boolean sorted) {
	}

	public Object[] getPossibleValues() {
	}

	public void setPossibleValues(Object[] possibleValues) {
	}

	/**
	 *  Applies the filter to the specified column index of the <code>FilterableTableModel</code>.
	 * 
	 *  @param filter      the filter.
	 *  @param columnIndex the column index.
	 */
	protected void applyFilter(com.jidesoft.filter.Filter filter, int columnIndex) {
	}

	protected void applyFilter(com.jidesoft.filter.Filter filter, int columnIndex, boolean clearFirst) {
	}

	/**
	 *  Creates the default combobox button. This method is used only if createButtonComponent() returns null. The idea
	 *  is each combobox can implement createButtonComponent() to provide its own button. However the default
	 *  implementation should still be the button created by this method.
	 * 
	 *  @return the default combobox button.
	 */
	protected javax.swing.AbstractButton createDefaultButton() {
	}

	/**
	 *  Creates the popup window. By default it will create a JidePopup which is not detached and not resizable. Subclass
	 *  can override it to create your own JidePopup or customize the default one.
	 * 
	 *  @return the popup window.
	 */
	protected JidePopup createPopupWindow() {
	}

	@java.lang.SuppressWarnings("RawUseOfParameterizedType")
	public Object[] getPossibleValues(ObjectGrouper objectGrouper, Object[] values, java.util.Comparator comparator) {
	}

	/**
	 *  Create the popup panel while the customer clicks the filter icon.
	 *  <p/>
	 *  Basically, we will try to use the converterContext defined in the table model to render the popup list in
	 *  AutoFilterTableHeader. With this attempt, the customer will be able to see a consistent display in table cells
	 *  and the popup list. You could also override AutoFilterBox#customizeList() to set your desired renderer.
	 * 
	 *  @param tableModel     the table model
	 *  @param columnIndex    the column index to create the popup panel
	 *  @param possibleValues possible values to be displayed
	 *  @return the popup panel to be displayed.
	 */
	@java.lang.SuppressWarnings("RawUseOfParameterizedType")
	protected com.jidesoft.combobox.PopupPanel createPopupPanel(javax.swing.table.TableModel tableModel, int columnIndex, Object[] possibleValues) {
	}

	/**
	 *  Shows CustomFilterEditor when "(Custom...) is selected in the drop down list.
	 * 
	 *  @param filterableTableModel the FilterableTableModel
	 *  @param columnIndex          the column index of the AutoFilterBox relative to the filterableTableModel.
	 *  @param possibleValues       the possible values of the column in the table model.
	 */
	protected void showCustomFilterEditor(IFilterableTableModel filterableTableModel, int columnIndex, Object[] possibleValues) {
	}

	/**
	 *  Creates the CustomFilterEditorDialog when the "(Custom...)" is clicked in the drop down list of the
	 *  AutoFilterBox.
	 * 
	 *  @param container    the top level ancestor of the AutoFilterBox.
	 *  @param title        the title of the dialog.
	 *  @param filterEditor the CustomFilterEditor.
	 *  @return a CustomFilterEditorDialog.
	 */
	protected StandardDialog createCustomFilterEditorDialog(java.awt.Container container, String title, com.jidesoft.filter.CustomFilterEditor filterEditor) {
	}

	/**
	 *  Creates the CustomFilterEditor used in the FieldBox's custom filter drop down list.
	 * 
	 *  @param filterFactoryManager the FilterFactoryManager.
	 *  @param type                 the type.
	 *  @param converterContext     the ConverterContext.
	 *  @param possibleValues       the possible values.
	 *  @return a new instance of CustomFilterEditor.
	 */
	protected com.jidesoft.filter.CustomFilterEditor createCustomFilterEditor(com.jidesoft.filter.FilterFactoryManager filterFactoryManager, Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	/**
	 *  Create Searchable instance for drop down list in AutoFilterBox. You can override this method to create your own
	 *  searchable. The default implementation is to utilize the converter from the cell renderer as below.
	 *  <code><pre>
	 *  new ListSearchable(list) {
	 *      protected String convertElementToString(Object object) {
	 *          return cellRenderer.convertElementToString(list.getLocale(), object);
	 *      }
	 *  };
	 *  </pre></code>
	 * 
	 *  @param list the list generated by possible values
	 */
	protected void customizeList(javax.swing.JList list) {
	}

	/**
	 *  Converts the element from object to string.
	 * 
	 *  @param item the item
	 *  @return the string.
	 */
	protected String convertElementToString(Object item) {
	}

	/**
	 *  Converts the element from object to string.
	 * 
	 *  @param item    the item
	 *  @param context the converter context
	 *  @return the string.
	 */
	protected String convertElementToString(Object item, ConverterContext context) {
	}

	/**
	 *  calculate the popup location.
	 * 
	 *  @return the location of popup.
	 */
	protected java.awt.Point calculatePopupLocation() {
	}

	/**
	 *  Causes the combo box to close its popup window.
	 */
	public void hidePopup() {
	}

	/**
	 *  Determines the visibility of the popup.
	 * 
	 *  @return true if the popup is visible, otherwise returns false
	 */
	public boolean isPopupVisible() {
	}

	/**
	 *  Add a <code>DynamicTableFilter</code>. <code>DynamicTableFilter</code> allows to add your own customize filter to
	 *  the drop down filter list. Any <code>DynamicTableFilter</code> will become an entry in the list. If user clicks
	 *  on that entry, the filter will be used to filter the column. What's special about <code>DynamicTableFilter</code>
	 *  is it allows to to create a filter on fly. For example, in initializeFilter method of DynamicTableFilter, you can
	 *  pop up a dialog to allow user to select certain information and you return a filter based on user selection. If
	 *  returning null, no filter will be added. If not null, the filter you just created will be added to the
	 *  <code>FilterableTableModel</code>.
	 * 
	 *  @param filter a <code>DynamicTableFilter</code>.
	 */
	public void addDynamicTableFilter(DynamicTableFilter filter) {
	}

	/**
	 *  Removes a <code>DynamicTableFilter</code> which was added earlier.
	 * 
	 *  @param filter a <code>DynamicTableFilter</code>.
	 */
	public void removeDynamicTableFilter(DynamicTableFilter filter) {
	}

	/**
	 *  Gets all the <code>DynamicTableFilter</code>s.
	 * 
	 *  @return an array of <code>DynamicTableFilter</code>s.
	 */
	public DynamicTableFilter[] getDynamicTableFilters() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Paints the filter indicator. By default, we will paint a line above the filter list button to indicate there is
	 *  filter on this column.
	 * 
	 *  @param g the Graphics object
	 */
	protected void paintFilterIndicator(java.awt.Graphics g) {
	}

	/**
	 *  Checks if the filter name is visible on the box as part of the title.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowFilterName() {
	}

	/**
	 *  Sets the flag if the filter name is shown on the title.
	 * 
	 *  @param showFilterName true to show the filter name. False to not show it.
	 */
	public void setShowFilterName(boolean showFilterName) {
	}

	/**
	 *  Checks if the filter name is displayed as tooltip of the box.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowFilterNameAsToolTip() {
	}

	/**
	 *  Sets the flag if the filter name is displayed as tooltip on the box.
	 * 
	 *  @param showFilterNameAsToolTip true to show the filter name as tooltip. False to not show it.
	 */
	public void setShowFilterNameAsToolTip(boolean showFilterNameAsToolTip) {
	}

	/**
	 *  Checks if the filter icon is visible on the box as part of the title.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowFilterIcon() {
	}

	/**
	 *  Sets the flag if the filter icon is shown on the title.
	 * 
	 *  @param showFilterIcon true to show the filter icon. False to not show it.
	 */
	public void setShowFilterIcon(boolean showFilterIcon) {
	}

	/**
	 *  Checks if the filter icon is visible on the box as part of the title.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowSortArrow() {
	}

	/**
	 *  Sets the flag if the filter icon is shown on the title.
	 * 
	 *  @param showSortArrow true to show the filter icon. False to not show it.
	 */
	public void setShowSortArrow(boolean showSortArrow) {
	}

	public java.awt.Component getTarget() {
	}

	public void setTarget(java.awt.Component target) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Checks if the <code>AutoFilterTableHeader</code> allows multiple values as the filter. The difference will be to
	 *  use a CheckBoxList or a regular JList as the popup panel when clicking on the filter button.
	 * 
	 *  @return true or false.
	 */
	public boolean isAllowMultipleValues() {
	}

	/**
	 *  Set the flag if the <code>AutoFilterTableHeader</code> allows multiple values as the filter. The difference will
	 *  be to use a CheckBoxList or a regular JList as the popup panel when clicking on the filter button.
	 * 
	 *  @param allowMultipleValues true to allow multiple value filters. False to disallow it. Default is false.
	 */
	public void setAllowMultipleValues(boolean allowMultipleValues) {
	}

	/**
	 *  Checks the flag if the <code>AutoFilterTableHeader</code> allows custom filter. The difference is there will be a
	 *  (Custom...) item in the drop down list.when clicking on the filter button.  The value is only considered when
	 *  {@link #isAllowMultipleValues()} returns false.
	 * 
	 *  @return true or false.
	 */
	public boolean isAllowCustomFilter() {
	}

	/**
	 *  Set the flag if the <code>AutoFilterTableHeader</code> allows custom filter. The difference is there will be a
	 *  (Custom...) item in the drop down list.when clicking on the filter button.  The value is only considered when
	 *  {@link #isAllowMultipleValues()} returns false.
	 * 
	 *  @param allowCustomFilter true to allow custom filter. False to disallow it. Default is true.
	 */
	public void setAllowCustomFilter(boolean allowCustomFilter) {
	}

	@java.lang.Override
	public void setVerticalAlignment(int alignment) {
	}

	@java.lang.Override
	public void setHorizontalAlignment(int alignment) {
	}

	public javax.swing.Icon getDescendingIcon() {
	}

	public void setDescendingIcon(javax.swing.Icon descendingIcon) {
	}

	/**
	 *  Gets the ascending icon.
	 * 
	 *  @return the ascending icon.
	 */
	public javax.swing.Icon getAscendingIcon() {
	}

	/**
	 *  @param ascendingIcon the new ascending icon
	 */
	public void setAscendingIcon(javax.swing.Icon ascendingIcon) {
	}

	/**
	 *  Gets the list cell renderer for the drop down filter list.
	 * 
	 *  @return the list cell renderer for the drop down filter list.
	 */
	public javax.swing.ListCellRenderer getListCellRenderer() {
	}

	/**
	 *  Sets the list cell renderer for the drop down filter list.
	 * 
	 *  @param listCellRenderer the new list cell renderer for the drop down filter list.
	 */
	public void setListCellRenderer(javax.swing.ListCellRenderer listCellRenderer) {
	}

	public boolean isCellEditor() {
	}

	public void setCellEditor(boolean cellEditor) {
	}

	public StringConverter getTitleConverter() {
	}

	public void setTitleConverter(StringConverter titleConverter) {
	}

	/**
	 *  An interface which is used to format the filter title.
	 */
	public static interface class FilterTitleFormatter {


		/**
		 *  Formats the title. You can use html code in the returned title.
		 * 
		 *  @param columnName the name for the column.
		 *  @param filters    the filters on the column
		 *  @return the new title after formatting.
		 */
		public String formatColumnTitle(String columnName, com.jidesoft.filter.Filter[] filters) {
		}
	}

	public class ArrowIcon {


		public AutoFilterBox.ArrowIcon(int direction) {
		}

		public int getIconWidth() {
		}

		public int getIconHeight() {
		}

		public synchronized void paintIcon(java.awt.Component c, java.awt.Graphics g, int x, int y) {
		}
	}
}
