/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An implementation of <code>ReferenceRow</code> which refers to a row using the row index.
 */
public class IndexReferenceRow extends AbstractRow implements ReferenceRow, Cacheable {
 {

	public IndexReferenceRow(javax.swing.table.TableModel tableModel, int rowIndex) {
	}

	public IndexReferenceRow(DefaultGroupTableModel groupTableModel, javax.swing.table.TableModel tableModel, int rowIndex) {
	}

	public int getActualColumnIndex(int columnIndex) {
	}

	public Object getValueAt(int columnIndex) {
	}

	public int getRowIndex() {
	}

	public void setRowIndex(int rowIndex) {
	}

	public TreeTableModel getTreeTableModel() {
	}

	public javax.swing.table.TableModel getTableModel() {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int columnIndex) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int columnIndex) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	public int getCachedValue() {
	}

	public void setCachedValue(int value) {
	}

	public boolean isCacheValid() {
	}

	public void invalidateCache() {
	}

	@java.lang.Override
	public boolean isCellEditable(int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int columnIndex) {
	}
}
