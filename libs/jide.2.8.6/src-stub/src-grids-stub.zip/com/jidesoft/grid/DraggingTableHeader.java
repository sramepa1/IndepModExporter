/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Subclass JTableHeader in order to fire property change event on {@link #setDraggedColumn(javax.swing.table.TableColumn)}
 *  and {@link #setResizingColumn(javax.swing.table.TableColumn)}.
 */
public class DraggingTableHeader extends javax.swing.table.JTableHeader {

	public static final String PROPERTY_DRAGGED_COLUMN = "draggedColumn";

	public static final String PROPERTY_RESIZING_COLUMN = "resizingColumn";

	public static final String PROPERTY_DRAGGED_DISTANCE = "draggedDistance";

	public DraggingTableHeader() {
	}

	public DraggingTableHeader(javax.swing.table.TableColumnModel cm) {
	}

	@java.lang.Override
	public void setDraggedColumn(javax.swing.table.TableColumn column) {
	}

	@java.lang.Override
	public void setResizingColumn(javax.swing.table.TableColumn column) {
	}

	@java.lang.Override
	public void setDraggedDistance(int distance) {
	}
}
