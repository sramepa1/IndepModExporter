/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The listener interface for receiving SortEvent.
 */
public interface SortListener extends java.util.EventListener {
 {

	/**
	 *  Called whenever the sorting index of SortableTableModel is about to change.
	 * 
	 *  @param event the SortEvent
	 */
	public void sortChanging(SortEvent event);

	/**
	 *  Called whenever the sorting index of SortableTableModel changed.
	 * 
	 *  @param event the SortEvent
	 */
	public void sortChanged(SortEvent event);
}
