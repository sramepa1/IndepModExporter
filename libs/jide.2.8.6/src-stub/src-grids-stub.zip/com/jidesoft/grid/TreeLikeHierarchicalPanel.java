/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  TreeLikeHierarchicalPanel is a special HierarchicalPanel which will draw a tree hash line that links the
 *  expand/collapse button to the child component. You can only use this panel when the expandableColumn of
 *  HierarchicalTable is 0.
 *  <p/>
 *  Note: This class is part of HierarchicalTable component. In current release, HierarchicalTable is still in beta.
 *  Please feel free to try it, give us suggestions and feedback. However we reserve the right to change the public APIs
 *  if it's necessary.
 * 
 *  @see HierarchicalPanel
 *  @see HierarchicalTable
 */
public class TreeLikeHierarchicalPanel extends HierarchicalPanel {

	public TreeLikeHierarchicalPanel() {
	}

	public TreeLikeHierarchicalPanel(java.awt.Component component) {
	}

	public TreeLikeHierarchicalPanel(java.awt.Component component, javax.swing.border.Border border) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}
}
