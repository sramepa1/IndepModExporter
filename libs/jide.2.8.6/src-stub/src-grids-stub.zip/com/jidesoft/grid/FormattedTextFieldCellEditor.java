/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a CellEditor which will assume userObject of a converter context as JFormattedTextField.AbstractFormatter and
 *  use it on a FormattedTextField.
 */
public class FormattedTextFieldCellEditor extends ContextSensitiveCellEditor implements java.awt.event.FocusListener {
 {

	protected javax.swing.JFormattedTextField _textField;

	/**
	 *  Creates a FormattedTextFieldCellEditor with no format and String as default class. The format can be set by
	 *  following setConverterContext().
	 */
	public FormattedTextFieldCellEditor() {
	}

	/**
	 *  Creates a FormattedTextFieldCellEditor with no format and specified class. The format can be set by following
	 *  setConverterContext().
	 * 
	 *  @param clazz the type.
	 */
	public FormattedTextFieldCellEditor(Class clazz) {
	}

	/**
	 *  Creates a FormattedTextFieldCellEditor with specified class and format.
	 * 
	 *  @param clazz  the type.
	 *  @param format Format used to look up an AbstractFormatter
	 */
	public FormattedTextFieldCellEditor(Class clazz, java.text.Format format) {
	}

	/**
	 *  Creates a FormattedTextFieldCellEditor with specified class and formatter.
	 * 
	 *  @param clazz     the type.
	 *  @param formatter AbstractFormatter to use for formatting.
	 */
	public FormattedTextFieldCellEditor(Class clazz, javax.swing.JFormattedTextField.AbstractFormatter formatter) {
	}

	/**
	 *  Creates the formatted text field used by this cell editor.
	 * 
	 *  @param format Format used to look up an AbstractFormatter
	 *  @return a JFormattedTextField.
	 */
	protected javax.swing.JFormattedTextField createFormattedTextField(java.text.Format format) {
	}

	/**
	 *  Creates the formatted text field used by this cell editor.
	 * 
	 *  @param formatter AbstractFormatter to use for formatting.
	 *  @return a JFormattedTextField.
	 */
	protected javax.swing.JFormattedTextField createFormattedTextField(javax.swing.JFormattedTextField.AbstractFormatter formatter) {
	}

	protected void customizeTextField() {
	}

	protected void setupTextField() {
	}

	@java.lang.Override
	public void setConverterContext(ConverterContext context) {
	}

	public Object getCellEditorValue() {
	}

	public void setCellEditorValue(Object value) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	public void focusLost(java.awt.event.FocusEvent e) {
	}

	public void focusGained(java.awt.event.FocusEvent e) {
	}

	protected javax.swing.JFormattedTextField.AbstractFormatterFactory getFormatFactory() {
	}
}
