/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>DefaultStyleTableModel</code> adds <code>StyleModel</code> support to <code>DefaultTableModel</code>. You can
 *  use it as replacement for <code>DefaultTableModel</code>. Instead of return a cell style programmatically like in
 *  {@link AbstractStyleTableModel}, you can use {@link #setCellStyle(int,int,CellStyle)} or {@link
 *  #removeCellStyle(int,int)} to control the cell style.
 */
public class DefaultStyleTableModel extends javax.swing.table.DefaultTableModel implements StyleTableModel {
 {

	public DefaultStyleTableModel() {
	}

	public DefaultStyleTableModel(int rowCount, int columnCount) {
	}

	public DefaultStyleTableModel(java.util.Vector columnNames, int rowCount) {
	}

	public DefaultStyleTableModel(Object[] columnNames, int rowCount) {
	}

	public DefaultStyleTableModel(java.util.Vector data, java.util.Vector columnNames) {
	}

	public DefaultStyleTableModel(Object[][] data, Object[] columnNames) {
	}

	/**
	 *  Gets the cell style at the specified row and column index.
	 * 
	 *  @param rowIndex
	 *  @param columnIndex
	 *  @return the cell style at the specified row and column index.
	 */
	public CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Adds a cell style.
	 * 
	 *  @param cellStyle
	 */
	public void setCellStyle(int rowIndex, int columnIndex, CellStyle cellStyle) {
	}

	/**
	 *  Removes the cell style.
	 * 
	 *  @param rowIndex
	 *  @param columnIndex
	 */
	public void removeCellStyle(int rowIndex, int columnIndex) {
	}

	/**
	 *  Removes all cell styles. TableDataChanged event will be fired if there were cell styles set before.
	 *  <p/>
	 *  Note: If you want to turn of all cell styles temporarily, you should use <code>setCellStyleOn(false)</code>.
	 */
	public void removeAllCellStyles() {
	}

	public boolean isCellStyleOn() {
	}

	public void setCellStyleOn(boolean cellStyleOn) {
	}
}
