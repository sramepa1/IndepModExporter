/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AbstractStyleTableModel</code> adds <code>StyleModel</code> support to <code>AbstractTableModel</code>.
 *  You can use it as replacement for <code>AbstractTableModel</code>. It implements both methods
 *  in {@link StyleModel} by returning false in {@link StyleModel#isCellStyleOn()} and returning null
 *  in {@link StyleModel#getCellStyleAt(int, int)}. Subclass can override the default
 *  implementation.
 */
public abstract class AbstractStyleTableModel extends javax.swing.table.AbstractTableModel implements StyleTableModel {
 {

	protected AbstractStyleTableModel() {
	}

	public CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	public boolean isCellStyleOn() {
	}
}
