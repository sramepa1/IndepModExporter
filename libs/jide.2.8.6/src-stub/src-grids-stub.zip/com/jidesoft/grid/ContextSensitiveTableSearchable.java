/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is the Searchable class for ContextSensitiveTable so that searchable could search on the converted string other
 *  than just value#toString().
 */
public class ContextSensitiveTableSearchable extends JideTableSearchable {

	public ContextSensitiveTableSearchable(javax.swing.JTable table) {
	}

	@java.lang.Override
	protected Object getValueAt(javax.swing.JTable table, int rowIndex, int columnIndex) {
	}
}
