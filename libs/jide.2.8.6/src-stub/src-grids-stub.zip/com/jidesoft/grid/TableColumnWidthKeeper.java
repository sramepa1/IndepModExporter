/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is an interface used by JideTable to save the table column width and order before table structure changed event
 *  so that the columns' width and order can be restored later.
 */
public interface TableColumnWidthKeeper {

	/**
	 *  Saves the table column width into an object.
	 * 
	 *  @param table the table.
	 *  @return the column width information.
	 */
	public Object saveTableColumnWidth(javax.swing.JTable table);

	/**
	 *  Restores the table column width from the same information.
	 * 
	 *  @param table      the table.
	 *  @param savedWidth the saved table column width information.
	 */
	public void restoreTableColumnWidth(javax.swing.JTable table, Object savedWidth);
}
