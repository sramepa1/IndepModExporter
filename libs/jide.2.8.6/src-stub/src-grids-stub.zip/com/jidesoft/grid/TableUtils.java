/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A collection of utility methods for JTable.
 */
public class TableUtils {

	/**
	 *  Client property for auto resize feature. If the value of this client property is Boolean.FALSE, it will not
	 *  consider header column preferred width when auto resizing. Otherwise, it will consider.
	 */
	public static final String CLIENT_PROPERTY_AUTO_RESIZE_CONSIDER_HEADER = "AutoResize.considerHeader";

	/**
	 *  Client property for auto resize feature. If the value of this client property is Boolean.TRUE, it will consider
	 *  visible rows only when when auto resizing. Otherwise, it will consider all rows.
	 */
	public static final String CLIENT_PROPERTY_AUTO_RESIZE_CONSIDER_VISIBLE_ROWS_ONLY = "AutoResize.considerVisibleRowsOnly";

	/**
	 *  Not used yet.
	 */
	public static final String CLIENT_PROPERTY_SAME_RENDERER_FOR_COLUMN = "JTable.sameRendererForColumn";

	/**
	 *  When {@link com.jidesoft.grid.TableColumnChooser#hideColumn(javax.swing.JTable, int)} is called, we will call the
	 *  code below to save the original column snapshot. We will use this snapshot to get the correct view order.
	 *  <code><pre>
	 *  table.putClientProperty(CLIENT_PROPERTY_TABLE_COLUMN_SNAPSHOT , snapshot);
	 *  </pre></code>
	 */
	public static final String CLIENT_PROPERTY_TABLE_COLUMN_SNAPSHOT = "TableColumnSnapshot:";

	/**
	 *  In the saved preference string, for GroupTable and AggregateTable, we will append ":::HEADER" to the column
	 *  identifier for grouping columns so we can keep right column order.
	 *  <p/>
	 *  In normal case, you don't have to use this flag. If you want to save a clear string to XML, you could erase those
	 *  flags. However, when you need load them back, you have to add the flags back, otherwise, the column order could
	 *  be unexpectedly changed.
	 */
	public static final String COLUMN_PROPERTY_HEADER_TABLE_MODEL_COLUMNS = ":::HEADER";

	/**
	 *  In the saved preference string, for AggregateTable, we will append ":::DATA:::" to the column identifier for
	 *  non-grouping columns so we can keep right column order.
	 *  <p/>
	 *  In normal case, you don't have to use this flag. If you want to save a clear string to XML, you could erase those
	 *  flags. However, when you need load them back, you have to add the flags back, otherwise, the column order could
	 *  be unexpectedly changed.
	 */
	public static final String COLUMN_PROPERTY_DATA_TABLE_MODEL_COLUMNS = ":::DATA:::";

	/**
	 *  In the saved preference string, for GroupTable, we will append "GROUP_COUNT:::HEADER" to the column identifier
	 *  for group count column so we can keep right column order.
	 *  <p/>
	 *  In normal case, you don't have to use this flag. If you want to save a clear string to XML, you could erase those
	 *  flags. However, when you need load them back, you have to add the flags back, otherwise, the column order could
	 *  be unexpectedly changed.
	 */
	public static final String COLUMN_PROPERTY_GROUP_TABLE_COUNT_COLUMN = "GROUP_COUNT:::HEADER";

	public static final char SEPARATOR = 9;

	public TableUtils() {
	}

	/**
	 *  Save the heights of the table to an integer array.
	 *  <p/>
	 *  The first element is the row count of its inner most table model.
	 *  <p/>
	 *  The second element is table.getRowHeight().
	 *  <p/>
	 *  After the first two elements, every two element is a pair, the first one of the pair is the row index while the
	 *  second one is its row height if different with table.getRowHeight().
	 *  <p/>
	 * 
	 *  @param table the table to save row heights
	 *  @return an integer array of the row heights.
	 */
	public static int[] saveRowHeights(javax.swing.JTable table) {
	}

	/**
	 *  Load row heights from the saved integer array.
	 *  <p/>
	 * 
	 *  @param table      the table to be loaded
	 *  @param rowHeights saved row heights by {@link #saveRowHeights(javax.swing.JTable)}
	 *  @see #saveRowHeights(javax.swing.JTable)
	 */
	public static void loadRowHeights(javax.swing.JTable table, int[] rowHeights) {
	}

	/**
	 *  Save the selection of the JTable as an array of integer. It works for all cases either row selection is allowed
	 *  or column selection or cell selection is allowed. However you cannot change the row/column selection allowed
	 *  attribute between saveSelection and loadSelection.
	 * 
	 *  @param table the table
	 *  @return selection as an array
	 */
	@java.lang.SuppressWarnings("ValueOfIncrementOrDecrementUsed")
	public static int[] saveSelection(javax.swing.JTable table) {
	}

	/**
	 *  Restore the selection in JTable. It must used the array that created by saveSelection. Internally it will call
	 *  {@link #loadSelection(javax.swing.JTable,int[],boolean)} with the <code>scrollSelectionToVisible</code> set to
	 *  true.
	 * 
	 *  @param table    the table
	 *  @param selected an int array created by saveSelection
	 */
	public static void loadSelection(javax.swing.JTable table, int[] selected) {
	}

	/**
	 *  Restore the selection in JTable. It must used the array that created by saveSelection.
	 * 
	 *  @param table                    the table
	 *  @param selected                 an int array created by saveSelection
	 *  @param scrollSelectionToVisible if the table is row selection mode and this flag is true, this method will scroll
	 *                                  the selected rows to visible.
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static void loadSelection(javax.swing.JTable table, int[] selected, boolean scrollSelectionToVisible) {
	}

	/**
	 *  Save the selection of the TreeTable as an array of Rows. It only works for when row selection is allowed. The
	 *  returned Row array can be used in {@link #loadSelection(TreeTable,Row[])} to restore the selection.
	 * 
	 *  @param table the table
	 *  @return selection as a Row array
	 * 
	 *  @see #loadSelection(TreeTable,Row[])
	 */
	public static Row[] saveSelection(TreeTable table) {
	}

	/**
	 *  Restore the selection in TreeTable. It must used the array that created by {@link #saveSelection(TreeTable)}.
	 * 
	 *  @param table        the tree table
	 *  @param selectedRows a Row array created by saveSelection
	 */
	public static void loadSelection(TreeTable table, Row[] selectedRows) {
	}

	/**
	 *  Restore the selection in TreeTable. It must used the array that created by {@link #saveSelection(TreeTable)}.
	 *  <p/>
	 *  In the scenario like collapse rows, if the selected rows is not visible any more, we would put its selection to
	 *  its first visible ancient.
	 * 
	 *  @param table                    the tree table
	 *  @param selectedRows             a Row array created by saveSelection
	 *  @param scrollSelectionToVisible if the table is row selection mode and this flag is true, this method will scroll
	 *                                  the selected rows to visible.
	 */
	public static void loadSelection(TreeTable table, Row[] selectedRows, boolean scrollSelectionToVisible) {
	}

	/**
	 *  Restore the selection in TreeTable. It must used the array that created by {@link #saveSelection(TreeTable)}.
	 *  <p/>
	 *  In the scenario like collapse rows, if the selected rows is not visible any more, we would put its selection to
	 *  its first visible ancient.
	 * 
	 *  @param table                    the tree table
	 *  @param selectedRows             a Row array created by saveSelection
	 *  @param scrollSelectionToVisible if the table is row selection mode and this flag is true, this method will scroll
	 *                                  the selected rows to visible.
	 *  @param compareCurrentSelection  if current selection will be compared with the selection to load. By default, the
	 *                                  value is false for performance reason. You could turn this flag to true if you care
	 *                                  more about the selection events.
	 */
	public static void loadSelection(TreeTable table, Row[] selectedRows, boolean scrollSelectionToVisible, boolean compareCurrentSelection) {
	}

	public static Object eraseIdentifierFlag(Object identifier, String flag) {
	}

	/**
	 *  Gets the table preference string. The preference string contains the information such as each table column width,
	 *  column order and column visibilities. If the table column width or order or visibility is changed after
	 *  getTablePreference is called, setTablePreference() will change table column width, order and visibility to the
	 *  previous state when this preference string is saved.
	 *  <p/>
	 *  The method is designed for single table only. If you are trying to save table preference for {@link
	 *  com.jidesoft.grid.TableScrollPane}, please use {@link #getTablePreferenceByName(TableScrollPane)}.
	 *  <p/>
	 *  Please note, this method deprecate {@link #getTablePreference(javax.swing.JTable)}, this method will save the
	 *  column name as defined in <code>TableModel</code>'s <code>getColumnName</code> method. So as long as the column
	 *  name doesn't change, you can use {@link #setTablePreferenceByName(javax.swing.JTable,String)} to restore
	 *  correctly, even if you add or remove columns between get and set. Please also note, since the column names can be
	 *  localized and sometimes can be duplicated, you can implement {@link com.jidesoft.grid.ColumnIdentifierTableModel}
	 *  and provides a unique column identifier for each column. This method will use the identifier returned from
	 *  ColumnIdentifierTableModel's getColumnIdentifier method.
	 *  <p/>
	 *  Comparing with the preference string you generated before release 2.5.0. Here are some differences you way want
	 *  to know:
	 *  <p/>
	 *  1, Added a column order part after "\t\t\t". That means the string part before that token has the same intend
	 *  with the older version. Since column order persistence is not easy to achieve only with the hide information
	 *  stored in previous version, we have to keep as many history information as we can so that we can restore the
	 *  column order correctly.
	 *  <p/>
	 *  2, We will have to calculate appropriate column order based on the history information in part 2 of the string
	 *  after "\t\t\t". So it's hard to say which column should be in which column index now from the preference string
	 *  itself. Actually we have an algorithm, which is invoked by <code>setTablePreferenceByName</code> internally to
	 *  calculate it.
	 *  <p/>
	 *  3, Since we have added another part to restore the column order and hidden information, we don't put -1 as width
	 *  for hidden columns any more in the first part.
	 *  <p/>
	 *  4, We considered backward-compatibility while making these changes. That means, if you have a preference string
	 *  generated by  <code>getTablePreferenceByName </code> in older version, you should be able to use it to reload the
	 *  grid by <code>setTablePreferenceByName </code> in the newest version. However, getTablePreference is already
	 *  deprecated and probably the string it generated is not able to use any more.
	 * 
	 *  @param table the table
	 *  @return table preference string.
	 */
	public static String getTablePreferenceByName(javax.swing.JTable table) {
	}

	/**
	 *  Gets the table preference string. The preference string contains the information such as each table column width,
	 *  column order and column visibilities. If the table column width or order or visibility is changed after
	 *  getTablePreference is called, setTablePreference() will change table column width, order and visibility to the
	 *  previous state when this preference string is saved.
	 *  <p/>
	 *  <p/>
	 *  The method is designed for {@link com.jidesoft.grid.TableScrollPane}. So you don't have to save the tables one by
	 *  one in your table scroll pane.
	 *  <p/>
	 *  this method will save the column name as defined in <code>TableModel</code>'s <code>getColumnName</code> method.
	 *  So as long as the column name doesn't change, you can use {@link #setTablePreferenceByName(javax.swing.JTable,String)}
	 *  to restore correctly, even if you add or remove columns between get and set. Please also note, since the column
	 *  names can be localized and sometimes can be duplicated, you can implement {@link
	 *  com.jidesoft.grid.ColumnIdentifierTableModel} and provides a unique column identifier for each column. This
	 *  method will use the identifier returned from ColumnIdentifierTableModel's getColumnIdentifier method.
	 * 
	 *  @param pane the table scroll pane
	 *  @return table preference string.
	 */
	public static String getTablePreferenceByName(TableScrollPane pane) {
	}

	/**
	 *  Sets the table preference string that was saved before to the table. This method will only restore correctly if
	 *  the string is saved by {@link #getTablePreferenceByName(javax.swing.JTable)}.
	 *  <p/>
	 *  The method is designed for single table only. If you are trying to set table preference for {@link
	 *  com.jidesoft.grid.TableScrollPane}, please use {@link #setTablePreferenceByName(TableScrollPane, String)}.
	 *  <p/>
	 * 
	 *  @param table the table
	 *  @param pref  the preference string. If the value is null or if the string is not saved from the table as
	 *               specified in table parameter, this method will simply return and won't change the table at all.
	 *  @return true if the preference is set correctly. Otherwise false.
	 */
	public static boolean setTablePreferenceByName(javax.swing.JTable table, String pref) {
	}

	/**
	 *  Sets the table preference string that was saved before to the table. This method will only restore correctly if
	 *  the string is saved by {@link #getTablePreferenceByName(javax.swing.JTable)}.
	 *  <p/>
	 *  The method is designed for single table only. If you are trying to set table preference for {@link
	 *  com.jidesoft.grid.TableScrollPane}, please use {@link #setTablePreferenceByName(TableScrollPane, String)}.
	 *  <p/>
	 * 
	 *  @param table              the table
	 *  @param pref               the preference string. If the value is null or if the string is not saved from the
	 *                            table as specified in table parameter, this method will simply return and won't change
	 *                            the table at all.
	 *  @param respectColumnModel the default value is true so that you'll just keep the visible columns in columnModel.
	 *                            However, if you want to respsect the table model instead, you need set it to false.
	 *  @return true if the preference is set correctly. Otherwise false.
	 */
	public static boolean setTablePreferenceByName(javax.swing.JTable table, String pref, boolean respectColumnModel) {
	}

	/**
	 *  Sets the table preference string that was saved before to the table. This method will only restore correctly if
	 *  the string is saved by {@link #getTablePreferenceByName(TableScrollPane)}.
	 *  <p/>
	 *  The method is designed for {@link com.jidesoft.grid.TableScrollPane}. So you don't have to set the table
	 *  preference one by one in your table scroll pane.
	 *  <p/>
	 * 
	 *  @param pane the table scroll pane
	 *  @param pref the preference string. If the value is null or if the string is not saved from the table as specified
	 *              in table parameter, this method will simply return and won't change the table at all.
	 *  @return true if the preference is set correctly. Otherwise false.
	 */
	public static boolean setTablePreferenceByName(TableScrollPane pane, String pref) {
	}

	/**
	 *  Sets the table preference string that was saved before to the table. This method will only restore correctly if
	 *  the string is saved by {@link #getTablePreferenceByName(TableScrollPane)}.
	 *  <p/>
	 *  The method is designed for {@link com.jidesoft.grid.TableScrollPane}. So you don't have to set the table
	 *  preference one by one in your table scroll pane.
	 *  <p/>
	 * 
	 *  @param pane               the table scroll pane
	 *  @param pref               the preference string. If the value is null or if the string is not saved from the
	 *                            table as specified in table parameter, this method will simply return and won't change
	 *                            the table at all.
	 *  @param respectColumnModel the default value is true so that you'll just keep the visible columns in columnModel.
	 *                            However, if you want to respsect the table model instead, you need set it to false.
	 *  @return true if the preference is set correctly. Otherwise false.
	 */
	public static boolean setTablePreferenceByName(TableScrollPane pane, String pref, boolean respectColumnModel) {
	}

	/**
	 *  It's for internal use only.
	 * 
	 *  @param table              the table
	 *  @param columnIndexMap     column index map
	 *  @param snapshot           column order snapshot
	 *  @param values             saved column width values
	 *  @param columnCount        saved column count
	 *  @param respectColumnModel the flag
	 */
	public static void adjustColumnOrderAndWidth(javax.swing.JTable table, java.util.Map columnIndexMap, TableColumnSnapshot snapshot, String[] values, int columnCount, boolean respectColumnModel) {
	}

	/**
	 *  It's for internal use only.
	 * 
	 *  @param pane               table scroll pane
	 *  @param columnIndexMap     column index map
	 *  @param snapshot           column order snapshot
	 *  @param values             saved column width values
	 *  @param columnCount        saved column count
	 *  @param respectColumnModel the flag
	 */
	public static void adjustColumnOrderAndWidth(TableScrollPane pane, java.util.Map columnIndexMap, TableColumnSnapshot snapshot, String[] values, int columnCount, boolean respectColumnModel) {
	}

	/**
	 *  Sets the table preference string that was saved before to the table. This method will only restore correctly if
	 *  the string is saved by {@link #getTablePreferenceByName(javax.swing.JTable)}. Different from {@link
	 *  #setTablePreferenceByName(javax.swing.JTable, String)}, this method only restores the column width but not the
	 *  column order.
	 *  <p/>
	 * 
	 *  @param table the table
	 *  @param pref  the preference string. If the value is null or if the string is not saved from the table as
	 *               specified in table parameter, this method will simply return and won't change the table at all.
	 *  @return true if the preference is set correctly. Otherwise false.
	 */
	public static boolean setTableColumnWidthByName(javax.swing.JTable table, String pref) {
	}

	/**
	 *  Sets the table preference string that was saved before to the TableScollPane. This method will only restore
	 *  correctly if the string is saved by {@link #getTablePreferenceByName(TableScrollPane)}. Different from {@link
	 *  #setTablePreferenceByName(TableScrollPane, String)}, this method only restores the column width but not the
	 *  column order.
	 *  <p/>
	 * 
	 *  @param pane the table scroll pane
	 *  @param pref the preference string. If the value is null or if the string is not saved from the table scroll pane
	 *              as specified in table parameter, this method will simply return and won't change the table scroll
	 *              pane at all.
	 *  @return true if the preference is set correctly. Otherwise false.
	 */
	public static boolean setTableColumnWidthByName(TableScrollPane pane, String pref) {
	}

	/**
	 *  Gets the table preference string. The preference string contains the information such as each table column width,
	 *  column order and column visibilities. If the table column width or order or visibility is changed after
	 *  getTablePreference is called, setTablePreference() will change table column width, order and visibility to the
	 *  previous state when is preference string is saved.
	 *  <p/>
	 *  Please note, different from {@link #getTablePreferenceByName(javax.swing.JTable)}, this method will save only
	 *  save the column index. So if the column order changes, {@link #setTablePreference(javax.swing.JTable,String)}
	 *  might restore it incorrectly. Or if the column count changes, <code>setTablePreference</code> will simply return
	 *  without even trying to restore.
	 * 
	 *  @param table the table
	 *  @return table preference string.
	 * 
	 *  @deprecated replaced by {@link #getTablePreferenceByName(javax.swing.JTable)}
	 */
	@java.lang.Deprecated
	public static String getTablePreference(javax.swing.JTable table) {
	}

	/**
	 *  Sets the table preference string that was saved before to the table.
	 *  <p/>
	 *  Note: This method works only if all columns in the TableColumnModel are there in the TableModel. If you manually
	 *  add a column to TableColumnModel without adding it to TableModel, this method won't work.
	 *  <p/>
	 * 
	 *  @param table the table
	 *  @param pref  the preference string. If the value is null or if the string is not saved from the table as
	 *               specified in table parameter, this method will simply return and won't change the table at all.
	 *  @return true if the preference is set correctly. Otherwise false.
	 * 
	 *  @deprecated replaced by {@link #setTablePreferenceByName(javax.swing.JTable, String)}
	 */
	@java.lang.Deprecated
	public static boolean setTablePreference(javax.swing.JTable table, String pref) {
	}

	/**
	 *  Gets the sortable table sorting order as String. The preference string contains the information such as table
	 *  column sorting order. If the table sorting order is changed after getSortableTablePreference is called,
	 *  setSortableTablePreference() will restore the sort order.
	 * 
	 *  @param table the table
	 *  @return sortable table preference string.
	 */
	public static String getSortableTablePreference(SortableTable table) {
	}

	/**
	 *  Gets the sortable table sorting order as String. The preference string contains the information such as table
	 *  column sorting order. If the table sorting order is changed after getSortableTablePreference is called,
	 *  setSortableTablePreference() will restore the sort order.
	 *  <p/>
	 * 
	 *  @param table         the table
	 *  @param saveColumName true or false. If true, we will keep the column name or identifier in the preference string
	 *                       instead of using column index. If your TableModel's column index (please note, not
	 *                       TableColumnModel) could change but the column name or identifier never changes, you should
	 *                       use true as the parameter.
	 *  @return sortable table preference string.
	 */
	public static String getSortableTablePreference(SortableTable table, boolean saveColumName) {
	}

	/**
	 *  Sets the sortable table sorting order preference string that was saved before to the table.
	 *  <p/>
	 * 
	 *  @param table the table
	 *  @param pref  the preference string. If the value is null or if the string is not saved from the table as
	 *               specified in table parameter, this method will simply return and won't change the table at all.
	 *  @return true if the preference is set correctly. Otherwise false.
	 */
	public static boolean setSortableTablePreference(SortableTable table, String pref) {
	}

	/**
	 *  Sets the sortable table sorting order preference string that was saved before to the table.
	 *  <p/>
	 * 
	 *  @param table         the table
	 *  @param saveColumName true or false. Please always use the same value when you call {@link
	 *                       #getSortableTablePreference(SortableTable,boolean)}.
	 *  @param pref          the preference string. If the value is null or if the string is not saved from the table as
	 *                       specified in table parameter, this method will simply return and won't change the table at
	 *                       all.
	 *  @return true if the preference is set correctly. Otherwise false.
	 */
	public static boolean setSortableTablePreference(SortableTable table, String pref, boolean saveColumName) {
	}

	/**
	 *  Synchronizes the row selection of the tables so that if any rows in one table is selected, the same rows in all
	 *  tables will be selected too.
	 * 
	 *  @param tables the tables
	 */
	public static void synchronizeTableRowSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  UnSynchronizes the row selection of the tables. This method is only useful if you called {@link
	 *  #synchronizeTableRowSelection(javax.swing.JTable[])} earlier.
	 * 
	 *  @param tables the tables
	 */
	public static void unsynchronizeTableRowSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Unifies the row selection into one selection so that only one row can be selected in all tables. You should call
	 *  this method only when the table in tables array in row selection mode.
	 *  <p/>
	 *  Internally it uses {@link ListSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void unifyTableRowSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Reverts the unification of the row selection by {@link #unifyTableRowSelection(javax.swing.JTable[])}. This
	 *  method is only useful if you called {@link #unifyTableRowSelection(javax.swing.JTable[])} earlier.
	 *  <p/>
	 *  <p/>
	 *  Internally it uses {@link ListSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void ununifyTableRowSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Unifies the column selection into one selection so that only one column can be selected in all tables. You should
	 *  call this method only when the table in tables array in column selection mode.
	 *  <p/>
	 *  Internally it uses {@link ListSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void unifyTableColumnSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Revers the unification of the column selection by {@link #unifyTableColumnSelection(javax.swing.JTable[])}. This
	 *  method is only useful if you called {@link #unifyTableColumnSelection(javax.swing.JTable[])} earlier.
	 *  <p/>
	 *  <p/>
	 *  Internally it uses {@link ListSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void ununifyTableColumnSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Unifies the non-contiguous cell selection into one selection so that only one cell can be selected in all tables.
	 *  You should call this method only when the table in tables array in non-contiguous cell selection mode.
	 *  <p/>
	 *  Internally it uses {@link TableSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void unifyTableNonContiguousCellSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Reverts the unification of the cell selection by {@link #unifyTableNonContiguousCellSelection(javax.swing.JTable[])}.
	 *  This method is only useful if you called {@link #unifyTableNonContiguousCellSelection(javax.swing.JTable[])}
	 *  earlier.
	 *  <p/>
	 *  <p/>
	 *  Internally it uses {@link TableSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void ununifyTableNonContiguousCellSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Unifies the mixed cell selection into one selection so that only one cell can be selected in all tables. You
	 *  could call this method when your tables have different cell selection options.
	 *  <p/>
	 *  Internally it uses {@link MixedTableSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void unifyTableCellSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Unifies the mixed cell selection into one selection so that only one cell can be selected in all tables. You
	 *  could call this method when your tables have different cell selection options.
	 *  <p/>
	 *  Internally it uses {@link MixedTableSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables    the tables
	 *  @param stayTable the table which will not clear its selection on other table's selection
	 */
	public static void unifyTableCellSelection(javax.swing.JTable[] tables, javax.swing.JTable stayTable) {
	}

	/**
	 *  Reverts the unification of the cell selection by {@link #unifyTableCellSelection(javax.swing.JTable[])}. This
	 *  method is only useful if you called {@link #unifyTableCellSelection(javax.swing.JTable[])} earlier.
	 *  <p/>
	 *  <p/>
	 *  Internally it uses {@link MixedTableSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void ununifyTableCellSelection(javax.swing.JTable[] tables) {
	}

	/**
	 *  Unifies the column selection into one selection so that only one column can be selected in all tables. You should
	 *  call this method only when the table in tables array in column selection mode.
	 *  <p/>
	 *  Internally it uses {@link ListSelectionModelGroup} to implement this feature.
	 * 
	 *  @param tables the tables
	 */
	public static void unifyTableCellEditing(javax.swing.JTable[] tables) {
	}

	/**
	 *  Reverts the unification of the table celling by {@link #unifyTableCellEditing(javax.swing.JTable[])}. This
	 *  method is only useful if you called {@link #unifyTableCellEditing(javax.swing.JTable[])} earlier.
	 *  <p/>
	 * 
	 *  @param tables the tables
	 */
	public static void ununifyTableCellEditing(javax.swing.JTable[] tables) {
	}

	/**
	 *  Synchronizes the table height of the list of tables to be the same. Whenever one table's {@link
	 *  JTable#setRowHeight(int)} method is called, the new height will be applied to all tables. This is only for when
	 *  table rows have the same row height. If they have different row heights, you should use {@link
	 *  #synchronizeRowHeights(JTable[])} to synchronize the row heights.
	 * 
	 *  @param tables the tables
	 */
	public static void synchronizeRowHeight(javax.swing.JTable[] tables) {
	}

	/**
	 *  Synchronizes the table row heights and table header height.
	 *  <p/>
	 *  Even though the parameter is an array of regular JTable, the code actually requires an array of JideTable which
	 *  provides additional features of row heights.
	 * 
	 *  @param tables the tables
	 */
	public static void synchronizeRowHeights(javax.swing.JTable[] tables) {
	}

	/**
	 *  Makes the master table and slave table using the same SelectionModel so that when any selection change in master
	 *  table will be reflected in slave table too.
	 * 
	 *  @param master the master table
	 *  @param slave  the slave table
	 */
	public static void synchronizeTableColumnSelection(javax.swing.JTable master, javax.swing.JTable slave) {
	}

	/**
	 *  The reverse action of {@link #synchronizeTableColumnSelection(javax.swing.JTable, javax.swing.JTable)}.
	 * 
	 *  @param master the master table
	 *  @param slave  the slave table
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static void unsynchronizeTableColumnSelection(javax.swing.JTable master, javax.swing.JTable slave) {
	}

	/**
	 *  Links the tables in the table array so that they look like one table. The things this method actually did is
	 *  smoothing key navigation (tab or array key will navigate across the table, maintaining only one sorting column if
	 *  those are SortableTable, synchronizing the row selection.
	 * 
	 *  @param tables the tables
	 */
	public static void synchronizeTables(javax.swing.JTable[] tables) {
	}

	/**
	 *  Links the tables in the table array so that they look like one table. The things this method actually did is
	 *  smoothing key navigation (tab or array key will navigate across the table, maintaining only one sorting column if
	 *  those are SortableTable, synchronizing the row selection.
	 * 
	 *  @param tables                 the list of tables.
	 *  @param rowSelectionAllowed    whether row selection is allowed.
	 *  @param columnSelectionAllowed whether column selection is allowed.
	 */
	public static void synchronizeTables(javax.swing.JTable[] tables, boolean rowSelectionAllowed, boolean columnSelectionAllowed) {
	}

	/**
	 *  Links the tables in the table array so that they look like one table. The things this method actually did is
	 *  smoothing key navigation (tab or array key will navigate across the table, maintaining only one sorting column if
	 *  those are SortableTable, synchronizing the row selection.
	 * 
	 *  @param tables                        the tables
	 *  @param rowSelectionAllowed           true to allow the row selection. Otherwise false.
	 *  @param columnSelectionAllowed        true to allow the column selection. Otherwise false.
	 *  @param nonContiguousSelectionAllowed true to allow the non-contiguous cell selection. Otherwise false.
	 */
	public static void synchronizeTables(javax.swing.JTable[] tables, boolean rowSelectionAllowed, boolean columnSelectionAllowed, boolean nonContiguousSelectionAllowed) {
	}

	public static void synchronizeSorting(javax.swing.JTable[] tables) {
	}

	/**
	 *  Synchronizes the navigation keys. The navigation keys include TAB, SHIFT-TAB, LEFT, RIGHT. Basically if you press
	 *  TAB key at the last column, the focus will change to the next table's first column of the same row.
	 * 
	 *  @param tables the tables
	 */
	public static void synchronizeNavigationKeys(javax.swing.JTable[] tables) {
	}

	/**
	 *  Unsynchronizes the navigation keys. It basically undo the changes did by {@link
	 *  #synchronizeNavigationKeys(javax.swing.JTable[])}.
	 * 
	 *  @param tables the tables
	 */
	public static void unsynchronizeNavigationKeys(javax.swing.JTable[] tables) {
	}

	protected static int nextRow(javax.swing.JTable table, javax.swing.JTable nextTable) {
	}

	protected static int previousRow(javax.swing.JTable table, javax.swing.JTable prevTable) {
	}

	/**
	 *  Synchronize two tables' columns so that the corresponding table column in both tables have the same width, at the
	 *  same position. If column selection is enabled, they will have the same column selection.
	 * 
	 *  @param master the master table
	 *  @param slave  the slave table
	 */
	public static void synchronizeTableColumn(javax.swing.JTable master, javax.swing.JTable slave) {
	}

	/**
	 *  The reverse action of {@link #synchronizeTableColumn(javax.swing.JTable, javax.swing.JTable)}.
	 * 
	 *  @param master the master table
	 *  @param slave  the slave table
	 */
	public static void unsynchronizeTableColumn(javax.swing.JTable master, javax.swing.JTable slave) {
	}

	/**
	 *  Synchronize two tables' columns so that the corresponding table column in both tables have the same width.
	 *  Different from {@link #synchronizeTableColumn(javax.swing.JTable,javax.swing.JTable)}, this method only
	 *  synchronizes the two tables' width and their columns width.
	 * 
	 *  @param master the master table
	 *  @param slave  the slave table
	 */
	public static void synchronizeTableColumnWidth(javax.swing.JTable master, javax.swing.JTable slave) {
	}

	/**
	 *  Synchronizes the two table columns width as well as the whole table width. It assumes the two tables have the
	 *  same number of columns. This method will only synchronize the two tables' width and columns' width once. If the
	 *  width of master table changes after this method is called, the slave table will not change. If you want the two
	 *  tables to be always synchronized, you can use {@link #synchronizeTableColumnWidth(javax.swing.JTable,javax.swing.JTable)}
	 *  method.
	 * 
	 *  @param master the master table
	 *  @param slave  the slave table
	 */
	public static void synchronizeTableAndColumnsWidth(javax.swing.JTable master, javax.swing.JTable slave) {
	}

	public static void synchronizeTableColumnWidthNow(javax.swing.JTable master, javax.swing.JTable slave) {
	}

	/**
	 *  Gets the value of extra width we will add to calculated column width when we do {@link
	 *  #autoResizeAllColumns(javax.swing.JTable)} or {@link #autoResizeColumn(javax.swing.JTable,int)}. Default is 4.
	 * 
	 *  @return extra width when we auto-resize table column.
	 */
	public static int getAutoResizeExtraWidth() {
	}

	/**
	 *  We will add 4 pixels extra width to the calculated column width when we do {@link
	 *  #autoResizeAllColumns(javax.swing.JTable)} or {@link #autoResizeColumn(javax.swing.JTable,int)}. You can change
	 *  this field to a different value if you want a different extra width.
	 * 
	 *  @param autoResizeExtraWidth the extra width added to the calculated preferred width.
	 */
	public static void setAutoResizeExtraWidth(int autoResizeExtraWidth) {
	}

	/**
	 *  Calculates the optimal width for the column of the given table. The calculation is based on the preferred width
	 *  of the header and cell renderer.
	 *  <p/>
	 *  By default, it will consider header column width. If you don't want, you can either use {@link
	 *  #autoResizeColumn(javax.swing.JTable,int,boolean)} method or you can call table.putClientProperty(TableUtils.AUTO_RESIZE_CONSIDER_HEADER,
	 *  Boolean.FALSE).
	 *  <p/>
	 *  Taken from the newsgroup de.comp.lang.java with some modifications.
	 * 
	 *  @param table the table to calculate the column width
	 *  @param col   the column to calculate the widths
	 *  @return the preferred width it sets to the column. -1 if the preferred width is not changed.
	 */
	public static int autoResizeColumn(javax.swing.JTable table, int col) {
	}

	/**
	 *  Calculates the optimal width for the column of the given table. The calculation is based on the preferred width
	 *  of the header (optional) and cell renderer. <br> Taken from the newsgroup de.comp.lang.java with some
	 *  modifications.
	 * 
	 *  @param table          the table to calculate the column width
	 *  @param col            the column to calculate the widths
	 *  @param considerHeader if considering header column width when calculating the optimal width. Please note, for the
	 *                        NestedTableHeader, only the last row in the table header can be considered.
	 *  @return the preferred width it sets to the column. -1 if the preferred width is not changed.
	 */
	public static int autoResizeColumn(javax.swing.JTable table, int col, boolean considerHeader) {
	}

	/**
	 *  Calculates the optimal width for the column of the given table. The calculation is based on the preferred width
	 *  of the header (optional) and cell renderer. <br> Taken from the newsgroup de.comp.lang.java with some
	 *  modifications.
	 * 
	 *  @param table           the table to calculate the column width
	 *  @param col             the column to calculate the widths
	 *  @param considerHeader  if considering header column width when calculating the optimal width. Please note, for
	 *                         the NestedTableHeader, only the last row in the table header can be considered.
	 *  @param visibleRowsOnly if we only consider the visible rows width only when calculating the preferred width.
	 *  @return the preferred width it sets to the column. -1 if the preferred width is not changed.
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static int autoResizeColumn(javax.swing.JTable table, int col, boolean considerHeader, boolean visibleRowsOnly) {
	}

	/**
	 *  Calculates the optimal width for the column of the given table. The calculation is based on the preferred width
	 *  of the header (optional) and cell renderer. <br> Taken from the newsgroup de.comp.lang.java with some
	 *  modifications.
	 * 
	 *  @param table           the table to calculate the column width
	 *  @param col             the column to calculate the widths
	 *  @param considerHeader  if considering header column width when calculating the optimal width. Please note, for
	 *                         the NestedTableHeader, only the last row in the table header can be considered.
	 *  @param visibleRowsOnly if we only consider the visible rows width only when calculating the preferred width.
	 *  @param minimumWidth    the minimum width of the column after resizing. -1 if there is no minimum width.
	 *  @return the preferred width it sets to the column. -1 if the preferred width is not changed.
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static int autoResizeColumn(javax.swing.JTable table, int col, boolean considerHeader, boolean visibleRowsOnly, int minimumWidth) {
	}

	/**
	 *  Calculates the optimal width for all columns of the given table. The calculation is based on the preferred width
	 *  of the header and cell renderer. In order to make this method working correctly, you also need to call {@link
	 *  JTable#setAutoResizeMode(int)} and set it to {@link JTable#AUTO_RESIZE_OFF}. <br> Taken from the newsgroup
	 *  de.comp.lang.java with some modifications.
	 *  <p/>
	 *  autoResizeAllColumns will calculate the width of each column first then resize the table using
	 *  SwingUtlities.invokeLater if the calling thread is not EDT. So this method is Swing thread safe. Because of this
	 *  feature, when this method returns while the calling thread is not EDT, you cannot assume the table columns are
	 *  all correctly resized (as it depends on when SwingUtlities.invokeLater actually calls). However the returned int
	 *  array will tell you the width of all columns after they are resized.
	 * 
	 *  @param table the table to calculate the column widths
	 *  @return the resized table column width as an int array.
	 */
	public static int[] autoResizeAllColumns(javax.swing.JTable table) {
	}

	/**
	 *  Calculates the optimal width for all columns of the given table. The calculation is based on the preferred width
	 *  of the header and cell renderer. In order to make this method working correctly, you also need to call {@link
	 *  JTable#setAutoResizeMode(int)} and set it to {@link JTable#AUTO_RESIZE_OFF}. <br> Taken from the newsgroup
	 *  de.comp.lang.java with some modifications.
	 *  <p/>
	 *  autoResizeAllColumns will calculate the width of each column first then resize the table using
	 *  SwingUtlities.invokeLater if the calling thread is not EDT. So this method is Swing thread safe. Because of this
	 *  feature, when this method returns while the calling thread is not EDT, you cannot assume the table columns are
	 *  all correctly resized (as it depends on when SwingUtlities.invokeLater actually calls). However the returned int
	 *  array will tell you the width of all columns after they are resized.
	 * 
	 *  @param table          the table to calculate the column widths
	 *  @param considerHeader if considering header column width when calculating the optimal width. Please note, for the
	 *                        NestedTableHeader, only the last row in the table header can be considered.
	 *  @return the resized table column width as an int array.
	 */
	public static int[] autoResizeAllColumns(javax.swing.JTable table, boolean considerHeader) {
	}

	/**
	 *  Calculates the optimal width for all columns of the given table. The calculation is based on the preferred width
	 *  of the header and cell renderer. In order to make this method working correctly, you also need to call {@link
	 *  JTable#setAutoResizeMode(int)} and set it to {@link JTable#AUTO_RESIZE_OFF}. <br> Taken from the newsgroup
	 *  de.comp.lang.java with some modifications.
	 *  <p/>
	 *  autoResizeAllColumns will calculate the width of each column first then resize the table using
	 *  SwingUtlities.invokeLater if the calling thread is not EDT. So this method is Swing thread safe. Because of this
	 *  feature, when this method returns while the calling thread is not EDT, you cannot assume the table columns are
	 *  all correctly resized (as it depends on when SwingUtlities.invokeLater actually calls). However the returned int
	 *  array will tell you the width of all columns after they are resized.
	 * 
	 *  @param table          the table to calculate the column widths
	 *  @param minimumWidth   the minimum width of each column. It could be either null or the same length as the table
	 *                        column count.
	 *  @param considerHeader if considering header column width when calculating the optimal width. Please note, for the
	 *                        NestedTableHeader, only the last row in the table header can be considered.
	 *  @return the resized table column width as an int array.
	 */
	public static int[] autoResizeAllColumns(javax.swing.JTable table, int[] minimumWidth, boolean considerHeader) {
	}

	/**
	 *  Calculates the optimal width for all columns of the given table. The calculation is based on the preferred width
	 *  of the header and cell renderer. In order to make this method working correctly, you also need to call {@link
	 *  JTable#setAutoResizeMode(int)} and set it to {@link JTable#AUTO_RESIZE_OFF}. <br> Taken from the newsgroup
	 *  de.comp.lang.java with some modifications.
	 *  <p/>
	 *  autoResizeAllColumns will calculate the width of each column first then resize the table using
	 *  SwingUtlities.invokeLater if the calling thread is not EDT. So this method is Swing thread safe. Because of this
	 *  feature, when this method returns while the calling thread is not EDT, you cannot assume the table columns are
	 *  all correctly resized (as it depends on when SwingUtlities.invokeLater actually calls). However the returned int
	 *  array will tell you the width of all columns after they are resized.
	 * 
	 *  @param table           the table to calculate the column widths
	 *  @param minimumWidth    the minimum width of each column. It could be either null or the same length as the table
	 *                         column count.
	 *  @param considerHeader  if considering header column width when calculating the optimal width. Please note, for
	 *                         the NestedTableHeader, only the last row in the table header can be considered.
	 *  @param visibleRowsOnly if we only consider the visible rows width only when calculating the preferred width.
	 *  @return the resized table column width as an int array.
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static int[] autoResizeAllColumns(javax.swing.JTable table, int[] minimumWidth, boolean considerHeader, boolean visibleRowsOnly) {
	}

	/**
	 *  Checks if the table column is resizable. It is resizable only when table header allows resizing and the column
	 *  getResizable() return true. If table header is null, as long as the column is resizable, it will return true.
	 * 
	 *  @param table  the table
	 *  @param column the column index.
	 *  @return true if the column can be resized.
	 */
	public static boolean isTableColumnResizable(javax.swing.JTable table, javax.swing.table.TableColumn column) {
	}

	/**
	 *  Calculates the optimal height for the row of the given table.
	 * 
	 *  @param table the table to calculate the row height
	 *  @param row   the row to calculate the height
	 *  @return the preferred height of this row
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static int autoResizeRow(javax.swing.JTable table, int row) {
	}

	/**
	 *  Calculates the optimal height for the row of the given table.
	 * 
	 *  @param table         the table to calculate the row height
	 *  @param row           the row to calculate the height
	 *  @param minimumHeight the minimum height of the row after resizing. -1 if there is no minimum height.
	 *  @return the preferred height of this row
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static int autoResizeRow(javax.swing.JTable table, int row, int minimumHeight) {
	}

	/**
	 *  Calculates the optimal height for the rows of the given table.
	 *  <p/>
	 *  autoResizeAllRows will calculate the height of each row first then resize the table using
	 *  SwingUtlities.invokeLater if the calling thread is not EDT. So this method is Swing thread safe. Because of this
	 *  feature, when this method returns while the calling thread is not EDT, you cannot assume the table rows are all
	 *  correctly resized (as it depends on when SwingUtlities.invokeLater actually calls). However the returned int
	 *  array will tell you the height of all rows after they are resized.
	 * 
	 *  @param table   the table to calculate the row heights
	 *  @param fromRow the beginning row to auto resize
	 *  @param toRow   the end row to auto resize
	 *  @return the row heights array after resize.
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static int[] autoResizeRows(javax.swing.JTable table, int fromRow, int toRow) {
	}

	/**
	 *  Calculates the optimal height for the rows of the given table.
	 *  <p/>
	 *  autoResizeAllRows will calculate the height of each row first then resize the table using
	 *  SwingUtlities.invokeLater if the calling thread is not EDT. So this method is Swing thread safe. Because of this
	 *  feature, when this method returns while the calling thread is not EDT, you cannot assume the table rows are all
	 *  correctly resized (as it depends on when SwingUtlities.invokeLater actually calls). However the returned int
	 *  array will tell you the height of all rows after they are resized.
	 * 
	 *  @param table         the table to calculate the row heights
	 *  @param fromRow       the beginning row to auto resize
	 *  @param toRow         the end row to auto resize
	 *  @param minimumHeight the minimum height of each row. It could be either null or the same length as the table row
	 *                       count.
	 *  @return the row heights array after resize.
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static int[] autoResizeRows(javax.swing.JTable table, int fromRow, int toRow, int[] minimumHeight) {
	}

	/**
	 *  Calculates the optimal height for the row of the given table.
	 *  <p/>
	 *  autoResizeAllRows will calculate the height of each row first then resize the table using
	 *  SwingUtlities.invokeLater if the calling thread is not EDT. So this method is Swing thread safe. Because of this
	 *  feature, when this method returns while the calling thread is not EDT, you cannot assume the table rows are all
	 *  correctly resized (as it depends on when SwingUtlities.invokeLater actually calls). However the returned int
	 *  array will tell you the height of all rows after they are resized.
	 * 
	 *  @param table the table to calculate the row heights
	 *  @return the row heights array after resize.
	 */
	public static int[] autoResizeAllRows(javax.swing.JTable table) {
	}

	/**
	 *  Calculates the optimal height for the row of the given table.
	 *  <p/>
	 *  autoResizeAllRows will calculate the height of each row first then resize the table using
	 *  SwingUtlities.invokeLater if the calling thread is not EDT. So this method is Swing thread safe. Because of this
	 *  feature, when this method returns while the calling thread is not EDT, you cannot assume the table rows are all
	 *  correctly resized (as it depends on when SwingUtlities.invokeLater actually calls). However the returned int
	 *  array will tell you the height of all rows after they are resized.
	 * 
	 *  @param table         the table to calculate the row heights
	 *  @param minimumHeight the minimum height of each row. It could be either null or the same length as the table row
	 *                       count.
	 *  @return the row heights array after resize.
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	public static int[] autoResizeAllRows(javax.swing.JTable table, int[] minimumHeight) {
	}

	protected static int calculateRowHeight(javax.swing.JTable table, int row, int minimumHeight) {
	}

	/**
	 *  To make sure the selected row is visible. If there are multiple selections, it will try to make the as many
	 *  selections visible as possible.
	 * 
	 *  @param table the table
	 */
	public static void ensureRowSelectionVisible(javax.swing.JTable table) {
	}

	/**
	 *  To make sure the row is visible. If the table's horizontal scroll bar is visible, the method will not change the
	 *  horizontal scroll bar's position.
	 * 
	 *  @param table the table
	 *  @param row   the row index
	 */
	public static void ensureRowVisible(javax.swing.JTable table, int row) {
	}

	/**
	 *  Finds the column that has the columnName.
	 * 
	 *  @param model      the table model.
	 *  @param columnName the column name
	 *  @return the column index of the column that has the columnName. -1 if columnName is null or not found.
	 */
	public static int findColumnIndex(javax.swing.table.TableModel model, String columnName) {
	}

	/**
	 *  Finds the column indexes that has the name specified in the columnNames array.
	 * 
	 *  @param model       the table model
	 *  @param columnNames column names array
	 *  @return the column index array of the columns that have the columnName. Null if columnNames is null. -1 in the
	 *          returned array if the column name is not found.
	 */
	public static int[] findColumnIndexes(javax.swing.table.TableModel model, String[] columnNames) {
	}

	/**
	 *  Gets the view y position for the row in a table.
	 * 
	 *  @param table the table.
	 *  @param row   the row index.
	 *  @return the y position of the row.
	 */
	public static int getViewPositionForRow(javax.swing.JTable table, int row) {
	}

	/**
	 *  Sets the view y position for the row in a table.
	 * 
	 *  @param table    the table.
	 *  @param row      the row index.
	 *  @param position the y position.
	 */
	public static void setViewPositionForRow(javax.swing.JTable table, int row, int position) {
	}

	public static void saveColumnOrders(javax.swing.JTable table, boolean isUngroup) {
	}

	public static void clearColumnOrdersMemory(javax.swing.JTable table) {
	}

	public static void saveDefaultColumnOrders(TableScrollPane pane, javax.swing.table.TableModel model) {
	}

	public static void saveDefaultColumnOrders(GroupTable table) {
	}

	public static void saveColumnOrders(TableScrollPane pane) {
	}

	public static void clearColumnOrdersMemory(TableScrollPane pane) {
	}

	/**
	 *  Get the resizing column instance based on the table and point and the column.
	 * 
	 *  @param table  the resizing JTable
	 *  @param p      the point of the mouse event
	 *  @param column the column
	 *  @return the resizing TableColumn instance. null if no instance found.
	 */
	public static javax.swing.table.TableColumn getResizingColumn(javax.swing.JTable table, java.awt.Point p, int column) {
	}
}
