/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableCustomFilterEditor</code> adds additional controls to create a list of FilterItems and they can be added
 *  to <code>FilterableTableModel</code>. To get the list of <code>FilterItem</code>s, you can call {@link
 *  #getFilterItems()} method.
 */
public class TableCustomFilterEditor extends AbstractDialogPage {

	public TableCustomFilterEditor(javax.swing.table.TableModel tableModel) {
	}

	public void lazyInitialize() {
	}

	protected void initComponents() {
	}

	/**
	 *  Creates the FilterFactoryManager used by this TableCustomFilterEditor. Subclass can override it to provide your
	 *  own instance of FilterFactoryManager or customize it before returning the one created by
	 *  super.createFilterFactoryManager.
	 * 
	 *  @return an new instance of FilterFactoryManager.
	 */
	protected com.jidesoft.filter.FilterFactoryManager createFilterFactoryManager() {
	}

	/**
	 *  Gets the table column name.
	 * 
	 *  @param tableModel  the table model.
	 *  @param columnIndex the column index.
	 *  @return the name of the column at the specified index.
	 */
	protected String getColumnName(javax.swing.table.TableModel tableModel, int columnIndex) {
	}

	/**
	 *  Creates a CustomFilterEditor.
	 * 
	 *  @param filterFactoryManager the FilterFactoryManager.
	 *  @param type                 the type.
	 *  @param converterContext     the ConverterContext.
	 *  @param possibleValues       the possible values.
	 *  @return a new instance of CustomFilterEditor.
	 */
	protected com.jidesoft.filter.CustomFilterEditor createCustomFilterEditor(com.jidesoft.filter.FilterFactoryManager filterFactoryManager, Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	/**
	 *  Creates the ValueEditor.
	 * 
	 *  @param type             the type.
	 *  @param converterContext the ConverterContext.
	 *  @param possibleValues   the possible values.
	 *  @return a new instance of the ValueEditor.
	 */
	protected com.jidesoft.filter.ValueEditor createValueEditor(Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	/**
	 *  Gets the FilterItems defined in this <code>TableCustomFilterEditor</code>.
	 * 
	 *  @return the FilterItems defined in this <code>TableCustomFilterEditor</code>.
	 */
	public IFilterableTableModel.FilterItem[] getFilterItems() {
	}

	/**
	 *  Sets the FilterItems. It will remove all existing FilterItems defined in the editor and replace them with the new
	 *  ones.
	 * 
	 *  @param filterItems the FilterItems defined this <code>TableCustomFilterEditor</code>.
	 */
	public void setFilterItems(IFilterableTableModel.FilterItem[] filterItems) {
	}

	/**
	 *  Gets the FilterFactoryManager used by this <code>TableCustomFilterEditor</code>.
	 * 
	 *  @return the FilterFactoryManager instance.
	 */
	public com.jidesoft.filter.FilterFactoryManager getFilterFactoryManager() {
	}

	protected String getResourceString(String key) {
	}
}
