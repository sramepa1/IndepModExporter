/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>JideCellEditorAdapter</code> is the default implementation for
 *  <code>JideCellEditorListener</code> so that you don't
 *  have to implement all the methods on the listener.
 */
public class JideCellEditorAdapter implements JideCellEditorListener {
 {

	public JideCellEditorAdapter() {
	}

	public boolean editingStarting(javax.swing.event.ChangeEvent e) {
	}

	public void editingStarted(javax.swing.event.ChangeEvent e) {
	}

	public boolean editingStopping(javax.swing.event.ChangeEvent e) {
	}

	public void editingStopped(javax.swing.event.ChangeEvent e) {
	}

	public void editingCanceled(javax.swing.event.ChangeEvent e) {
	}
}
