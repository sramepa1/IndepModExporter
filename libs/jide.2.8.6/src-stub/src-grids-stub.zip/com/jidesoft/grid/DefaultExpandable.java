/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A default implementation of <code>Expandable</code>.
 */
public class DefaultExpandable extends AbstractExpandable {

	/**
	 *  The children.
	 */
	protected java.util.List _children;

	public static final String PROPERTY_CHILDREN = "children";

	public DefaultExpandable() {
	}

	public DefaultExpandable(java.util.List children) {
	}

	public java.util.List getChildren() {
	}

	/**
	 *  Sets the children for this Expandable. Unless the Expandable is not added to a TreeTableModel yet, otherwise do
	 *  not use this method but use {@link #addChild(Object)} instead. Nor should you use getChildren().add(...) because
	 *  both setChildren and getChildren().add will not notify the TreeTableModel about the change.
	 * 
	 *  @param children the new children
	 */
	public void setChildren(java.util.List children) {
	}
}
