/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The listener that's notified when a table selection value changes.
 * 
 *  @see TableSelectionEvent
 */
public interface TableSelectionListener extends java.util.EventListener, java.io.Serializable {
 {

	/**
	 *  Called whenever the value of the selection changes.
	 * 
	 *  @param e the event that characterizes the change.
	 */
	public void valueChanged(TableSelectionEvent e);
}
