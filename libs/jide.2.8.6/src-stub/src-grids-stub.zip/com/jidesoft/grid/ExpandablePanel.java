/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The component has a "+/-" button which can be used in TreeTable or other tables.
 */
public class ExpandablePanel extends JCellRendererPane implements RendererWrapper {
 {

	public static final int TEXT_ICON_GAP = 4;

	public static final int LEFT_MARGIN = 16;

	public static boolean VERTICAL_CENTER_ALIGNMENT;

	protected Node _node;

	protected java.awt.Component _actualRenderer;

	protected javax.swing.JTable _table;

	protected javax.swing.Icon _expandedIcon;

	protected javax.swing.Icon _collapsedIcon;

	protected java.awt.Color _disabledForeground;

	protected java.awt.Color _disabledBackground;

	protected boolean _isSelected;

	protected boolean _hasFocus;

	/**
	 *  Creates an ExpandablePanel.
	 * 
	 *  @param table the table
	 *  @param expandedIcon the expanded icon
	 *  @param collapsedIcon the collapsed icon
	 *  @param disabledBackground the disabled background
	 *  @param disabledForeground the disabled foreground
	 */
	public ExpandablePanel(javax.swing.JTable table, javax.swing.Icon expandedIcon, javax.swing.Icon collapsedIcon, java.awt.Color disabledBackground, java.awt.Color disabledForeground) {
	}

	/**
	 *  Creates an ExpandablePanel.
	 * 
	 *  @param table the table
	 *  @param actualRenderer the renderer
	 *  @param expandedIcon the expanded icon
	 *  @param collapsedIcon the collapsed icon
	 *  @param disabledBackground the disabled background
	 *  @param disabledForeground the disabled foreground
	 */
	public ExpandablePanel(javax.swing.JTable table, java.awt.Component actualRenderer, javax.swing.Icon expandedIcon, javax.swing.Icon collapsedIcon, java.awt.Color disabledBackground, java.awt.Color disabledForeground) {
	}

	protected void initComponents() {
	}

	/**
	 *  Gets the actual renderer. ExpandablePanel can only paint the "+/-" button and let the actual renderer paint other
	 *  part.
	 * 
	 *  @return the actual renderer.
	 */
	public java.awt.Component getActualRenderer() {
	}

	/**
	 *  Sets the actual renderer. By default, ExpandablePanel will paint the +/- button as well as a text. However if you
	 *  call this method, ExpandablePanel will only paint the "+/-" button and let the actual renderer paint other part.
	 * 
	 *  @param actualRenderer the renderer
	 */
	public void setActualRenderer(java.awt.Component actualRenderer) {
	}

	/**
	 *  ExpandableCell is the data used by ExpandablePanel. ExpandableCell provides attributes such as expandable, level,
	 *  name etc which is useful when painting the expandable panel. In the case of PropertyTable component, Property
	 *  itself is an instance of ExpandableCell.
	 * 
	 *  @param node the node
	 */
	public void setNode(Node node) {
	}

	/**
	 *  Calls the UI delegate's paint method, if the UI delegate is non-<code>null</code>.  We pass the delegate a copy
	 *  of the <code>Graphics</code> object to protect the rest of the paint code from irrevocable changes (for example,
	 *  <code>Graphics.translate</code>).
	 *  <p/>
	 *  If you override this in a subclass you should not make permanent changes to the passed in <code>Graphics</code>.
	 *  For example, you should not alter the clip <code>Rectangle</code> or modify the transform. If you need to do
	 *  these operations you may find it easier to create a new <code>Graphics</code> from the passed in
	 *  <code>Graphics</code> and manipulate it. Further, if you do not invoker super's implementation you must honor the
	 *  opaque property, that is if this component is opaque, you must completely fill in the background in a non-opaque
	 *  color. If you do not honor the opaque property you will likely see visual artifacts.
	 * 
	 *  @param g the <code>Graphics</code> object to protect
	 *  @see #paint
	 *  @see javax.swing.plaf.ComponentUI
	 */
	@java.lang.Override
	public void paint(java.awt.Graphics g) {
	}

	/**
	 *  Paints the focus border.
	 * 
	 *  @param g the Graphics instance
	 */
	protected void paintFocus(java.awt.Graphics g) {
	}

	/**
	 *  Paints the background.
	 * 
	 *  @param g the Graphics instance
	 */
	protected void paintBackground(java.awt.Graphics g) {
	}

	protected void paintDecoration(java.awt.Graphics g) {
	}

	/**
	 *  Checks if the expandable panel is selected.
	 * 
	 *  @return true if it is selected.
	 */
	public boolean isSelected() {
	}

	/**
	 *  Sets the expandable panel selected/
	 * 
	 *  @param selected the flag
	 */
	public void setSelected(boolean selected) {
	}

	/**
	 *  Checks if expandable panel has focus.
	 * 
	 *  @return true if it has focus.
	 */
	public boolean isHasFocus() {
	}

	/**
	 *  Sets the expandable panel focus attribute.
	 * 
	 *  @param hasFocus the flag
	 */
	public void setHasFocus(boolean hasFocus) {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize() {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	public void setBackground(java.awt.Color c) {
	}

	@java.lang.Override
	public void setForeground(java.awt.Color c) {
	}

	@java.lang.Override
	public void setFont(java.awt.Font c) {
	}

	/**
	 *  Delegates getTooltipText to actual renderer.
	 * 
	 *  @param e the mouse event
	 *  @return the tooltip of actual renderer
	 */
	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent e) {
	}

	public boolean isExpandIconVisible(javax.swing.JTable table) {
	}
}
