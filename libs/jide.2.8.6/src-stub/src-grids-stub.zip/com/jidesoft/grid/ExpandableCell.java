/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to indicate anything that can be expanded and collapsed.
 */
public interface ExpandableCell extends Expandable, Cell {
 {
}
