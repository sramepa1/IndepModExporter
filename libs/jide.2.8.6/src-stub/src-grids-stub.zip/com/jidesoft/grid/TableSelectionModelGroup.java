/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is used to create a multiple-exclusion scope for a set of TableSelectionModel so that one
 *  TableSelectionModel can have selected index at a time.
 *  <p/>
 *  To use this class, you just need to add the TableSelectionModel of the non-contiguous JideTable to the group by
 *  calling {@link #add(TableSelectionModel)}. To remove from the group, call {@link #remove(TableSelectionModel)}.
 */
public class TableSelectionModelGroup implements java.io.Serializable {
 {

	protected java.util.List _models;

	protected TableSelectionListener _tableSelectionListener;

	/**
	 *  Creates a new <code>ButtonGroup</code>.
	 */
	public TableSelectionModelGroup() {
	}

	/**
	 *  Adds the TableSelectionModel to the group.
	 * 
	 *  @param model the TableSelectionModel to be added
	 */
	public void add(TableSelectionModel model) {
	}

	/**
	 *  Adds the TableSelectionModel to the group.
	 * 
	 *  @param index the position
	 *  @param model the TableSelectionModel to be added
	 */
	public void add(int index, TableSelectionModel model) {
	}

	/**
	 *  Removes the TableSelectionModel from the group.
	 * 
	 *  @param model the TableSelectionModel to be removed
	 */
	public void remove(TableSelectionModel model) {
	}

	/**
	 *  Returns all the TableSelectionModel that are participating in this group.
	 * 
	 *  @return an array of all TableSelectionModels
	 */
	public TableSelectionModel[] getTableModels() {
	}

	/**
	 *  Returns all the TableSelectionModel that are participating in this group.
	 * 
	 *  @return an <code>Enumeration</code> of the buttons in this group
	 */
	public java.util.Enumeration getElements() {
	}

	/**
	 *  Returns the number of TableSelectionModel in the group.
	 * 
	 *  @return the TableSelectionModel count
	 * 
	 *  @since 1.3
	 */
	public int getModelCount() {
	}
}
