/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AbstractTableFilter</code> is a special <code>Filter</code> for TableModel. It has row index and column index.
 *  When you implement {@link #isValueFiltered(Object)}, you can call {@link #getRowIndex()} and  {@link
 *  #getColumnIndex()} to find out which cell the value comes from. You should only use this filter with
 *  <code>FilterableTableModel</code> which will fill the row and column index..
 *  <p/>
 *  Please note, this class extends com.jidesoft.grid.AbstractFilter for backward compatible reason. It will change to
 *  extend com.jidesoft.filter.AbstractFilter after a few releases.
 */
public abstract class AbstractTableFilter extends AbstractFilter implements TableFilter {
 {

	protected AbstractTableFilter() {
	}

	protected AbstractTableFilter(String name) {
	}

	public int getColumnIndex() {
	}

	public void setColumnIndex(int columnIndex) {
	}

	public int getRowIndex() {
	}

	public void setRowIndex(int rowIndex) {
	}
}
