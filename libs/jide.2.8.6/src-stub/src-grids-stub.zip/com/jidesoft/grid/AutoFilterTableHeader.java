/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AutoFilterTableHeader</code> implements auto-filter feature. Each column header has a combobox-like control to
 *  allow user selecting certain values to be filtered from the list. The list contains the possible values for that
 *  column as well as other customized items. Each item represents a <code>Filter</code> class that will be added to
 *  <code>FilterableTableModel</code> when selected.
 *  <p/>
 *  <code>AutoFilterTableHeader</code> works with any <code>FilterableTableModel</code>. If the table passed to the
 *  constructor of AutoFilterTableHeader already defined a FilterableTableModel, it will use that FilterableTableModel.
 *  Otherwise, it will create a new FilterableTableModel, wrapping the current table's table model and reset the table's
 *  table model to the newly created FilterableTableModel.
 *  <p/>
 *  There are three kinds of Filters AutoFilterTableHeader will use. They are {@link
 *  com.jidesoft.grid.SingleValueFilter}, {@link com.jidesoft.grid.MultipleValuesFilter} and {@link
 *  com.jidesoft.grid.DynamicTableFilter}. When {@link #isAllowMultipleValues()} returns false and user selects a value
 *  from AutoFilterTableHeader's drop down value list, SingleValueFilter will be created and added to that column as the
 *  filter. DynamicTableFilter could also be used in this case when you call {@link
 *  com.jidesoft.grid.AutoFilterBox#addDynamicTableFilter(DynamicTableFilter)}. This method call will add new custom
 *  filter to the header which will appear as a new item under "All" item in the drop down value list. If {@link
 *  #isAllowMultipleValues()} returns true, MultipleValuesFilter will be the only filter that is used to allow multiple
 *  values as the filter values.
 *  <p/>
 *  <code>AutoFilterTableHeader</code> also detects filters added outside AutoFilterTableHeader. For example, if
 *  isAllowMultipleValues returns false, you can add a SingleValueFilter to the column, or if isAllowMultipleValues
 *  returns true, you can add a MultipleValuesFilter. After you did it, AutoFilterTableHeader will automatically update
 *  the display to show a filter name or filter name to indicate the column has a filter.
 */
public class AutoFilterTableHeader extends EditableTableHeader implements FilterableTableModelListener, java.beans.PropertyChangeListener {
 {

	protected IFilterableTableModel _filterableTableModel;

	protected boolean _autoFilterEnabled;

	/**
	 *  Creates <code>AutoFilterTableHeader</code>. By default, rollover is enabled.
	 * 
	 *  @param table the table to install this <code>AutoFilterTableHeader</code>. The table model of this table could be
	 *               <code>FilterableTableModel</code> or if it is a TableModelWrapper, it could have a nested
	 *               <code>FilterableTableModel</code>. In either case, we will use the <code>FilterableTableModel</code>
	 *               and add filters to it. If there is no <code>FilterableTableModel</code>, we will create one and wrap
	 *               it around the table model returned from <code>table.getModel()</code>. If so, after creating the
	 *               <code>AutoFilterTableHeader</code>, <code>table.getModel()</code> will return a
	 *               <code>FilterableTableModel</code>. <code>FilterableTableModel</code>'s <code>getActualModel()</code>
	 *               will be the old tableModel.
	 */
	public AutoFilterTableHeader(javax.swing.JTable table) {
	}

	/**
	 *  Overrides to create an <code>AutoFilterTableHeaderRenderer</code>. Below is the default code in case you need to
	 *  override it to you create your own renderer.
	 *  <code><pre>
	 *  if (isAutoFilterEnabled()) {
	 *      return new AutoFilterTableHeaderRenderer(){
	 *          protected void customizeAutoFilterBox(AutoFilterBox autoFilterBox) {
	 *              super.customizeAutoFilterBox(autoFilterBox);
	 *              AutoFilterTableHeader.this.customizeAutoFilterBox(autoFilterBox);
	 *              autoFilterBox.applyComponentOrientation(AutoFilterTableHeader.this.getComponentOrientation());
	 *          }
	 *      };
	 *  }
	 *  else {
	 *      return super.createDefaultRenderer();
	 *  }
	 *  </pre></code>
	 * 
	 *  @return an <code>AutoFilterTableHeaderRenderer</code>.
	 */
	@java.lang.Override
	protected javax.swing.table.TableCellRenderer createDefaultRenderer() {
	}

	/**
	 *  Overrides to create an <code>AutoFilterTableHeaderEditor</code>. Below is the default code in case you need to
	 *  override it to you create your own editor.
	 *  <code><pre>
	 *  if (isAutoFilterEnabled()) {
	 *     return new AutoFilterTableHeaderEditor() {
	 *         protected void customizeAutoFilterBox(AutoFilterBox autoFilterBox) {
	 *             autoFilterBox.applyComponentOrientation(AutoFilterTableHeader.this.getComponentOrientation());
	 *             super.customizeAutoFilterBox(autoFilterBox);
	 *             AutoFilterTableHeader.this.customizeAutoFilterBox(autoFilterBox);
	 *         }
	 *      };
	 *  }
	 *  else {
	 *      return null;
	 *  }
	 *  </pre></code>
	 * 
	 *  @return an <code>AutoFilterTableHeaderEditor</code>.
	 */
	@java.lang.Override
	protected javax.swing.table.TableCellEditor createDefaultEditor() {
	}

	/**
	 *  Customizes the <code>AutoFilterBox</code>.
	 * 
	 *  @param autoFilterBox the AutoFilterBox created by {@link AutoFilterTableHeaderRenderer} or {@link
	 *                       AutoFilterTableHeaderEditor}.
	 */
	protected void customizeAutoFilterBox(AutoFilterBox autoFilterBox) {
	}

	/**
	 *  Initializes the table.
	 * 
	 *  @param table the table which is passed in as parameter of the constructor {@link
	 *               #AutoFilterTableHeader(javax.swing.JTable)}.
	 */
	protected void initTable(javax.swing.JTable table) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  This method will be called when TableModel on JTable is changed.
	 * 
	 *  @param table the table
	 */
	protected void tableModelChanged(javax.swing.JTable table) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	public void filterableTableModelChanged(FilterableTableModelEvent event) {
	}

	/**
	 *  Creates the <code>FilterableTableModel</code> to be used by {@link AutoFilterTableHeader}. It returns null by
	 *  default. You can override it to create your own <code>FilterableTableModel</code>.
	 * 
	 *  @param model the table model.
	 *  @return the <code>FilterableTableModel</code>.
	 */
	protected IFilterableTableModel createFilterableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Creates the <code>FilterableTableModel</code>.
	 * 
	 *  @param model the table model.
	 *  @return the <code>FilterableTableModel</code>.
	 */
	protected IFilterableTableModel createDefaultFilterableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Gets the <code>FilterableTableModel</code> used by this <code>AutoFilterTableHeader</code>.
	 * 
	 *  @return the <code>FilterableTableModel</code>.
	 */
	public IFilterableTableModel getFilterableTableModel() {
	}

	/**
	 *  Clears all filters from the <code>AutoFilterTableHeader</code>. Please note, this method only clears all the
	 *  filters but doesn't refresh the data. You still need to call <code>AutoFilterTableHeader#getFilterableTableModel().refresh()</code>
	 *  after this call.
	 */
	public void clearFilters() {
	}

	public boolean isAutoFilterEnabled() {
	}

	public void setAutoFilterEnabled(boolean autoFilterEnabled) {
	}

	@java.lang.Override
	protected void paintSortArrows(java.awt.Graphics g) {
	}

	/**
	 *  Checks if the filter name is visible on the box as part of the title.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowFilterName() {
	}

	/**
	 *  Sets the flag if the filter name is shown on the title.
	 * 
	 *  @param showFilterName true to show the filter name. False to not show it.
	 */
	public void setShowFilterName(boolean showFilterName) {
	}

	/**
	 *  Checks if the filter name is displayed as tooltip on the table header.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowFilterNameAsToolTip() {
	}

	/**
	 *  Sets the flag if the filter name is displayed as tooltip on the table header.
	 * 
	 *  @param showFilterNameAsToolTip true to show the filter name as tooltip. False to not show it.
	 */
	public void setShowFilterNameAsToolTip(boolean showFilterNameAsToolTip) {
	}

	/**
	 *  Checks if the filter icon is visible on the box as part of the title.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowFilterIcon() {
	}

	/**
	 *  Sets the flag if the filter icon is shown on the title.
	 * 
	 *  @param showFilterIcon true to show the filter icon. False to not show it.
	 */
	public void setShowFilterIcon(boolean showFilterIcon) {
	}

	/**
	 *  Checks if the sort arrow is visible on the table header.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowSortArrow() {
	}

	/**
	 *  Sets the flag if the sort arrow is shown on the header.
	 * 
	 *  @param showSortArrow true to show the sort arrow. False to not show it.
	 */
	public void setShowSortArrow(boolean showSortArrow) {
	}

	/**
	 *  Checks if the <code>AutoFilterTableHeader</code> allows multiple values as the filter. The difference will be to
	 *  use a CheckBoxList or a regular JList as the popup panel when clicking on the filter button.
	 * 
	 *  @return true or false.
	 */
	public boolean isAllowMultipleValues() {
	}

	/**
	 *  Set the flag if the <code>AutoFilterTableHeader</code> allows multiple values as the filter. The difference will
	 *  be to use a CheckBoxList or a regular JList as the popup panel when clicking on the filter button.
	 *  <p/>
	 *  Please note, call this method will clear all filters that were added before.
	 * 
	 *  @param allowMultipleValues true to allow multiple value filters. False to disallow it. Default is false.
	 */
	public void setAllowMultipleValues(boolean allowMultipleValues) {
	}

	@java.lang.Override
	protected boolean isAutoRequestFocus() {
	}

	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Gets the FilterableTableModel used by the AutoFilterBox. By default, we will return {@link
	 *  #getFilterableTableModel()} which means all AutoFilterBoxes will use the same filter table model. If for whatever
	 *  reason you need to use different instances for different AutoFilterBox, you can create a new FilterableTableModel
	 *  and return.
	 * 
	 *  @param box the AutoFilterBox who will use the IFilterableTableModel returned from this method.
	 *  @return IFilterableTableModel.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected IFilterableTableModel getFilterableTableModel(AutoFilterBox box) {
	}
}
