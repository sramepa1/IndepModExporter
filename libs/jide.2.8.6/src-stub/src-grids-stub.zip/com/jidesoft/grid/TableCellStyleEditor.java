/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class TableCellStyleEditor extends javax.swing.JPanel {

	public TableCellStyleEditor(javax.swing.table.TableModel tableModel) {
	}

	public CellStyle[] getCellStyles() {
	}
}
