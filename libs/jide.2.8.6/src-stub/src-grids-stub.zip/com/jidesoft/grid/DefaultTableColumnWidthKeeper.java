/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>DefaultTableColumnWidthKeeper</code> provides a default implementation of {@link TableColumnWidthKeeper} to
 *  enable the application to keep the column width and column order even after the tableStructureChanged event is
 *  fired.
 */
public class DefaultTableColumnWidthKeeper implements TableColumnWidthKeeper {
 {

	public DefaultTableColumnWidthKeeper() {
	}

	public Object saveTableColumnWidth(javax.swing.JTable table) {
	}

	public void restoreTableColumnWidth(javax.swing.JTable table, Object savedWidth) {
	}
}
