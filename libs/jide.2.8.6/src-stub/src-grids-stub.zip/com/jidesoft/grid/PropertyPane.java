/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The PropertyPane is a wrapper around PropertyTable. It adds a toolbar and a description area so that make it more
 *  like a component.
 */
public class PropertyPane extends javax.swing.JPanel implements javax.swing.event.ListSelectionListener {
 {

	/**
	 *  Action name of action to switch to categorical view.
	 */
	public final String ACTION_CATEGORIED_VIEW = "CATEGORIED";

	/**
	 *  Action name of action to switch to alphabetic view.
	 */
	public final String ACTION_ALPHEBETIC_VIEW = "ALPHEBETIC";

	/**
	 *  Action name of action to toggle description.
	 */
	public final String ACTION_TOGGLE_DESCRIPTION = "DESCRIPTION";

	/**
	 *  Action name of action to expand all.
	 */
	public final String ACTION_EXPAND = "EXPAND";

	/**
	 *  Action name of action to collapse all.
	 */
	public final String ACTION_COLLAPSE = "COLLAPSE";

	/**
	 *  Display name of the beaninfo.
	 */
	protected javax.swing.JLabel _nameLabel;

	protected javax.swing.JComponent _descriptionPanel;

	public static final int BUTTONS_SORT = 1;

	public static final int BUTTONS_DESCRIPTION = 2;

	public static final int BUTTONS_EXPAND_COLLAPSE = 4;

	public static final int BUTTONS_ALL = -1;

	/**
	 *  Creates PropertyPane with an empty PropertyTable.
	 */
	public PropertyPane() {
	}

	/**
	 *  Creates a new <code>PropertyPane</code> using PropertyTable.
	 * 
	 *  @param table PropertyTable to be used in this PropertyPane
	 */
	public PropertyPane(PropertyTable table) {
	}

	/**
	 *  Creates a new <code>PropertyPane</code> using PropertyTable and specify which buttons are visible.
	 * 
	 *  @param table          PropertyTable to be used in this PropertyPane
	 *  @param visibleButtons visible buttons. The value is a bitwise OR of BUTTONS_SORT, BUTTONS_DESCRIPTION and
	 *                        BUTTONS_EXPAND_COLLAPSE.
	 */
	public PropertyPane(PropertyTable table, int visibleButtons) {
	}

	/**
	 *  Creates a panel that holds the property table. Default implementation adds the property table to a scroll pane
	 *  and return the scroll pane.
	 * 
	 *  @param table the property table.
	 *  @return the scroll pane which contains the property table.
	 */
	protected java.awt.Component createPropertyTablePanel(PropertyTable table) {
	}

	/**
	 *  Gets the scroll pane that contains the <code>PropertyTable</code>.
	 * 
	 *  @return the scroll pane that contains the <code>PropertyTable</code>.
	 */
	public javax.swing.JScrollPane getScrollPane() {
	}

	/**
	 *  Sets the bottom empty space of the PropertyPane background color. It's the same as JTable background by default.
	 * 
	 *  @param color the new viewport background color
	 */
	public void setViewportBackground(java.awt.Color color) {
	}

	/**
	 *  Creates the tool bar component on top of the <code>PropertyTable</code>.
	 * 
	 *  @return a JToolBar component.
	 */
	protected javax.swing.JComponent createToolBar() {
	}

	/**
	 *  Creates the toolbar component for the PropertyPane.
	 * 
	 *  @return a JToolBar. You can subclass it to create a CommandBar if you have JIDE Action Framework.
	 */
	protected javax.swing.JComponent createToolBarComponent() {
	}

	protected JideButton createButton(javax.swing.Action action) {
	}

	/**
	 *  Gets the built-in action.
	 * 
	 *  @param action the name of action
	 *  @return the action
	 */
	public javax.swing.Action getAction(String action) {
	}

	/**
	 *  Creates the description panel. If you override this method to create your own description panel, you also need to
	 *  override {@link #updateDescription(String,String)} to update the new value of name and description to the
	 *  components you created.
	 * 
	 *  @return the description panel.
	 */
	protected javax.swing.JComponent createDescriptionPanel() {
	}

	/**
	 *  Creates the description area. It is a MultilineLabel by default.
	 * 
	 *  @return the description area.
	 */
	protected javax.swing.JComponent createDescriptionArea() {
	}

	/**
	 *  Updates the name and description to description panel. If you override {@link #createDescriptionPanel()} to
	 *  create your own name and description, you will have to override this method to set the new name and description
	 *  to your components.
	 * 
	 *  @param name        the name of the description panel
	 *  @param description the description of the description panel
	 */
	protected void updateDescription(String name, String description) {
	}

	/**
	 *  Resets the description to default name and description. It usually happens when there is no property is
	 *  selected.
	 */
	protected void resetDescription() {
	}

	/**
	 *  Creates the description panel. Subclass can overwrite this to provide your own description panel. Below is the
	 *  default implementation.
	 *  <pre><code>
	 *  JPanel panel = new JPanel(new BorderLayout(0, 0));
	 *  panel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(getBorderColor()),
	 *  BorderFactory.createEmptyBorder(1, 1, 1, 1)));
	 *  panel.add(nameLabel, BorderLayout.BEFORE_FIRST_LINE);
	 *  panel.add(descriptionArea, BorderLayout.CENTER);
	 *  return panel;
	 *  </code></pre>
	 * 
	 *  @param nameLabel       the name component
	 *  @param descriptionArea the description area component
	 *  @return the description panel.
	 */
	protected javax.swing.JPanel createDescriptionPanel(javax.swing.JComponent nameLabel, javax.swing.JComponent descriptionArea) {
	}

	/**
	 *  Called whenever the value of the selection changes.
	 * 
	 *  @param e the event that characterizes the change.
	 */
	public void valueChanged(javax.swing.event.ListSelectionEvent e) {
	}

	/**
	 *  Gets the border color.
	 * 
	 *  @return the border color
	 */
	public java.awt.Color getBorderColor() {
	}

	/**
	 *  Sets the border color.
	 * 
	 *  @param borderColor the color of the border
	 */
	public void setBorderColor(java.awt.Color borderColor) {
	}

	/**
	 *  Gets the toolbar which has the categorized and sorted buttons. You can add your own buttons or whatever component
	 *  to it.
	 * 
	 *  @return toolbar
	 */
	public javax.swing.JComponent getToolBar() {
	}

	/**
	 *  Is the toolbar visible.
	 * 
	 *  @return the visibility of toolbar
	 */
	public boolean isShowToolBar() {
	}

	/**
	 *  Sets the visibility of toolbar.
	 * 
	 *  @param showToolBar true to show toolbar and false to hide toolbar.
	 */
	public void setShowToolBar(boolean showToolBar) {
	}

	/**
	 *  Is the description area visible.
	 * 
	 *  @return true if the description is visible and false if not.
	 */
	public boolean isShowDescription() {
	}

	/**
	 *  Sets the visibility of description area.
	 * 
	 *  @param showDescription true to show description area and false to hide description area.
	 */
	public void setShowDescription(boolean showDescription) {
	}

	/**
	 *  Override to set the font of description area along with the pane itself.
	 * 
	 *  @param font new font to be used by this pane
	 */
	@java.lang.Override
	public void setFont(java.awt.Font font) {
	}

	/**
	 *  Gets the property table.
	 * 
	 *  @return property table
	 */
	public PropertyTable getPropertyTable() {
	}

	/**
	 *  Gets the order PropertyPane. Please note, PropertyPane doesn't listen to the order of underlying
	 *  PropertyTableModel. If you ever called setOrder on PropertyTableModel directly, the value returned here might be
	 *  the same as the order in PropertyTableModel. To avoid this, always use {@link #setOrder(int)} on PropertyPane to
	 *  change the order of underlying PropertyTableModel.
	 * 
	 *  @return the order of PropertyPane.
	 */
	public int getOrder() {
	}

	/**
	 *  Sets the order of property pane. This method will set the order of property table model. And it will set the
	 *  buttons (sorted button and categorized button) to the correct selection state.
	 * 
	 *  @param order the order
	 */
	public void setOrder(int order) {
	}

	/**
	 *  Gets the image icons that is used in PropertyPane. By default it will use {@link GridIconsFactory} to get the
	 *  image icons.
	 *  <p/>
	 *  Subclass can override this method to provide their own icon. The the value of the name parameter will be
	 *  constants defined in {@link GridIconsFactory.PropertyPane}. For example, GridIconsFactory.PropertyPane.SORT is
	 *  for the sort icon.
	 * 
	 *  @param name the name
	 *  @return the image icon of a name.
	 */
	protected javax.swing.ImageIcon getImageIcon(String name) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grids.properties that begin with "Pane.".
	 * 
	 *  @param key the key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}
}
