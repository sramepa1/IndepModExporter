/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A special table header for SortableTable which draws arrows and index to indicate the sorting order.
 */
public class SortableTableHeader extends DraggingTableHeader {

	/**
	 *  The distant from top edge of the table header to the top edge of the sort arrow.
	 */
	public static int V_GAP;

	/**
	 *  The distant from the right edge of the table header to left edge of sort arrow.
	 */
	public static int H_GAP;

	/**
	 *  The gap between the sort arrow and index text.
	 */
	public static int ARROW_TEXT_GAP;

	public SortableTableHeader(javax.swing.table.TableColumnModel cm) {
	}

	/**
	 *  Overrides to paint the sort arrows on table header.
	 * 
	 *  @param g the Graphics object
	 */
	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Paints the sort arrows.
	 * 
	 *  @param g the Graphics object
	 */
	protected void paintSortArrows(java.awt.Graphics g) {
	}

	/**
	 *  Paints the sort arrow.
	 * 
	 *  @param c         table header
	 *  @param table     the sortable table.
	 *  @param g         Graphics
	 *  @param rect      the bounds of the table column header
	 *  @param index     the sorting index
	 *  @param ascending the sorting direction.
	 */
	protected void paintSortArrow(javax.swing.JComponent c, SortableTable table, java.awt.Graphics g, java.awt.Rectangle rect, int index, boolean ascending) {
	}

	/**
	 *  Should the arrow be displayed on the top of the header.
	 * 
	 *  @return true to display the sort arrow on top. Otherwise false.
	 */
	protected boolean shouldDisplayOnTop() {
	}

	/**
	 *  Create the sort arrow icon. Subclass can override it to create your own sort arrow. Although the name is
	 *  createSortIcon, you could cache the icon internally and don't create it every time when this method is called.
	 * 
	 *  @param table     the sortable table.
	 *  @param ascending true or false. True is ascending.
	 *  @return the sort arrow icon.
	 */
	protected javax.swing.Icon createSortIcon(SortableTable table, boolean ascending) {
	}
}
