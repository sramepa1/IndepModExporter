/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>RowHeights</code> is wrapper around a <code>SizeSequence</code> object. It can fire {@link
 *  RowHeightChangeEvent} when row height changes.
 *  <p/>
 *  RowHeights is nothing but a data structure to hold row heights information. The row used in this class is the row
 *  that appears on the table which has nothing to do with underlying row index such as the actualRow in the case of
 *  TableModelWrapper.
 */
public class RowHeights {

	protected javax.swing.event.EventListenerList listenerList;

	protected javax.swing.SizeSequence _sizeSequence;

	protected int _rowCount;

	/**
	 *  Creates a new <code>RowHeights</code> object that contains no rows .  To add rows, you can use
	 *  <code>insertRows</code> or <code>setHeights</code>.
	 * 
	 *  @see #insertRows
	 *  @see #setRowHeights
	 */
	public RowHeights() {
	}

	/**
	 *  Creates a new <code>RowHeights</code> object that contains the specified number of rows, all initialized to have
	 *  size 0.
	 * 
	 *  @param numRows the number of row heights to track
	 *  @throws NegativeArraySizeException if <code>numRows < 0</code>
	 */
	public RowHeights(int numRows) {
	}

	/**
	 *  Creates a new <code>RowHeights</code> object that contains the specified number of rows, all initialized to have
	 *  size <code>value</code>.
	 * 
	 *  @param numRows the number of rows to track
	 *  @param value   the initial value of each size
	 */
	public RowHeights(int numRows, int value) {
	}

	/**
	 *  Creates a new <code>RowHeights</code> object that contains the specified heights.
	 * 
	 *  @param heights the array of heights to be contained in the <code>SizeSequence</code>
	 */
	public RowHeights(int[] heights) {
	}

	/**
	 *  Resets this <code>RowHeights</code> object, using the data in the <code>rowHeights</code> argument. This method
	 *  re-initializes this object so that it contains as many rows as the <code>rowHeights</code> array. Each row height
	 *  is initialized to the value of the corresponding item in <code>rowHeights</code>.
	 * 
	 *  @param rowHeights the array of rowHeights to be contained in this <code>RowHeights</code>
	 */
	public void setRowHeights(int[] rowHeights) {
	}

	/**
	 *  Returns the row height of all rows.
	 * 
	 *  @return a new array containing the row heights in this object
	 */
	public int[] getRowHeights() {
	}

	/**
	 *  Returns the start y position for the specified row. <p>Note that if <code>index</code> is greater than
	 *  <code>length</code> the value returned may be meaningless.
	 * 
	 *  @param index the index of the row whose y position is desired
	 *  @return the starting y position of the specified entry
	 */
	public int getRowPosition(int index) {
	}

	/**
	 *  Returns the index of the row that corresponds to the specified position. For example, <code>getRowIndex(0)</code>
	 *  is 0, since the first row always starts at position 0.
	 * 
	 *  @param position the position of the row
	 *  @return the index of the row that occupies the specified position
	 */
	public int getRowIndex(int position) {
	}

	/**
	 *  Returns the row height of the specified row. If <code>index</code> is out of the range <code>(0 <= index <
	 *  getRowHeights().length)</code> the behavior is unspecified.
	 * 
	 *  @param index the index corresponding to the row
	 *  @return the height of the row
	 */
	public int getRowHeight(int index) {
	}

	/**
	 *  Sets the height of the specified row. Note that if the value of <code>index</code> does not fall in the range:
	 *  <code>(0 <= index < getRowHeights().length)</code> the behavior is unspecified.
	 * 
	 *  @param index  the index corresponding to the row
	 *  @param height the height of the row
	 */
	public void setRowHeight(int index, int height) {
	}

	/**
	 *  Adds a contiguous group of row heights to this <code>RowHeights</code>. Note that the values of
	 *  <code>start</code> and <code>length</code> must satisfy the following conditions:  <code>(0 <= start <
	 *  getRowHeights().length) AND (length >= 0)</code>.  If these conditions are not met, the behavior is unspecified
	 *  and an exception may be thrown.
	 * 
	 *  @param start  the index to be assigned to the first row in the group
	 *  @param length the number of rows in the group
	 *  @param value  the size to be assigned to each new row
	 *  @throws ArrayIndexOutOfBoundsException if the parameters are outside of the range: (<code>0 <= start <
	 *                                         (getRowHeights().length)) AND (length >= 0)</code>
	 */
	public void insertRows(int start, int length, int value) {
	}

	/**
	 *  Removes a contiguous group of entries from this <code>RowHeights</code>. Note that the values of
	 *  <code>start</code> and <code>length</code> must satisfy the following conditions:  <code>(0 <= start <
	 *  getRowHeights().length) AND (length >= 0)</code>.  If these conditions are not met, the behavior is unspecified
	 *  and an exception may be thrown.
	 * 
	 *  @param start  the index of the first row to be removed
	 *  @param length the number of rows to be removed
	 */
	public void removeRows(int start, int length) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the row model occurs.
	 * 
	 *  @param l the RowHeightChangeListener
	 */
	public void addRowHeightChangeListener(RowHeightChangeListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the row model occurs.
	 * 
	 *  @param l the RowHeightChangeListener
	 */
	public void removeRowHeightChangeListener(RowHeightChangeListener l) {
	}

	/**
	 *  Returns an array of all the row model listeners registered on this model.
	 * 
	 *  @return all of this model's <code>RowHeightChangeListener</code>s or an empty array if no row model listeners are
	 *          currently registered
	 * 
	 *  @see #addRowHeightChangeListener
	 *  @see #removeRowHeightChangeListener
	 */
	public RowHeightChangeListener[] getRowHeightChangeListeners() {
	}

	/**
	 *  Forwards the given notification event to all <code>RowModelListeners</code> that registered themselves as
	 *  listeners for this row model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addRowHeightChangeListener
	 *  @see RowHeightChangeEvent
	 *  @see EventListenerList
	 */
	public void fireRowHeightChanged(RowHeightChangeEvent e) {
	}
}
