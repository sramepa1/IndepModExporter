/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The default implementation of ColumnTableModelWrapper.
 */
public class DefaultColumnTableModelWrapper extends javax.swing.table.AbstractTableModel implements ColumnTableModelWrapper, ContextSensitiveTableModel, StyleModel, SpanModel, MultiTableModel, javax.swing.event.TableModelListener, ColumnIdentifierTableModel {
 {

	protected javax.swing.table.TableModel _model;

	protected int[] _indexes;

	/**
	 *  Creates a DefaultColumnTableModelWrapper from any table model.
	 * 
	 *  @param model the table model
	 */
	public DefaultColumnTableModelWrapper(javax.swing.table.TableModel model) {
	}

	/**
	 *  Gets the actual table model. Since ColumnTableModelWrapper is just a wrapper around another table model, this
	 *  method will return you the actual table model.
	 * 
	 *  @return the actual table model.
	 */
	public javax.swing.table.TableModel getActualModel() {
	}

	/**
	 *  Gets the actual column.
	 * 
	 *  @param column the column on the UI.
	 *  @return the actual column in the actual model. It will throw IllegalArgumentException if the column is out of
	 *          range.
	 */
	public int getActualColumnAt(int column) {
	}

	/**
	 *  Gets the visual column.
	 * 
	 *  @param actualColumn the actual column in actual model.
	 *  @return the column on UI. -1 if cannot find the column.
	 */
	public int getVisualColumnAt(int actualColumn) {
	}

	public Object getValueAt(int row, int column) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int row, int column) {
	}

	public int getRowCount() {
	}

	public int getColumnCount() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	@java.lang.Override
	public Class getColumnClass(int column) {
	}

	@java.lang.Override
	public boolean isCellEditable(int row, int column) {
	}

	/**
	 *  Gets the converter context of the underlying table model. This will return a valid value only if underlying table
	 *  model is instance of <code>ContextSensitiveTableModel</code>. If not, it will return null.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return converter context of the underlying table model.
	 */
	public ConverterContext getConverterContextAt(int row, int column) {
	}

	/**
	 *  Gets the editor context of the underlying table model. This will return a valid value only if underlying table
	 *  model is instance of <code>ContextSensitiveTableModel</code>. If not, it will return null.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return editor context of the underlying table model.
	 */
	public EditorContext getEditorContextAt(int row, int column) {
	}

	/**
	 *  Gets the cell class of the underlying table model. This will return a valid value only if underlying table model
	 *  is instance of <code>ContextSensitiveTableModel</code>. If not, it will return null.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return cell class of the underlying table model.
	 */
	public Class getCellClassAt(int row, int column) {
	}

	public Object getColumnIdentifier(int column) {
	}

	/**
	 *  Resets the index mapping.
	 */
	protected void reallocateIndexes() {
	}

	/**
	 *  Gets the indexes that maps from the visual column index to the actual column index.
	 * 
	 *  @return the indexes.
	 */
	public int[] getIndexes() {
	}

	/**
	 *  Sets the indexes of the column mapping. We exposed this method to allow quick access to the underlying indexes.
	 *  The method won't fire any table events. So once you change the indexes, you need to fire corresponding table
	 *  event so that table can update itself.
	 * 
	 *  @param indexes the new index array.
	 */
	public void setIndexes(int[] indexes) {
	}

	public CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	public boolean isCellStyleOn() {
	}

	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	public boolean isCellSpanOn() {
	}

	public int getColumnType(int columnIndex) {
	}

	public int getTableIndex(int columnIndex) {
	}

	/**
	 *  Implementation of the <code>TableChangeListener</code> interface. Depending on the type of the
	 *  <code>TableModelEvent</code>, this method delegates to one of the following methods based on the contract of the
	 *  <code>TableModelEvent</code> object: <ul> <li>{@link #tableRowsInserted(int,int)} <li>{@link
	 *  #tableRowsDeleted(int,int)} <li>{@link #tableStructureChanged()} <li>{@link #tableDataChanged()} <li>{@link
	 *  #tableRowsUpdated(int,int)} <li>{@link #tableCellsUpdated(int,int,int)} <ul> The default implementations of the
	 *  above methods simply rebroadcast a <code>TableModelEvent</code> to the listeners on this model. Most Subclasses
	 *  will override one or more of the above protected methods to provide custom behavior for particular events.
	 *  However, some implementations may wish to override this method instead. Obviously, if this method is overridden,
	 *  the above protected methods will not be called unless the overridden implementation does so explicitly.
	 * 
	 *  @param e the <code>TableModelEvent</code> representing the change
	 */
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Called each time one or more contiguous rows are inserted into the underlying <code>TableModel</code>. This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was inserted
	 *  @param lastRow  the index of the last row that was inserted
	 */
	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time one or more contiguous rows are deleted from the underlying <code>TableModel</code>. This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was deleted
	 *  @param lastRow  the index of the last row that was deleted
	 */
	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time one or more contiguous rows are updated in the underlying <code>TableModel</code>. simply fires
	 *  a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was updated
	 *  @param lastRow  the index of the last row that was updated
	 */
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time the cells in <code>column</code> in the range [<code>firstRow</code>, <code>lastRow</code>] are
	 *  updated. This default implementation simply fires a corresponding <code> TableModelEvent</code> to the listeners
	 *  on this model.
	 * 
	 *  @param firstRow the index of the first row in the above <code> column</code> that was updated
	 *  @param lastRow  the index of the last row in the above <code> column</code> that was updated
	 *  @param column   the index of the column that was updated
	 */
	public void fireTableCellsUpdated(int firstRow, int lastRow, int column) {
	}

	/**
	 *  Called each time the cells in <code>column</code> in the range [<code>firstRow</code>, <code>lastRow</code>] are
	 *  updated. This default implementation simply fires a corresponding <code> TableModelEvent</code> to the listeners
	 *  on this model.
	 * 
	 *  @param column   the index of the column that was updated
	 *  @param firstRow the index of the first row in the above <code> column</code> that was updated
	 *  @param lastRow  the index of the last row in the above <code> column</code> that was updated
	 */
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	/**
	 *  Called each time all of the data (i.e. all rows) is changed in the underlying<code>TableModel</code>.  This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 */
	protected void tableDataChanged() {
	}

	/**
	 *  Called each time the structure (<code>TableColumn</code>s, etc) of the underlying <code>TableModel</code>
	 *  changes. This default implementation simply fires a corresponding <code>TableModelEvent </code> to the listeners
	 *  on this model.
	 */
	protected void tableStructureChanged() {
	}
}
