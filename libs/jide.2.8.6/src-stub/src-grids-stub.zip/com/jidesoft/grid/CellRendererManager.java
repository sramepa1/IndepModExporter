/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A global object that can register cell renderer with a type and a EditorContext.
 */
public class CellRendererManager {

	public CellRendererManager() {
	}

	/**
	 *  Registers a renderer with a class and default context. If no context is specified, this renderer will be used as
	 *  default renderer for that type.
	 * 
	 *  @param clazz    the type
	 *  @param renderer the renderer
	 */
	public static void registerRenderer(Class clazz, javax.swing.table.TableCellRenderer renderer) {
	}

	/**
	 *  Registers a renderer with a class and a context.
	 * 
	 *  @param clazz    the type
	 *  @param renderer the renderer
	 *  @param context  the editor context
	 */
	public static void registerRenderer(Class clazz, javax.swing.table.TableCellRenderer renderer, EditorContext context) {
	}

	/**
	 *  Unregisters the renderer which registers with the class and the context.
	 * 
	 *  @param clazz   the type of which the cell renderer will be registered.
	 *  @param context the editor context.
	 */
	public static void unregisterRenderer(Class clazz, EditorContext context) {
	}

	/**
	 *  Unregisters the renderer which registers with the class and the default context.
	 * 
	 *  @param clazz the type of which the cell renderer will be unregistered.
	 */
	public static void unregisterRenderer(Class clazz) {
	}

	/**
	 *  Unregisters all the renderers which registered before.
	 */
	public static void unregisterAllRenderers() {
	}

	/**
	 *  Gets the registered renderer.
	 * 
	 *  @param clazz   the type
	 *  @param context the editor context.
	 *  @return the registered renderer
	 */
	public static javax.swing.table.TableCellRenderer getRenderer(Class clazz, EditorContext context) {
	}

	/**
	 *  Gets the registered renderer using default context.
	 * 
	 *  @param clazz the type
	 *  @return the registered renderer
	 */
	public static javax.swing.table.TableCellRenderer getRenderer(Class clazz) {
	}

	/**
	 *  Updates the UI of the registered cell editors when LookAndFeel changed. This method will be called automatically
	 *  since CellEditorManager listens to the UIManager's LookAndFeel change.
	 */
	public static void updateUI() {
	}

	/**
	 *  Checks the value of autoInit.
	 * 
	 *  @return true or false.
	 * 
	 *  @see #setAutoInit(boolean)
	 */
	public static boolean isAutoInit() {
	}

	/**
	 *  Sets autoInit to true or false. If autoInit is true, whenever someone tries to call methods like as toString or
	 *  fromString, {@link #initDefaultRenderer()} will be called if it has never be called. By default, autoInit is
	 *  true.
	 *  <p/>
	 *  This might affect the behavior if users provide their own renderers and want to overwrite default renderers. In
	 *  this case, instead of depending on autoInit to initialize default renderers, you should call {@link
	 *  #initDefaultRenderer()} first, then call registerRenderer to add your own renderers.
	 * 
	 *  @param autoInit true or false.
	 */
	public static void setAutoInit(boolean autoInit) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the manager occurs.
	 * 
	 *  @param l the RegistrationListener
	 */
	public static void addRegistrationListener(RegistrationListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the manager occurs.
	 * 
	 *  @param l the RegistrationListener
	 */
	public static void removeRegistrationListener(RegistrationListener l) {
	}

	/**
	 *  Returns an array of all the registration listeners registered on this manager.
	 * 
	 *  @return all of this registration's <code>RegistrationListener</code>s or an empty array if no registration
	 *          listeners are currently registered
	 * 
	 *  @see #addRegistrationListener
	 *  @see #removeRegistrationListener
	 */
	public static RegistrationListener[] getRegistrationListeners() {
	}

	/**
	 *  Gets all the cell editor customizers in an array.
	 * 
	 *  @return all the cell editor customizers in an array.
	 */
	public static CellRendererManager.CellRendererCustomizer[] getCellRendererCustomizers() {
	}

	/**
	 *  Adds a cell editor customizer. It will be called when a cell editor is created in CellRendererFactory before it
	 *  is returned from getEditor method.
	 *  <p/>
	 *  Here is a typical use case to make all cell editors to be clicked twice before it starts editing.
	 *  <p/>
	 *  <pre><code>
	 *  CellRendererManager.addCellRendererCustomizer(new CellRendererManager.CellRendererCustomizer(){
	 *      public void customize(TableCellRenderer cellRenderer) {
	 *          if(cellRenderer instanceof AbstractComboBox) {
	 *              ((AbstractComboBox) cellRenderer).setButtonVisible(true);
	 *          }
	 *      }
	 *  });
	 *  </code></pre>
	 * 
	 *  @param CellRendererCustomizer the cell editor customer to be added.
	 */
	public static void addCellRendererCustomizer(CellRendererManager.CellRendererCustomizer CellRendererCustomizer) {
	}

	/**
	 *  Removes a cell editor Customizer that was added before.
	 * 
	 *  @param CellRendererCustomizer the cell editor customer to be removed.
	 */
	public static void removeCellRendererCustomizer(CellRendererManager.CellRendererCustomizer CellRendererCustomizer) {
	}

	/**
	 *  Gets the available EditorContexts registered with the class.
	 * 
	 *  @param clazz the class.
	 *  @return the available EditorContexts.
	 */
	public static EditorContext[] getEditorContexts(Class clazz) {
	}

	/**
	 *  Initials the default renderers.
	 */
	public static void initDefaultRenderer() {
	}

	/**
	 *  If {@link #initDefaultRenderer()} is called once, calling it again will have no effect because an internal flag
	 *  is set. This method will reset the internal flag so that you can call  {@link #initDefaultRenderer()} in case you
	 *  unregister all renderers using {@link #unregisterAllRenderers()}.
	 */
	public static void resetInit() {
	}

	public static void clear() {
	}

	/**
	 *  A cell editor customizer interface. You can use {@link CellRendererManager#addCellRendererCustomizer(com.jidesoft.grid.CellRendererManager.CellRendererCustomizer)}
	 *  method to set a cell editor customizer.
	 */
	public static interface class CellRendererCustomizer {


		public void customize(javax.swing.table.TableCellRenderer cellRenderer) {
		}
	}
}
