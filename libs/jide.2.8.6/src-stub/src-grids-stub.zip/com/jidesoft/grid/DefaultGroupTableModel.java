/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class DefaultGroupTableModel extends AbstractGroupTableModel implements ColumnIdentifierTableModel, SpanModel, RowTableModelWrapper, ColumnTableModelWrapper {
 {

	public DefaultGroupTableModel(javax.swing.table.TableModel tableModel) {
	}

	public void groupAndRefresh() {
	}

	protected DefaultGroupRow createGroupRow() {
	}

	protected ReferenceRow createReferenceRow(javax.swing.table.TableModel tableModel, int row) {
	}

	public boolean isKeepColumnOrder() {
	}

	public void setKeepColumnOrder(boolean keepColumnOrder) {
	}

	public DefaultGroupRow addGroupRow(Expandable parentRow, DefaultGroupRow groupRow) {
	}

	public DefaultGroupRow findParentGroupRow(Expandable parent, GroupCondition condition) {
	}

	protected void ensureGroupColumnsCreated() {
	}

	@java.lang.Override
	public boolean isGroupEnabled() {
	}

	/**
	 *  Is the column grouped.
	 * 
	 *  @param columnIndex the column index. It is the column index as in the model.l
	 *  @return true if the column is grouped. Otherwise false.
	 */
	public boolean isColumnGrouped(int columnIndex) {
	}

	/**
	 *  Checks if it has grouped columns.
	 * 
	 *  @return true if it has grouped columns. Otherwise false.
	 */
	public boolean hasGroupColumns() {
	}

	/**
	 *  Gets the total count of group columns. You can use this method to get the count then use {@link
	 *  #getGroupColumnAt(int)} method to find out each group column index.
	 * 
	 *  @return the total count of group columns.
	 */
	public int getGroupColumnCount() {
	}

	/**
	 *  Gets the group column index.
	 * 
	 *  @param index the column index.
	 *  @return the group column index.
	 */
	public int getGroupColumnAt(int index) {
	}

	public void addGroupColumn(int columnIndex) {
	}

	public void removeGroupColumn(int columnIndex) {
	}

	public void setGroupColumns(int[] columnIndices) {
	}

	public void clearGroupColumns() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	public Object getColumnIdentifier(int column) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Class getColumnClass(int column) {
	}

	@java.lang.Override
	public int getRowCount() {
	}

	public int getColumnCount() {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	public boolean isSingleLevelGrouping() {
	}

	public void setSingleLevelGrouping(boolean singleLevelGrouping) {
	}

	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	public DefaultGroupRow findGroupRow(Expandable parent, javax.swing.table.TableModel tableModel, int rowIndex) {
	}

	public DefaultGroupRow findGroupRow(Row row, int columnIndex) {
	}

	@java.lang.Override
	public Row getRowAt(int rowIndex) {
	}

	@java.lang.Override
	public int getRowIndex(Row row) {
	}

	public ReferenceRow getReferenceRow(int rowIndex) {
	}

	public boolean isCellSpanOn() {
	}

	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	protected void updateReference(int index, int inc) {
	}

	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	protected void tableStructureChanged() {
	}

	protected void tableDataChanged() {
	}

	public int[] getColumnMapping() {
	}

	public javax.swing.table.TableModel getActualModel() {
	}

	public int getActualRowAt(int visualRow) {
	}

	public int getVisualRowAt(int actualRow) {
	}

	public int getActualColumnAt(int column) {
	}

	public int getVisualColumnAt(int actualColumn) {
	}

	public boolean isDisplayGroupColumns() {
	}

	public void setDisplayGroupColumns(boolean displayGroupColumns) {
	}

	public boolean isDisplayCountColumn() {
	}

	public void setDisplayCountColumn(boolean displayCountColumn) {
	}

	@java.lang.Override
	public void expandRow(ExpandableRow row, boolean expanded) {
	}

	@java.lang.Override
	public void expandAll() {
	}

	@java.lang.Override
	public void expandFirstLevel() {
	}

	@java.lang.Override
	public void collapseAll() {
	}

	@java.lang.Override
	public void collapseFirstLevel() {
	}

	/**
	 *  Sorts the rows.
	 *  <p/>
	 *  Subclass can override this method to implement their own algorithm to sort. When doing comparison in the
	 *  algorithm, use the compare(int, int) method defined in this class.
	 * 
	 *  @param from an int array of row indices to be sorted
	 *  @param to   an int array of row indices to store the result after sorting
	 *  @param low  the start index of the row in the array to be sorted
	 *  @param high the end index of the row in the array to be sorted
	 */
	protected void sort(int[] from, int[] to, int low, int high) {
	}

	/**
	 *  While grouping, the rows are sorted first according the grouping columns. You could use this method to get
	 *  current sorting direction.
	 * 
	 *  @return true if the sorting is ascending, false if the sorting is descending.
	 */
	public boolean isAscendingGroupOrder() {
	}

	/**
	 *  While grouping, the rows are sorted first according the grouping columns. You could use this method to set
	 *  current sorting direction.
	 * 
	 *  @param order true to make later sorting ascending, false to make later sorting descending.
	 */
	public void setAscendingGroupOrder(boolean order) {
	}
}
