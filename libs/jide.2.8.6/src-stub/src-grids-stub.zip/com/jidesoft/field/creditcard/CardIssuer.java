package com.jidesoft.field.creditcard;


/**
 *  Interface of credit card Issuer. Implemented class should include card name and check method.
 */
public interface CardIssuer {

	/**
	 *  Code to be returned when card number is valid
	 */
	public static final int VAILDATE_SUCCESS = 0;

	/**
	 *  Code to be returned when card number length is invalid
	 */
	public static final int VAILDATE_ERROR_WRONG_LENGTH = 1;

	/**
	 *  Check if specified card number length and identifier is valid for the issuer.
	 * 
	 *  @param cardNumber number to be checked
	 *  @return 0-the number is valid, other-invalid
	 */
	public int isCardNumberValid(String cardNumber);

	/**
	 *  Get the card issuer's name
	 * 
	 *  @return the card issuer's name
	 */
	public String getName();

	/**
	 *  Get the card issuer's icon
	 * 
	 *  @return card issuer's icon
	 */
	public javax.swing.Icon getIcon();
}
