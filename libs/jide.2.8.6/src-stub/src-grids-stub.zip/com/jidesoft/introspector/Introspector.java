/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


public interface Introspector {

	/**
	 *  Gets the property count.
	 * 
	 *  @return the property count.
	 */
	public int getPropertyCount();

	/**
	 *  Gets the property with the specified name.
	 * 
	 *  @param name the property name.
	 *  @return the property with the specified name.
	 */
	public com.jidesoft.grid.Property getProperty(String name);

	/**
	 *  Removes the property with the specified name.
	 * 
	 *  @param name the property name.
	 */
	public void removeProperty(String name);

	/**
	 *  Adds a new property.
	 * 
	 *  @param property a new property
	 */
	public void addProperty(com.jidesoft.grid.Property property);

	/**
	 *  Gets the properties names in an array.
	 * 
	 *  @return the property names.
	 */
	public String[] getPropertyNames();
}
