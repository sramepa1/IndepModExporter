/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  The introspector context is used by BeanIntrospectorManager so that for the same type, different bean introspector
 *  can be registered since the BeanIntrospectorContext is different.
 * 
 *  @deprecated Please use {@link IntrospectorContext} instead.
 */
@java.lang.Deprecated
public class BeanIntrospectorContext extends IntrospectorContext {

	public BeanIntrospectorContext(String name) {
	}

	public BeanIntrospectorContext(String name, Object object) {
	}
}
