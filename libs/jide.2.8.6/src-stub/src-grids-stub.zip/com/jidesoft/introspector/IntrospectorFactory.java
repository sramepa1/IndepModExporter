/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  Interfaces used by {@link IntrospectorManager} to create an Introspector using the factory pattern. The purpose of
 *  this factory is to make sure a new instance of Introspector is created every time when asking IntrospectorManager for
 *  one.
 */
public interface IntrospectorFactory {

	public Introspector create();
}
