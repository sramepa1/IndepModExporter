/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  A global object that can register BeanIntrospector with a type and a IntrospectorContext.
 */
public class IntrospectorManager {

	public IntrospectorManager() {
	}

	/**
	 *  Registers a BeanIntrospector with a class and a context.
	 * 
	 *  @param clazz        the type
	 *  @param introspector the BeanIntrospector
	 *  @param context      the BeanIntrospector context
	 * 
	 *  @deprecated Please use {@link #registerIntrospector(Class, Introspector, IntrospectorContext)}
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	public static void registerBeanIntrospector(Class clazz, BeanIntrospector introspector, BeanIntrospectorContext context) {
	}

	/**
	 *  Registers a BeanIntrospector with a class and a context.
	 * 
	 *  @param clazz                   the type
	 *  @param beanIntrospectorFactory the BeanIntrospector factory
	 *  @param context                 the BeanIntrospector context
	 * 
	 *  @deprecated Please use {@link #registerIntrospector(Class, IntrospectorFactory, IntrospectorContext)}
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	public static void registerBeanIntrospector(Class clazz, BeanIntrospectorFactory beanIntrospectorFactory, BeanIntrospectorContext context) {
	}

	/**
	 *  Registers a BeanIntrospector with a class and default context. If no context is specified, this BeanIntrospector
	 *  will be used as default BeanIntrospector for that type.
	 * 
	 *  @param clazz        the type
	 *  @param introspector the BeanIntrospector
	 * 
	 *  @deprecated Please use {@link #registerIntrospector(Class, Introspector)}
	 */
	@java.lang.Deprecated
	public static void registerBeanIntrospector(Class clazz, BeanIntrospector introspector) {
	}

	/**
	 *  Registers a BeanIntrospector with a class and default context. If no context is specified, this BeanIntrospector
	 *  will be used as default BeanIntrospector for that type.
	 * 
	 *  @param clazz               the type
	 *  @param introspectorFactory the BeanIntrospector factory
	 * 
	 *  @deprecated Please use {@link #registerIntrospector(Class, IntrospectorFactory, IntrospectorContext)}
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	public static void registerBeanIntrospector(Class clazz, BeanIntrospectorFactory introspectorFactory) {
	}

	/**
	 *  Unregisters the BeanIntrospector which registers with the class and the context.
	 * 
	 *  @param clazz   the type of which the BeanIntrospector will be unregistered.
	 *  @param context the BeanIntrospector context
	 * 
	 *  @deprecated Please use {@link #unregisterIntrospector(Class, IntrospectorContext)}
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	public static void unregisterBeanIntrospector(Class clazz, BeanIntrospectorContext context) {
	}

	/**
	 *  Unregisters the BeanIntrospector which registers with the class and the default context.
	 * 
	 *  @param clazz the type of which the BeanIntrospector will be unregistered.
	 * 
	 *  @deprecated Please use {@link #unregisterIntrospector(Class)}
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	public static void unregisterBeanIntrospector(Class clazz) {
	}

	/**
	 *  Gets the registered BeanIntrospector.
	 * 
	 *  @param clazz   the type of which the BeanIntrospector will be unregistered.
	 *  @param context the BeanIntrospector context
	 * 
	 *  @return the registered BeanIntrospector
	 */
	public static BeanIntrospector getBeanIntrospector(Class clazz, IntrospectorContext context) {
	}

	/**
	 *  Gets the registered BeanIntrospector using default context.
	 * 
	 *  @param clazz the type of which the BeanIntrospector will be unregistered.
	 * 
	 *  @return the registered BeanIntrospector
	 */
	public static BeanIntrospector getBeanIntrospector(Class clazz) {
	}

	/**
	 *  Initial the default BeanIntrospectors.
	 * 
	 *  @deprecated use {@link #initDefaultIntrospector()}
	 */
	@java.lang.Deprecated
	public static void initDefaultBeanIntrospector() {
	}

	/**
	 *  Registers a Introspector with a class and a context.
	 * 
	 *  @param clazz        the type
	 *  @param introspector the Introspector
	 *  @param context      the Introspector context
	 */
	public static void registerIntrospector(Class clazz, Introspector introspector, IntrospectorContext context) {
	}

	/**
	 *  Registers a Introspector with a class and a context.
	 * 
	 *  @param clazz               the type
	 *  @param introspectorFactory the Introspector factory
	 *  @param context             the Introspector context
	 */
	public static void registerIntrospector(Class clazz, IntrospectorFactory introspectorFactory, IntrospectorContext context) {
	}

	/**
	 *  Registers a Introspector with a class and default context. If no context is specified, this Introspector will be
	 *  used as default Introspector for that type.
	 * 
	 *  @param clazz        the type
	 *  @param introspector the Introspector
	 */
	public static void registerIntrospector(Class clazz, Introspector introspector) {
	}

	/**
	 *  Registers a Introspector with a class and default context. If no context is specified, this Introspector will be
	 *  used as default Introspector for that type.
	 * 
	 *  @param clazz               the type
	 *  @param introspectorFactory the Introspector factory
	 */
	public static void registerIntrospector(Class clazz, IntrospectorFactory introspectorFactory) {
	}

	/**
	 *  Unregisters the Introspector which registers with the class and the context.
	 * 
	 *  @param clazz   the type of which the Introspector will be unregistered.
	 *  @param context the Introspector context
	 */
	public static void unregisterIntrospector(Class clazz, IntrospectorContext context) {
	}

	/**
	 *  Unregisters the Introspector which registers with the class and the default context.
	 * 
	 *  @param clazz the type of which the Introspector will be unregistered.
	 */
	public static void unregisterIntrospector(Class clazz) {
	}

	/**
	 *  Gets the registered Introspector.
	 * 
	 *  @param clazz   the type of which the Introspector will be unregistered.
	 *  @param context the Introspector context
	 * 
	 *  @return the registered Introspector
	 */
	public static Introspector getIntrospector(Class clazz, IntrospectorContext context) {
	}

	/**
	 *  Gets the registered Introspector using default context.
	 * 
	 *  @param clazz the type of which the Introspector will be unregistered.
	 * 
	 *  @return the registered Introspector
	 */
	public static Introspector getIntrospector(Class clazz) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the manager occurs.
	 * 
	 *  @param l the RegistrationListener
	 */
	public static void addRegistrationListener(RegistrationListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the manager occurs.
	 * 
	 *  @param l the RegistrationListener
	 */
	public static void removeRegistrationListener(RegistrationListener l) {
	}

	/**
	 *  Returns an array of all the registration listeners registered on this manager.
	 * 
	 *  @return all of this registration's <code>RegistrationListener</code>s or an empty array if no registration
	 *          listeners are currently registered
	 * 
	 *  @see #addRegistrationListener
	 *  @see #removeRegistrationListener
	 */
	public static RegistrationListener[] getRegistrationListeners() {
	}

	/**
	 *  Gets the available IntrospectorContexts registered with the class.
	 * 
	 *  @param clazz the class.
	 * 
	 *  @return the available IntrospectorContexts.
	 */
	public static IntrospectorContext[] getIntrospectorContexts(Class clazz) {
	}

	/**
	 *  Initial the default Introspectors.
	 */
	public static void initDefaultIntrospector() {
	}
}
