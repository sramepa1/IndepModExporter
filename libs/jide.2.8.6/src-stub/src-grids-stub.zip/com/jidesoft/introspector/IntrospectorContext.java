/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  The introspector context is used by IntrospectorManager so that for the same type, different introspectors can be
 *  registered since the IntrospectorContext is different.
 */
public class IntrospectorContext extends AbstractContext {

	/**
	 *  Default editor context with empty name and no user object.
	 */
	public static IntrospectorContext DEFAULT_CONTEXT;

	/**
	 *  Creates an editor context with a name.
	 * 
	 *  @param name
	 */
	public IntrospectorContext(String name) {
	}

	/**
	 *  Creates an editor context with a name and an object.
	 * 
	 *  @param name
	 *  @param object the user object. It can be used as any object to pass information along.
	 */
	public IntrospectorContext(String name, Object object) {
	}
}
