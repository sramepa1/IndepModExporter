/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  Interfaces used by {@link IntrospectorManager} to create a BeanIntrospector using the factory pattern. The purpose of
 *  this factory is to make sure a new instance of BeanIntrospector is created every time when asking
 *  BeanIntrospectorManager for one.
 * 
 *  @deprecated Please use {@link IntrospectorFactory} instead.
 */
@java.lang.Deprecated
public interface BeanIntrospectorFactory extends IntrospectorFactory {
 {

	public BeanIntrospector create();
}
