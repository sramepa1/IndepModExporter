/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  A global object that can register BeanIntrospector with a type and a IntrospectorContext.
 * 
 *  @deprecated Please use {@link IntrospectorManager} instead.
 */
@java.lang.Deprecated
public class BeanIntrospectorManager extends IntrospectorManager {

	public BeanIntrospectorManager() {
	}
}
