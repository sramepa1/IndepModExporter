/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  <code>TreeModelWrapper</code> is a wrapper around tree model which is referred as the actual tree model or underlying
 *  tree model. It can be used to provide a different view to the actual model. A typical use case is
 *  <code>SortableTreeModel</code>.
 */
public interface TreeModelWrapper {

	/**
	 *  Gets the underlying <code>TreeModel</code>.
	 * 
	 *  @return the underlying <code>TreeModel</code>.
	 */
	public javax.swing.tree.TreeModel getActualModel();

	/**
	 *  Sets the actual <code>TreeModel</code>.
	 * 
	 *  @param model the actual <code>TreeModel</code>.
	 */
	public void setActualModel(javax.swing.tree.TreeModel model);
}
