/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  <code>QuickTreeFilterField</code> works along with any TreeModel to provide filtering feature.
 *  <p/>
 *  It is very simple to use it.
 *  <code><pre>
 *  QuickTreeFilterField filterField = new QuickTreeFilterField(anyTreeModel);</pre></code>
 *  Later on, when you display the JTree, instead using your original tree model, use {@link #getDisplayTreeModel()}.
 *  <code><pre>
 *  JTree tree = new JTree(filterField.getDisplayTreeModel());
 *  filterField.setTree(tree); // optional. Only if you want the selection to be kept before and
 *  after filtering.
 *  </pre></code>
 *  Usually you place <code>QuickTreeFilterField</code> somewhere close to the JTree in the user interface. User can type
 *  in any text in the text field, you will see the JTree automatically display the data that matches with the text.
 * 
 *  @see QuickFilterField
 */
public class QuickTreeFilterField extends com.jidesoft.grid.QuickFilterField {

	/**
	 *  Creates an empty <code>QuickSearchField</code>. This method is useless since <code>QuickSearchField</code> has to
	 *  have a table model in order to work correctly. So we have this method in place mainly to make it JavaBean
	 *  compatible. You must call {@link #setTreeModel(TreeModel)} after you create <code>QuickSearchField</code> using
	 *  this constructor.
	 */
	public QuickTreeFilterField() {
	}

	/**
	 *  Creates a <code>QuickSearchField</code> using the specified listModel.
	 * 
	 *  @param treeModel the TreeModel
	 */
	public QuickTreeFilterField(javax.swing.tree.TreeModel treeModel) {
	}

	/**
	 *  Returns the value of hideEmptyParentNode property. By default it will return true, meaning if none of the parent
	 *  node's children match with the searching text, the parent will be hidden too. This flag will take effect only
	 *  when {@link #isMatchesLeafNodeOnly()} returns true.
	 * 
	 *  @return true or false.
	 */
	public boolean isHideEmptyParentNode() {
	}

	/**
	 *  Sets the value of hideEmptyParentNode property. By default this value is true. Changing this value will cause the
	 *  filters to be applied again.
	 * 
	 *  @param hideEmptyParentNode true or false
	 */
	public void setHideEmptyParentNode(boolean hideEmptyParentNode) {
	}

	/**
	 *  If the filters matches the leaf node only. By default it is true, meaning only leaf node will be compared to the
	 *  searching text.
	 * 
	 *  @return true if only leaf node will be compared to the searching text. False if all nodes will be compared to the
	 *          searching text.
	 */
	public boolean isMatchesLeafNodeOnly() {
	}

	/**
	 *  Sets the value of matchesLeafNodeOnly property. By default this value is true. Changing this value will cause the
	 *  filters to be applied again.
	 * 
	 *  @param matchesLeafNodeOnly true or false
	 */
	public void setMatchesLeafNodeOnly(boolean matchesLeafNodeOnly) {
	}

	/**
	 *  If a parent node matches, all its children will be kept if this flag is true. Otherwise, we will further filter
	 *  all the children and only leave those matched children visible.
	 * 
	 *  @return true if all children nodes will be kept if the parent node matches the filter condition.
	 */
	public boolean isKeepAllChildren() {
	}

	/**
	 *  Sets the value of keepAllChildren property. By default this value is true.
	 * 
	 *  @param keepAllChildren the flag
	 */
	public void setKeepAllChildren(boolean keepAllChildren) {
	}

	/**
	 *  Creates the the context menu. It will call super.createContextMenu() first, then add three menu items for
	 *  <code>QuickTreeFilterField</code>. You can override this method if you want to customize the popup menu. The
	 *  three menu items' name are "Filter.matchLeafNodeOnly", "Filter.hideNodesWithoutChildren" and
	 *  "Filter.keepAllChildren" respectively. If you need to remove any of the menu items, you can always look it up by
	 *  name and remove it.
	 * 
	 *  @return the popup menu.
	 */
	@java.lang.Override
	protected JidePopupMenu createContextMenu() {
	}

	/**
	 *  Compares the element with the searching text. In <code>QuickTreeFilterField</code> case, the element will be an
	 *  instance of TreeNode. <p>Subclass can always override this method to do their own comparison.
	 * 
	 *  @param element       the TreeNode
	 *  @param searchingText the searching text
	 *  @return true if the element should be filtered. Otherwise, false.
	 */
	@java.lang.Override
	protected boolean compare(Object element, String searchingText) {
	}

	/**
	 *  Applies the filter.
	 */
	@java.lang.Override
	public void applyFilter(String text) {
	}

	/**
	 *  Sets the table model used by this component. It could be any table model, not necessarily be a
	 *  FilterableListModel.
	 * 
	 *  @param treeModel the TreeModel
	 */
	public void setTreeModel(javax.swing.tree.TreeModel treeModel) {
	}

	/**
	 *  Creates the <code>FilterableTreeModel</code>. By default, it will always create a new
	 *  <code>FilterableTreeModel</code> that wraps the treeModel but you can always override it to return an existing
	 *  <code>FilterableTreeModel</code> if you want.
	 * 
	 *  @param treeModel the tree model.
	 *  @return the <code>FilterableTreeModel</code> that wraps the tree model.
	 */
	protected FilterableTreeModel createDisplayTreeModel(javax.swing.tree.TreeModel treeModel) {
	}

	/**
	 *  Gets the table model.
	 * 
	 *  @return the table model.
	 */
	public javax.swing.tree.TreeModel getTreeModel() {
	}

	/**
	 *  Gets the display table model. <code>QuickSearchField</code> doesn't modify the table model that you passed in but
	 *  wrap it in FilterableListModel. So if you want to display the result after being filtered, you should use this
	 *  method to get the display table model and set it to your table.
	 * 
	 *  @return the table model to be displayed.
	 */
	public FilterableTreeModel getDisplayTreeModel() {
	}

	/**
	 *  Gets the tree that is using the displayTreeModel.
	 * 
	 *  @return the tree that is using the displayTreeModel.
	 */
	public javax.swing.JTree getTree() {
	}

	/**
	 *  Sets the tree that is using the displayTreeModel. The only reason we want to know the tree is to keep the
	 *  selection during filtering. For example, if node A is selected before fitlering, and since it matches with the
	 *  searching text, the selection should be kept after filtering. If you didn't call this method to let
	 *  <code>QuickTreeFilterField</code> what the tree is, the selection will be gone.
	 *  <p/>
	 *  Please note, this method will be set displayTreeModel onto the tree. You still need to call {@link
	 *  #getDisplayTreeModel()} to get the model and set it to the tree.
	 * 
	 *  @param tree the JTree
	 */
	public void setTree(javax.swing.JTree tree) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grid.properties that begin with "Filter.".
	 * 
	 *  @param key the resource key
	 *  @return the localized string.
	 */
	protected String getTreeResourceString(String key) {
	}
}
