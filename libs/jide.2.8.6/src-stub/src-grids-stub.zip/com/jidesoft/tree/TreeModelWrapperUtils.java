/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  <code>TreeModelWrapperUtils</code> is a utility class that contains several useful methods for
 *  <code>TreeModelWrapper</code>.
 */
public class TreeModelWrapperUtils {

	public TreeModelWrapperUtils() {
	}

	/**
	 *  Gets the inner <code>TreeModel</code> whose class is an instance of the innerModelClass.
	 * 
	 *  @param outerModel      the outermost <code>TreeModel</code>.
	 *  @param innerModelClass the class for the inner model.
	 *  @return the TreeModel whose class is innerModelClass.
	 */
	public static javax.swing.tree.TreeModel getActualTreeModel(javax.swing.tree.TreeModel outerModel, Class innerModelClass) {
	}

	/**
	 *  Gets the inner most <code>TreeModel</code>.
	 * 
	 *  @param outerModel the outermost <code>TreeModel</code>.
	 *  @return the inner most Tree model. It is the first inner model that is not an instance of
	 *          <code>TreeModelWrapper</code>.
	 */
	public static javax.swing.tree.TreeModel getActualTreeModel(javax.swing.tree.TreeModel outerModel) {
	}
}
