/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  <code>TreeShrinkSearchableSupport</code> is a subclass of <code>ShrinkSearchableSupport</code> to make <code>TreeSearchable</code>
 *  shrinkable while searching.
 */
public class TreeShrinkSearchableSupport extends com.jidesoft.grid.ShrinkSearchableSupport {

	public TreeShrinkSearchableSupport(Searchable searchable) {
	}

	public void installFilterableModel() {
	}

	public void uninstallFilterableModel() {
	}

	protected void applyFilter(String searchingText) {
	}

	protected int getActualIndexAt(int viewIndex) {
	}

	protected int getVisualIndexAt(int actualIndex) {
	}
}
