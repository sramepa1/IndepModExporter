/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  The default implementation of TreeModelWrapper. It implements all methods on {@link TreeModel} and {@link
 *  TreeModelWrapper}.
 *  <p/>
 */
public class DefaultTreeModelWrapper extends AbstractTreeModel implements TreeModelWrapper, javax.swing.event.TreeModelListener {
 {

	/**
	 *  Creates an empty <code>DefaultTreeModelWrapper</code>.
	 */
	public DefaultTreeModelWrapper() {
	}

	/**
	 *  Creates a DefaultTreeModelWrapper from for a tree model.
	 * 
	 *  @param model the original tree model
	 */
	public DefaultTreeModelWrapper(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Sets the actual tree model.
	 * 
	 *  @param model the original tree model
	 */
	public void setActualModel(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Gets the actual tree model. Since TreeModelWrapper is just a wrapper around another tree model, this method will
	 *  return you the actual tree model.
	 * 
	 *  @return the actual tree model.
	 */
	public javax.swing.tree.TreeModel getActualModel() {
	}

	/**
	 *  Implementations of the method in TreeModel. it delegates to the actual tree model.
	 * 
	 *  @return the root
	 */
	public Object getRoot() {
	}

	/**
	 *  Implementations of the method in TreeModel. it delegates to the actual tree model after index conversion.
	 */
	public int getIndexOfChild(Object parent, Object child) {
	}

	/**
	 *  Implementations of the method in TreeModel. it delegates to the actual tree model after index conversion.
	 */
	public Object getChild(Object parent, int index) {
	}

	/**
	 *  Implementations of the method in TreeModel. it delegates to the actual tree model after index conversion.
	 */
	public int getChildCount(Object parent) {
	}

	/**
	 *  Implementations of the method in TreeModel. it delegates to the actual tree model.
	 */
	public boolean isLeaf(Object node) {
	}

	protected com.jidesoft.list.ListModelWrapper getListModelWrapper(Object node) {
	}

	protected void setListModelWrapper(Object node, com.jidesoft.list.ListModelWrapper wrapper) {
	}

	protected void clearListModelWrapper(Object node) {
	}

	protected void clearAllListModelWrappers() {
	}

	/**
	 *  Creates an empty list model wrapper. Subclass can override this method to create their special list model
	 *  wrapper. For example, {@link FilterableTreeModel} overrides it to create an instance of {@link
	 *  com.jidesoft.list.FilterableListModel}. {@link SortableTreeModel} overrides it to create an instance of {@link
	 *  com.jidesoft.list.SortableListModel}.
	 *  <p/>
	 *  Default implementation of this method in this class simply returns a new instance of
	 *  <code>DefaultListModelWrapper</code>.
	 * 
	 *  @param node the tree node
	 *  @return an empty list model wrapper.
	 */
	protected com.jidesoft.list.ListModelWrapper createListModelWrapper(Object node) {
	}

	/**
	 *  This is the method that will be called to configure the empty list model wrapper you created in {@link
	 *  #createListModelWrapper(Object)}. Subclass can override it to configure the list model. For example, {@link
	 *  FilterableTreeModel} uses this method to add filters that defined on <code>FilterableTreeModel</code> to
	 *  <code>FilterableListModel</code> and turn those filters on.
	 *  <p/>
	 *  In default implementation on <code>DefaultTreeModelWrapper</code>, this method is empty.
	 * 
	 *  @param wrapper the wrapper to be configured.
	 *  @param node    the tree node
	 */
	protected void configureListModelWrapper(com.jidesoft.list.ListModelWrapper wrapper, Object node) {
	}

	/**
	 *  Delegates to underlying tree model.
	 * 
	 *  @param path     the tree path
	 *  @param newValue the new value
	 */
	@java.lang.Override
	public void valueForPathChanged(javax.swing.tree.TreePath path, Object newValue) {
	}

	/**
	 *  Method for TreeModelListener. It will listen to the event from actual tree model and fire converted tree model
	 *  for this tree model.
	 * 
	 *  @param e the TreeModelEvent
	 */
	public void treeNodesChanged(javax.swing.event.TreeModelEvent e) {
	}

	/**
	 *  Method for TreeModelListener. It will listen to the event from actual tree model and fire converted tree model
	 *  for this tree model.
	 * 
	 *  @param e the TreeModelEvent
	 */
	public void treeNodesInserted(javax.swing.event.TreeModelEvent e) {
	}

	/**
	 *  Method for TreeModelListener. It will listen to the event from actual tree model and fire converted tree model
	 *  for this tree model.
	 * 
	 *  @param e the TreeModelEvent
	 */
	public void treeNodesRemoved(javax.swing.event.TreeModelEvent e) {
	}

	/**
	 *  Method for TreeModelListener. It will listen to the event from actual tree model and fire converted tree model
	 *  for this tree model.
	 * 
	 *  @param e the TreeModelEvent
	 */
	public void treeStructureChanged(javax.swing.event.TreeModelEvent e) {
	}

	/**
	 *  Converts the tree model event for the actual model to the event for this model.
	 * 
	 *  @param e the TreeModelEvent
	 *  @return the tree model event for this model.
	 */
	protected javax.swing.event.TreeModelEvent convertTreeModelEvent(javax.swing.event.TreeModelEvent e) {
	}
}
