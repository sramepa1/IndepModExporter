/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  SortableTreeModel is a tree model wrapper which can do the sorting.
 *  Given any existing tree model, you can wrap it into <code>SortableTreeModel</code>
 *  and use it later on any JTree.
 *  <p/>
 *  <pre><code>
 *  SortableTreeModel sortableTreeModel = new SortableTreeModel(treeModel);
 *  JTree sortableTree = new JTree(sortableTreeModel);
 *  </code></pre>
 *  To sort the tree, you just call
 *  <pre><code>
 *  sortableTreeModel.sort(); // or sort(SortableTreeModel.SORT_DESCENDING) to sort descending.
 *  </code></pre>
 */
public class SortableTreeModel extends DefaultTreeModelWrapper {

	public static final int SORT_ASCENDING = 1;

	public static final int SORT_DESCENDING = -1;

	public static final int UNSORTED = 0;

	public SortableTreeModel() {
	}

	/**
	 *  Creates a DefaultTreeModelWrapper from any table model.
	 * 
	 *  @param model
	 */
	public SortableTreeModel(javax.swing.tree.TreeModel model) {
	}

	@java.lang.Override
	protected com.jidesoft.list.ListModelWrapper createListModelWrapper(Object parent) {
	}

	/**
	 *  Configures the ListModelWrapper that is used to sort the tree nodes at the same level. Please note,
	 *  if you want to override this method to set a new comparator to the wrapper (you can cast it to SortableListModel and call setComparator to set it),
	 *  please make sure you call setComparator first then call super.configureListModelWrapper.
	 * 
	 *  @param wrapper
	 *  @param parent
	 */
	@java.lang.Override
	protected void configureListModelWrapper(com.jidesoft.list.ListModelWrapper wrapper, Object parent) {
	}

	public int getSortOrder() {
	}

	/**
	 *  Set the sort order.
	 * 
	 *  @param sortOrder the new sort order. Valid values for sortOrder are {@link #SORT_ASCENDING}, {@link #SORT_DESCENDING} and {@link #UNSORTED}.
	 */
	public void setSortOrder(int sortOrder) {
	}

	/**
	 *  Sort the tree model. The order could be either {@link #SORT_ASCENDING} or {@link #SORT_DESCENDING}.
	 *  You can also pass in {@link #UNSORTED}, which will be the same as {@link #unsort()}.
	 * 
	 *  @param order the new sort order.
	 */
	public void sort(int order) {
	}

	/**
	 *  Sort or unsort the tree model.
	 */
	public void sort() {
	}

	/**
	 *  Unsort the tree model.
	 */
	public void unsort() {
	}
}
