/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  This class is used to create a multiple-exclusion scope for a set of TreeSelectionModel so that one
 *  TreeSelectionModel can have selected index at a time.
 */
public class TreeSelectionModelGroup extends <any> implements java.io.Serializable {
 {

	/**
	 *  Creates a new <code>ListSelectionModelGroup</code>.
	 */
	public TreeSelectionModelGroup() {
	}

	@java.lang.Override
	protected javax.swing.event.TreeSelectionListener createSelectionListener() {
	}

	@java.lang.Override
	protected void addSelectionListener(javax.swing.tree.TreeSelectionModel model, javax.swing.event.TreeSelectionListener listener) {
	}

	@java.lang.Override
	protected void removeSelectionListener(javax.swing.tree.TreeSelectionModel model, javax.swing.event.TreeSelectionListener listener) {
	}

	/**
	 *  Returns all the TreeSelectionModel that are participating in this group.
	 * 
	 *  @return an array of all TreeSelectionModels
	 */
	public javax.swing.tree.TreeSelectionModel[] getListModels() {
	}
}
