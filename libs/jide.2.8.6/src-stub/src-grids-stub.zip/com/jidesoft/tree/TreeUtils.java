/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


public class TreeUtils {

	public TreeUtils() {
	}

	/**
	 *  Save the selection of the JTree as an array of integer.
	 * 
	 *  @param tree the JTree
	 *  @return selection as an array
	 */
	public static javax.swing.tree.TreePath[] saveSelection(javax.swing.JTree tree) {
	}

	/**
	 *  Restore the selection in JTree. It must used the array that created by saveSelection.
	 * 
	 *  @param tree     the JTree
	 *  @param selected an int array created by {@link #saveSelection(javax.swing.JTree)}.
	 */
	public static void loadSelection(javax.swing.JTree tree, javax.swing.tree.TreePath[] selected) {
	}

	/**
	 *  Save the expansion state of a tree.
	 * 
	 *  @param tree the JTree
	 *  @return expanded tree path as Enumeration
	 */
	public static java.util.Enumeration saveExpansionStateByTreePath(javax.swing.JTree tree) {
	}

	/**
	 *  Restore the expansion state of a JTree.
	 * 
	 *  @param tree        the JTree
	 *  @param enumeration an Enumeration of expansion state. You can get it using {@link #saveExpansionStateByTreePath(javax.swing.JTree)}.
	 */
	public static void loadExpansionStateByTreePath(javax.swing.JTree tree, java.util.Enumeration enumeration) {
	}

	public static boolean isDescendant(javax.swing.tree.TreePath path1, javax.swing.tree.TreePath path2) {
	}

	public static String saveExpansionState(javax.swing.JTree tree, int row) {
	}

	/**
	 *  @param tree           the JTree
	 *  @param row            the row index
	 *  @param expansionState the expansion state
	 */
	public static void loadExpansionState(javax.swing.JTree tree, int row, String expansionState) {
	}

	/**
	 *  Expands the visible rows in a JTree. It will only expand one level from the current expansion level. If you want
	 *  to expand all nodes recursively in a tree, use {@link #expandAll(javax.swing.JTree, boolean)} with a true
	 *  parameter.
	 * 
	 *  @param tree the JTree
	 */
	public static void expandAll(javax.swing.JTree tree) {
	}

	/**
	 *  Expands the tree completely.
	 * 
	 *  @param tree   the tree
	 *  @param expand expand or collapse
	 */
	public static void expandAll(javax.swing.JTree tree, boolean expand) {
	}

	/**
	 *  Expands the tree completely.
	 * 
	 *  @param tree   the tree
	 *  @param parent the parent tree path. Only tree paths under this parent tree path will be expanded or collapsed.
	 *  @param expand expand or collapse
	 */
	public static void expandAll(javax.swing.JTree tree, javax.swing.tree.TreePath parent, boolean expand) {
	}

	/**
	 *  Finds the TreeNode that has the user object as passed in. Please note, since only DefaultMutableTreeNode has
	 *  userObject, this method will only find the tree node that is the DefaultMutableTreeNode.
	 * 
	 *  @param tree       the tree
	 *  @param userObject the user object to match with the tree node's user object.
	 *  @return the tree node.
	 */
	public static Object findTreeNode(javax.swing.JTree tree, Object userObject) {
	}

	/**
	 *  Finds the TreeNode that has the user object as passed in starting from a tree path. Please note, since only
	 *  DefaultMutableTreeNode has userObject, this method will only find the tree node that is the
	 *  DefaultMutableTreeNode.
	 * 
	 *  @param tree       the tree
	 *  @param parent     the parent tree path. Only tree paths under this parent tree path will be searched.
	 *  @param userObject the user object to match with the tree node's user object.
	 *  @return the tree node that matches with the user object.
	 */
	public static Object findTreeNode(javax.swing.JTree tree, javax.swing.tree.TreePath parent, Object userObject) {
	}

	/**
	 *  Gets the leaf node count. It will recursively go into each children node starting from root and count how many
	 *  leaf nodes in the tree model.
	 *  <p/>
	 *  Please use it carefully. If your tree model has unlimited number of tree nodes and a huge number of tree nodes,
	 *  this method will never or take a long time to return.
	 * 
	 *  @param treeModel the TreeModel.
	 *  @return the number of leaf nodes.
	 */
	public static int getLeafCount(javax.swing.tree.TreeModel treeModel) {
	}

	/**
	 *  Gets the leaf node count. It will recursively go into each children node starting from the specified node and
	 *  count how many leaf nodes in the tree model.
	 *  <p/>
	 *  Please use it carefully. If your tree model has unlimited number of tree nodes and a huge number of tree nodes,
	 *  this method will never or take a long time to return.
	 * 
	 *  @param treeModel the TreeModel
	 *  @param node      the tree node
	 *  @return the number of leaf nodes.
	 */
	public static int getLeafCount(javax.swing.tree.TreeModel treeModel, Object node) {
	}
}
