/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  <code>FilterableCheckBoxTreeSelectionModel</code> is a subclass of {@link CheckBoxTreeSelectionModel} and use in
 *  {@link com.jidesoft.swing.CheckBoxTree} to keep track of the checked tree paths.
 *  <p/>
 *  With this class, you can solve the selection issue while implementing FilterableTreeModel in CheckBoxTree.
 */
public class FilterableCheckBoxTreeSelectionModel extends CheckBoxTreeSelectionModel {

	public FilterableCheckBoxTreeSelectionModel(javax.swing.tree.TreeModel model) {
	}

	public FilterableCheckBoxTreeSelectionModel(javax.swing.tree.TreeModel model, boolean digIn) {
	}

	@java.lang.Override
	public void addSelectionPaths(javax.swing.tree.TreePath[] paths) {
	}

	@java.lang.Override
	public void removeSelectionPaths(javax.swing.tree.TreePath[] paths) {
	}

	@java.lang.Override
	public boolean isPartiallySelected(javax.swing.tree.TreePath path) {
	}

	@java.lang.Override
	protected boolean isParentActuallySelected(javax.swing.tree.TreePath path, javax.swing.tree.TreePath parent) {
	}

	@java.lang.Override
	protected boolean areSiblingsSelected(javax.swing.tree.TreePath path) {
	}

	@java.lang.Override
	protected int getChildrenCount(Object node) {
	}

	@java.lang.Override
	protected Object getChild(Object node, int i) {
	}

	/**
	 *  The method to handle tree structure change event. By default, it will clear the current check box tree selection.
	 *  However, if you want your CheckBoxTree work with QuickTreeFilterField, you would need override this method to do
	 *  nothing so that the selection could be kept during the input in the QuickTreeFilterField. However, please be
	 *  noted that if you do this, if the customer does change the tree structure, the selection would not be cleared
	 *  also.
	 * 
	 *  @param e the tree model event
	 */
	@java.lang.Override
	public void treeStructureChanged(javax.swing.event.TreeModelEvent e) {
	}
}
