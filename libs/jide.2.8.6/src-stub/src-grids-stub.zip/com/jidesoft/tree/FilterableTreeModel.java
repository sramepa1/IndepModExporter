/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  <code>FilterableTreeModel</code> is a TreeModelWrapper that can handle filters.
 *  <p/>
 *  You can add multiple filters to this tree model. By default, the filters are AND relation, meaning only as long as
 *  one filter return true for a value, the value will be filtered. You can call {@link #setAndMode(boolean)} to set to
 *  false. If so, as long as one filter return false for a value, the value will be kept.
 *  <p/>
 *  By default, filters won't take effect immediately. You need to call <code>setFiltersApplied(true)</code> to apply
 *  those filters. If <code>filtersApplied</code> flag is true already, you just need to call refresh(). We don't refresh
 *  automatically because you might have several filters to add. You can add all of them, then only call refresh once.
 */
public class FilterableTreeModel extends DefaultTreeModelWrapper {

	/**
	 *  The data structure contains all the filters.
	 */
	protected java.util.List _filters;

	/**
	 *  A flag to turn on/off filters. {@link #setFiltersApplied(boolean)} with true will turn it on and {@link
	 *  #setFiltersApplied(boolean)} with false will turn it off.
	 */
	protected boolean _filtersApplied;

	public FilterableTreeModel() {
	}

	/**
	 *  Creates a FilterableTreeModel from any tree model.
	 * 
	 *  @param model
	 */
	public FilterableTreeModel(javax.swing.tree.TreeModel model) {
	}

	@java.lang.Override
	protected com.jidesoft.list.ListModelWrapper createListModelWrapper(Object node) {
	}

	@java.lang.Override
	protected void configureListModelWrapper(com.jidesoft.list.ListModelWrapper wrapper, Object node) {
	}

	/**
	 *  Adds a list of filters.
	 * 
	 *  @param filters
	 */
	public void addFilters(java.util.List filters) {
	}

	/**
	 *  Adds a filter.
	 * 
	 *  @param filter
	 */
	public void addFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes the filters. The filter must be added using {@link #addFilter(Filter)}.
	 * 
	 *  @param filter
	 */
	public void removeFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes all filters.
	 */
	public void clearFilters() {
	}

	/**
	 *  Gets the filters.
	 * 
	 *  @return the filters.
	 */
	public com.jidesoft.filter.Filter[] getFilters() {
	}

	/**
	 *  Applies or unapplies the filters. By default, the filters are not applied. So after user adds several filters,
	 *  this method should be called to make filters taking effect. When new filter is added or existing is removed, this
	 *  method should be called as well.
	 * 
	 *  @param apply true to apply the filters.
	 */
	public void setFiltersApplied(boolean apply) {
	}

	/**
	 *  Reapply all filters after they are changed.
	 */
	public void refresh() {
	}

	/**
	 *  Checks if the filters are in effect.
	 * 
	 *  @return true if filters are in effect.
	 */
	public boolean isFiltersApplied() {
	}

	/**
	 *  Sets the logic of filters. If true, filters are in AND mode, meaning if one of the filters return true in
	 *  isValueFiltered method, the value will be filtered. If false, filters are in OR mode, meaning if one of the
	 *  filters return false, the value will NOT be filtered.
	 * 
	 *  @return the AND/OR mode. Default is true which means AND mode.
	 */
	public boolean isAndMode() {
	}

	/**
	 *  Sets the logic of the filters.
	 * 
	 *  @param andMode
	 */
	public void setAndMode(boolean andMode) {
	}

	@java.lang.Override
	public void treeNodesInserted(javax.swing.event.TreeModelEvent e) {
	}

	@java.lang.Override
	public void treeNodesRemoved(javax.swing.event.TreeModelEvent e) {
	}

	@java.lang.Override
	public void treeStructureChanged(javax.swing.event.TreeModelEvent e) {
	}

	@java.lang.Override
	public void treeNodesChanged(javax.swing.event.TreeModelEvent e) {
	}

	/**
	 *  Clears the filters related to the tree path.
	 * 
	 *  @param path the tree path.
	 */
	public void clearFiltersOnTreePath(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Updates the tree based on the TreeModelEvent. By default, we will fire structure changed on the parent node which
	 *  is not a good idea.
	 * 
	 *  @param e TreeModelEvent
	 */
	protected void updateTree(javax.swing.event.TreeModelEvent e) {
	}
}
