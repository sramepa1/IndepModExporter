/**
 *  The package contains all kinds of components and classes based on JTree for JIDE Grids product.
 */
package com.jidesoft.tree;


/**
 *  This abstract class provides default implementations for some of the methods in the <code>TreeModel</code> interface.
 *  It takes care of the management of listeners and provides some conveniences for generating
 *  <code>TreeModelEvents</code> and dispatching them to the listeners.
 * 
 *  @author Santhosh Kumar T
 */
public abstract class AbstractTreeModel implements javax.swing.tree.TreeModel {
 {

	protected javax.swing.event.EventListenerList listenerList;

	public AbstractTreeModel() {
	}

	public void valueForPathChanged(javax.swing.tree.TreePath path, Object newValue) {
	}

	public void addTreeModelListener(javax.swing.event.TreeModelListener l) {
	}

	public void removeTreeModelListener(javax.swing.event.TreeModelListener l) {
	}

	public javax.swing.event.TreeModelListener[] getTreeModelListeners() {
	}

	/**
	 *  Invoke this method after you've changed how node is to be represented in the tree.
	 */
	public void nodeChanged(javax.swing.tree.TreeNode node) {
	}

	/**
	 *  Invoke this method after you've changed how the children identified by childIndicies are to be represented in the
	 *  tree.
	 */
	public void nodesChanged(javax.swing.tree.TreeNode node, int[] childIndices) {
	}

	/**
	 *  Builds the parents of node up to and including the root node, where the original node is the last element in the
	 *  returned array. The length of the returned array gives the node's depth in the tree.
	 * 
	 *  @param aNode the TreeNode to get the path for
	 */
	public javax.swing.tree.TreeNode[] getPathToRoot(javax.swing.tree.TreeNode aNode) {
	}

	/**
	 *  Builds the parents of node up to and including the root node, where the original node is the last element in the
	 *  returned array. The length of the returned array gives the node's depth in the tree.
	 * 
	 *  @param aNode the TreeNode to get the path for
	 *  @param depth an int giving the number of steps already taken towards the root (on recursive calls), used to size
	 *               the returned array
	 *  @return an array of TreeNodes giving the path from the root to the specified node
	 */
	protected javax.swing.tree.TreeNode[] getPathToRoot(javax.swing.tree.TreeNode aNode, int depth) {
	}

	/**
	 *  Fires events to notify the parties who listener to TreeModelEvent about tree nodes are changed.
	 * 
	 *  @param source       the Object responsible for generating the event (typically the creator of the event object
	 *                      passes <code>this</code> for its value)
	 *  @param path         an array of Object identifying the path to the parent of the modified item(s), where the
	 *                      first element of the array is the Object stored at the root node and the last element is the
	 *                      Object stored at the parent node
	 *  @param childIndices an array of <code>int</code> that specifies the index values of the changed items. The
	 *                      indices must be in sorted order, from lowest to highest
	 *  @param children     an array of Object containing the inserted, removed, or changed objects
	 */
	protected void fireTreeNodesChanged(Object source, Object[] path, int[] childIndices, Object[] children) {
	}

	/**
	 *  Fires events to notify the parties who listener to TreeModelEvent about tree nodes are inserted.
	 * 
	 *  @param source       the Object responsible for generating the event (typically the creator of the event object
	 *                      passes <code>this</code> for its value)
	 *  @param path         an array of Object identifying the path to the parent of the modified item(s), where the
	 *                      first element of the array is the Object stored at the root node and the last element is the
	 *                      Object stored at the parent node
	 *  @param childIndices an array of <code>int</code> that specifies the index values of the inserted items. The
	 *                      indices must be in sorted order, from lowest to highest
	 *  @param children     an array of Object containing the inserted, removed, or changed objects
	 */
	protected void fireTreeNodesInserted(Object source, Object[] path, int[] childIndices, Object[] children) {
	}

	/**
	 *  Fires events to notify the parties who listener to TreeModelEvent about tree nodes are removed.
	 * 
	 *  @param source       the Object responsible for generating the event (typically the creator of the event object
	 *                      passes <code>this</code> for its value)
	 *  @param path         an array of Object identifying the path to the parent of the modified item(s), where the
	 *                      first element of the array is the Object stored at the root node and the last element is the
	 *                      Object stored at the parent node
	 *  @param childIndices an array of <code>int</code> that specifies the index values of the removed items. The
	 *                      indices must be in sorted order, from lowest to highest
	 *  @param children     an array of Object containing the inserted, removed, or changed objects
	 */
	protected void fireTreeNodesRemoved(Object source, Object[] path, int[] childIndices, Object[] children) {
	}

	/**
	 *  Fires events to notify the parties who listener to TreeModelEvent about tree structure changed.
	 * 
	 *  @param source       the Object responsible for generating the event (typically the creator of the event object
	 *                      passes <code>this</code> for its value)
	 *  @param path         an array of Object identifying the path to the parent of the modified item(s), where the
	 *                      first element of the array is the Object stored at the root node and the last element is the
	 *                      Object stored at the parent node
	 *  @param childIndices an array of <code>int</code> that specifies the index values of the changed items. The
	 *                      indices must be in sorted order, from lowest to highest
	 *  @param children     an array of Object containing the inserted, removed, or changed objects
	 */
	protected void fireTreeStructureChanged(Object source, Object[] path, int[] childIndices, Object[] children) {
	}

	protected void fireTreeStructureChanged(Object source, javax.swing.tree.TreePath path) {
	}
}
