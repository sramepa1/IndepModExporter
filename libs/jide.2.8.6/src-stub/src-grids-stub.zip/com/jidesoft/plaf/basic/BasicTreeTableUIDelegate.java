package com.jidesoft.plaf.basic;


public class BasicTreeTableUIDelegate extends BasicCellSpanTableUIDelegate {

	public BasicTreeTableUIDelegate(javax.swing.JTable table, javax.swing.CellRendererPane rendererPane) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void paintSpanDraggedArea(java.awt.Graphics g, int rMin, int rMax, javax.swing.table.TableColumn draggedColumn, int distance) {
	}
}
