package com.jidesoft.plaf.basic;


public class BasicNavigableTableUIDelegate extends BasicJideTableUIDelegate {

	public BasicNavigableTableUIDelegate(javax.swing.JTable table, javax.swing.CellRendererPane rendererPane) {
	}

	public javax.swing.event.MouseInputListener createMouseInputListener(javax.swing.event.MouseInputListener mouseInputListener) {
	}
}
