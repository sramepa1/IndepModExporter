package com.jidesoft.plaf.basic;


public class BasicHierarchicalTableUI extends BasicCellSpanTableUI {

	public BasicHierarchicalTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected com.jidesoft.plaf.TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	protected void paintGrid(java.awt.Graphics g, int rMin, int rMax, int cMin, int cMax) {
	}

	@java.lang.Override
	protected void paintCell(java.awt.Graphics g, java.awt.Rectangle cellRect, int row, int column) {
	}
}
