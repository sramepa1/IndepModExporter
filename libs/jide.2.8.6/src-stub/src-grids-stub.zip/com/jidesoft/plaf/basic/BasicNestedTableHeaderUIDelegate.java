package com.jidesoft.plaf.basic;


/**
 *  UI class for NestedTableHeader.
 */
public class BasicNestedTableHeaderUIDelegate extends com.jidesoft.plaf.TableHeaderUIDelegate {

	protected javax.swing.table.JTableHeader header;

	protected javax.swing.CellRendererPane rendererPane;

	public BasicNestedTableHeaderUIDelegate(javax.swing.table.JTableHeader header, javax.swing.CellRendererPane rendererPane) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	public int viewIndexForColumn(javax.swing.table.TableColumn aColumn) {
	}

	public javax.swing.table.TableColumn getResizingColumn(java.awt.Point p, int column) {
	}

	public int mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e, int mouseXOffset) {
	}

	public int mouseDragged(java.awt.event.MouseEvent e, int mouseXOffset) {
	}
}
