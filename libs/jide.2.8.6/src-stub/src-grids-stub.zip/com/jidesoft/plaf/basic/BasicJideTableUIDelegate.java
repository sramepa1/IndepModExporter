package com.jidesoft.plaf.basic;


/**
 *  The TableUI based on BasicTableUI. It's almost the same as BasicTableUI except the methods paintCell() and
 *  paintGrid() methods are protected so that subclasses can override those methods.
 */
public class BasicJideTableUIDelegate implements com.jidesoft.plaf.TableUIDelegate {
 {

	protected javax.swing.JTable table;

	protected javax.swing.CellRendererPane rendererPane;

	public BasicJideTableUIDelegate(javax.swing.JTable table, javax.swing.CellRendererPane rendererPane) {
	}

	/**
	 *  Copied from BasicTableUI - jdk6 u10
	 * 
	 *  @param g the Graphics instance
	 *  @param c the component to paint
	 */
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	public void paintGrid(java.awt.Graphics g, int rMin, int rMax, int cMin, int cMax) {
	}

	protected int viewIndexForColumn(javax.swing.table.TableColumn aColumn) {
	}

	public void paintDraggedArea(java.awt.Graphics g, int rMin, int rMax, javax.swing.table.TableColumn draggedColumn, int distance) {
	}

	public void paintCell(java.awt.Graphics g, java.awt.Rectangle cellRect, int row, int column) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void adjustCellEditor(java.awt.Graphics g, java.awt.Rectangle cellRect, int row, int column) {
	}
}
