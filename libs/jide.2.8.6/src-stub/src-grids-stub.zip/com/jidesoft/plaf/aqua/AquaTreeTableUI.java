package com.jidesoft.plaf.aqua;


public class AquaTreeTableUI extends AquaCellSpanTableUI {

	public AquaTreeTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected com.jidesoft.plaf.TableUIDelegate createUIDelegate() {
	}
}
