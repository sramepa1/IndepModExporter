package com.jidesoft.plaf.windows;


/**
 *  UI class for NestedTableHeader.
 */
public class WindowsNestedTableHeaderUI extends com.sun.java.swing.plaf.windows.WindowsTableHeaderUI {

	protected com.jidesoft.plaf.TableHeaderUIDelegate _delegate;

	public WindowsNestedTableHeaderUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	protected void installDefaults() {
	}

	protected com.jidesoft.plaf.TableHeaderUIDelegate createDelegate() {
	}

	protected void uninstallDefaults() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	/**
	 *  Creates the mouse listener for the JTable.
	 */
	@java.lang.Override
	protected javax.swing.event.MouseInputListener createMouseInputListener() {
	}
}
