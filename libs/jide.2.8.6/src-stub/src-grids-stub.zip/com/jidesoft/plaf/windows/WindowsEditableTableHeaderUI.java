package com.jidesoft.plaf.windows;


/**
 *  EditableTableHeaderUI of EditableTableHeader for Windows L&F. Note, since the same code is used in several different
 *  places, if you make changes to this class, please make sure you update all three (BasicEditableTableHeaderUI,
 *  WindowsEditableTableHeaderUI and AquaEditableTableHeaderUI) at the same time.
 */
public class WindowsEditableTableHeaderUI extends com.sun.java.swing.plaf.windows.WindowsTableHeaderUI {

	public WindowsEditableTableHeaderUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected javax.swing.event.MouseInputListener createMouseInputListener() {
	}

	public class MouseInputHandler {


		protected com.jidesoft.grid.EditableTableHeader _tableHeader;

		public WindowsEditableTableHeaderUI.MouseInputHandler(com.jidesoft.grid.EditableTableHeader header) {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseMoved(java.awt.event.MouseEvent e) {
		}
	}
}
