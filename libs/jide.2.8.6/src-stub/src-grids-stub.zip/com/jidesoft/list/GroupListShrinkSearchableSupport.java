/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>GroupListShrinkSearchableSupport</code> is a subclass of <code>ShrinkSearchableSupport</code> to make <code>GroupList</code>
 *  shrinkable while searching.
 */
public class GroupListShrinkSearchableSupport extends com.jidesoft.grid.ListShrinkSearchableSupport {

	public GroupListShrinkSearchableSupport(Searchable searchable) {
	}

	public void installFilterableModel() {
	}

	public void uninstallFilterableModel() {
	}

	protected int getActualIndexAt(int viewIndex) {
	}

	protected int getVisualIndexAt(int actualIndex) {
	}
}
