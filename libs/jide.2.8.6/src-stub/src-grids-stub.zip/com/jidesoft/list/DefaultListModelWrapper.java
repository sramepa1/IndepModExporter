/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  The default implementation of ListModelWrapper.
 */
public class DefaultListModelWrapper extends javax.swing.AbstractListModel implements ListModelWrapper, javax.swing.event.ListDataListener {
 {

	protected javax.swing.ListModel _model;

	protected int[] _indexes;

	protected transient int[] _adjustingIndexes;

	public DefaultListModelWrapper() {
	}

	/**
	 *  Creates a DefaultListModelWrapper from any list model.
	 * 
	 *  @param model the wrapped list model
	 */
	public DefaultListModelWrapper(javax.swing.ListModel model) {
	}

	/**
	 *  Sets the actual list model.
	 * 
	 *  @param model the list model.
	 */
	public void setActualModel(javax.swing.ListModel model) {
	}

	/**
	 *  Gets the actual list model. Since ListModelWrapper is just a wrapper around another list model, this method will
	 *  return you the actual list model.
	 * 
	 *  @return the actual list model.
	 */
	public javax.swing.ListModel getActualModel() {
	}

	/**
	 *  Gets the actual row.
	 * 
	 *  @param row the row on the UI.
	 *  @return the actual row in the actual model. It will throw IllegalArgumentException if the row is out of range.
	 */
	public int getActualIndexAt(int row) {
	}

	/**
	 *  Gets the visual row.
	 * 
	 *  @param actualRow the actual row in actual model.
	 *  @return the row on UI. -1 if cannot find the row.
	 */
	public int getIndexAt(int actualRow) {
	}

	public Object getElementAt(int row) {
	}

	public int getSize() {
	}

	/**
	 *  Resets the index mapping.
	 */
	protected void reallocateIndexes() {
	}

	/**
	 *  Gets the indexes that maps from the visual row index to the actual row index.
	 * 
	 *  @return the indexes.
	 */
	public int[] getIndexes() {
	}

	/**
	 *  Sets the indexes of the row mapping. We exposed this method to allow quick access to the underlying indexes. The
	 *  method won't fire any list data events. So once you change the indexes, you need to fire corresponding list data
	 *  event so that table can update itself.
	 * 
	 *  @param indexes the new indices
	 */
	public void setIndexes(int[] indexes) {
	}

	/**
	 *  Fires the exact events when index changed.
	 * 
	 *  @param oldIndexes the index array before filtering.
	 *  @param newIndexes the index array after filtering.
	 */
	protected void fireEvents(int[] oldIndexes, int[] newIndexes) {
	}

	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}
}
