/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  This is a default implementation for GroupableListModel. It added methods such as {@link #setGroupAt(Object,int)},
 *  {@link #setGroups(Object[])} and {@link #renameGroup(Object,Object)} to allow user to change groups directly.
 */
public class DefaultGroupableListModel extends javax.swing.DefaultListModel implements GroupableListModel {
 {

	/**
	 *  Creates a new instance of DefaultGroupableListModel
	 */
	public DefaultGroupableListModel() {
	}

	/**
	 *  Set the new group for the element at the specified index.
	 * 
	 *  @param index the index of element
	 *  @param group a group to be added
	 */
	public void setGroupAt(Object group, int index) {
	}

	/**
	 *  Set a new array of groups for this <code>DefaultGroupableListModel</code>
	 * 
	 *  @param groups the new array of group objects
	 *  @see #getGroups()
	 */
	@java.lang.SuppressWarnings("unchecked")
	public void setGroups(Object[] groups) {
	}

	/**
	 *  Returns the group close before the element at the specified index.
	 * 
	 *  @param index the index of element
	 *  @return the close before the element at the specified index..
	 */
	public Object getGroupAt(int index) {
	}

	public Object[] getGroups() {
	}

	/**
	 *  Rename a specified group.
	 * 
	 *  @param oldGroup the old group to be changed
	 *  @param newGroup the new group object.
	 */
	public void renameGroup(Object oldGroup, Object newGroup) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the groups of the list model occurs.
	 * 
	 *  @param l the <code>ListGroupChangeListener</code> to be added
	 */
	public void addListGroupChangeListener(ListGroupChangeListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the groups of the list model occurs.
	 * 
	 *  @param l the <code>ListGroupChangeListener</code> to be removed
	 */
	public void removeListGroupChangeListener(ListGroupChangeListener l) {
	}

	/**
	 *  Returns an array of all the list group change listeners registered on this <code>DefaultGroupableListModel</code>.
	 * 
	 *  @return all of this model's <code>ListGroupChangeListener</code>s, or an empty array if no list data listeners
	 *          are currently registered
	 * 
	 *  @see #addListGroupChangeListener
	 *  @see #removeListGroupChangeListener
	 */
	public ListGroupChangeListener[] getListGroupChangeListeners() {
	}

	/**
	 *  <code>AbstractListModel</code> subclasses must call this method <b>after</b> one or more elements are added to
	 *  the model.  The new elements are specified by a closed interval index0, index1 -- the end points are included.
	 *  Note that index0 need not be less than or equal to index1.
	 * 
	 *  @param source the <code>GroupableListModel</code> that changed, typically "this"
	 */
	protected void fireGroupChanged(Object source) {
	}
}
