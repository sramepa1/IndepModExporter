/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  The model class for DualList.
 */
public interface DualListModel extends javax.swing.ListModel {
 {

	/**
	 *  A value for the selectionMode property: the selected items will be removed from
	 *  original list.
	 * 
	 *  @see #setSelectionMode
	 */
	public static final int REMOVE_SELECTION = 0;

	/**
	 *  A value for the selectionMode property: the selected items in the original list will be disabled
	 * 
	 *  @see #setSelectionMode
	 */
	public static final int DISABLE_SELECTION = 1;

	/**
	 *  A value for the selectionMode property: no change to the original list when items are selected.
	 * 
	 *  @see #setSelectionMode
	 */
	public static final int KEEP_SELECTION = 2;

	/**
	 *  Change the selection to be the set union of the current selection
	 *  and the indices between index0 and index1 inclusive.  If this represents
	 *  a change to the current selection, then notify each
	 *  ListSelectionListener. Note that index0 doesn't have to be less
	 *  than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 *  @see #addListSelectionListener
	 */
	public void addSelectionInterval(int index0, int index1);

	/**
	 *  Change the selection to be the set difference of the current selection
	 *  and the indices between index0 and index1 inclusive.  If this represents
	 *  a change to the current selection, then notify each
	 *  ListSelectionListener.  Note that index0 doesn't have to be less
	 *  than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 *  @see #addListSelectionListener
	 */
	public void removeSelectionInterval(int index0, int index1);

	/**
	 *  Returns true if the specified index is selected.
	 * 
	 *  @param index the specified index
	 *  @return true if the specified index is selected.
	 */
	public boolean isSelectedIndex(int index);

	/**
	 *  Returns all selected indices in order.
	 *  Note that the return value may have duplicated indices
	 * 
	 *  @return all selected indices in order
	 */
	public int[] getSelectedIndices();

	/**
	 *  Moves all indices of an interval to a new index.
	 *  note this index is relative to the selected index, not in the original list model.
	 * 
	 *  @param index0   one end of the interval.
	 *  @param index1   other end of the interval
	 *  @param newIndex new index
	 *  @param before   true if moving the indices before the new index
	 */
	public void moveSelection(int index0, int index1, int newIndex, boolean before);

	/**
	 *  Change the selection to the empty set.  If this represents
	 *  a change to the current selection then notify each ListSelectionListener.
	 * 
	 *  @see #addListSelectionListener
	 */
	public void clearSelection();

	/**
	 *  Returns true if no indices are selected.
	 * 
	 *  @return true if no indices are selected.
	 */
	public boolean isSelectionEmpty();

	/**
	 *  Select all elements that exist in original list.
	 */
	public void selectAll();

	/**
	 *  This property is true if upcoming changes to the value
	 *  of the model should be considered a single event. For example
	 *  if the model is being updated in response to a user drag,
	 *  the value of the valueIsAdjusting property will be set to true
	 *  when the drag is initiated and be set to false when
	 *  the drag is finished.  This property allows listeners to
	 *  to update only when a change has been finalized, rather
	 *  than always handling all of the intermediate values.
	 * 
	 *  @param valueIsAdjusting The new value of the property.
	 *  @see #getValueIsAdjusting
	 */
	public void setValueIsAdjusting(boolean valueIsAdjusting);

	/**
	 *  Returns true if the value is undergoing a series of changes.
	 * 
	 *  @return true if the value is currently adjusting
	 *  @see #setValueIsAdjusting
	 */
	public boolean getValueIsAdjusting();

	/**
	 *  Set the selection mode. The following selectionMode values are allowed:
	 *  <ul>
	 *  <li> <code>REMOVE_SELECTION</code> the selected items will be removed from
	 *  original list.
	 *  <li> <code>DISABLE_SELECTION</code> the selected items in the original list
	 *  will be disabled
	 *  <li> <code>KEEP_SELECTION</code> no affection to the original list
	 *  </ul>
	 * 
	 *  @param selectionMode the selection mode
	 *  @see #getSelectionMode
	 */
	public void setSelectionMode(int selectionMode);

	/**
	 *  Returns the current selection mode.
	 * 
	 *  @return The value of the selectionMode property.
	 *  @see #setSelectionMode
	 */
	public int getSelectionMode();

	/**
	 *  Add a listener to the list that's notified each time a change
	 *  to the selection occurs.
	 * 
	 *  @param x the ListSelectionListener
	 *  @see #removeListSelectionListener
	 *  @see #addSelectionInterval
	 *  @see #removeSelectionInterval
	 *  @see #clearSelection
	 */
	public void addListSelectionListener(javax.swing.event.ListSelectionListener x);

	/**
	 *  Remove a listener from the list that's notified each time a
	 *  change to the selection occurs.
	 * 
	 *  @param x the ListSelectionListener
	 *  @see #addListSelectionListener
	 */
	public void removeListSelectionListener(javax.swing.event.ListSelectionListener x);

	/**
	 *  Add a PropertyChangeListener to the listener list.
	 *  The listener is registered for all properties.
	 *  The same listener object may be added more than once, and will be called
	 *  as many times as it is added.
	 *  If <code>listener</code> is null, no exception is thrown and no action
	 *  is taken.
	 * 
	 *  @param x The PropertyChangeListener to be added
	 */
	public void addPropertyChangeListener(java.beans.PropertyChangeListener x);

	/**
	 *  Remove a PropertyChangeListener from the listener list.
	 *  This removes a PropertyChangeListener that was registered
	 *  for all properties.
	 *  If <code>listener</code> was added more than once to the same event
	 *  source, it will be notified one less time after being removed.
	 *  If <code>listener</code> is null, or was never added, no exception is
	 *  thrown and no action is taken.
	 * 
	 *  @param x The PropertyChangeListener to be removed
	 */
	public void removePropertyChangeListener(java.beans.PropertyChangeListener x);
}
