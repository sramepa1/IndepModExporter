/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  A helper class to contain icons for JIDE Grids product.
 */
public class ListIconsFactory {

	public ListIconsFactory() {
	}

	public static javax.swing.ImageIcon getImageIcon(String name) {
	}

	public static void main(String[] argv) {
	}

	public static class ListSelectionPane {


		public static final String MOVE_LEFT = "icons/moveLeft.png";

		public static final String MOVE_LEFT_DISABLED = "icons/moveLeft_disabled.png";

		public static final String MOVE_ALL_LEFT = "icons/moveAllLeft.png";

		public static final String MOVE_ALL_LEFT_DISABLED = "icons/moveAllLeft_disabled.png";

		public static final String MOVE_RIGHT = "icons/moveRight.png";

		public static final String MOVE_RIGHT_DISABLED = "icons/moveRight_disabled.png";

		public static final String MOVE_ALL_RIGHT = "icons/moveAllRight.png";

		public static final String MOVE_ALL_RIGHT_DISABLED = "icons/moveAllRight_disabled.png";

		public static final String MOVE_UP = "icons/moveUp.png";

		public static final String MOVE_UP_DISABLED = "icons/moveUp_disabled.png";

		public static final String MOVE_DOWN = "icons/moveDown.png";

		public static final String MOVE_DOWN_DISABLED = "icons/moveDown_disabled.png";

		public static final String MOVE_TO_TOP = "icons/moveToTop.png";

		public static final String MOVE_TO_TOP_DISABLED = "icons/moveToTop_disabled.png";

		public static final String MOVE_TO_BOTTOM = "icons/moveToBottom.png";

		public static final String MOVE_TO_BOTTOM_DISABLED = "icons/moveToBottom_disabled.png";

		public ListIconsFactory.ListSelectionPane() {
		}
	}
}
