/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>GroupableListModel</code> is the model used by <code>GroupList</code>. It extends <code>ListModel</code> by
 *  adding group information to each row. With the information provided by this interface, <code>GroupList</code> knows
 *  how to display the rows in groups.
 *  <p/>
 *  Please note, rows of the same group don't have to be adjacent.
 */
public interface GroupableListModel extends javax.swing.ListModel {
 {

	/**
	 *  Returns the group of the element at the specified index. Note that the order of groups is controlled by first
	 *  getGroups() then getGroupAt(int).
	 * 
	 *  @param index the index of element
	 *  @return the group for the specified index.
	 *  @see #getGroups()
	 */
	public Object getGroupAt(int index);

	/**
	 *  Returns all groups, which control the order of appearance. Besides, if getGroupAt(int) returns a value that
	 *  doesn't exist in the groups, the value will be arranged after the array.
	 * 
	 *  @return an array of groups in the order of appearance.
	 *  @see #getGroupAt(int)
	 */
	public Object[] getGroups();

	/**
	 *  Adds a listener to the list which s notified each time a change to the group information occurs.
	 * 
	 *  @param listener the <code>ListGroupChangeListener</code> to be added
	 */
	public void addListGroupChangeListener(ListGroupChangeListener listener);

	/**
	 *  Removes a listener from the list which is notified each time a change to the group information occurs.
	 * 
	 *  @param listener the <code>ListGroupChangeListener</code> to be removed
	 */
	public void removeListGroupChangeListener(ListGroupChangeListener listener);
}
