/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>GroupList</code> is JList that supports the grouping of items. Each group row has a special cell renderer which
 *  is different from the regular cell renderer. You can decide through an interface called
 *  <code>GroupableListModel</code> to decide which rows are included under which group.
 *  <p/>
 *  The group rows can have their own cell renderer which can be set by {@link #setGroupCellRenderer(javax.swing.ListCellRenderer)}.
 *  Typically, user doesn't want to select the group rows. But if they do want, you can call {@link
 *  #setGroupCellSelectable(boolean)} and set it true.
 */
public class GroupList extends javax.swing.JList {

	/**
	 *  Indicates the default layout: one row for each group.
	 * 
	 *  @see #setLayoutOrientation
	 */
	public static final int HORIZONTAL = 3;

	/**
	 *  Holds value of property headersSelectable.
	 */
	protected boolean _groupCellSelectable;

	/**
	 *  Constructs a <code>GroupList</code> with an empty model.
	 */
	public GroupList() {
	}

	/**
	 *  Constructs a <code>GroupList</code> that displays the elements in the specified, non-<code>null</code>
	 *  <code>ListModel</code>. All <code>GroupList</code> constructors delegate to this one.
	 * 
	 *  @param dataModel the data model for this list
	 *  @throws IllegalArgumentException if <code>dataModel</code> is <code>null</code>
	 */
	public GroupList(javax.swing.ListModel dataModel) {
	}

	/**
	 *  Constructs a <code>GroupList</code> that displays the elements in the specified array.  This constructor just
	 *  delegates to the <code>ListModel</code> constructor.
	 * 
	 *  @param listData the array of Objects to be loaded into the data model
	 */
	public GroupList(Object[] listData) {
	}

	/**
	 *  Constructs a <code>GroupList</code> that displays the elements in the specified <code>List</code>.  This
	 *  constructor just delegates to the <code>ListModel</code> constructor.
	 * 
	 *  @param listData the <code>List</code> to be loaded into the data model
	 */
	public GroupList(java.util.List listData) {
	}

	/**
	 *  Constructs a <code>GroupList</code> that displays the elements in the specified, non-<code>null</code>
	 *  <code>GroupListModel</code>. All <code>GroupList</code> constructors delegate to this one.
	 * 
	 *  @param dataModel the data model for this list
	 *  @throws IllegalArgumentException if <code>dataModel</code> is <code>null</code>
	 */
	public GroupList(GroupListModel dataModel) {
	}

	/**
	 *  Constructs a <code>GroupList</code> that displays the elements in the specified, non-<code>null</code>
	 *  <code>GroupableListModel</code>. All <code>GroupList</code> constructors delegate to this one.
	 * 
	 *  @param dataModel the data model for this list
	 *  @throws IllegalArgumentException if <code>dataModel</code> is <code>null</code>
	 */
	public GroupList(GroupableListModel dataModel) {
	}

	/**
	 *  Creates a GroupList.
	 * 
	 *  @param map a map from the group object to the elements belong to this group. The elements can be any Collection
	 *             type or an array.
	 */
	public GroupList(java.util.Map map) {
	}

	/**
	 *  Notification from the <code>UIManager</code> that the look and feel has changed. Replaces the current UI object
	 *  with the latest version from the <code>UIManager</code>.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns a string that specifies the name of the l&f class that renders this component.
	 * 
	 *  @return String "GroupListUI"
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  Returns a <code>GroupableListModel</code> wrapping the specified object. If the object is:<ul> <li>an array of
	 *  <code>Object</code>s, <li>a <code>Map</code>, or <li>a <code>List</code> </ul>then a new root node is created
	 *  with each of the incoming objects as children. Otherwise, a new root is created with the specified object as its
	 *  value.
	 * 
	 *  @param map the <code>Object</code> used as the foundation for the <code>GroupableListModel</code>
	 *  @return a <code>GroupableListModel</code> wrapping the specified object
	 */
	@java.lang.SuppressWarnings("unchecked")
	protected static GroupableListModel createModel(java.util.Map map) {
	}

	/**
	 *  Overrides to wrap the model into GroupableListModel if the model itself is not GroupableListModel.
	 * 
	 *  @param model the <code>ListModel</code> that provides the list of items for display
	 *  @throws IllegalArgumentException if <code>model</code> is <code>null</code>
	 *  @see #getModel
	 */
	@java.lang.Override
	public void setModel(javax.swing.ListModel model) {
	}

	/**
	 *  Returns the data model that holds the list of items displayed by the <code>GroupList</code> component.
	 * 
	 *  @return the <code>GroupListModel</code> that provides the displayed list of items
	 * 
	 *  @see #setModel
	 */
	@java.lang.Override
	public GroupListModel getModel() {
	}

	/**
	 *  Returns true if the group rows are selectable, false otherwise.
	 * 
	 *  @return Value of property headersSelectable.
	 */
	public boolean isGroupCellSelectable() {
	}

	/**
	 *  Set a new value which represents whether group rows are selectable for this <code>GroupList</code>.
	 * 
	 *  @param groupCellSelectable New value of property headersSelectable.
	 */
	public void setGroupCellSelectable(boolean groupCellSelectable) {
	}

	/**
	 *  Returns the preferred number of columns.
	 * 
	 *  @return an integer indicating the preferred number of columns to display without using a scroll bar
	 * 
	 *  @see #setPreferredColumnCount(int)
	 */
	public int getPreferredColumnCount() {
	}

	/**
	 *  Sets the preferred number of columns in the list that can be displayed without a scrollbar, as determined by the
	 *  nearest <code>JViewport</code> ancestor, if any. The value of this property only affects the value of the
	 *  <code>JList</code>'s <code>preferredScrollableViewportSize</code>.
	 *  <p/>
	 *  The default value of this property is 8.
	 * 
	 *  @param preferredColumnCount an integer specifying the preferred number of visible columns
	 */
	public void setPreferredColumnCount(int preferredColumnCount) {
	}

	/**
	 *  Returns the number of rows. In vertical mode, it will be the same as the model size. But in other modes, it could
	 *  be different.
	 * 
	 *  @return an integer indicating the number of rows to be displayed.
	 */
	public int getRowCount() {
	}

	/**
	 *  Returns the amount of cells in the specified row. It should return 1 for vertical mode but for other modes, it
	 *  could return another value.
	 * 
	 *  @param rowIndex int
	 *  @return the amount of elements in the specified row
	 */
	public int getColumnCount(int rowIndex) {
	}

	/**
	 *  Returns the object that renders the list headers.
	 * 
	 *  @return the <code>ListCellRenderer</code> which renders the list headers.
	 * 
	 *  @see #setGroupCellRenderer(ListCellRenderer)
	 *  @see #getCellRenderer()
	 */
	public javax.swing.ListCellRenderer getGroupCellRenderer() {
	}

	/**
	 *  Sets the cell renderer for the group cells
	 * 
	 *  @param cellRenderer the <code>ListCellRenderer</code> that paints group cells
	 *  @see #getGroupCellRenderer()
	 *  @see #setCellRenderer(ListCellRenderer)
	 */
	public void setGroupCellRenderer(javax.swing.ListCellRenderer cellRenderer) {
	}

	/**
	 *  Override the method in JList to support a new orientation called {@link #HORIZONTAL}. {@link #HORIZONTAL} is
	 *  almost the same as {@link #HORIZONTAL_WRAP} except it will not wrap. It probably doesn't make too much sense in
	 *  the normal JList. But in GroupList, it makes sense as it means all items under the same group will not wrap
	 *  horizontally.
	 * 
	 *  @param layoutOrientation new layoutOrientation.
	 */
	@java.lang.Override
	public void setLayoutOrientation(int layoutOrientation) {
	}

	/**
	 *  Returns the layout orientation property for the list: {@link #VERTICAL} if the layout is a single column of
	 *  cells, {@link #VERTICAL_WRAP} if the layout is "newspaper style" with the content flowing vertically then
	 *  horizontally, or {@link #HORIZONTAL_WRAP} if the layout is "newspaper style" with the content flowing
	 *  horizontally then vertically. GroupList also added one more layout orientation called {@link #HORIZONTAL}. It
	 *  basically arrange all cell under the same group into one row.
	 * 
	 *  @return the value of the {@code layoutOrientation} property
	 * 
	 *  @see #setLayoutOrientation
	 */
	@java.lang.Override
	public int getLayoutOrientation() {
	}

	/**
	 *  Gets the group rows indices.
	 * 
	 *  @return the group rows indices.
	 */
	public int[] getGroupCellIndices() {
	}

	/**
	 *  Overrides the method in JList to provide tooltips for group rows through the group cell renderer.
	 */
	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}
}
