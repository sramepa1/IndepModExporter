/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  SortableListModel is a list model wrapper which can do the sorting. Given any existing list model, you can wrap it
 *  into <code>SortableListModel</code> and use it later on any JList.
 *  <p/>
 *  <pre><code>
 *  SortableListModel sortableListModel = new SortableListModel(listModel);
 *  JList sortableList = new JList(sortableListModel);
 *  </code></pre>
 *  To sort the list, you just call
 *  <pre><code>
 *  sortableListModel.sort(); // or sort(SortableListModel.SORT_DESCENDING) to sort descending.
 *  </code></pre>
 */
public class SortableListModel extends DefaultListModelWrapper {

	public static final int SORT_ASCENDING = 1;

	public static final int SORT_DESCENDING = -1;

	public static final int UNSORTED = 0;

	protected javax.swing.event.EventListenerList listenerList;

	public SortableListModel() {
	}

	/**
	 *  Creates a SortableListModel from any list model.
	 * 
	 *  @param model the actual list model
	 */
	public SortableListModel(javax.swing.ListModel model) {
	}

	@java.lang.Override
	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}

	/**
	 *  Gets the row index range that will be sorted. It will be a one dimension int array with the first value to be the
	 *  low row index of the range and the second value to be the high row index of the range. The low row index is
	 *  included in the range and the hig row index is not included in the range. By default, we will return new int[]{0,
	 *  _indexes.length} which is from the first row to the last row, the whole range. If your last row is a summary row
	 *  so you don't want it to be sorted, you can return new int[]{0, _indexes.length - 1}. Or if you want the row at
	 *  index 3 to always stay there, you can return new int[]{0, 3, 4, _indexes.length}.
	 * 
	 *  @return the sort ranges.
	 */
	protected int[] getSortRanges() {
	}

	/**
	 *  Searches the specified array of rows for the specified value using binary search. The array <strong>must</strong>
	 *  be sorted prior to making this call.  If it is not sorted, the results are undefined.  If the array contains
	 *  multiple elements with the specified value, there is no guarantee which one will be found. <br> Subclass can
	 *  override this method to implement their own algorithm to do the search. When doing comparison in the algorithm,
	 *  use the compare(int, int) method defined in this class. The original indexes are sorted in a way that
	 *  compare(indexes[n], indexes[n + 1]) will always return 1 or 0. So if you compare(indexes[n], row) and it returns
	 *  -1, you knows the row index should be greater than n.
	 * 
	 *  @param indexes the array of row to be searched.
	 *  @param row     the index of the row to be searched for.
	 *  @return index of the search key, if it is contained in the list; otherwise, <tt>(-(<i>insertion point</i>) -
	 *          1)</tt>.  The <i>insertion point</i> is defined as the point at which the key would be inserted into the
	 *          list: the index of the first element greater than the key, or <tt>list.size()</tt>, if all elements in
	 *          the list are less than the specified key.  Note that this guarantees that the return value will be &gt;=
	 *          0 if and only if the key is found.
	 */
	protected int search(int[] indexes, int row) {
	}

	/**
	 *  Sorts the rows.
	 *  <p/>
	 *  Subclass can override this method to implement their own algorithm to sort. When doing comparison in the
	 *  algorithm, use the compare(int, int) method defined in this class.
	 * 
	 *  @param from an int array of row indices to be sorted
	 *  @param to   an int array of row indices to store the result after sorting
	 *  @param low  the start index of the row in the array to be sorted
	 *  @param high the end index of the row in the array to be sorted
	 */
	protected void sort(int[] from, int[] to, int low, int high) {
	}

	/**
	 *  Compares two rows to decide the order. It will consider the ascending or descending and return different value so
	 *  the return has different meaning comparing to that of Comparator.compare(o1, o2). <br>If it returns 1, it means
	 *  keep the current order. If it returns -1, it means the order should be swapped. If it returns 0, it means the
	 *  order doesn't matter. It could be either the table model is not sorted so the order doesn't matter or the two
	 *  rows have the same order.
	 *  <p/>
	 *  Subclass can override this method to provide their own way to compare the two rows. Please make sure you access
	 *  the element using <code>getActualModel().getElement(rowIndex)</code> since SortableListModel is also a
	 *  ListModelWrapper.
	 * 
	 *  @param row1 index of the first row to be compared
	 *  @param row2 index of the second row to be compared
	 *  @return If it returns 1, it means keep the current order. If it returns -1, it means the order should be swapped.
	 *          If it returns 0, it means the order doesn't matter. It could be either the table model is not sorted so
	 *          the order doesn't matter or the two rows have the same order.
	 */
	protected int compare(int row1, int row2) {
	}

	/**
	 *  Compares its two arguments for order. Returns a negative integer, zero, or a positive integer as the first
	 *  argument is less than, equal to, or greater than the second. By default, we will use Comparator to do the
	 *  comparison. Subclass can override it to provide your own way to compare.
	 * 
	 *  @param o1 the first object to be compared
	 *  @param o2 the second object to be compared
	 *  @return a negative integer, zero, or a positive integer as the first argument is less than, equal to, or greater
	 *          than the second.
	 */
	protected int compare(Object o1, Object o2) {
	}

	/**
	 *  Gets the comparator.
	 * 
	 *  @return the comparator that will be used to compare the values.
	 */
	public java.util.Comparator getComparator() {
	}

	/**
	 *  Sets the comparator. If you never set it, SortableTableModel will look up for a comparator from
	 *  ObjectComparatorManager based on the class of the value to be compared and the value returned from
	 *  getComparatorContext.
	 * 
	 *  @param comparator the comparator
	 */
	public void setComparator(java.util.Comparator comparator) {
	}

	/**
	 *  Gets the comparator context. Comparator context along with the type of the element in the list will uniquely find
	 *  a comparator on {@link ObjectComparatorManager}. In most cases, comparator context is null. Only if the type is
	 *  the same but you want to compare differently, you can use comparator context to break the tie.
	 * 
	 *  @return the comparator context. Default value is null.
	 */
	public ComparatorContext getComparatorContext() {
	}

	/**
	 *  Sets the comparator context. Comparator context along with the type of the element in the list will uniquely find
	 *  a comparator on {@link ObjectComparatorManager}.
	 * 
	 *  @param comparatorContext the comparator context
	 */
	public void setComparatorContext(ComparatorContext comparatorContext) {
	}

	/**
	 *  Gets the sort order.
	 * 
	 *  @return the sort order. The value could be {@link #UNSORTED}, {@link #SORT_DESCENDING}, or {@link
	 *          #SORT_ASCENDING}.
	 */
	public int getSortOrder() {
	}

	/**
	 *  Sets the sort order.
	 * 
	 *  @param sortOrder the new sort order. The value could be {@link #UNSORTED}, {@link #SORT_DESCENDING}, or {@link
	 *                   #SORT_ASCENDING}.
	 */
	public void setSortOrder(int sortOrder) {
	}

	/**
	 *  Sort the list model ascending.
	 */
	public void sort() {
	}

	/**
	 *  Sort the list model. The order could be either {@link #SORT_ASCENDING} or {@link #SORT_DESCENDING}. You can also
	 *  pass in {@link #UNSORTED}, which will be the same as {@link #unsort()}.
	 * 
	 *  @param order the new sort order.
	 */
	public void sort(int order) {
	}

	/**
	 *  Unsorts the list model.
	 */
	public void unsort() {
	}

	/**
	 *  Resets. It's the same as {@link #unsort()}.
	 */
	public void reset() {
	}

	/**
	 *  Overrides the method in DefaultListModelWrapper to clear up any sort order.
	 * 
	 *  @param indexes the indexes
	 */
	@java.lang.Override
	public void setIndexes(int[] indexes) {
	}

	/**
	 *  Gets the sortable table model. If model is a ListModelWrapper, it will get the actual model until it finds the
	 *  first sortable table model.
	 * 
	 *  @param model the outer list model
	 *  @return sortable list model.
	 */
	public static SortableListModel getSortableListModel(javax.swing.ListModel model) {
	}

	/**
	 *  Checks if the sortable table model is in optimized mode.
	 * 
	 *  @return the optimizedd flag.
	 */
	public boolean isOptimized() {
	}

	/**
	 *  If optimized flag is true and the table is already sorted, SortableListModel will do incremental sorting when
	 *  data is only partially changed. If the flag is false, SortableListModel will resort completely whenever data
	 *  changed. <br>Default is false. The performance will be not as good but it's more stable. If you want to change
	 *  the flag to true, you need to make sure the underlying table model fires correct event when data changes.
	 * 
	 *  @param optimized the flag
	 */
	public void setOptimized(boolean optimized) {
	}

	/**
	 *  Checks if the table is automatically resorted when data changes.
	 * 
	 *  @return true if autoResort. Otherwise false.
	 */
	public boolean isAutoResort() {
	}

	/**
	 *  AutoResort is a feature that automatically resort the table when table data changes. This is the default behavior
	 *  and useful in most cases. However there are cases when the data changes frequently, resort will make it very hard
	 *  for user to read the value. So in these cases, you can set autoResort to false. Then you will need to provide a
	 *  button to call {@link #resort} to resort the table.
	 *  <p/>
	 *  Note: this flag is only used when optimized flag is true. If optimized is false, autoResort is always true.
	 * 
	 *  @param autoResort the flag
	 */
	public void setAutoResort(boolean autoResort) {
	}

	/**
	 *  Resort the table. When autoResort is false, the table will be out of order after data changes. The method will
	 *  resort the table while keeping the sorting columns.
	 */
	public void resort() {
	}

	/**
	 *  Adds the specified listener to receive collapsible pane events from this collapsible frame.
	 * 
	 *  @param l the collapsible pane listener
	 */
	public void addSortListener(com.jidesoft.grid.SortListener l) {
	}

	/**
	 *  Removes the specified collapsible pane listener so that it no longer receives collapsible pane events from this
	 *  collapsible pane .
	 * 
	 *  @param l the collapsible pane listener
	 */
	public void removeSortListener(com.jidesoft.grid.SortListener l) {
	}

	/**
	 *  Returns an array of all the <code>SortListener</code>s added to this <code>CollapsiblePane</code> with
	 *  <code>addSortListener</code>.
	 * 
	 *  @return all of the <code>SortListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addSortListener
	 *  @since 1.4
	 */
	public com.jidesoft.grid.SortListener[] getSortListeners() {
	}

	/**
	 *  Fires an collapsible pane event.
	 */
	public void fireSortEvent() {
	}

	/**
	 *  Checks if the alwaysUseComparators flag value.
	 * 
	 *  @return true if alwaysUseComparators is true. Otherwise false.
	 */
	public boolean isAlwaysUseComparators() {
	}

	/**
	 *  Sets the alwaysUseComparators flag. By default, we will check if the two values are Comparable. If they both are,
	 *  we will use {@link Comparable#compareTo(Object)} to compare. This is the default preferred way because this gives
	 *  developer a finer control of the comparison result.
	 * 
	 *  @param alwaysUseComparators true or false.
	 */
	public void setAlwaysUseComparators(boolean alwaysUseComparators) {
	}
}
