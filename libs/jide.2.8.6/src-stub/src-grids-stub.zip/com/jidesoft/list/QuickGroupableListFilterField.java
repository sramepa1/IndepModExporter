/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


public class QuickGroupableListFilterField extends QuickListFilterField {

	public QuickGroupableListFilterField() {
	}

	public QuickGroupableListFilterField(javax.swing.ListModel listModel) {
	}

	@java.lang.Override
	protected FilterableGroupableListModel createDisplayListModel(javax.swing.ListModel model) {
	}
}
