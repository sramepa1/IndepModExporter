/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  An enhanced interface of <code>ListModel</code>.
 *  <p/>
 *  In fact, only one of all the methods below is useful. It is isGroupRow, because any methods else
 *  is dependent on isGroupRow(int) .
 */
public interface GroupListModel extends javax.swing.ListModel {
 {

	/**
	 *  Returns the group row index where the group has the specified row.
	 * 
	 *  @param row the row index.
	 *  @return the group row index where the group has the specified row
	 */
	public int getGroupRowIndex(int row);

	/**
	 *  Returns the next group row index where the previous group has the specified row, if any.
	 * 
	 *  @param row the row index.
	 *  @return the next group row index where the previous group has the specified row
	 */
	public int getNextGroupRowIndex(int row);

	/**
	 *  Returns true if the specified row is a group row, false otherwise.
	 * 
	 *  @param row the row index.
	 *  @return true if the specified row is a group row, false otherwise.
	 */
	public boolean isGroupRow(int row);

	/**
	 *  Returns all group cell indices
	 *  @return all group cell indices
	 */
	public int[] getGroupCellIndices();
}
