/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  Default implementation of PreviewImageIcon.
 */
public class DefaultPreviewImageIcon implements ImagePreviewList.PreviewImageIcon {
 {

	public DefaultPreviewImageIcon(javax.swing.ImageIcon icon) {
	}

	public DefaultPreviewImageIcon(javax.swing.ImageIcon icon, String title) {
	}

	public DefaultPreviewImageIcon(javax.swing.ImageIcon icon, java.awt.Dimension size) {
	}

	public DefaultPreviewImageIcon(javax.swing.ImageIcon icon, String title, java.awt.Dimension size) {
	}

	public DefaultPreviewImageIcon(javax.swing.ImageIcon icon, String title, String description) {
	}

	public DefaultPreviewImageIcon(javax.swing.ImageIcon icon, String title, String description, java.awt.Dimension size) {
	}

	public javax.swing.ImageIcon getImageIcon() {
	}

	public void setIcon(javax.swing.ImageIcon icon) {
	}

	public String getTitle() {
	}

	public void setTitle(String title) {
	}

	public java.awt.Dimension getSize() {
	}

	public void setSize(java.awt.Dimension size) {
	}

	public String getDescription() {
	}

	public void setDescription(String description) {
	}
}
