/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>AbstractListFilter</code> is a special <code>Filter</code> for ListModel. It has row index. When you implement
 *  {@link #isValueFiltered(Object)}, you can call {@link #getRowIndex()} to find out which row the value comes from. You
 *  should only use this filter with <code>FilterableListModel</code> which will fill the row and column index..
 *  <p/>
 *  Please note, this class extends com.jidesoft.grid.AbstractFilter for backward compatible reason. It will change to
 *  extend com.jidesoft.filter.AbstractFilter after a few releases.
 */
public abstract class AbstractListFilter extends com.jidesoft.grid.AbstractFilter implements ListFilter {
 {

	protected AbstractListFilter() {
	}

	protected AbstractListFilter(String name) {
	}

	public int getRowIndex() {
	}

	public void setRowIndex(int rowIndex) {
	}
}
