/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


public class SortableGroupableListModel extends SortableListModel implements GroupableListModel, ListGroupChangeListener {
 {

	public SortableGroupableListModel() {
	}

	/**
	 *  Creates a SortableGroupableListModel from any list model.
	 * 
	 *  @param model
	 */
	public SortableGroupableListModel(javax.swing.ListModel model) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void setActualModel(javax.swing.ListModel model) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void setSortOrder(int sortOrder) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void unsort() {
	}

	public Object getGroupAt(int index) {
	}

	public Object[] getGroups() {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change
	 *  to the data model occurs.
	 * 
	 *  @param l the <code>ListGroupChangeListener</code> to be added
	 */
	public void addListGroupChangeListener(ListGroupChangeListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a
	 *  change to the data model occurs.
	 * 
	 *  @param l the <code>ListGroupChangeListener</code> to be removed
	 */
	public void removeListGroupChangeListener(ListGroupChangeListener l) {
	}

	/**
	 *  Returns an array of all the list group change listeners
	 *  registered on this <code>DefaultGroupableListModel</code>.
	 * 
	 *  @return all of this model's <code>ListGroupChangeListener</code>s,
	 *          or an empty array if no list data listeners
	 *          are currently registered
	 *  @see #addListGroupChangeListener
	 *  @see #removeListGroupChangeListener
	 */
	public ListGroupChangeListener[] getListGroupChangeListeners() {
	}

	/**
	 *  <code>AbstractListModel</code> subclasses must call this method
	 *  <b>after</b> the group for any of the item is changed.
	 * 
	 *  @param source the <code>ListModel</code> that changed, typically "this"
	 */
	protected void fireGroupChanged(Object source) {
	}

	public void groupChanged(ListGroupChangeEvent e) {
	}
}
