/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is the same date as
 *  today's date.
 */
public class TodayFilter extends DateOrCalendarFilter {

	public TodayFilter() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the class of the two filters are same or the input Filter is ThisWeekFilter or ThisMonthFilter or
	 *          ThisQuarterFilter or ThisYearFilter. Otherwise false.
	 */
	public boolean stricterThan(Filter inputFilter) {
	}
}
