/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A filter implements filtering a string based the regular expression as defined in Java {@link Pattern} class.
 */
public class RegexFilter extends AbstractFilter {

	protected java.util.regex.Pattern _regex;

	protected boolean _beginWith;

	public RegexFilter() {
	}

	public RegexFilter(String pattern) {
	}

	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Converts an element to String. By default we will use ObjectConverterManager.toString(value) to convert.
	 * 
	 *  @param value the element to be filtered.
	 *  @return the String version of the value.
	 */
	protected String convertElementToString(Object value) {
	}

	/**
	 *  Converts the input pattern to the pattern used in Java Pattern class.
	 * 
	 *  @param pattern the input pattern.
	 *  @return the pattern string used by {@link java.util.regex.Pattern}.
	 */
	protected String convertFromPatternToRegex(String pattern) {
	}

	/**
	 *  Sets the pattern.
	 * 
	 *  @param pattern the new pattern.
	 *  @see Pattern
	 */
	public void setPattern(String pattern) {
	}

	/**
	 *  Gets the pattern string.
	 * 
	 *  @return the pattern string.
	 */
	public String getPattern() {
	}

	/**
	 *  Checks if the filter is case sensitive.
	 * 
	 *  @return true if case sensitive. Otherwise false.
	 */
	public boolean isCaseSensitive() {
	}

	/**
	 *  Sets the case sensitive.
	 * 
	 *  @param caseSensitive true or false.
	 */
	public void setCaseSensitive(boolean caseSensitive) {
	}

	/**
	 *  Checks if the filter only matches the pattern from the beginning of the string.
	 * 
	 *  @return true or false.
	 */
	public boolean isBeginWith() {
	}

	/**
	 *  Sets the begingWidth flag. If true, the filter will match the pattern from the beginning of the string. Note that
	 *  if both begingWith and endWith flag are true, it means "match exactly". If both flags are false, it means "match
	 *  anywhere".
	 * 
	 *  @param beginWith true or false.
	 */
	public void setBeginWith(boolean beginWith) {
	}

	/**
	 *  Checks if the filter only matches the pattern from the end of the string.
	 * 
	 *  @return true or false.
	 */
	public boolean isEndWith() {
	}

	/**
	 *  Sets the endWith flag. If true, the filter will match the pattern from the end of the string.
	 * 
	 *  @param endWith true or false.
	 */
	public void setEndWith(boolean endWith) {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 *  <p/>
	 *  Since we don't have a good algorithm to parse the regular expression, so far we just take it as a normal String.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the pattern string in this filter contains the patter string in the input filter. Otherwise
	 *          false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}
}
