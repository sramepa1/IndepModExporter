/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


public class ValueEditor extends javax.swing.JPanel {

	public ValueEditor(Class dataType, ConverterContext converterContext, Object[] possibleValues) {
	}

	public void setDataType(Class dataType, ConverterContext converterContext) {
	}

	protected void initComponents() {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale l) {
	}

	/**
	 *  Customizes the value editor with a component to make it value editing easier. By default, we create a button-only
	 *  DateComboBox and added to the BorderLayout.AFTER_LINE_ENDS of the panel. To make it easier for you to customize,
	 *  here is our default code.
	 *  <code><pre>
	 *   if (dataType.isAssignableFrom(Date.class) || dataType.isAssignableFrom(Calendar.class)) {
	 *        AbstractComboBox button = null;
	 *        button = new DateComboBox() {
	 *            public AbstractButton createButtonComponent() {
	 *                JButton dateButton = new JButton(IconsFactory.getImageIcon(ValueEditor.class, "icons/date.png"));
	 *                dateButton.setMargin(new Insets(3, 3, 3, 3));
	 *                return dateButton;
	 *            }
	 *        };
	 *        button.setButtonOnly(true);
	 *        button.addItemListener(new ItemListener() {
	 *            public void itemStateChanged(ItemEvent e) {
	 *                if (e.getStateChange() == ItemEvent.SELECTED) {
	 *                    Object selectedDate = e.getItem();
	 *                    if (selectedDate instanceof Calendar && dataType.isAssignableFrom(Date.class)) {
	 *                        comboBox.setSelectedItem(((Calendar) selectedDate).getTime());
	 *                    }
	 *                    else if (dataType.isAssignableFrom(Calendar.class)) {
	 *                        comboBox.setSelectedItem(selectedDate);
	 *                    }
	 *                }
	 *            }
	 *        });
	 *        panel.add(button, BorderLayout.AFTER_LINE_ENDS);
	 *   }
	 *  </pre></code>
	 * 
	 *  @param panel    the panel.
	 *  @param dataType the data type.
	 *  @param comboBox the AbstractComboBox. This is either a ListComboBox or a CheckBoxListComboBox.
	 */
	protected void customizeValueEditor(javax.swing.JPanel panel, Class dataType, com.jidesoft.combobox.AbstractComboBox comboBox) {
	}

	public boolean isLabelVisible() {
	}

	public void setLabelVisible(boolean labelVisible) {
	}

	public Object getValue() {
	}

	public void setValue(Object value) {
	}

	public String getValueInString() {
	}

	protected String getResourceString(String key) {
	}
}
