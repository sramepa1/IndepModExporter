/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value not equal to the
 *  specified value.
 */
public class NotEqualFilter extends EqualFilter {

	public NotEqualFilter() {
	}

	public NotEqualFilter(Object value) {
	}

	public NotEqualFilter(String name, Object value) {
	}

	@java.lang.Override
	public boolean isValueFiltered(Object value) {
	}

	@java.lang.Override
	public String getOperator() {
	}
}
