/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is in a collection of
 *  the specified values.
 *  <p/>
 *  Please note, for numbers, as long as the numbers have the same value, they are considered as equal. For example 20.0
 *  == 20 even though they are double and int respectively. In the other word, <code>new InFilter(new
 *  Object[]{20.0}).isValueFilter(20)</code> returns false.
 */
public class InFilter extends AbstractFilter implements SqlFilterSupport {
 {

	/**
	 *  Creates an InFilter.
	 */
	public InFilter() {
	}

	/**
	 *  Creates an InFilter.
	 * 
	 *  @param values the values that will not be filtered
	 */
	public InFilter(Object[] values) {
	}

	/**
	 *  Creates MultipleValuesFilter.
	 * 
	 *  @param name   name of the filter
	 *  @param values the values that will not be filtered
	 */
	public InFilter(String name, Object[] values) {
	}

	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Sets the allowed values.
	 * 
	 *  @param values the allowed values.
	 */
	public void setValues(Object[] values) {
	}

	/**
	 *  Gets the only allowed value.
	 * 
	 *  @return the only allowed value.
	 */
	public Object[] getValues() {
	}

	/**
	 *  Gets the operator. It will return " IN " by default.
	 * 
	 *  @return the operator.
	 */
	public String getOperator() {
	}

	@java.lang.Override
	public String getName() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if all the possible values contained in this filter are also contained in the input filter.
	 *          Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}
}
