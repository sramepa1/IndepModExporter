/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is within the next
 *  week of today's date.
 */
public class NextWeekFilter extends DateOrCalendarFilter {

	public NextWeekFilter() {
	}
}
