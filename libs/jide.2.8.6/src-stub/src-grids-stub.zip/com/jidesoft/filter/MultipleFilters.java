/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  MultipleFilter is an abstract class that has a list of filters. The actual concrete class can extend it to provide
 *  the filter logic such as AND or OR on the list of filters.
 */
public abstract class MultipleFilters extends AbstractFilter {

	public MultipleFilters() {
	}

	public MultipleFilters(Filter[] filters) {
	}

	/**
	 *  Adds a filter.
	 * 
	 *  @param filter a new filter.
	 */
	public void addFilter(Filter filter) {
	}

	/**
	 *  Removes an existing filter.
	 * 
	 *  @param filter a filter to be removed
	 *  @return true if the filter exists and is removed successfully. Otherwise false.
	 */
	public boolean removeFilter(Filter filter) {
	}

	/**
	 *  Gets the list of filters.
	 * 
	 *  @return the list of filters.
	 */
	public java.util.List getFilters() {
	}

	/**
	 *  Sets the filters.
	 * 
	 *  @param filters the new list of filters.
	 */
	public void setFilters(java.util.List filters) {
	}

	/**
	 *  Removes all the existing filters.
	 */
	public void clearFilters() {
	}

	@java.lang.Override
	public Object clone() {
	}
}
