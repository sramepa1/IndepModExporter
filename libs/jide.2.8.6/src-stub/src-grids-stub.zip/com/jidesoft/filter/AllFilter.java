/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> that always returns false in {@link #isValueFiltered(Object)} no matter what the input value
 *  is.
 */
public class AllFilter extends AbstractFilter {

	/**
	 *  Creates a AllFilter.
	 */
	public AllFilter() {
	}

	/**
	 *  Checks if the value is allowed.
	 * 
	 *  @param value the value to check.
	 *  @return always false.
	 */
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Check if this filter is stricter than the input filter. This method always returns false as AllFilter is not
	 *  stricter than or the same strict as any other filters.
	 * 
	 *  @param inputFilter the input filter
	 *  @return always false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}
}
