/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is within the same
 *  quarter of today's date.
 */
public class ThisQuarterFilter extends DateOrCalendarFilter {

	public ThisQuarterFilter() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the class of the two filters are same or the input Filter is ThisYearFilter. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}
}
