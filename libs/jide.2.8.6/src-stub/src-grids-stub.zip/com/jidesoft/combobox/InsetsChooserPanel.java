/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  A popup panel for insets.
 */
public class InsetsChooserPanel extends ButtonPopupPanel {

	public InsetsChooserPanel() {
	}

	public InsetsChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	protected void initComponents() {
	}

	protected javax.swing.JSpinner createSpinner(javax.swing.SpinnerModel model) {
	}

	protected javax.swing.JComponent createPreviewPanel() {
	}

	public java.awt.Insets getSelectedInsets() {
	}

	public void setSelectedInsets(java.awt.Insets insets) {
	}

	@java.lang.Override
	public Object getSelectedObject() {
	}

	@java.lang.Override
	public void setSelectedObject(Object object) {
	}

	@java.lang.Override
	public javax.swing.Action getOkAction() {
	}

	@java.lang.Override
	public javax.swing.Action getCancelAction() {
	}

	public static void main(String[] args) {
	}
}
