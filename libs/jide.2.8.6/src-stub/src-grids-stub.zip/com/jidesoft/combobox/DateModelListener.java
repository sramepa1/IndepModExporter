/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  A listener for DateModel.
 */
public interface DateModelListener extends java.util.EventListener {
 {

	/**
	 *  This notification tells listeners the something changed in date model.
	 * 
	 *  @param e
	 */
	public void dateModelChanged(DateModelEvent e);
}
