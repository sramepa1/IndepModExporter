/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  ColorChooserPanel is a panel that has many color buttons. User can click on one and select the color. It supports
 *  ItemListener. Whenever a color is selected, itemStateChanged will be fired. <br> We support several color sets. From
 *  the 15 basic colors, 40 basic colors and 215 web colors. In additional to color sets, we also support gray scale,
 *  from 16 gray scales, 102 gray scales and 256 gray scales.
 */
public class ColorChooserPanel extends PopupPanel implements java.awt.event.ItemListener {
 {

	/**
	 *  15 color palette. The 15 colors are (255, 255, 0), (0, 255, 0), (0, 255, 255), (255, 0, 255), (0, 0, 255), (255,
	 *  0, 0), (0, 0, 128), (0, 128, 128), (0, 128, 0), (0, 128, 0), (128, 0, 0), (128, 128, 0), (128, 128, 128), (192,
	 *  192, 192), and (0, 0, 0).
	 */
	public static final int PALETTE_COLOR_15 = 0;

	/**
	 *  40 color palette. The 40 colors are (0, 0, 0), (153, 51, 0), (51, 51, 0), (0, 51, 0), (0, 51, 102), (0, 0, 128),
	 *  (51, 51, 153), (51, 51, 51), (128, 0, 0), (255, 102, 0), (128, 128, 0), (0, 128, 0), (0, 128, 128), (0, 0, 255),
	 *  (102, 102, 153), (128, 128, 128), (255, 0, 0), (255, 153, 0), (153, 204, 0), (51, 153, 102), (51, 204, 204), (51,
	 *  102, 255), (128, 0, 128), (153, 153, 153), (255, 0, 255), (255, 204, 0), (255, 255, 0), (0, 255, 0), (0, 255,
	 *  255), (0, 204, 255), (153, 51, 102), (192, 192, 192), (255, 153, 204), (255, 204, 153), (255, 255, 153), (204,
	 *  255, 204), (204, 255, 255), (153, 204, 255), (204, 153, 255), and (255, 255, 255).
	 */
	public static final int PALETTE_COLOR_40 = 1;

	/**
	 *  Standard web-safe 216 color palette.
	 */
	public static final int PALETTE_COLOR_216 = 2;

	/**
	 *  16 gray color palette.
	 */
	public static final int PALETTE_GRAY_16 = 3;

	/**
	 *  102 gray color palette.
	 */
	public static final int PALETTE_GRAY_102 = 4;

	/**
	 *  256 gray color palette.
	 */
	public static final int PALETTE_GRAY_256 = 5;

	/**
	 *  By passing value as palette, you can call setPossibleColors() and setPossibleColorNames() to setup your own
	 *  palette.
	 */
	public static final int PALETTE_CUSTOMIZE = -1;

	/**
	 *  Button for default color.
	 */
	protected javax.swing.AbstractButton _defaultColor;

	/**
	 *  Button for more color.
	 */
	protected javax.swing.AbstractButton _moreColor;

	/**
	 *  JPanel which holds all color buttons.
	 */
	protected javax.swing.JPanel _colorPanel;

	public static final String PROPERTY_SELECTED_COLOR = "selectedColor";

	/**
	 *  Creates a new <code>ColorChooserPanel</code>.
	 */
	public ColorChooserPanel() {
	}

	/**
	 *  Creates a new <code>ColorChooserPanel</code> with specified palette.
	 * 
	 *  @param palette the palette.
	 */
	public ColorChooserPanel(int palette) {
	}

	/**
	 *  Creates a new <code>ColorChooserPanel</code> with the specified palette and button options.
	 * 
	 *  @param palette           color palette
	 *  @param allowMoreColors   if more color button is visible.
	 *  @param allowDefaultColor if default color button is visible.
	 */
	public ColorChooserPanel(int palette, boolean allowMoreColors, boolean allowDefaultColor) {
	}

	/**
	 *  Creates a new <code>ColorChooserPanel</code> with the specified palette and button options.
	 * 
	 *  @param palette           color palette
	 *  @param allowMoreColors   if more color button is visible.
	 *  @param allowDefaultColor if default color button is visible.
	 *  @param locale            the Locale
	 */
	public ColorChooserPanel(int palette, boolean allowMoreColors, boolean allowDefaultColor, java.util.Locale locale) {
	}

	/**
	 *  Creates a new <code>ColorChooserPanel</code> with customized palette.
	 * 
	 *  @param colors            possible colors
	 *  @param names             names of possible colors.
	 *  @param allowMoreColors   if more color button is visible.
	 *  @param allowDefaultColor if default color button is visible.
	 */
	public ColorChooserPanel(java.awt.Color[] colors, String[] names, boolean allowMoreColors, boolean allowDefaultColor) {
	}

	/**
	 *  Creates a new <code>ColorChooserPanel</code> with customized palette.
	 * 
	 *  @param colors            possible colors
	 *  @param names             names of possible colors.
	 *  @param allowMoreColors   if more color button is visible.
	 *  @param allowDefaultColor if default color button is visible.
	 *  @param locale            the Locale
	 */
	public ColorChooserPanel(java.awt.Color[] colors, String[] names, boolean allowMoreColors, boolean allowDefaultColor, java.util.Locale locale) {
	}

	/**
	 *  Creates a new <code>ColorChooserPanel</code> with customized palette. You can also specify how the color buttons
	 *  are laid out by passing in rows and columns. Please note, if either the rows or columns is 0, we will suggest a
	 *  preferred row and column value based on the length of the colors array. Otherwise we will use the row value
	 *  specified in the rows parameter. The value in the columns is ignored because the length of the colors and rows
	 *  are enough to determine the layout of the color labels.
	 *  <p/>
	 *  Please make sure the length of colors and names array should equal with each other and not equal with 0. And
	 *  please make rows no larger than the length of colors. Otherwise, the method will throw illegal argument
	 *  exceptions.
	 * 
	 *  @param colors            the possible colors
	 *  @param names             the names of possible colors.
	 *  @param rows              the number of rows, 0 if you want to use the suggested row value based on the number of
	 *                           the possible colors
	 *  @param columns           the number of columns, 0 if you want to use the suggested column value based on the
	 *                           number of the possible colors
	 *  @param allowMoreColors   if more color button is visible.
	 *  @param allowDefaultColor if default color button is visible.
	 *  @param locale            the Locale
	 */
	public ColorChooserPanel(java.awt.Color[] colors, String[] names, int rows, int columns, boolean allowMoreColors, boolean allowDefaultColor, java.util.Locale locale) {
	}

	@java.lang.Override
	public void updateUI() {
	}

	protected void initColors() {
	}

	protected static java.awt.Color[] getPaletteGrayScale16() {
	}

	protected static java.awt.Color[] getPaletteGrayScale120() {
	}

	protected static java.awt.Color[] getPaletteGrayScale256() {
	}

	/**
	 *  Gets possible colors used by this color chooser panel.
	 * 
	 *  @return possible colors.
	 */
	public java.awt.Color[] getPossibleColors() {
	}

	/**
	 *  Gets possible color names.
	 * 
	 *  @return possible color names
	 */
	public String[] getPossibleColorsName() {
	}

	/**
	 *  Gets the selected color.
	 * 
	 *  @return the selected color.
	 */
	public java.awt.Color getSelectedColor() {
	}

	/**
	 *  Sets the selected color.
	 * 
	 *  @param selectedColor the selected color.
	 */
	public void setSelectedColor(java.awt.Color selectedColor) {
	}

	protected void initComponent() {
	}

	protected javax.swing.AbstractButton createButton(String resourceString) {
	}

	/**
	 *  This method is called when when the "More" button is pressed on the ColorChooserPanel. It will use
	 *  ColorChooserDialogProvider to show a custom color chooser dialog to choose a customized color. If
	 *  ColorChooserDialogProvider is null, we will use the default JColorChooser to choose a color.
	 * 
	 *  @param component the owner of the JColorChooser.
	 *  @param title     the title of the JColorChooser dialog.
	 *  @param initColor the initial color.
	 *  @return the color user picked.
	 */
	protected java.awt.Color showColorChooser(java.awt.Component component, String title, java.awt.Color initColor) {
	}

	/**
	 *  Gets a provider that can show a ColorChooserDialog and select a color.
	 * 
	 *  @return a ColorChooserDialogProvider.
	 */
	public ColorChooserPanel.ColorChooserDialogProvider getColorChooserDialogProvider() {
	}

	/**
	 *  Sets a ColorChooserDialogProvider. You can use this method to provide your own color chooser dialog when the
	 *  "More" button is pressed on the ColorChooserPanel.
	 * 
	 *  @param colorChooserDialogProvider a new ColorChooserDialogProvider.
	 */
	public void setColorChooserDialogProvider(ColorChooserPanel.ColorChooserDialogProvider colorChooserDialogProvider) {
	}

	/**
	 *  Get the color buttons in the color chooser panel.
	 * 
	 *  @return the buttons.
	 */
	public ColorChooserPanel.ColorButton[] getColorButtons() {
	}

	/**
	 *  Shows a modal color-chooser dialog and blocks until the dialog is hidden.  If the user presses the "OK" button,
	 *  then this method hides/disposes the dialog and returns the selected color. If the user presses the "Cancel"
	 *  button or closes the dialog without pressing "OK", then this method hides/disposes the dialog and returns
	 *  <code>null</code>.
	 * 
	 *  @param component    the parent <code>Component</code> for the dialog
	 *  @param title        the String containing the dialog's title
	 *  @param initialColor the initial Color set when the color-chooser is shown
	 *  @return the selected color or <code>null</code> if the user opted out
	 * 
	 *  @throws HeadlessException if GraphicsEnvironment.isHeadless() returns true.
	 *  @see java.awt.GraphicsEnvironment#isHeadless
	 */
	public static java.awt.Color showColorChooserDialog(java.awt.Component component, String title, java.awt.Color initialColor) {
	}

	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	protected void prevCell() {
	}

	protected void nextCell() {
	}

	protected void prevRow() {
	}

	protected void nextRow() {
	}

	protected void firstCell() {
	}

	protected void lastCell() {
	}

	protected void registerKeyStrokes() {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale locale) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in color.properties. We get color names directly from the resource bundle without using this
	 *  method. So overriding it will not have any effect on color names.
	 * 
	 *  @param key the resource key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Gets the localized string from resource bundle of specified locale. Subclass can override it to provide its own
	 *  string. Available keys are defined in color.properties.
	 * 
	 *  @param key    the resource key
	 *  @param locale the locale
	 *  @return the localized string.
	 */
	protected String getResourceString(String key, java.util.Locale locale) {
	}

	/**
	 *  An interface to bring up a custom ColorChooserDialog to choose a color when when the "More" button is pressed on
	 *  the ColorChooserPanel.
	 */
	public static interface class ColorChooserDialogProvider {


		public java.awt.Color showColorChooserDialog(java.awt.Component component, String title, java.awt.Color initColor) {
		}
	}

	/**
	 *  This class is the color button used in the <code>ColorChooserPanel</code>.
	 */
	public class ColorButton {


		/**
		 *  Creates a button with no set text or icon.
		 * 
		 *  @param color the color
		 *  @param index the index of the button
		 */
		public ColorChooserPanel.ColorButton(java.awt.Color color, int index) {
		}

		/**
		 *  Get the color value in the ColorButton.
		 * 
		 *  @return the color.
		 */
		public java.awt.Color getColor() {
		}

		/**
		 *  Set the color value in the ColorButton.
		 * 
		 *  @param color the color
		 */
		public void setColor(java.awt.Color color) {
		}

		@java.lang.Override
		protected void paintComponent(java.awt.Graphics g) {
		}
	}
}
