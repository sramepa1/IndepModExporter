/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  This interface represents the current state of the
 *  selection for DateChooserPanel. It has three different selection modes
 *  - {@link #SINGLE_SELECTION}, {@link #SINGLE_INTERVAL_SELECTION} and
 *  {@link #MULTIPLE_INTERVAL_SELECTION} which is the same as {@link javax.swing.ListSelectionModel}.
 * 
 *  @see DefaultDateSelectionModel
 */
public interface DateSelectionModel extends Cloneable {
 {

	/**
	 *  A value for the selectionMode property: select one Date
	 *  at a time.
	 * 
	 *  @see #setSelectionMode
	 */
	public static final int SINGLE_SELECTION = 0;

	/**
	 *  A value for the selectionMode property: select one contiguous
	 *  range of Dates at a time.
	 * 
	 *  @see #setSelectionMode
	 */
	public static final int SINGLE_INTERVAL_SELECTION = 1;

	/**
	 *  A value for the selectionMode property: select one or more
	 *  contiguous ranges of Dates at a time.
	 * 
	 *  @see #setSelectionMode
	 */
	public static final int MULTIPLE_INTERVAL_SELECTION = 2;

	/**
	 *  Change the selection date1 be between date0 and date1 inclusive.
	 *  If this represents a change date1 the current selection, then
	 *  notify each DateSelectionListener. Note that date0 doesn't have
	 *  date1 be less than or equal date1 date1.
	 * 
	 *  @param date0 one end of the interval.
	 *  @param date1 other end of the interval
	 *  @see #addDateSelectionListener(DateSelectionListener)
	 */
	public void setSelectionInterval(java.util.Date date0, java.util.Date date1);

	/**
	 *  Change the selection date1 be the set union of the current selection
	 *  and the indices between date0 and date1 inclusive.  If this represents
	 *  a change date1 the current selection, then notify each
	 *  DateSelectionListener. Note that date0 doesn't have date1 be less
	 *  than or equal date1 date1.
	 * 
	 *  @param date0 one end of the interval.
	 *  @param date1 other end of the interval
	 *  @see #addDateSelectionListener(DateSelectionListener)
	 */
	public void addSelectionInterval(java.util.Date date0, java.util.Date date1);

	/**
	 *  Change the selection to the set difference of the current selection
	 *  and the indices between date0 and date1 inclusive.  If this represents
	 *  a change to the current selection, then notify each
	 *  DateSelectionListener.  Note that date0 doesn't have date1 be less
	 *  than or equal to date1.
	 * 
	 *  @param date0 one end of the interval.
	 *  @param date1 other end of the interval
	 *  @see #addDateSelectionListener(DateSelectionListener)
	 */
	public void removeSelectionInterval(java.util.Date date0, java.util.Date date1);

	/**
	 *  Returns true if the specified Date is selected.
	 * 
	 *  @param date the date to be checked
	 *  @return true if the input date is selected. Otherwise false.
	 */
	public boolean isSelectedDate(java.util.Date date);

	/**
	 *  Return the first index argument from the most recent call to
	 *  setSelectionInterval(), addSelectionInterval() or removeSelectionInterval().
	 *  The most recent index0 is considered the "anchor" and the most recent
	 *  index1 is considered the "lead".
	 * 
	 *  @see #getLeadSelectionDate
	 *  @see #setSelectionInterval
	 *  @see #addSelectionInterval
	 *  @return the anchor selection date.
	 */
	public java.util.Date getAnchorSelectionDate();

	/**
	 *  Set the anchor selection Date.
	 * 
	 *  @param date the anchor selection date
	 *  @see #getAnchorSelectionDate
	 */
	public void setAnchorSelectionDate(java.util.Date date);

	/**
	 *  Return the second index argument from the most recent call to
	 *  setSelectionInterval(), addSelectionInterval() or removeSelectionInterval().
	 * 
	 *  @see #getAnchorSelectionDate
	 *  @see #setSelectionInterval
	 *  @see #addSelectionInterval
	 *  @return the lead selection date.
	 */
	public java.util.Date getLeadSelectionDate();

	/**
	 *  Set the lead selection date.
	 * 
	 *  @param date the lead selection date
	 *  @see #getLeadSelectionDate
	 */
	public void setLeadSelectionDate(java.util.Date date);

	/**
	 *  Change the selection to the empty set.  If this represents
	 *  a change to the current selection then notify each DateSelectionListener.
	 * 
	 *  @see #addDateSelectionListener(DateSelectionListener)
	 */
	public void clearSelection();

	/**
	 *  Check if current selection is empty.
	 * 
	 *  @return true if there is no selection. Otherwise false.
	 */
	public boolean isSelectionEmpty();

	/**
	 *  This property is true if upcoming changes to the value
	 *  of the model should be considered a single event. For example
	 *  if the model is being updated in response to a user drag,
	 *  the value of the valueIsAdjusting property will be set to true
	 *  when the drag is initiated and be set to false when
	 *  the drag is finished.  This property allows listeners to
	 *  to update only when a change has been finalized, rather
	 *  than always handling all of the intermediate values.
	 * 
	 *  @param valueIsAdjusting The new value of the property.
	 *  @see #getValueIsAdjusting
	 */
	public void setValueIsAdjusting(boolean valueIsAdjusting);

	/**
	 *  Returns true if the value is undergoing a series of changes.
	 * 
	 *  @return true if the value is currently adjusting
	 *  @see #setValueIsAdjusting
	 */
	public boolean getValueIsAdjusting();

	/**
	 *  Set the selection mode. The following selectionMode values are allowed:
	 *  <ul>
	 *  <li> <code>SINGLE_SELECTION</code>
	 *  Only one list index can be selected at a time.  In this
	 *  mode the setSelectionInterval and addSelectionInterval
	 *  methods are equivalent, and only the second index
	 *  argument (the "lead date") is used.
	 *  <li> <code>SINGLE_INTERVAL_SELECTION</code>
	 *  One contiguous index interval can be selected at a time.
	 *  In this mode setSelectionInterval and addSelectionInterval
	 *  are equivalent.
	 *  <li> <code>MULTIPLE_INTERVAL_SELECTION</code>
	 *  In this mode, there's no restriction on what can be selected.
	 *  </ul>
	 * 
	 *  @param selectionMode the selection mode
	 *  @see #getSelectionMode
	 */
	public void setSelectionMode(int selectionMode);

	/**
	 *  Returns the current selection mode.
	 * 
	 *  @return The value of the selectionMode property.
	 *  @see #setSelectionMode
	 */
	public int getSelectionMode();

	/**
	 *  Add a listener to the list that's notified each time a change
	 *  to the selection occurs.
	 * 
	 *  @param listener the DateSelectionListener
	 *  @see #removeDateSelectionListener(DateSelectionListener)
	 *  @see #setSelectionInterval
	 *  @see #addSelectionInterval
	 *  @see #removeSelectionInterval
	 *  @see #clearSelection
	 */
	public void addDateSelectionListener(DateSelectionListener listener);

	/**
	 *  Remove a listener from the list that's notified each time a
	 *  change to the selection occurs.
	 * 
	 *  @param listener the DateSelectionListener
	 *  @see #addDateSelectionListener(DateSelectionListener)
	 */
	public void removeDateSelectionListener(DateSelectionListener listener);

	/**
	 *  Gets the selected date. If multiple selection is allowed, this method
	 *  will return the lead selection date.
	 * 
	 *  @return the select date.
	 */
	public java.util.Date getSelectedDate();

	/**
	 *  Sets selected date.
	 * 
	 *  @param date the selected date
	 */
	public void setSelectedDate(java.util.Date date);

	/**
	 *  Gets all selected dates. It returns a sorted array of all
	 *  selected dates. It will never return null. If no selection, it will
	 *  return an empty array.
	 * 
	 *  @return all selected dates.
	 */
	public java.util.Date[] getSelectedDates();

	/**
	 *  Sets selected dates.
	 * 
	 *  @param dates the selected dates
	 */
	public void setSelectedDates(java.util.Date[] dates);

	/**
	 *  Clone the DateSelectionModel instance.
	 * 
	 *  @return A new instance with exactly the same selection value.
	 *  @throws CloneNotSupportedException
	 */
	public Object clone();
}
