/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  FileNameChooserPanel is a popup panel that can choose file name.
 */
public class FileNameChooserPanel extends PopupPanel {

	/**
	 *  Creates a new FileNameChooserPanel.
	 */
	public FileNameChooserPanel() {
	}

	/**
	 *  Creates a new FileNameChooserPanel.
	 */
	public FileNameChooserPanel(String currentDirectoryPath) {
	}

	/**
	 *  Creates a new FileNameChooserPanel.
	 */
	public FileNameChooserPanel(java.io.File currentDirectory) {
	}

	protected void initComponents() {
	}

	public java.io.File getCurrentDirectory() {
	}

	public void setCurrentDirectory(java.io.File currentDirectory) {
	}

	public String getCurrentDirectoryPath() {
	}

	public void setCurrentDirectoryPath(String currentDirectoryPath) {
	}

	protected javax.swing.JComponent createFileChooserPanel() {
	}

	protected javax.swing.JFileChooser createFileChooser() {
	}

	@java.lang.Override
	public boolean needsButtons() {
	}
}
