/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  This class provides default implementation of any ComboBox-like component. With this class, you can fully customize
 *  the dropdown popup or even show popup as dialog. You can also customize the button and the text field to whatever you
 *  want. All you need is to create a class which extends <code>AbstractComboBox</code> and implements several methods.
 *  <br> Any combobox-like component can be divided into several parts. They are an editor such as a JTextField, a button
 *  which shows the popup and a popup which will be shown when button is pressed. <br> There are also two types of
 *  ComboBox. One is the popup shown as drop down, same as <code>JComboBox</code>. The other one is the popup shown as
 *  dialog such as a text field which can choose a file. So when you construct AbstractComboBox, you can pass in type
 *  either as DROPDOWN or as POPUP. <br> This class doesn't extend JComboBox. However all interfaces in JComboBox are
 *  divided into two parts and put in AbstractComboBox or ListComboBox, whichever makes senses. So you shouldn't see much
 *  problem if converting existing JComboBox implementation to AbstractComboBox and ListComboBox implementation.
 *  <p/>
 *  If you extend this class to create your own ComboBox, make sure you call {@link #initComponent()} or {@link
 *  #initComponent(javax.swing.ComboBoxModel)} method in your ComboBox's constructor. We didn't call it automatically
 *  because we want you to decide when to call it during your ComboBox's initialization steps.
 */
public abstract class AbstractComboBox extends javax.swing.JComponent implements java.awt.ItemSelectable, java.awt.event.MouseListener, java.awt.event.ActionListener, javax.swing.event.PopupMenuListener, java.awt.event.FocusListener, javax.accessibility.Accessible {
 {

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #getModel
	 *  @see #setModel
	 */
	protected javax.swing.ComboBoxModel dataModel;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #getEditor
	 *  @see #setEditor
	 */
	protected javax.swing.ComboBoxEditor _editor;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #isEditable
	 *  @see #setEditable
	 */
	protected boolean _editable;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #setActionCommand
	 *  @see #getActionCommand
	 */
	protected String actionCommand;

	/**
	 *  This protected field is implementation specific. Do not access directly or override.
	 */
	protected Object selectedItemReminder;

	/**
	 *  The button that will show the popup.
	 */
	protected javax.swing.AbstractButton _popupButton;

	/**
	 *  The dialog that will be shown.
	 */
	protected StandardDialog _dialog;

	/**
	 *  The actual panel inside the PopupWindow.
	 */
	protected PopupPanel _popupPanel;

	/**
	 *  If the AbstractComboBox type is DROPDOWN, the popup panel will be shown as dropdown.
	 */
	public static final int DROPDOWN = 0;

	/**
	 *  If the AbstractComboBox type is DIALOG, the popup panel will be shown as dialog.
	 */
	public static final int DIALOG = 1;

	public static final String PROPERTY_SELECTED_ITEM = "selectedItem";

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #getRenderer
	 *  @see #setRenderer
	 */
	protected javax.swing.ListCellRenderer _renderer;

	public static final String CLIENT_PROPERTY_TABLE_CELL_EDITOR = "AbstractComboBox.isTableCellEditor";

	public static final String CLIENT_PROPERTY_HIDE_POPUP_ON_LIST_DATA_CHANGED = "AbstractComboBox.isHidePopupOnListDataChanged";

	/**
	 *  Constant identifying that when focus is lost, <code>commitEdit</code> should be invoked. If in committing the new
	 *  value a <code>ParseException</code> is thrown, the invalid value will remain.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int COMMIT = 0;

	/**
	 *  Constant identifying that when focus is lost, <code>commitEdit</code> should be invoked. If in committing the new
	 *  value a <code>ParseException</code> is thrown, the value will be reverted.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int COMMIT_OR_REVERT = 1;

	/**
	 *  Constant identifying that when focus is lost, the editing value should be reverted to current value set on the
	 *  <code>AbstractComboBox</code>.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int REVERT = 2;

	/**
	 *  Constant identifying that when focus is lost, the edited value should be left.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int PERSIST = 3;

	/**
	 *  Constant identifying that when focus is lost, <code>commitEdit</code> should be invoked. If in committing the new
	 *  value a <code>ParseException</code> is thrown, the value will be reset to null.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int COMMIT_OR_RESET = 4;

	/**
	 *  Constant identifying that when focus is lost, the editing value will be reset to null.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int RESET = 5;

	protected javax.swing.event.ListDataListener _listDataListener;

	protected Object HIDE_POPUP_KEY;

	/**
	 *  Creates a new DROPDOWN <code>AbstractComboBox</code>.
	 */
	public AbstractComboBox() {
	}

	/**
	 *  Creates a new <code>AbstractComboBox</code> with default context.
	 * 
	 *  @param type DIALOG or DROPDOWN
	 */
	public AbstractComboBox(int type) {
	}

	/**
	 *  Creates a new <code>AbstractComboBox</code>.
	 * 
	 *  @param type    DIALOG or DROPDOWN
	 *  @param context ConverterContext
	 */
	public AbstractComboBox(int type, ConverterContext context) {
	}

	/**
	 *  Subclass should implement this method to create the actual editor component.
	 * 
	 *  @return the editor component
	 */
	public abstract AbstractComboBox.EditorComponent createEditorComponent() {
	}

	/**
	 *  Subclass should implement this method to create the actual popup component.
	 * 
	 *  @return the popup component
	 */
	public abstract PopupPanel createPopupComponent() {
	}

	/**
	 *  Subclass should override this method to create the actual button component. If subclass doesn't implement or it
	 *  returns null, a default button will be created which is the same look as the JComboBox's drop down button. There
	 *  is also UIDefault "AbstractComboBox.useJButton" you can set. If it false by default. If you set it to true, we
	 *  will create a JButton for it without using the JComboBox's button. If type is DROPDOWN, down arrow button will be
	 *  used. If type is DIALOG, "..." button will be used.
	 * 
	 *  @return the button component
	 */
	public javax.swing.AbstractButton createButtonComponent() {
	}

	/**
	 *  Initialize this component such as creating button, editor etc. If you choose to override this method, it'd better
	 *  you override {@link #initComponent(javax.swing.ComboBoxModel)} as it is guaranteed ?* to be called. this method
	 *  is not called in the case of {@link ListComboBox}.
	 */
	protected void initComponent() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Checks if the popup is volatile. If a popup is volatile, it will be recreated every time the popup is shown. By
	 *  default, it's false. Subclasses can override it to return true or false depending on the actual case.
	 * 
	 *  @return true if the popup is volatile.
	 */
	public boolean isPopupVolatile() {
	}

	/**
	 *  Sets the volatile attribute of popup. If a popup is volatile, it will be recreated every time the popup is shown.
	 *  By default, it's false. you can call this method to true or false depending on the actual case.
	 * 
	 *  @param popupVolatile true or false
	 */
	public void setPopupVolatile(boolean popupVolatile) {
	}

	/**
	 *  Resets the popup. If the popup is not volatile, this method will reset the popup to null so next time it will
	 *  recreate again.
	 */
	public void resetPopup() {
	}

	/**
	 *  Initialize this component such as creating button, editor etc. All subclasses must call this method in the
	 *  constructor to initialize the ComboBox.
	 * 
	 *  @param model ComboBoxModel if any. If it's null, use InfiniteComboBoxModel.
	 */
	protected void initComponent(javax.swing.ComboBoxModel model) {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Delegates key strokes to popup panel. When popup panel is shown, the keyboard focus is still in the editor of
	 *  ComboBox. So for certain keystrokes we need to delegate to popup panel. By default, we will delegate ESCAPE, UP,
	 *  DOWN, PAGE_UP, PAGE_DOWN, ENTER, LEFT, RIGHT, HOME, and END. This method will be called when popup panel is shown
	 *  and the corresponding {@link #undelegateKeyStrokes()} will be called when popup panel is hidden.
	 *  <p/>
	 *  Subclass can override it to delegate more. To delegate a KeyStroke, you can simply call {@link
	 *  DelegateAction#replaceAction(javax.swing.JComponent,int,javax.swing.KeyStroke,com.jidesoft.swing.DelegateAction)}.
	 */
	protected void delegateKeyStrokes() {
	}

	/**
	 *  Undelegates keystrokes.
	 *  <p/>
	 *  Subclass can override it to undelegate those keystrokes if it overrides delegateKeyStrokes to delegate more
	 *  KeyStrokes. To undelegate a KeyStroke, you can simply call {@link DelegateAction#restoreAction(javax.swing.JComponent,int,javax.swing.KeyStroke)}.
	 * 
	 *  @see #delegateKeyStrokes()
	 */
	protected void undelegateKeyStrokes() {
	}

	/**
	 *  Gets the list of KeyStrokes that will be delegated to the popup panel. By default, we will return ESCAPE, UP,
	 *  DOWN, PAGE_DOWN, PAGE_UP, ENTER, LEFT, RIGHT, HOME and END keys.
	 * 
	 *  @return the list of KeyStrokes that will be delegated to the popup panel.
	 */
	protected java.util.List getDelegateKeyStrokes() {
	}

	/**
	 *  The action on list data change events. You could override this method to customize your behavior.
	 *  <p/>
	 *  By default, we would reset popup panel and clear selection if the flags are on.
	 * 
	 *  @see #isHidePopupOnListDataChanged()
	 *  @see #isClearSelectionOnListDataChanged()
	 */
	protected void listDataChanged() {
	}

	public ObjectConverter getConverter() {
	}

	public void setConverter(ObjectConverter converter) {
	}

	public ConverterContext getConverterContext() {
	}

	public void setConverterContext(ConverterContext converterContext) {
	}

	public Class getType() {
	}

	public void setType(Class clazz) {
	}

	/**
	 *  Sets the visibility of the button. Sometimes the same CellEditor can be used as CellRenderer. If so, just set
	 *  button invisible.
	 * 
	 *  @param visible true to make popup button visible.
	 */
	public void setButtonVisible(boolean visible) {
	}

	/**
	 *  Checks if the button is visible.
	 * 
	 *  @return true if visible. Otherwise false.
	 */
	public boolean isButtonVisible() {
	}

	/**
	 *  Sets the visibility of the editor and only makes the button visible. It is false by default. If you set it to
	 *  true, you may also want to override {@link #createButtonComponent()} to create a button that is unique, such as a
	 *  date chooser icon if this is a DateComboBox. The default combobox button is not appropriate when only the button
	 *  is visible.
	 * 
	 *  @param buttonOnly true to make only the popup button visible (and hide the editor area).
	 */
	public void setButtonOnly(boolean buttonOnly) {
	}

	/**
	 *  Checks if only the button is visible. By default is false. You can set it to true if you just want to use a
	 *  button to show the popup panel. You can listen to the item selection change to find out the new value and set it
	 *  to somewhere else.
	 * 
	 *  @return true if visible. Otherwise false.
	 */
	public boolean isButtonOnly() {
	}

	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	/**
	 *  Get the flag if AbstractComboBox should hide popup if it receives list data change event.
	 *  <p/>
	 *  By default, the value is set to true. With this configuration, AbstractComboBox can guarantee the contents it
	 *  shows up in the popup panel are the latest updated.
	 *  <p/>
	 *  However, in some cases, if you want to listen to PopupMenuListener and update list data there, you have to set
	 *  this flag to false. Otherwise you will get NPE thrown. Since you are updating list data while the popup menu is
	 *  being shown up, you are supposed to have the full control of the list data.
	 * 
	 *  @return the flag if AbstractComboBox should hide popup if it receives list data change event.
	 */
	public boolean isHidePopupOnListDataChanged() {
	}

	/**
	 *  Set the flag if AbstractComboBox should hide popup if it receives list data change event.
	 *  <p/>
	 * 
	 *  @param hidePopupOnListDataChanged the flag if AbstractComboBox should hide popup if it receives list data change
	 *                                    event.
	 *  @see #isHidePopupOnListDataChanged()
	 */
	public void setHidePopupOnListDataChanged(boolean hidePopupOnListDataChanged) {
	}

	/**
	 *  Get the flag if AbstractComboBox should clear the current selection and field if it receives list data change
	 *  event.
	 *  <p/>
	 *  By default, the value is set to false for backward compatibility reason. You could set it to true so that
	 *  AbstractComboBox can guarantee the contents it shows up in the editor field are not out-of-dated.
	 * 
	 *  @return the flag if AbstractComboBox should clear current selection if it receives list data change event.
	 */
	public boolean isClearSelectionOnListDataChanged() {
	}

	/**
	 *  Set the flag if AbstractComboBox should clear the current selection and field if it receives list data change
	 *  event.
	 *  <p/>
	 *  By default, the value is set to false for backward compatibility reason. You could set it to true so that
	 *  AbstractComboBox can guarantee the contents it shows up in the editor field are not out-of-dated.
	 * 
	 *  @param clearSelectionOnListDataChanged
	 *          the flag if AbstractComboBox should clear current selection if it receives list data change event.
	 *  @see #isClearSelectionOnListDataChanged()
	 */
	public void setClearSelectionOnListDataChanged(boolean clearSelectionOnListDataChanged) {
	}

	protected void updateToolTipTextForChildren() {
	}

	/**
	 *  Creates the spinner for the editor component of this ComboBox. By default, it will return a JSpinner. Subclass
	 *  can override it to return a JSpinner() or any other customized spinner.
	 *  <p/>
	 *  Please note, JideTable has a feature to allow any key to start cell editing just like in Excel. However, in order
	 *  to make this feature works in any AbstractComboBox-based cell editors, you must use {@link ComboBoxSpinner} to
	 *  replace JSpinner. So if you ever override this createSpinner to create your own JSpinner, use ComboBoxSpinner
	 *  instead. The only difference between JSpinner and ComboBoxSpinner is ComboBoxSpinner implements {@link
	 *  ProcessKeyBinding} interface and make processKeyBinding(...) a public method so that we can use it to pass the
	 *  key event to it. Otherwise, you hit a key to start cell editing and the first key will get lost.
	 * 
	 *  @return the text field.
	 */
	protected javax.swing.JSpinner createSpinner() {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Has to make public due to implementation of an interface. Do not call it directly. However you can override it if
	 *  you want to provide a different action for the button. The ActionEvent will not be null if this method is
	 *  triggered by the button action.
	 * 
	 *  @param e the ActionEvent. Null if the event is actually fired by mousePressed event.
	 */
	public void actionPerformed(java.awt.event.ActionEvent e) {
	}

	/**
	 *  Gets the popup type. It could be either DROPDOWN or DIALOG.
	 * 
	 *  @return the popup type.
	 */
	public int getPopupType() {
	}

	/**
	 *  Sets the popup type. It could be either DROPDOWN or DIALOG.
	 * 
	 *  @param popupType the new popup type.
	 */
	public void setPopupType(int popupType) {
	}

	/**
	 *  Shows the popup panel. It will show popup as drop down or dialog depending on the type.
	 */
	protected void showPopupPanel() {
	}

	/**
	 *  @param show the flag that if we should really show the popup panel
	 */
	protected void showPopupPanelAsPopup(boolean show) {
	}

	/**
	 *  Customizes the JidePopup that is used to show the drop down.
	 * 
	 *  @param popup the JidePopup.
	 */
	protected void customizePopup(JidePopup popup) {
	}

	/**
	 *  Creates the popup window. By default it will create a JidePopup which is not detached and not resizable. Subclass
	 *  can override it to create your own JidePopup or customize the default one.
	 * 
	 *  @return the popup window.
	 */
	protected JidePopup createPopupWindow() {
	}

	/**
	 *  calculate the popup location.
	 * 
	 *  @return the location of popup.
	 */
	protected java.awt.Point calculatePopupLocation() {
	}

	/**
	 *  Gets the OK button action for the dialog type ComboBox.
	 * 
	 *  @return the dialog OK action.
	 */
	protected javax.swing.Action getDialogOKAction() {
	}

	/**
	 *  Gets the cancel button action for the dialog type ComboBox.
	 * 
	 *  @return the dialog cancel action.
	 */
	protected javax.swing.Action getDialogCancelAction() {
	}

	/**
	 *  Customizes the dialog location. By default, we will call dialog.setLocationRelativeTo(this) so that it will
	 *  locate relative to the AbstractComboBox itself. If you want to put at at the center of the screen, you can call
	 *  dialog.setLocationRelativeTo(null). Or you can call setLocation to set it at any location on the screen. We will
	 *  call this method after dialog.pack() is called and before dialog.setVisible(true) is called.
	 * 
	 *  @param dialog the dialog
	 */
	protected void customizeDialogLocation(javax.swing.JDialog dialog) {
	}

	/**
	 *  Customizes the dialog. This method is called just before dialog.pack() and dialog.setVisible(true) are called.
	 *  You can override it to add extra code to customize the dialog.
	 * 
	 *  @param dialog the dialog
	 */
	protected void customizeDialog(javax.swing.JDialog dialog) {
	}

	/**
	 *  Gets the button that will shows the popup.
	 * 
	 *  @return the button
	 */
	public javax.swing.AbstractButton getPopupButton() {
	}

	/**
	 *  Sets the popup button.
	 * 
	 *  @param button a new popup button.
	 */
	public void setPopupButton(javax.swing.AbstractButton button) {
	}

	/**
	 *  Gets the popup panel.
	 * 
	 *  @return the popup panel
	 */
	public PopupPanel getPopupPanel() {
	}

	@java.lang.Override
	public void setForeground(java.awt.Color fg) {
	}

	@java.lang.Override
	public void setBackground(java.awt.Color fg) {
	}

	/**
	 *  Returns an array containing the selected item. This method is implemented for compatibility with
	 *  <code>ItemSelectable</code>.
	 * 
	 *  @return an array of <code>Objects</code> containing one element -- the selected item
	 */
	public Object[] getSelectedObjects() {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type.
	 * 
	 *  @param e the event of interest
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireItemStateChanged(java.awt.event.ItemEvent e) {
	}

	/**
	 *  Sets the data model that the <code>JComboBox</code> uses to obtain the list of items.
	 * 
	 *  @param aModel the <code>ComboBoxModel</code> that provides the displayed list of items description: Model that
	 *                the combo box uses to get data to display.
	 */
	public void setModel(javax.swing.ComboBoxModel aModel) {
	}

	/**
	 *  Returns the data model currently used by the <code>JComboBox</code>.
	 * 
	 *  @return the <code>ComboBoxModel</code> that provides the displayed list of items
	 */
	public javax.swing.ComboBoxModel getModel() {
	}

	/**
	 *  Determines whether the <code>JComboBox</code> field is editable. An editable <code>JComboBox</code> allows the
	 *  user to type into the field or selected an item from the list to initialize the field, after which it can be
	 *  edited. (The editing affects only the field, the list item remains intact.) A non editable <code>JComboBox</code>
	 *  displays the selected item in the field, but the selection cannot be modified.
	 * 
	 *  @param editable a boolean value, where true indicates that the field is editable preferred: true description: If
	 *                  true, the user can type a new value in the combo box.
	 */
	public void setEditable(boolean editable) {
	}

	/**
	 *  Returns true if the <code>JComboBox</code> is editable. By default, a combo box is not editable.
	 * 
	 *  @return true if the <code>JComboBox</code> is editable, else false
	 */
	public boolean isEditable() {
	}

	/**
	 *  Sets the editor used to paint and edit the selected item in the <code>AbstractComboBox</code> field. The editor
	 *  is used only if the receiving <code>AbstractComboBox</code> is editable. If not editable, the combo box uses the
	 *  renderer to paint the selected item.
	 * 
	 *  @param anEditor the <code>ComboBoxEditor</code> that displays the selected item
	 *  @deprecated Please do not use this method for AbstractComboBox. If you need to provide your own editor, please
	 *              override {@link #createEditorComponent()} method instead.
	 */
	@java.lang.Deprecated
	public void setEditor(javax.swing.ComboBoxEditor anEditor) {
	}

	/**
	 *  Returns the editor used to paint and edit the selected item in the <code>JComboBox</code> field.
	 * 
	 *  @return the <code>ComboBoxEditor</code> that displays the selected item
	 */
	public javax.swing.ComboBoxEditor getEditor() {
	}

	/**
	 *  Sets the selected item in the combo box display area to the object in the argument. If <code>anObject</code> is
	 *  in the list, the display area shows <code>anObject</code> selected.
	 *  <p/>
	 *  If <code>anObject</code> is <i>not</i> in the list and the combo box is not editable, it will not change the
	 *  current selection. For editable combo boxes, the selection will change to <code>anObject</code>.
	 *  <p/>
	 *  If this constitutes a change in the selected item, <code>ItemListener</code>s added to the combo box will be
	 *  notified with one or two <code>ItemEvent</code>s. If there is a current selected item, an <code>ItemEvent</code>
	 *  will be fired and the state change will be <code>ItemEvent.DESELECTED</code>. If <code>anObject</code> is in the
	 *  list and is not currently selected then an <code>ItemEvent</code> will be fired and the state change will be
	 *  <code>ItemEvent.SELECTED</code>.
	 *  <p/>
	 *  <code>ActionListener</code>s added to the combo box will be notified with an <code>ActionEvent</code> when this
	 *  method is called.
	 * 
	 *  @param anObject the list object to select; use <code>null</code> to clear the selection
	 */
	public void setSelectedItem(Object anObject) {
	}

	/**
	 *  Same as {@link #setSelectedItem(Object)} except you can choose to fire the ItemEvent or not.
	 * 
	 *  @param anObject  the new value
	 *  @param fireEvent true to fire event which is the same as {@link #setSelectedItem(Object)}. False if you don't
	 *                   want to fire event.
	 */
	public void setSelectedItem(Object anObject, boolean fireEvent) {
	}

	/**
	 *  Check if object1 is equal to object2. The default implementation is check if the object1 and object2 is the same
	 *  instance. You can override it if you need more concise control on the events.
	 * 
	 *  @param object1 one of the two objects
	 *  @param object2 another one of the two objects
	 *  @return true if those two objects are equal. Otherwise false.
	 */
	protected boolean equals(Object object1, Object object2) {
	}

	protected boolean validateValueForNonEditable(Object value) {
	}

	/**
	 *  Returns the current selected item.
	 *  <p/>
	 *  If the combo box is editable, then this value may not have been added to the combo box with <code>addItem</code>,
	 *  <code>insertItemAt</code> or the data constructors.
	 * 
	 *  @return the current selected Object
	 * 
	 *  @see #setSelectedItem
	 */
	public Object getSelectedItem() {
	}

	/**
	 *  Returns the "prototypical display" value - an Object used for the calculation of the display height and width.
	 * 
	 *  @return the value of the <code>prototypeDisplayValue</code> property
	 * 
	 *  @see #setPrototypeDisplayValue
	 */
	public Object getPrototypeDisplayValue() {
	}

	/**
	 *  Sets the prototype display value used to calculate the size of the display for the UI portion.
	 *  <p/>
	 *  If a prototype display value is specified, the preferred size of the combo box is calculated by configuring the
	 *  renderer with the prototype display value and obtaining its preferred size. Specifying the preferred display
	 *  value is often useful when the combo box will be displaying large amounts of data. If no prototype display value
	 *  has been specified, the renderer must be configured for each value from the model and its preferred size
	 *  obtained, which can be relatively expensive.
	 * 
	 *  @param prototypeDisplayValue attribute: visualUpdate true description: The display prototype value, used to
	 *                               compute display width and height.
	 *  @see #getPrototypeDisplayValue
	 */
	public void setPrototypeDisplayValue(Object prototypeDisplayValue) {
	}

	/**
	 *  Causes the combo box to display its popup window.
	 * 
	 *  @see #setPopupVisible
	 */
	public void showPopup() {
	}

	/**
	 *  Causes the combo box to close its popup window.
	 * 
	 *  @see #setPopupVisible
	 */
	public void hidePopup() {
	}

	/**
	 *  Sets the visibility of the popup.
	 * 
	 *  @param v visibility
	 */
	public void setPopupVisible(boolean v) {
	}

	/**
	 *  Determines the visibility of the popup.
	 * 
	 *  @return true if the popup is visible, otherwise returns false
	 */
	public boolean isPopupVisible() {
	}

	/**
	 *  Adds an <code>ItemListener</code>.
	 *  <p/>
	 *  <code>aListener</code> will receive one or two <code>ItemEvent</code>s when the selected item changes.
	 * 
	 *  @param aListener the <code>ItemListener</code> that is to be notified
	 *  @see #setSelectedItem
	 */
	public void addItemListener(java.awt.event.ItemListener aListener) {
	}

	/**
	 *  Removes an <code>ItemListener</code>.
	 * 
	 *  @param aListener the <code>ItemListener</code> to remove
	 */
	public void removeItemListener(java.awt.event.ItemListener aListener) {
	}

	/**
	 *  Returns an array of all the <code>ItemListener</code>s added to this JComboBox with addItemListener().
	 * 
	 *  @return all of the <code>ItemListener</code>s added or an empty array if no listeners have been added
	 */
	public java.awt.event.ItemListener[] getItemListeners() {
	}

	/**
	 *  Adds an <code>ActionListener</code>.
	 *  <p/>
	 *  The <code>ActionListener</code> will receive an <code>ActionEvent</code> when a selection has been made. If the
	 *  combo box is editable, then an <code>ActionEvent</code> will be fired when editing has stopped.
	 * 
	 *  @param l the <code>ActionListener</code> that is to be notified
	 *  @see #setSelectedItem
	 */
	public void addActionListener(java.awt.event.ActionListener l) {
	}

	/**
	 *  Removes an <code>ActionListener</code>.
	 * 
	 *  @param l the <code>ActionListener</code> to remove
	 */
	public void removeActionListener(java.awt.event.ActionListener l) {
	}

	/**
	 *  Returns an array of all the <code>ActionListener</code>s added to this JComboBox with addActionListener().
	 * 
	 *  @return all of the <code>ActionListener</code>s added or an empty array if no listeners have been added
	 */
	public java.awt.event.ActionListener[] getActionListeners() {
	}

	/**
	 *  Adds a <code>PopupMenu</code> listener which will listen to notification messages from the popup portion of the
	 *  combo box.
	 *  <p/>
	 *  For all standard look and feels shipped with Java 2, the popup list portion of combo box is implemented as a
	 *  <code>JPopupMenu</code>. A custom look and feel may not implement it this way and will therefore not receive the
	 *  notification.
	 * 
	 *  @param l the <code>PopupMenuListener</code> to add
	 */
	public void addPopupMenuListener(javax.swing.event.PopupMenuListener l) {
	}

	/**
	 *  Removes a <code>PopupMenuListener</code>.
	 * 
	 *  @param l the <code>PopupMenuListener</code> to remove
	 *  @see #addPopupMenuListener
	 */
	public void removePopupMenuListener(javax.swing.event.PopupMenuListener l) {
	}

	/**
	 *  Returns an array of all the <code>PopupMenuListener</code>s added to this JComboBox with addPopupMenuListener().
	 * 
	 *  @return all of the <code>PopupMenuListener</code>s added or an empty array if no listeners have been added
	 */
	public javax.swing.event.PopupMenuListener[] getPopupMenuListeners() {
	}

	/**
	 *  Notifies <code>PopupMenuListener</code>s that the popup portion of the combo box will become visible.
	 *  <p/>
	 *  This method is public but should not be called by anything other than the UI delegate.
	 * 
	 *  @see #addPopupMenuListener
	 */
	public void firePopupMenuWillBecomeVisible() {
	}

	/**
	 *  Notifies <code>PopupMenuListener</code>s that the popup portion of the combo box has become invisible.
	 *  <p/>
	 *  This method is public but should not be called by anything other than the UI delegate.
	 * 
	 *  @see #addPopupMenuListener
	 */
	public void firePopupMenuWillBecomeInvisible() {
	}

	/**
	 *  Notifies <code>PopupMenuListener</code>s that the popup portion of the combo box has been canceled.
	 *  <p/>
	 *  This method is public but should not be called by anything other than the UI delegate.
	 * 
	 *  @see #addPopupMenuListener
	 */
	public void firePopupMenuCanceled() {
	}

	/**
	 *  Sets the _action command that should be included in the event sent to _action listeners.
	 * 
	 *  @param aCommand a string containing the "command" that is sent to _action listeners; the same listener can then
	 *                  do different things depending on the command it receives
	 */
	public void setActionCommand(String aCommand) {
	}

	/**
	 *  Returns the _action command that is included in the event sent to _action listeners.
	 * 
	 *  @return the string containing the "command" that is sent to _action listeners.
	 */
	public String getActionCommand() {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type.
	 * 
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireActionEvent() {
	}

	/**
	 *  This protected method is implementation specific. Do not access directly or override.
	 */
	protected void selectedItemChanged() {
	}

	/**
	 *  Sets the <code>Action</code> for the <code>ActionEvent</code> source. The new <code>Action</code> replaces any
	 *  previously set <code>Action</code> but does not affect <code>ActionListeners</code> independently added with
	 *  <code>addActionListener</code>. If the <code>Action</code> is already a registered <code>ActionListener</code>
	 *  for the <code>ActionEvent</code> source, it is not re-registered.
	 *  <p/>
	 *  <p/>
	 *  A side-effect of setting the <code>Action</code> is that the <code>ActionEvent</code> source's properties are
	 *  immediately set from the values in the <code>Action</code> (performed by the method
	 *  <code>configurePropertiesFromAction</code>) and subsequently updated as the <code>Action</code>'s properties
	 *  change (via a <code>PropertyChangeListener</code> created by the method <code>createActionPropertyChangeListener</code>.
	 * 
	 *  @param a the <code>Action</code> for the <code>JComboBox</code>, or <code>null</code>. attribute: visualUpdate
	 *           true description: the Action instance connected with this ActionEvent source
	 *  @see Action
	 *  @see #getAction
	 *  @see #configurePropertiesFromAction
	 *  @see #createActionPropertyChangeListener
	 */
	public void setAction(javax.swing.Action a) {
	}

	/**
	 *  Returns the currently set <code>Action</code> for this <code>ActionEvent</code> source, or <code>null</code> if
	 *  no <code>Action</code> is set.
	 * 
	 *  @return the <code>Action</code> for this <code>ActionEvent</code> source; or <code>null</code>
	 * 
	 *  @see Action
	 *  @see #setAction
	 */
	public javax.swing.Action getAction() {
	}

	/**
	 *  Factory method which sets the <code>ActionEvent</code> source's properties according to values from the
	 *  <code>Action</code> instance. The properties which are set may differ for subclasses. By default, the properties
	 *  which get set are <code>Enabled</code> and <code>ToolTipText</code>.
	 * 
	 *  @param a the <code>Action</code> from which to get the properties, or <code>null</code>
	 *  @see Action
	 *  @see #setAction
	 */
	protected void configurePropertiesFromAction(javax.swing.Action a) {
	}

	/**
	 *  Factory method which creates the <code>PropertyChangeListener</code> used to update the <code>ActionEvent</code>
	 *  source as properties change on its <code>Action</code> instance. Subclasses may override this in order to provide
	 *  their own <code>PropertyChangeListener</code> if the set of properties which should be kept up to date differs
	 *  from the default properties (Text, Icon, Enabled, ToolTipText).
	 *  <p/>
	 *  Note that <code>PropertyChangeListeners</code> should avoid holding strong references to the
	 *  <code>ActionEvent</code> source, as this may hinder garbage collection of the <code>ActionEvent</code> source and
	 *  all components in its containment hierarchy.
	 * 
	 *  @param a the action
	 *  @return property change listener
	 */
	protected java.beans.PropertyChangeListener createActionPropertyChangeListener(javax.swing.Action a) {
	}

	public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent e) {
	}

	public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e) {
	}

	public void popupMenuCanceled(javax.swing.event.PopupMenuEvent e) {
	}

	public void focusGained(java.awt.event.FocusEvent e) {
	}

	public void focusLost(java.awt.event.FocusEvent e) {
	}

	/**
	 *  Conditionally commit the edit considering the focusLostBehavior.
	 * 
	 *  @param commit true or false.
	 */
	protected void commitEditWithFocusLostBehavior(boolean commit) {
	}

	/**
	 *  Calls PortingUtils.notifyUser() to notify the user an error occurred when committing the edit.
	 */
	protected void notifyUser() {
	}

	/**
	 *  Commits the editing change to the AbstractComboBox.
	 * 
	 *  @return true if commits successful. Otherwise it will return false.
	 */
	public boolean commitEdit() {
	}

	/**
	 *  Cancels the editing change and reverts to the previous valid.
	 */
	public void revertEdit() {
	}

	/**
	 *  Cancels the editing change and resets to null.
	 */
	public void resetEdit() {
	}

	/**
	 *  Gets the AccessibleContext associated with this JComboBox. For combo boxes, the AccessibleContext takes the form
	 *  of an AccessibleJComboBox. A new AccessibleJComboBox instance is created if necessary.
	 * 
	 *  @return an AccessibleJComboBox that serves as the AccessibleContext of this JComboBox
	 */
	@java.lang.Override
	public javax.accessibility.AccessibleContext getAccessibleContext() {
	}

	protected void installListener() {
	}

	protected void uninstallListener() {
	}

	/**
	 *  Creates the default ComboBox button. This method is used only if createButtonComponent() returns null. The idea
	 *  is each ComboBox can implement createButtonComponent() to provide its own button. However the default
	 *  implementation should still be the button created by this method.
	 * 
	 *  @return the default ComboBox button.
	 */
	protected javax.swing.AbstractButton createDefaultButton() {
	}

	/**
	 *  Customizes the button used by the AbstractComboBox.
	 * 
	 *  @param button the button component.
	 */
	protected void customizeButton(javax.swing.AbstractButton button) {
	}

	@java.lang.Override
	public void removeNotify() {
	}

	@java.lang.Override
	public void addNotify() {
	}

	protected javax.swing.JComponent getDelegateTarget() {
	}

	/**
	 *  Creates the text field for the editor component of this ComboBox. By default, it will return a JTextField.
	 *  Subclass can override it to return a JFormattedTextField() or any other customized text field.
	 *  <p/>
	 *  Please note, JideTable has a feature to allow any key to start cell editing just like in Excel. However, in order
	 *  to make this feature works in any AbstractComboBox-based cell editors, you must use {@link ComboBoxTextField} to
	 *  replace JTextField. So if you ever override this createTextField to create your own JTextField, use
	 *  ComboBoxTextField instead. The only difference between JTextField and ComboBoxTextField is ComboBoxTextField
	 *  implements {@link ProcessKeyBinding} interface and make processKeyBinding(...) a public method so that we can use
	 *  it to pass the key event to it. Otherwise, you hit a key to start cell editing and the first key will get lost.
	 * 
	 *  @return the text field.
	 */
	protected javax.swing.JTextField createTextField() {
	}

	/**
	 *  Override to always return true.
	 */
	@java.lang.Override
	public boolean isOpaque() {
	}

	protected void installColorFontAndBorder(javax.swing.JTable table, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	/**
	 *  Sets the renderer that paints the list items and the item selected from the list in the JComboBox field. The
	 *  renderer is used if the JComboBox is not editable. If it is editable, the editor is used to render and edit the
	 *  selected item.
	 *  <p/>
	 *  The default renderer displays a string or an icon. Other renderers can handle graphic images and composite
	 *  items.
	 *  <p/>
	 *  To display the selected item, <code>aRenderer.getListCellRendererComponent</code> is called, passing the list
	 *  object and an index of -1.
	 * 
	 *  @param aRenderer the <code>ListCellRenderer</code> that displays the selected item expert: true description: The
	 *                   renderer that paints the item selected in the list.
	 *  @see #setEditor
	 */
	public void setRenderer(javax.swing.ListCellRenderer aRenderer) {
	}

	/**
	 *  Returns the renderer used to display the selected item in the <code>JComboBox</code> field.
	 * 
	 *  @return the <code>ListCellRenderer</code> that displays the selected item.
	 */
	public javax.swing.ListCellRenderer getRenderer() {
	}

	/**
	 *  Gets the popup location. The ComboBox could show popup above the ComboBox or below the ComboBox depending on if
	 *  there is enough space to show the whole popup.
	 * 
	 *  @return SwingConstants.TOP or SwingContants.BOTTOM. Usually it will return BOTTOM. But if there isn't enough
	 *          space below the ComboBox to show the whole popup, the popup will show above the ComboBox. If so, it will
	 *          return TOP.
	 */
	public int getPopupLocation() {
	}

	@java.lang.Override
	protected boolean processKeyBinding(javax.swing.KeyStroke ks, java.awt.event.KeyEvent e, int condition, boolean pressed) {
	}

	public int getBaseline(int width, int height) {
	}

	/**
	 *  Sets the behavior when focus is lost. This will be one of <code>AbstractComboBox.COMMIT</code>,
	 *  <code>AbstractComboBox.COMMIT_OR_REVERT</code>, <code>AbstractComboBox.REVERT</code>,
	 *  <code>AbstractComboBox.PERSIST</code>, <code>AbstractComboBox.COMMIT_OR_RESET</code> or
	 *  <code>AbstractComboBox.RESET</code>. Note that some <code>ObjectConverter</code>s may push changes as they occur,
	 *  so that the value of this will have no effect.
	 *  <p/>
	 *  This will throw an <code>IllegalArgumentException</code> if the object passed in is not one of the afore
	 *  mentioned values.
	 *  <p/>
	 *  The default value of this property is <code>AbstractComboBox.COMMIT_OR_REVERT</code>.
	 * 
	 *  @param behavior Identifies behavior when focus is lost
	 *  @throws IllegalArgumentException if behavior is not one of the known values
	 */
	public void setFocusLostBehavior(int behavior) {
	}

	/**
	 *  Returns the behavior when focus is lost. This will be one of <code>COMMIT</code>, <code>COMMIT_OR_REVERT</code>,
	 *  <code>REVERT</code>, <code>PERSIST</code>, <code>COMMIT_OR_RESET</code> or <code>RESET</code>. Note that some
	 *  <code>ObjectConverter</code>s may push changes as they occur, so that the value of this will have no effect.
	 * 
	 *  @return returns behavior when focus is lost
	 */
	public int getFocusLostBehavior() {
	}

	/**
	 *  Sets the behavior when the popup drop down is canceled. This will be one of <code>AbstractComboBox.PERSIST</code>,
	 *  <code>AbstractComboBox.REVERT</code>, or <code>AbstractComboBox.RESET</code>.
	 *  <p/>
	 *  The default value of this property is <code>AbstractComboBox.REVERT</code> which means the value will be reset to
	 *  the previous value before the drop down is shown.
	 * 
	 *  @param behavior Identifies behavior when the drop down popup is canceled.
	 *  @throws IllegalArgumentException if behavior is not one of the known values
	 */
	public void setPopupCancelBehavior(int behavior) {
	}

	/**
	 *  Returns the behavior when the popup drop down is canceled. This will be one of <code>PERSIST</code>,
	 *  <code>REVERT</code>, or <code>RESET</code>.
	 * 
	 *  @return returns behavior when the drop down popup is canceled.
	 */
	public int getPopupCancelBehavior() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void modelUpdated(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Checks if double click on the editor part will toggle the value.
	 * 
	 *  @return true or false.
	 */
	public boolean isToggleValueOnDoubleClick() {
	}

	/**
	 *  Sets the flag whether the value will be toggled when double clicking on the editor part. By default, it is true.
	 *  Only ListComboBox and TableComboBox use this flag.
	 * 
	 *  @param toggleValueOnDoubleClick the flag
	 */
	public void setToggleValueOnDoubleClick(boolean toggleValueOnDoubleClick) {
	}

	public void setHorizontalAlignment(int alignment) {
	}

	public int getHorizontalAlignment() {
	}

	public int getVerticalAlignment() {
	}

	public void setVerticalAlignment(int alignment) {
	}

	@java.lang.Override
	public void setBorder(javax.swing.border.Border border) {
	}

	/**
	 *  Checks if the popup panel should be stretched to be the same width as the ComboBox. By default, if this is a
	 *  ListComboBox, TableComboBox or TreeComboBox, this is default to true. For ColorComboBox, DateComboBox etc, it is
	 *  false by default.
	 * 
	 *  @return true or false.
	 */
	public boolean isStretchToFit() {
	}

	/**
	 *  Sets the flag if the popup panel should be stretched to be the same width as the ComboBox. By default, if this is
	 *  a ListComboBox, TableComboBox or TreeComboBox, this is default to true. For ColorComboBox, DateComboBox etc, it
	 *  is false by default.
	 * 
	 *  @param stretchToFit true or false.
	 */
	public void setStretchToFit(boolean stretchToFit) {
	}

	/**
	 *  Gets the default OK action for the OK button on the drop down panel, if needed. You can use this method when
	 *  creating the PopupPanel such as new FontChooserPanel(getDefaultOKAction(), getDefaultCancelAction()) in
	 *  createPopupComponent() method of the FontComboBox.
	 * 
	 *  @return the default OK action for the OK button on the drop down panel, if needed.
	 */
	protected javax.swing.AbstractAction getDefaultOKAction() {
	}

	/**
	 *  Gets the default Cancel action for the Cancel button on the drop down panel, if needed. You can use this method
	 *  when creating the PopupPanel such as new FontChooserPanel(getDefaultOKAction(), getDefaultCancelAction()) in
	 *  createPopupComponent() method of the FontComboBox.
	 * 
	 *  @return the default Cancel action for the Cancel button on the drop down panel, if needed.
	 */
	protected javax.swing.AbstractAction getDefaultCancelAction() {
	}

	/**
	 *  This is a flag used internally. Subclass can override it to return true or false. If true, it tells the
	 *  AbstractComboBox that the change on the popup panel will automatically change the editor. Otherwise it is false.
	 * 
	 *  @return true or false.
	 */
	protected boolean isUpdateFromPopupOnFly() {
	}

	/**
	 *  Gets the background color when the combobox is disabled.
	 * 
	 *  @return the background color when the combobox is disabled.
	 */
	public java.awt.Color getDisabledBackground() {
	}

	/**
	 *  Sets the background color when the combobox is disabled.
	 * 
	 *  @param disabledBackground the background color when the combobox is disabled.
	 */
	public void setDisabledBackground(java.awt.Color disabledBackground) {
	}

	/**
	 *  Gets the foreground color when the combobox is disabled.
	 * 
	 *  @return the foreground color when the combobox is disabled.
	 */
	public java.awt.Color getDisabledForeground() {
	}

	/**
	 *  Sets the foreground color when the combobox is disabled.
	 * 
	 *  @param disabledForeground the foreground color when the combobox is disabled.
	 */
	public void setDisabledForeground(java.awt.Color disabledForeground) {
	}

	@java.lang.Override
	public java.awt.Color getBackground() {
	}

	@java.lang.Override
	public java.awt.Color getForeground() {
	}

	/**
	 *  Checks if the popup size is kept when the popup is shown again. By default, the popup size is already reset to
	 *  the popup's preferred size. However in some AbstractComboBoxes, user can resize the popup. This flag will control
	 *  if the popup keeps the size after user resizes.
	 * 
	 *  @return true or false.
	 */
	public boolean isKeepPopupSize() {
	}

	/**
	 *  Sets the flag if the popup size should be kept.
	 * 
	 *  @param keepPopupSize true or false.
	 */
	public void setKeepPopupSize(boolean keepPopupSize) {
	}

	/**
	 *  Default EditorComponent which has a text field. It's actually a JPanel with BorderLayout. A JTextField is added
	 *  to the CENTER. Usually this is good enough for most editing purpose. However if you want, you can add more
	 *  components to EAST or WEST of the BorderLayout. For example, ColorEditorComponent adds a component to the WEST to
	 *  actually show the color.
	 *  <p/>
	 *  {@link #getEditorComponent()} will return the JTextField.
	 *  <p/>
	 *  Subclass can override {@link #registerKeys(javax.swing.JComponent)} to register additional keystrokes. The base
	 *  class used it to register ALT-DOWN key to show the popup.
	 */
	public class DefaultTextFieldEditorComponent {


		protected javax.swing.JTextField _textField;

		/**
		 *  Creates a DefaultTextFieldEditorComponent.
		 * 
		 *  @param clazz class type which this editor can handle.
		 */
		public AbstractComboBox.DefaultTextFieldEditorComponent(Class clazz) {
		}

		@java.lang.Override
		public void setFont(java.awt.Font font) {
		}

		public void insertUpdate(javax.swing.event.DocumentEvent e) {
		}

		public void removeUpdate(javax.swing.event.DocumentEvent e) {
		}

		public void changedUpdate(javax.swing.event.DocumentEvent e) {
		}

		/**
		 *  Overrides it so that no one can set opaque to false on this component.
		 * 
		 *  @return always returns true.
		 */
		@java.lang.Override
		public boolean isOpaque() {
		}

		@java.lang.Override
		public void updateUI() {
		}

		public java.awt.Component getEditorComponent() {
		}

		public void selectAll() {
		}

		public void addActionListener(java.awt.event.ActionListener l) {
		}

		public void removeActionListener(java.awt.event.ActionListener l) {
		}

		@java.lang.Override
		public String getText() {
		}

		@java.lang.Override
		public void setText(String text) {
		}

		@java.lang.Override
		public void setEditable(boolean editable) {
		}

		@java.lang.Override
		public boolean isEditable() {
		}

		@java.lang.Override
		public void setForeground(java.awt.Color fg) {
		}

		@java.lang.Override
		public void requestFocus() {
		}

		@java.lang.Override
		public boolean requestFocusInWindow() {
		}

		@java.lang.Override
		public int getHorizontalAlignment() {
		}

		@java.lang.Override
		public void setHorizontalAlignment(int alignment) {
		}
	}

	public class DefaultRendererComponent {


		protected javax.swing.CellRendererPane _rendererPane;

		/**
		 *  Creates a DefaultRendererComponent.
		 * 
		 *  @param clazz class type which this editor can handle.
		 */
		public AbstractComboBox.DefaultRendererComponent(Class clazz) {
		}

		@java.lang.Override
		public java.awt.Dimension getPreferredSize() {
		}

		@java.lang.Override
		protected void paintComponent(java.awt.Graphics g) {
		}

		/**
		 *  Paint renderer pane to an appropriate place.
		 * 
		 *  @param g the Graphics instance
		 *  @param c the component
		 */
		protected void paintRendererPane(java.awt.Graphics g, java.awt.Component c) {
		}

		public java.awt.Component getEditorComponent() {
		}

		public void selectAll() {
		}

		public void addActionListener(java.awt.event.ActionListener l) {
		}

		public void removeActionListener(java.awt.event.ActionListener l) {
		}

		@java.lang.Override
		public String getText() {
		}

		@java.lang.Override
		public void setText(String text) {
		}

		@java.lang.Override
		public void setEditable(boolean editable) {
		}

		@java.lang.Override
		public boolean isEditable() {
		}

		@java.lang.Override
		public int getHorizontalAlignment() {
		}

		@java.lang.Override
		public void setHorizontalAlignment(int horizontalAlignment) {
		}

		@java.lang.Override
		public int getVerticalAlignment() {
		}

		@java.lang.Override
		public void setVerticalAlignment(int verticalAlignment) {
		}
	}

	/**
	 *  Default EditorComponent which has a text field. It's actually a JPanel with BorderLayout. A JTextField is added
	 *  to the CENTER. Usually this is good enough for most editing purpose. However if you want, you can add more
	 *  components to EAST or WEST of the BorderLayout. For example, ColorEditorComponent adds a component to the WEST to
	 *  actually show the color.
	 *  <p/>
	 *  {@link #getEditorComponent()} will return the JTextField.
	 *  <p/>
	 *  Subclass can override {@link #registerKeys(javax.swing.JComponent)} to register additional keystrokes. The base
	 *  class used it to register ALT-DOWN key to show the popup.
	 */
	public class SpinnerEditorComponent {


		protected javax.swing.JSpinner _spinner;

		/**
		 *  Creates a DefaultTextFieldEditorComponent.
		 * 
		 *  @param clazz class type which this editor can handle.
		 */
		public AbstractComboBox.SpinnerEditorComponent(Class clazz) {
		}

		@java.lang.Override
		public void setFont(java.awt.Font font) {
		}

		public void insertUpdate(javax.swing.event.DocumentEvent e) {
		}

		public void removeUpdate(javax.swing.event.DocumentEvent e) {
		}

		public void changedUpdate(javax.swing.event.DocumentEvent e) {
		}

		/**
		 *  Overrides it so that no one can set opaque to false on this component.
		 * 
		 *  @return always returns true.
		 */
		@java.lang.Override
		public boolean isOpaque() {
		}

		@java.lang.Override
		public void updateUI() {
		}

		public java.awt.Component getEditorComponent() {
		}

		public void selectAll() {
		}

		public void addActionListener(java.awt.event.ActionListener l) {
		}

		public void removeActionListener(java.awt.event.ActionListener l) {
		}

		@java.lang.Override
		public String getText() {
		}

		@java.lang.Override
		public void setText(String text) {
		}

		@java.lang.Override
		public void setEditable(boolean editable) {
		}

		@java.lang.Override
		public boolean isEditable() {
		}

		@java.lang.Override
		public void setForeground(java.awt.Color fg) {
		}

		@java.lang.Override
		public void requestFocus() {
		}

		@java.lang.Override
		public boolean requestFocusInWindow() {
		}

		@java.lang.Override
		public int getHorizontalAlignment() {
		}

		@java.lang.Override
		public void setHorizontalAlignment(int alignment) {
		}

		protected javax.swing.JFormattedTextField getTextField() {
		}
	}

	public static class ComboBoxSpinner {


		public AbstractComboBox.ComboBoxSpinner() {
		}

		@java.lang.Override
		public boolean processKeyBinding(javax.swing.KeyStroke ks, java.awt.event.KeyEvent e, int condition, boolean pressed) {
		}
	}

	/**
	 *  The EditorComponent is the one that used as editor. If you want to create your own EditorComponent that can be
	 *  used in AbstractComboBox, you should always extend this class. EditorComponent is actually a JPanel. So you
	 *  create whatever component you want to use it as editor and add it using BorderLayout to this EditorComponent. For
	 *  example, the code below creates a JTextField as editor and add it to the EditorComponent. You can put this code
	 *  in the constructor.
	 *  <code><pre>
	 *  if (LookAndFeelFactory.isLnfInUse(LookAndFeelFactory.AQUA_LNF)) {
	 *      setLayout(new BorderLayout(0, 0));
	 *  }
	 *  else {
	 *      setLayout(new BorderLayout(2, 2));
	 *      setBorder(BorderFactory.createEmptyBorder(0, 2, 0, 2));
	 *  }
	 *  _textField = createTextField();
	 *  if (!LookAndFeelFactory.isLnfInUse(LookAndFeelFactory.AQUA_LNF)
	 *  || AbstractComboBox.this.getClientProperty(CLIENT_PROPERTY_TABLE_CELL_EDITOR ||
	 *  AbstractComboBox.this.getClientProperty(CLIENT_PROPERTY_TABLE_CELL_RENDERER) instanceof TableCellRenderer)
	 *  instanceof CellEditor) {
	 *      _textField.setBorder(BorderFactory.createEmptyBorder());
	 *  }
	 *  add(_textField, BorderLayout.CENTER);
	 *  </pre></code>
	 *  It has nothing but a value. Subclass should implement stringToObject which can convert from the text to the
	 *  actual value.
	 */
	public abstract class EditorComponent {


		protected Class _class;

		protected Object _value;

		/**
		 *  Constructs an EditorComponent for a specified type.
		 * 
		 *  @param clazz the type
		 */
		public AbstractComboBox.EditorComponent(Class clazz) {
		}

		/**
		 *  Gets the text. Since subclass can use different components to edit text, this method will provide a common
		 *  interface to retrieve text from those different components.
		 * 
		 *  @return the text.
		 */
		public abstract String getText() {
		}

		/**
		 *  Sets the text.  Since subclass can use different components to edit text, this method will provide a common
		 *  interface to set text to those different components.
		 * 
		 *  @param text the text
		 */
		public abstract void setText(String text) {
		}

		/**
		 *  Sets the editable attribute. Since subclass can use different components to edit text, this method will
		 *  provide a common interface to change editable attribute to those different components.
		 * 
		 *  @param editable true or false.
		 */
		public abstract void setEditable(boolean editable) {
		}

		/**
		 *  Gets the editable attribute. Since subclass can use different components to edit text, this method will
		 *  provide a common interface to check editable attribute for those different components.
		 * 
		 *  @return true if the editor component is editable
		 */
		public abstract boolean isEditable() {
		}

		/**
		 *  Gets the item (aka value) from this editor component.
		 *  <p/>
		 *  The implementation in base class did the conversion from text that is displayed in the JTextField to the
		 *  Object that is clazz type using ObjectConverterManager. If you want to do your own conversion, you should
		 *  override this method.
		 * 
		 *  @return the item from this editor component.
		 */
		public Object getItem() {
		}

		/**
		 *  Converts the value to string so that it can display in text field.
		 * 
		 *  @param value the value to be converted to string
		 *  @return the string representation of the value.
		 */
		protected String convertElementToString(Object value) {
		}

		/**
		 *  Converts string to a value.
		 * 
		 *  @param text the text to be converted to element
		 *  @return the value.
		 */
		protected Object convertStringToElement(String text) {
		}

		/**
		 *  Sets the item (aka value) of the editor component. Subclass can override this method to set the value other
		 *  components. For example ColorEditorComponent has a color component which displays the actual color. So it
		 *  overrides this method and set the value (which is a Color) to the color component.
		 *  <p/>
		 *  The implementation in base class did the conversion from Object to the text that will be displayed in the
		 *  JTextField using ObjectConverterManager. If you want to do your own conversion, you should override this
		 *  method too.
		 * 
		 *  @param value the new value
		 */
		public void setItem(Object value) {
		}

		protected void textChanged() {
		}

		protected void registerKeys(javax.swing.JComponent component) {
		}

		/**
		 *  Gets the default preferred size {100, 18}.
		 * 
		 *  @return preferred size
		 */
		@java.lang.Override
		public java.awt.Dimension getPreferredSize() {
		}

		public int getHorizontalAlignment() {
		}

		public void setHorizontalAlignment(int alignment) {
		}

		public int getVerticalAlignment() {
		}

		public void setVerticalAlignment(int alignment) {
		}
	}

	/**
	 *  This class implements accessibility support for the <code>JComboBox</code> class.  It provides an implementation
	 *  of the Java Accessibility API appropriate to Combo Box user-interface elements.
	 *  <p/>
	 *  <strong>Warning:</strong> Serialized objects of this class will not be compatible with future Swing releases. The
	 *  current serialization support is appropriate for short term storage or RMI between applications running the same
	 *  version of Swing.  As of 1.4, support for long term storage of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package. Please see {@link java.beans.XMLEncoder}.
	 */
	protected class AccessibleJComboBox {


		protected AbstractComboBox.AccessibleJComboBox() {
		}

		/**
		 *  Returns the number of accessible children in the object.  If all of the children of this object implement
		 *  Accessible, than this method should return the number of children of this object.
		 * 
		 *  @return the number of accessible children in the object.
		 */
		@java.lang.Override
		public int getAccessibleChildrenCount() {
		}

		/**
		 *  Returns the nth Accessible child of the object. The child at index zero represents the popup. If the combo
		 *  box is editable, the child at index one represents the editor.
		 * 
		 *  @param i zero-based index of child
		 *  @return the nth Accessible child of the object
		 */
		@java.lang.Override
		public javax.accessibility.Accessible getAccessibleChild(int i) {
		}

		/**
		 *  Get the role of this object.
		 * 
		 *  @return an instance of AccessibleRole describing the role of the object
		 * 
		 *  @see javax.accessibility.AccessibleRole
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleRole getAccessibleRole() {
		}

		/**
		 *  Get the AccessibleAction associated with this object.  In the implementation of the Java Accessibility API
		 *  for this class, return this object, which is responsible for implementing the AccessibleAction interface on
		 *  behalf of itself.
		 * 
		 *  @return this object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleAction getAccessibleAction() {
		}

		/**
		 *  Return a description of the specified _action of the object.
		 * 
		 *  @param i zero-based index of the actions
		 *  @return description.
		 */
		public String getAccessibleActionDescription(int i) {
		}

		/**
		 *  Returns the number of Actions available in this object.  The default behavior of a combo box is to have one
		 *  _action.
		 * 
		 *  @return 1, the number of Actions in this object.
		 */
		public int getAccessibleActionCount() {
		}

		/**
		 *  Perform the specified Action on the object.
		 * 
		 *  @param i zero-based index of actions.
		 *  @return true if the the _action was performed; else false.
		 */
		public boolean doAccessibleAction(int i) {
		}

		/**
		 *  Get the AccessibleSelection associated with this object.  In the implementation of the Java Accessibility API
		 *  for this class, return this object, which is responsible for implementing the AccessibleSelection interface
		 *  on behalf of itself.
		 * 
		 *  @return this object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleSelection getAccessibleSelection() {
		}

		/**
		 *  Returns the number of Accessible children currently selected. If no children are selected, the return value
		 *  will be 0.
		 * 
		 *  @return the number of items currently selected.
		 */
		public int getAccessibleSelectionCount() {
		}

		/**
		 *  Returns an Accessible representing the specified selected child in the popup.  If there isn't a selection, or
		 *  there are fewer children selected than the integer passed in, the return value will be null. <p>Note that the
		 *  index represents the i-th selected child, which is different from the i-th child.
		 * 
		 *  @param i the zero-based index of selected children
		 *  @return the i-th selected child
		 * 
		 *  @see #getAccessibleSelectionCount
		 */
		public javax.accessibility.Accessible getAccessibleSelection(int i) {
		}

		/**
		 *  Determines if the current child of this object is selected.
		 * 
		 *  @param i the zero-based index of the child in this Accessible object.
		 *  @return true if the current child of this object is selected; else false
		 * 
		 *  @see javax.accessibility.AccessibleContext#getAccessibleChild
		 */
		public boolean isAccessibleChildSelected(int i) {
		}

		/**
		 *  Adds the specified Accessible child of the object to the object's selection.  If the object supports multiple
		 *  selections, the specified child is added to any existing selection, otherwise it replaces any existing
		 *  selection in the object.  If the specified child is already selected, this method has no effect.
		 * 
		 *  @param i the zero-based index of the child
		 *  @see javax.accessibility.AccessibleContext#getAccessibleChild
		 */
		public void addAccessibleSelection(int i) {
		}

		/**
		 *  Removes the specified child of the object from the object's selection.  If the specified item isn't currently
		 *  selected, this method has no effect.
		 * 
		 *  @param i the zero-based index of the child
		 *  @see javax.accessibility.AccessibleContext#getAccessibleChild
		 */
		public void removeAccessibleSelection(int i) {
		}

		/**
		 *  Clears the selection in the object, so that no children in the object are selected.
		 */
		public void clearAccessibleSelection() {
		}

		/**
		 *  Causes every child of the object to be selected if the object supports multiple selections.
		 */
		public void selectAllAccessibleSelection() {
		}
	}

	protected class LazyDelegateAction {


		protected javax.swing.KeyStroke _keyStroke;

		public AbstractComboBox.LazyDelegateAction(javax.swing.KeyStroke keyStroke) {
		}

		@java.lang.Override
		public boolean delegateActionPerformed(java.awt.event.ActionEvent e) {
		}
	}

	protected class EnterLazyDelegateAction {


		public AbstractComboBox.EnterLazyDelegateAction(javax.swing.KeyStroke keyStroke) {
		}

		@java.lang.Override
		public boolean delegateActionPerformed(java.awt.event.ActionEvent e) {
		}
	}

	public static class ComboBoxTextField {


		public AbstractComboBox.ComboBoxTextField() {
		}

		@java.lang.Override
		public boolean processKeyBinding(javax.swing.KeyStroke ks, java.awt.event.KeyEvent e, int condition, boolean pressed) {
		}
	}
}
