/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>FileChooserComboBox</code> is a combination of text field and a button. You can type in file name directly into
 *  the text field. or you can press the button which will popup a FileChooser dialog to choose a file.
 */
public class FileChooserComboBox extends AbstractFileComboBox {

	/**
	 *  Creates a new <code>ColorComboBox</code>.
	 */
	public FileChooserComboBox() {
	}

	/**
	 *  Creates the popup panel. It simply return a FileChooserPanel. If you want to popup your own panel, you can
	 *  override this method in its subclass and return your own FileChooserPanel.
	 * 
	 *  @return the popup panel.
	 */
	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	public java.io.File getCurrentDirectory() {
	}

	public void setCurrentDirectory(java.io.File currentDirectory) {
	}

	public String getCurrentDirectoryPath() {
	}

	public void setCurrentDirectoryPath(String currentDirectoryPath) {
	}
}
