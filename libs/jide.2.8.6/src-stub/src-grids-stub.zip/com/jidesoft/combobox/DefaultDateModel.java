/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  Default implementation of DateModel.
 */
public class DefaultDateModel implements DateModel {
 {

	/**
	 *  DateFilter for week day only. It will return false when it's weekend and true otherwise.
	 */
	public static final DateFilter WEEKDAY_ONLY;

	/**
	 *  DateFilter for this week only. It will return true if the date passed in is the same week as today, and false
	 *  otherwise.
	 */
	public static final DateFilter THIS_WEEK;

	/**
	 *  DateFilter for this week only. It will return true if the date passed in is the same month as today, and false
	 *  otherwise.
	 */
	public static final DateFilter THIS_MONTH_ONLY;

	/**
	 *  DateFilter for this week only. It will return true if the date passed in is the same month but after today, and
	 *  false otherwise.
	 */
	public static final DateFilter LATER_THIS_MONTH;

	/**
	 *  DateFilter for weekend only. It will return true when it's weekend and false otherwise.
	 */
	public static final DateFilter WEEKEND_ONLY;

	/**
	 *  DateFilter for this year only. It will return true if the date passed in is the same year as today, and false
	 *  otherwise.
	 */
	public static final DateFilter THIS_YEAR_ONLY;

	/**
	 *  DateFilter for next year only. It will return true if the date passed in is the next year of today, and false
	 *  otherwise.
	 */
	public static final DateFilter NEXT_YEAR_ONLY;

	/**
	 *  DateFilter for next year only. It will return true if the date passed in is the next year of today, and false
	 *  otherwise.
	 */
	public static final DateFilter PREVIOUS_YEAR_ONLY;

	/**
	 *  Constructs a DefaultDateModel.
	 */
	public DefaultDateModel() {
	}

	/**
	 *  Constructs a DefaultDateModel with specified minDate and maxDate.
	 * 
	 *  @param minDate
	 *  @param maxDate
	 */
	public DefaultDateModel(java.util.Calendar minDate, java.util.Calendar maxDate) {
	}

	public java.util.Calendar getMinDate() {
	}

	public void setMinDate(java.util.Calendar minDate) {
	}

	public java.util.Calendar getMaxDate() {
	}

	public void setMaxDate(java.util.Calendar maxDate) {
	}

	public boolean dayInRange(java.util.Calendar calendar) {
	}

	public boolean monthInRange(java.util.Calendar calendar) {
	}

	public boolean yearInRange(java.util.Calendar calendar) {
	}

	/**
	 *  Clear the DateFilter list.
	 */
	public void clearDateFilters() {
	}

	/**
	 *  Adds a DateFilter.
	 * 
	 *  @param filter
	 */
	public void addDateFilter(DateFilter filter) {
	}

	/**
	 *  Remove the DateFilter.
	 * 
	 *  @param filter
	 */
	public void removeDateFilter(DateFilter filter) {
	}

	/**
	 *  Check if the date is a valid date.
	 * 
	 *  @param calendar
	 *  @return true if the date is not in invalid dates list and passed all date filters and in the range of minDate -
	 *          maxDate.
	 */
	public boolean isValidDate(java.util.Calendar calendar) {
	}

	/**
	 *  Clear whatever invalid dates added before.
	 */
	public void clearInvalidDates() {
	}

	/**
	 *  Adds an invalid date.
	 * 
	 *  @param date
	 */
	public void addInvalidDate(java.util.Calendar date) {
	}

	/**
	 *  Removes an invalid date.
	 * 
	 *  @param date
	 */
	public void removeInvalidDate(java.util.Calendar date) {
	}

	public String getTimeFormat() {
	}

	public void setTimeFormat(String timeFormat) {
	}

	public java.util.TimeZone getTimeZone() {
	}

	public void setTimeZone(java.util.TimeZone timeZone) {
	}

	public java.text.DateFormat getDateFormat() {
	}

	public void setDateFormat(java.text.DateFormat dateFormat) {
	}

	/**
	 *  Creates a new Calendar instance that will be used internally.
	 * 
	 *  @return a Calendar instance.
	 */
	public java.util.Calendar createCalendarInstance() {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the date model occurs. We will not add the
	 *  listener if it is already added.
	 * 
	 *  @param l the DateModelListener
	 */
	public void addDateModelListener(DateModelListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the date model occurs.
	 * 
	 *  @param l the DateModelListener
	 */
	public void removeDateModelListener(DateModelListener l) {
	}

	/**
	 *  Returns an array of all the date model listeners registered on this model.
	 * 
	 *  @return all of this model's <code>DateModelListener</code>s or an empty array if no date model listeners are
	 *          currently registered
	 */
	public DateModelListener[] getDateModelListeners() {
	}

	/**
	 *  Fires the DateModelEvent.
	 * 
	 *  @param e
	 */
	public void fireDateModelChanged(DateModelEvent e) {
	}
}
