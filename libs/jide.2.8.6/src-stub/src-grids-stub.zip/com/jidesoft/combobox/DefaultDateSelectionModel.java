/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  Default data model for DateSelectionModel.
 * 
 *  @see DateSelectionModel
 */
public class DefaultDateSelectionModel implements DateSelectionModel {
 {

	public DefaultDateSelectionModel() {
	}

	public DefaultDateSelectionModel(int mode) {
	}

	public void addSelectionInterval(java.util.Date date0, java.util.Date date1) {
	}

	public void setSelectionInterval(java.util.Date date0, java.util.Date date1) {
	}

	public void clearSelection() {
	}

	public boolean isSelectedDate(java.util.Date date) {
	}

	public boolean isSelectionEmpty() {
	}

	public void removeSelectionInterval(java.util.Date date0, java.util.Date date1) {
	}

	public synchronized void addDateSelectionListener(DateSelectionListener listener) {
	}

	public synchronized void removeDateSelectionListener(DateSelectionListener listener) {
	}

	@java.lang.Override
	public Object clone() {
	}

	public int getSelectionMode() {
	}

	public void setSelectionMode(int selectionMode) {
	}

	public java.util.Date getLeadSelectionDate() {
	}

	public void setLeadSelectionDate(java.util.Date date) {
	}

	public java.util.Date getAnchorSelectionDate() {
	}

	public void setAnchorSelectionDate(java.util.Date date) {
	}

	public void setValueIsAdjusting(boolean b) {
	}

	public boolean getValueIsAdjusting() {
	}

	public java.util.Date getSelectedDate() {
	}

	public void setSelectedDate(java.util.Date date) {
	}

	public java.util.Date[] getSelectedDates() {
	}

	public void setSelectedDates(java.util.Date[] dates) {
	}
}
