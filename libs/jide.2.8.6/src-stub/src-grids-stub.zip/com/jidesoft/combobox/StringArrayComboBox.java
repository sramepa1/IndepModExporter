/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>StringArrayComboBox</code> is a combobox which
 *  can be used to choose a String array.
 */
public class StringArrayComboBox extends AbstractComboBox {

	public StringArrayComboBox() {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	public void setArray(String[] array) {
	}

	public String[] getArray() {
	}
}
