/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>ButtonPopupPanel</code> provides a button panel which has OK and Cancel button. Usually when mouse clicks on
 *  popup panel, selection changes and the popup will disappear. However there are cases that a selection needs several
 *  mouse clicks. There is no clear indication of the selection is done unless user presses OK button.
 *  <p/>
 *  This class provides a method called createButtonPanel(). Subclasses can call it to create a button panel and add it
 *  wherever appropriate. By default, it will add a partial sunken border to button panel. Since you have the button
 *  panel, you can set whatever border you want if you don't like the default border.
 */
public abstract class ButtonPopupPanel extends PopupPanel {

	protected javax.swing.JButton _okButton;

	protected javax.swing.JButton _cancelButton;

	protected javax.swing.Action _okAction;

	protected javax.swing.Action _cancelAction;

	public ButtonPopupPanel() {
	}

	protected ButtonPopupPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public void setOkAction(javax.swing.Action okAction) {
	}

	public javax.swing.Action getOkAction() {
	}

	public javax.swing.JButton getOkButton() {
	}

	public javax.swing.Action getCancelAction() {
	}

	public void setCancelAction(javax.swing.Action cancelAction) {
	}

	public java.awt.Component createButtonPanel(int alignment) {
	}
}
