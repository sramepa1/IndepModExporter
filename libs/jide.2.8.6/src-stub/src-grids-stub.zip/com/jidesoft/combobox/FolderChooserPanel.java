/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  FolderChooserPanel is a popup panel that can choose a folder.
 */
public class FolderChooserPanel extends PopupPanel {

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer
	 *  and a flow layout.
	 */
	public FolderChooserPanel() {
	}

	public FolderChooserPanel(String currentDirectoryPath) {
	}

	protected void initComponents() {
	}

	public String getCurrentDirectoryPath() {
	}

	public void setCurrentDirectoryPath(String currentDirectoryPath) {
	}

	protected javax.swing.JComponent createFolderChooserPanel() {
	}

	protected FolderChooser createFolderChooser() {
	}

	@java.lang.Override
	public boolean needsButtons() {
	}
}
