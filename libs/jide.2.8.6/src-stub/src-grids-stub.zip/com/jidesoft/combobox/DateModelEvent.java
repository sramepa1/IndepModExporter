/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  DateModelEvent is an event to indicate changes in DateModel.
 */
public class DateModelEvent extends java.util.EventObject {

	/**
	 *  An event id to indicate invalid date changed.
	 */
	public static final int INVALID_DATE_CHANGED = 0;

	/**
	 *  An event id to indicate date filter changed.
	 */
	public static final int DATE_FILTER_CHANGED = 1;

	/**
	 *  An event id to indicate date range changed.
	 */
	public static final int DATE_RANGE_CHANGED = 2;

	/**
	 *  Constructs a <code>DateModelEvent</code> object with the
	 *  specified source component.
	 * 
	 *  @param source
	 */
	public DateModelEvent(Object source) {
	}

	/**
	 *  Constructs a <code>DateModelEvent</code> object with the
	 *  specified source component and type.
	 * 
	 *  @param source
	 *  @param type
	 */
	public DateModelEvent(Object source, int type) {
	}

	/**
	 *  Gets the type of the event.
	 * 
	 *  @return the type of the event.
	 */
	public int getType() {
	}

	/**
	 *  Sets the type of the event.
	 * 
	 *  @param type
	 */
	public void setType(int type) {
	}
}
