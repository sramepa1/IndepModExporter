/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  Still in development.
 */
public class DateSpinnerComboBox extends DateComboBox {

	public DateSpinnerComboBox() {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	@java.lang.Override
	protected javax.swing.JSpinner createSpinner() {
	}

	@java.lang.Override
	public void setFormat(java.text.DateFormat format) {
	}

	/**
	 *  EditorComponent for DateComboBox when it is not readonly.
	 */
	public class DateSpinnerEditorComponent {


		/**
		 *  Constructs a new <code>TextField</code>.  A default model is created, the initial string is
		 *  <code>null</code>, and the number of columns is set to 0.
		 * 
		 *  @param clazz
		 */
		public DateSpinnerComboBox.DateSpinnerEditorComponent(Class clazz) {
		}

		@java.lang.Override
		public Object getItem() {
		}

		@java.lang.Override
		public void setItem(Object value) {
		}
	}
}
