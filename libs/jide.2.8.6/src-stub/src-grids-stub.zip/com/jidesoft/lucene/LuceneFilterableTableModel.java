/**
 *  The package contains classes related to Lucene for JIDE Grids product.
 */
package com.jidesoft.lucene;


/**
 *  <code>LuceneFilterableTableModel</code> is a table model which wraps another table model, not including tree table
 *  model, so that user can apply filters on it, the filter is working on Lucene mode, which means we will use Lucene Jar
 *  to create indexing for the entire table data once you pass the table model in as a parameter or it receives table
 *  data change event.
 *  <p/>
 *  Comparing with <code>FilterableTableModel</code>, <code>LuceneFilterableTableModel</code> has higher performance at
 *  filtering part and has more text search options based on Lucene syntax. So if you have a large table and you don't
 *  expect your customer to refresh the data of the table very frequently, you can consider using
 *  <code>LuceneFilterableTableModel</code> instead of <code>FilterableTableModel</code>. However, if you are expecting
 *  your customer refresh the data very frequently or you have a lot of columns with Number class, you probably better
 *  use <code>FilterableTableModel</code>.
 *  <p/>
 *  Please be noted that <code>LuceneFilterableTableModel</code> does not support TreeTableModel.
 *  <p/>
 *  It's not recommended to wrap two LuceneFilterableTableModel in one model wrapper chain. Because it will consumes
 *  twice memory than necessary.
 *  <p/>
 *  There are two ways to add a filter. One is to add a filter to apply to all the values in the table model using {@link
 *  #addFilter(com.jidesoft.filter.Filter)}. Or you can add filter to a particular column using {@link #addFilter(int,
 *  com.jidesoft.filter.Filter)}.
 *  <p/>
 *  By default, filters won't take effect immediately. You need to call <code>setFiltersApplied(true)</code> to apply
 *  those filters. If <code>filtersApplied</code> flag is true already, you just need to call refresh(). We don't refresh
 *  automatically because you might have several filters to add. You can add all of them, then only call refresh once.
 *  <code>setFiltersApplied(int)</code> will control all the filters. Each filter has its own enabled flag which will
 *  control each individual filter.
 */
public class LuceneFilterableTableModel extends com.jidesoft.grid.FilterableTableModel implements LuceneDocumentProvider {
 {

	/**
	 *  Creates a LuceneFilterableTableModel from any table model.
	 * 
	 *  @param model the table model that has the data before filtering.
	 */
	public LuceneFilterableTableModel(javax.swing.table.TableModel model) {
	}

	public Document getDocument(int rowIndex) {
	}

	public int getDocumentCount() {
	}

	public void notifyIndexCreated() {
	}

	@java.lang.Override
	protected void tableDataChanged() {
	}

	@java.lang.Override
	protected void tableStructureChanged() {
	}

	@java.lang.Override
	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected java.util.List getReservedRows(int firstRow, int lastRow) {
	}

	/**
	 *  Applies filters and generates a new array of indices.
	 * 
	 *  @param filterAllData if this run of filter have to go through all the rows
	 */
	@java.lang.Override
	protected void filter(boolean filterAllData) {
	}

	/**
	 *  Convert Filter to Query text.
	 *  <p/>
	 *  In AutoFilterTableHeader scenario, we will call this method to convert filter to query, if we can get a valid
	 *  Query instance, we can gain the performance by using lucene mechanism. Otherwise we will go back to traditional
	 *  FilterableTableModel.
	 *  <p/>
	 *  So far we only converted SingleValueFilter and MultipleValuesFilter in eachColumnFilter to Query instances. You
	 *  can convert your desired filter to query as you wish. If you think you cannot convert the filter you encounter,
	 *  you'd better return null. Otherwise, you probably will lose some effect from the lost filter.
	 *  <p/>
	 *  Please be notd that you don't have to add bracket in the outer most but you need add bracket inside this filter.
	 * 
	 *  @param columnIndex the index of the column the filter is going to apply
	 *  @param filter      the filter
	 *  @return null if you think this filter is not able to converted to query text in some cases. "" if you want to
	 *          ignore the filter. Otherwise return a valid string.
	 */
	protected String convertFilterToLuceneQueryText(int columnIndex, com.jidesoft.filter.Filter filter) {
	}

	@java.lang.Override
	public void fireFilterChanged(com.jidesoft.grid.FilterableTableModelEvent e) {
	}

	public LuceneSupport getLuceneSupport() {
	}

	public void setLuceneSupport(LuceneSupport luceneSupport) {
	}

	/**
	 *  Get the max clause count configuration for BooleanQuery
	 * 
	 *  @return the value.
	 */
	public int getBooleanQueryMaxClauseCount() {
	}

	/**
	 *  Set the max clause count configuration for BooleanQuery
	 * 
	 *  @param booleanQueryMaxClauseCount the value
	 */
	public void setBooleanQueryMaxClauseCount(int booleanQueryMaxClauseCount) {
	}

	/**
	 *  Get if the boundary value should be included in RangeQuery
	 * 
	 *  @return true if inclusive. Otherwise false.
	 */
	public boolean isRangeQueryInclusive() {
	}

	/**
	 *  Set if the boundary value should be included in RangeQuery
	 * 
	 *  @param rangeQueryInclusive true if inclusive. Otherwise false.
	 */
	public void setRangeQueryInclusive(boolean rangeQueryInclusive) {
	}

	/**
	 *  Get if allow the customer input leading wildcard
	 * 
	 *  @return true if allow. Otherwise false.
	 */
	public boolean isAllowLeadingWildcard() {
	}

	/**
	 *  Set if allow the customer input leading wildcard
	 * 
	 *  @param allowLeadingWildcard true if allow. Otherwise false.
	 */
	public void setAllowLeadingWildcard(boolean allowLeadingWildcard) {
	}
}
