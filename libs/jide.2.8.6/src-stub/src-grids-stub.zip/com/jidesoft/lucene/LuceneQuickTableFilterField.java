/**
 *  The package contains classes related to Lucene for JIDE Grids product.
 */
package com.jidesoft.lucene;


/**
 *  <code>LuceneQuickTableFilterField</code> works along with any TableModel except TreeTableModel to provide
 *  Lucene-equipped searching feature.
 *  <p/>
 *  It is very simple to use it.
 *  <code><pre>
 *  LuceneQuickTableFilterField field = new LuceneQuickTableFilterField(anyTableModel, new int[]{1, 2, 0,
 *  5});</pre></code>
 *  Later on, when you display the table, instead using your original table model, use {@link #getDisplayTableModel()}.
 *  <code><pre>
 *  SortableTable table = new SortableTable(field.getDisplayTableModel());
 *  </pre></code>
 *  Usually you place <code>LuceneQuickTableFilterField</code> somewhere close to the JTable in the user interface. User
 *  can type in any text in the text field, you will see the JTable automatically display the data that matches with the
 *  text.
 *  <p/>
 *  <code>LuceneQuickTableFilterField</code> has two input mode.
 *  <p/>
 *  One is normal input mode just like <code>QuickTableFilterField</code>, which allows you to choose multiple columns to
 *  search. By default, it will search for all columns. If you click on the icon before the text field, a popup menu will
 *  be shown to allow you choose which columns to search. It could be All which means it will search for all columns. You
 *  can control which columns to be listed in the popup menu using {@link #setColumnIndices(int[])}. The actual texts can
 *  be set using {@link #setDisplayNames(String[])}. You can also set a text as searching text by calling {@link
 *  #setSearchingText(String)}. In this mode, we will parse the input text for you to accommodate Lucene syntax. Since we
 *  still have to parse the input text, so some options valid in <code>QuickTableFilterField</code> like case
 *  sensitive/insensitive, wildcard flag will not valid any more.
 *  <p/>
 *  Another is Lucene input mode. In this mode, we will just pass your input text directly to lucene QueryParser, so you
 *  have to know exactly what Lucene syntax allows and not allows. We provided available input in the popup menu based on
 *  Lucene 2.4.1, so you can get limited help from the menu. We also provided an link to Lucene help documents. You can
 *  invoke {@link com.jidesoft.lucene.LuceneFilterMenuSupport#setLuceneHelpURL(String)} to change the link if you have
 *  better reference.
 *  <p/>
 *  This component has a timer. If user types very fast, it will accumulate them together and generate only one searching
 *  action. You can listen to property change event of {@link #PROPERTY_SEARCH_TEXT} to detect any text change
 *  programmatically.
 */
public class LuceneQuickTableFilterField extends com.jidesoft.grid.QuickTableFilterField implements LuceneFilterField {
 {

	/**
	 *  Creates an empty <code>LuceneQuickTableFilterField</code>. This method is useless since
	 *  <code>LuceneQuickTableFilterField</code> has to have a table model in order to work correctly. So we have this
	 *  method in place mainly to make it JavaBean compatible. You must call {@link #setTableModel(javax.swing.table.TableModel)}
	 *  after you create <code>LuceneQuickTableFilterField</code> using this constructor.
	 */
	public LuceneQuickTableFilterField() {
	}

	/**
	 *  Creates a <code>LuceneQuickTableFilterField</code> using the specified tableModel.
	 * 
	 *  @param tableModel the TableModel
	 */
	public LuceneQuickTableFilterField(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Creates a <code>LuceneQuickTableFilterField</code> using the specified tableModel.
	 * 
	 *  @param tableModel    the TableModel
	 *  @param columnIndices the columns that you want to give user an option in the popup menu to limit the search.
	 */
	public LuceneQuickTableFilterField(javax.swing.table.TableModel tableModel, int[] columnIndices) {
	}

	/**
	 *  Creates a <code>LuceneQuickTableFilterField</code> using the specified tableModel.
	 * 
	 *  @param tableModel    the TableModel
	 *  @param columnIndices the columns that you want to give user an option in the popup menu to limit the search.
	 *  @param displayNames  the text appears on the popup menu.
	 */
	public LuceneQuickTableFilterField(javax.swing.table.TableModel tableModel, int[] columnIndices, String[] displayNames) {
	}

	/**
	 *  Sets the table model used by this component. It could be any table model, not necessarily be a
	 *  FilterableTableModel.
	 * 
	 *  @param tableModel the TableModel
	 */
	@java.lang.Override
	public void setTableModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Creates LuceneFilterableTableModel which will be used by LuceneQuickTableFilterField to do the filter.
	 *  <p/>
	 *  Please be noted that so far we don't support TreeTableModel work with lucene.
	 * 
	 *  @param tableModel the actual table model.
	 *  @return an IFilterableTableModel, which has to be LuceneFilterableTableModel.
	 */
	protected com.jidesoft.grid.IFilterableTableModel createFilterableTableModel(javax.swing.table.TableModel tableModel) {
	}

	public LuceneDocumentProvider getLuceneDocumentProvider() {
	}

	@java.lang.Override
	protected JidePopupMenu createContextMenu() {
	}

	@java.lang.Override
	public void applyFilter(String text) {
	}

	public void setFromStart(boolean fromStart) {
	}

	public void setFromEnd(boolean fromEnd) {
	}

	/**
	 *  Get the flag if current input mode for JTextField is lucene input mode.
	 * 
	 *  @return the flag.
	 */
	public boolean isLuceneInputMode() {
	}

	/**
	 *  Set the flag if current input mode for JTextField is lucene input mode.
	 * 
	 *  @param luceneInputMode the flag
	 */
	public void setLuceneInputMode(boolean luceneInputMode) {
	}

	/**
	 *  Get the URL link for lucene query syntax on-line document.
	 *  <p/>
	 *  The default link is <URL>http://lucene.apache.org/java/2_4_1/queryparsersyntax.html</URL>
	 * 
	 *  @return the URL link.
	 * 
	 *  @deprecated please use {@link LuceneFilterMenuSupport#getLuceneHelpURL()} instead
	 */
	@java.lang.Deprecated
	public static String getLuceneHelpURL() {
	}

	/**
	 *  Set the URL link for lucene query syntax on-line document.
	 * 
	 *  @param luceneHelpURL the URL link
	 *  @deprecated please use {@link com.jidesoft.lucene.LuceneFilterMenuSupport#setLuceneHelpURL(String)} instead
	 */
	@java.lang.Deprecated
	public static void setLuceneHelpURL(String luceneHelpURL) {
	}
}
