/**
 *  The package contains classes related to Lucene for JIDE Grids product.
 */
package com.jidesoft.lucene;


public class LuceneResource {

	public LuceneResource() {
	}

	public static java.util.ResourceBundle getResourceBundle(java.util.Locale locale) {
	}
}
