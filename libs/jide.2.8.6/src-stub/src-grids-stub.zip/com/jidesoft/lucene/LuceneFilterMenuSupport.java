/**
 *  The package contains classes related to Lucene for JIDE Grids product.
 */
package com.jidesoft.lucene;


public class LuceneFilterMenuSupport {

	/**
	 *  Get the URL link for lucene query syntax on-line document.
	 *  <p/>
	 *  The default link is <URL>http://lucene.apache.org/java/2_4_1/queryparsersyntax.html</URL>
	 *  @return the URL link.
	 */
	public static String getLuceneHelpURL() {
	}

	/**
	 *  Set the URL link for lucene query syntax on-line document.
	 *  @param luceneHelpURL the URL link
	 */
	public static void setLuceneHelpURL(String luceneHelpURL) {
	}
}
