/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  Interface to customer a popup menu in any IDocumentPane.
 */
public interface PopupMenuCustomizer {

	/**
	 *  Allow user to customize the popup menu. Popup menu will be shown when user
	 *  right click on the tab of TdiPane or user drag a tab and drop in the middle
	 *  of a tab group. In the first case, <code>onTab</code> is true. In the second case,
	 *  <code>onTab</code> is false.
	 * 
	 *  @param menu              Popup menu to be customized
	 *  @param pane              the DocumentPane
	 *  @param dragComponentName the name of drag document
	 *  @param dropGroup         the document group
	 *  @param onTab             true if the popup menu is trigger by right click on tab
	 */
	public void customizePopupMenu(javax.swing.JPopupMenu menu, IDocumentPane pane, String dragComponentName, IDocumentGroup dropGroup, boolean onTab);
}
