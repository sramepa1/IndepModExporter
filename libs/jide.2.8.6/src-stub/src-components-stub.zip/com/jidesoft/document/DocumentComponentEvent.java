/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  Event for DocumentComponent.
 */
public class DocumentComponentEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for document component events.
	 */
	public static final int DOCUMENT_COMPONENT_FIRST = 5999;

	/**
	 *  The last number in the range of IDs used for document component events.
	 */
	public static final int DOCUMENT_COMPONENT_LAST = 6008;

	/**
	 *  The "document opened" event.  This event is delivered only the first time the document component is made
	 *  visible.
	 */
	public static final int DOCUMENT_COMPONENT_OPENED = 5999;

	/**
	 *  The "document is closing" event. This event is delivered when the user attempts to close the document component,
	 *  such as by clicking the document component's close button, or when a program attempts to close the document
	 *  component by invoking the <code>closeDocument</code> method. When you handle this event, you have a chance to
	 *  prevent it from closed by setAllowClosing to false.
	 */
	public static final int DOCUMENT_COMPONENT_CLOSING = 6000;

	/**
	 *  The "document closed" event. This event is delivered after the document component has been closed as the result
	 *  of a call to the <code>closeDocument</code>.
	 */
	public static final int DOCUMENT_COMPONENT_CLOSED = 6001;

	/**
	 *  The "document component activated" event type. This event indicates that keystrokes and mouse clicks are directed
	 *  towards this document component .
	 */
	public static final int DOCUMENT_COMPONENT_ACTIVATED = 6002;

	/**
	 *  The "document component deactivated" event type. This event indicates that keystrokes and mouse clicks are no
	 *  longer directed to the document component.
	 */
	public static final int DOCUMENT_COMPONENT_DEACTIVATED = 6003;

	/**
	 *  The "document is moving" event. This event is delivered when the user attempts to move the document component,
	 *  such as by dragging the tab of the document component and move it to somewhere else, or when a program attempts
	 *  to close the document component by invoking the <code>moveDocument</code> method. When you handle this event, you
	 *  have a chance to prevent it from moved by setAllowMoving to false.
	 */
	public static final int DOCUMENT_COMPONENT_MOVING = 6004;

	/**
	 *  The "document moved" event. This event is delivered after the document component has been moved as the result of
	 *  a call to the <code>moveDocument</code>.
	 */
	public static final int DOCUMENT_COMPONENT_MOVED = 6005;

	/**
	 *  The "document docked" event. This event is delivered after the document component is docked from the floated
	 *  state to the docked state as the result of a call to the <code>dockDocument</code>.
	 */
	public static final int DOCUMENT_COMPONENT_DOCKED = 6006;

	/**
	 *  The "document floating" event. This event is delivered after the document component is floated from the docked
	 *  state to the floated state as the result of a call to the <code>floatDocument</code>.
	 */
	public static final int DOCUMENT_COMPONENT_FLOATED = 6007;

	/**
	 *  Constructs an <code>DocumentComponentEvent</code> object.
	 * 
	 *  @param source the <code>DocumentComponent</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 */
	public DocumentComponentEvent(DocumentComponent source, int id) {
	}

	/**
	 *  Returns a parameter string identifying this event. This method is useful for event logging and for debugging.
	 * 
	 *  @return a string identifying the event and its attributes
	 */
	@java.lang.Override
	public String paramString() {
	}

	/**
	 *  Returns the originator of the event.
	 * 
	 *  @return the document associate with this event
	 */
	public DocumentComponent getDocumentComponent() {
	}
}
