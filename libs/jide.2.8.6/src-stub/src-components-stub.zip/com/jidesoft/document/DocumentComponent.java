/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  A class that represents a document object.
 */
public class DocumentComponent {

	public static final String PROPERTY_ICON = "icon";

	public static final String PROPERTY_TITLE = "title";

	public static final String PROPERTY_TOOLTIP = "tooltip";

	public static final String PROPERTY_BACKGROUND = "background";

	public static final String PROPERTY_FOREGROUND = "foreground";

	public static final String PROPERTY_COMPONENT = "component";

	public static final String PROPERTY_CLOSABLE = "closable";

	/**
	 *  Creates a DocumentComponent with component and name, but no icon.
	 * 
	 *  @param component the component of the document
	 *  @param name      the name of the document. It has to unique within the same DocumentPane. If you try to create
	 *                   two DocumentComponents with the same and try to open them in DocumentPane, only the first one
	 *                   will be opened because the name is the same. If the title is not specified, we will display the
	 *                   name on the tab. But if you specified the title, the name will never appear anywhere in the UI.
	 *                   In the other word, the name could be non-localized string and the title should be localized.
	 */
	public DocumentComponent(javax.swing.JComponent component, String name) {
	}

	/**
	 *  Creates a DocumentComponent with component, name and title, but no icon.
	 * 
	 *  @param component the component of the document
	 *  @param name      the name of the document. It has to unique within the same DocumentPane. If you try to create
	 *                   two DocumentComponents with the same and try to open them in DocumentPane, only the first one
	 *                   will be opened because the name is the same. If the title is not specified, we will display the
	 *                   name on the tab. But if you specified the title, the name will never appear anywhere in the UI.
	 *                   In the other word, the name could be non-localized string and the title should be localized.
	 *  @param title     the title of the document. It will be displayed on the tab on a DocumentPane. The title should
	 *                   be a localized string.
	 */
	public DocumentComponent(javax.swing.JComponent component, String name, String title) {
	}

	/**
	 *  Creates a DocumentComponent with component, name, title, and icon.
	 * 
	 *  @param component the component of the document
	 *  @param name      the name of the document. It has to unique within the same DocumentPane. If you try to create
	 *                   two DocumentComponents with the same and try to open them in DocumentPane, only the first one
	 *                   will be opened because the name is the same. If the title is not specified, we will display the
	 *                   name on the tab. But if you specified the title, the name will never appear anywhere in the UI.
	 *                   In the other word, the name could be non-localized string and the title should be localized.
	 *  @param title     the title of the document. It will be displayed on the tab on a DocumentPane. The title should
	 *                   be a localized string.
	 *  @param icon      the icon for the document It will be displayed on the tab on a DocumentPane.
	 */
	public DocumentComponent(javax.swing.JComponent component, String name, String title, javax.swing.Icon icon) {
	}

	/**
	 *  Gets the DocumentPane where this DocumentComponent is added to.
	 * 
	 *  @return DocumentPane whose has this DocumentComponent
	 */
	public IDocumentPane getDocumentPane() {
	}

	public void cleanup() {
	}

	/**
	 *  When this DocumentComponent is added to a DocumentPane, this method will be called.
	 * 
	 *  @param documentPane the document pane where the document component is added.
	 */
	protected void setDocumentPane(IDocumentPane documentPane) {
	}

	/**
	 *  Gets the name of the document.
	 * 
	 *  @return the name
	 */
	public String getName() {
	}

	/**
	 *  Sets the name.
	 *  <p/>
	 *  Please note, Name is passed in from constructorr of DocumentComponent. End user shouldn't call setName directly
	 *  once it is added to document pane. If you want to change the name, use {@link DocumentPane#renameDocument}.
	 * 
	 *  @param name name to be set
	 */
	public void setName(String name) {
	}

	/**
	 *  Gets the title.
	 * 
	 *  @return the title
	 */
	public String getTitle() {
	}

	/**
	 *  Sets the title.
	 * 
	 *  @param title title to be set
	 */
	public void setTitle(String title) {
	}

	/**
	 *  Gets the tooltip.
	 * 
	 *  @return the tooltip
	 */
	public String getTooltip() {
	}

	/**
	 *  Sets the tooltip.
	 * 
	 *  @param tooltip tooltip to be set
	 */
	public void setTooltip(String tooltip) {
	}

	/**
	 *  Gets the icon.
	 * 
	 *  @return the icon
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Sets the icon.
	 * 
	 *  @param icon icon to be set
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Gets the background.
	 * 
	 *  @return the background
	 */
	public java.awt.Color getBackground() {
	}

	/**
	 *  Sets the background.
	 * 
	 *  @param background background to be set
	 */
	public void setBackground(java.awt.Color background) {
	}

	/**
	 *  Gets the foreground.
	 * 
	 *  @return the foreground
	 */
	public java.awt.Color getForeground() {
	}

	/**
	 *  Sets the foreground.
	 * 
	 *  @param foreground foreground to be set
	 */
	public void setForeground(java.awt.Color foreground) {
	}

	/**
	 *  Gets the component.
	 * 
	 *  @return component
	 */
	public javax.swing.JComponent getComponent() {
	}

	/**
	 *  Sets the component.
	 * 
	 *  @param component component to be set
	 */
	public void setComponent(javax.swing.JComponent component) {
	}

	/**
	 *  The title to be displayed. By default it will return whatever getTitle() return.
	 * 
	 *  @return the display title
	 */
	public String getDisplayTitle() {
	}

	/**
	 *  Sets allow closing. If true, the document cannot be closed. user can change the value in documentComponentClosing
	 *  event to prevent document from being closed.
	 * 
	 *  @param allowClosing whether the document is allowed to be closed.
	 */
	public void setAllowClosing(boolean allowClosing) {
	}

	/**
	 *  Allow this document closing. By default it return true. User can override this method to return based on
	 *  condition. A typical user case is: add a DocumentComponentListener. In documentComponentClosing, make this method
	 *  return to false to prevent it from being closed.
	 * 
	 *  @return whether allow closing
	 */
	public boolean allowClosing() {
	}

	/**
	 *  Sets allow moving. If true, the document cannot be moved. user can change the value in documentComponentMoving
	 *  event to prevent document from being moved.
	 * 
	 *  @param allowMoving whether the document is allowed to be moved.
	 */
	public void setAllowMoving(boolean allowMoving) {
	}

	/**
	 *  Allow this document moving. By default it return true. User can override this method to return based on
	 *  condition. A typical user case is: add a DocumentComponentListener. In documentComponentMoving, make this method
	 *  return to false to prevent it from being moved.
	 * 
	 *  @return whether allow moving
	 */
	public boolean allowMoving() {
	}

	/**
	 *  Adds the specified listener to receive internal frame events from this titled frame.
	 * 
	 *  @param l the titled frame listener
	 */
	public void addDocumentComponentListener(DocumentComponentListener l) {
	}

	/**
	 *  Removes the specified titled frame listener so that it no longer receives titled frame events from this titled
	 *  frame.
	 * 
	 *  @param l the titled frame listener
	 */
	public void removeDocumentComponentListener(DocumentComponentListener l) {
	}

	/**
	 *  Returns an array of all the <code>DocumentComponentListener</code>s added to this <code>DockableFrame</code> with
	 *  <code>addDocumentComponentListener</code>.
	 * 
	 *  @return all of the <code>DocumentComponentListener</code>s added or an empty array if no listeners have been
	 *          added
	 */
	public DocumentComponentListener[] getDocumentComponentListeners() {
	}

	/**
	 *  Gets the default focus component for the document component. When the dockable frame is activated for the first
	 *  time, this component will get focus.
	 *  <p/>
	 *  See also <code>setDefaultFocusComponent</code>, <code>getLastFocusedComponent</code>,
	 *  <code>setLastFocusedComponent</code>
	 * 
	 *  @return the default component.
	 */
	public java.awt.Component getDefaultFocusComponent() {
	}

	/**
	 *  Sets the default focus component for the document component. When the dockable frame is activated for the first
	 *  time, this component will get focus.
	 *  <p/>
	 *  See also <code>getDefaultFocusComponent</code>, <code>getLastFocusedComponent</code>,
	 *  <code>setLastFocusedComponent</code>
	 * 
	 *  @param defaultFocusComponent the component which should receive focus if the document is activated for the first
	 *                               time.
	 */
	public void setDefaultFocusComponent(java.awt.Component defaultFocusComponent) {
	}

	/**
	 *  Gets the last subcomponent of the document component which held focus. When the dockable frame is reactivated
	 *  after being deactivated, this component will get focus returned to it.
	 *  <p/>
	 *  See also <code>setLastFocusedComponent</code>, <code>getDefaultFocusComponent</code>,
	 *  <code>setDefaultFocusComponent</code>
	 * 
	 *  @return the last-focused subcomponent
	 */
	public java.awt.Component getLastFocusedComponent() {
	}

	/**
	 *  Sets the subcomponent of the document component which currently has focus. When the dockable frame is reactivated
	 *  after being deactivated, this component will get focus returned to it.
	 *  <p/>
	 *  See also <code>getLastFocusedComponent</code>, <code>getDefaultFocusComponent</code>,
	 *  <code>setDefaultFocusComponent</code>
	 * 
	 *  @param lastFocusedComponent last-focused subcomponent
	 */
	protected void setLastFocusedComponent(java.awt.Component lastFocusedComponent) {
	}

	/**
	 *  Set the last focused component to focus. This method is used when the document component is selected.
	 */
	public void refocusLastFocusedComponent() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method should be used to remove
	 *  PropertyChangeListeners that were registered for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific property. This method should be used to
	 *  remove PropertyChangeListeners that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated with the named property.
	 * 
	 *  @param propertyName the property name.
	 *  @return all of the <code>PropertyChangeListeners</code> associated with the named property or an empty array if
	 *          no listeners have been added
	 * 
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}

	/**
	 *  Gets the closable attribute of this <code>DocumentComponent</code>. By default, all
	 *  <code>DocumentComponent</code>s can be closed by clicking on the close button. If this attribute is false, the
	 *  close button will not be visible if the close button is on tab.
	 * 
	 *  @return true if it can be closed. Otherwise false.
	 */
	public boolean isClosable() {
	}

	/**
	 *  Sets the closable attribute.
	 * 
	 *  @param closable whether the document can be closed.
	 */
	public void setClosable(boolean closable) {
	}

	public PreviousState getDockPreviousState() {
	}

	public void setDockPreviousState(PreviousState dockPreviousState) {
	}

	public PreviousState getFloatPreviousState() {
	}

	public void setFloatPreviousState(PreviousState floatPreviousState) {
	}
}
