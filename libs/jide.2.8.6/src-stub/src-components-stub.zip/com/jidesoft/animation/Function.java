/**
 *  The package contains the classes related to CustomAnimation, mainly used by Alert for JIDE Components product.
 */
package com.jidesoft.animation;


/**
 *  An interface to represent the math function concept. In this particular case, as it is mainly used
 *  to implement animation in CustomAnimation, the passed in parameters are currentStep and totalSteps
 *  respectively.Step is current step, so currentStep/totalSteps will be x. The value of x is between
 *  0 and 1. We expect the returned y is between 0 and 1 as well.
 */
public interface Function {

	/**
	 *  Calculation y = f(x), x = currentStep / totalSteps. x belongs [0, 1] and y belongs to [0, 1]
	 * 
	 *  @param currentStep current step index
	 *  @param totalSteps  total steps
	 *  @return a double value between 0 and 1.
	 */
	public double calculate(int currentStep, int totalSteps);
}
