/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  A custom status bar component.
 */
public class StatusBar extends javax.swing.JPanel implements java.awt.event.ComponentListener, java.awt.event.ContainerListener {
 {

	/**
	 *  Default constructor.
	 */
	public StatusBar() {
	}

	@java.lang.Override
	public void add(java.awt.Component comp, Object constraints) {
	}

	/**
	 *  Removes the status bar item by name. Nothing will be removed if there is no status bar item that has the name.
	 * 
	 *  @param name the name of the status bar item to be removed.
	 */
	public void remove(String name) {
	}

	/**
	 *  Checks if a separator will be added automatically when a new status bar item is added.
	 * 
	 *  @return true or false.
	 */
	public boolean isAutoAddSeparator() {
	}

	/**
	 *  Sets the value of autoAddSeparator. By default it's true which means a separator is added automatically between
	 *  two status bar items. You can set it to false to turn it off. In this case, you can manually add separators.
	 * 
	 *  @param autoAddSeparator true or false.
	 */
	public void setAutoAddSeparator(boolean autoAddSeparator) {
	}

	/**
	 *  Invoked when a component has been added to the container. Basically if you add anything which is not divider, a
	 *  divider will automatically added before or after the component.
	 * 
	 *  @param e ContainerEvent
	 */
	public void componentAdded(java.awt.event.ContainerEvent e) {
	}

	/**
	 *  Invoked when a component has been removed from the container. Basically if you remove anything which is not
	 *  divider, a divider will automatically deleted before or after the component.
	 * 
	 *  @param e ContainerEvent
	 */
	public void componentRemoved(java.awt.event.ContainerEvent e) {
	}

	public void componentResized(java.awt.event.ComponentEvent e) {
	}

	public void componentMoved(java.awt.event.ComponentEvent e) {
	}

	public void componentShown(java.awt.event.ComponentEvent e) {
	}

	/**
	 *  Lays out the <code>JideSplitPane</code> layout based on the preferred size of the children components. This will
	 *  likely result in changing the divider location.
	 */
	public void resetToPreferredSizes() {
	}

	public void componentHidden(java.awt.event.ComponentEvent e) {
	}

	protected boolean removeExtraSeparator() {
	}

	protected void addExtraSeparator() {
	}

	/**
	 *  Creates the status bar separator.
	 * 
	 *  @return a status bar separator.
	 */
	protected StatusBarSeparator createStatusBarSeparator() {
	}

	/**
	 *  Adds a separator. If {@link #isAutoAddSeparator()} is true, you don't need to add separator manually because a
	 *  separator will be added automatically between two status bar items. Only when it's false, you need to add
	 *  separator manually using this method.
	 */
	public void addSeparator() {
	}

	/**
	 *  Resets the UI property with a value from the current look and feel.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Gets status bar item by its name.
	 * 
	 *  @param name item name
	 *  @return item with the name
	 */
	public StatusBarItem getItemByName(String name) {
	}

	/**
	 *  Returns the current height of this component. This method is preferable to writing
	 *  <code>component.getBounds().height</code>, or <code>component.getSize().height</code> because it doesn't cause
	 *  any heap allocations.
	 * 
	 *  @return the current height of this component
	 */
	@java.lang.Override
	public int getHeight() {
	}

	/**
	 *  If the <code>preferredSize</code> has been set to a non-<code>null</code> value just returns it. If the UI
	 *  delegate's <code>getPreferredSize</code> method returns a non <code>null</code> value then return that; otherwise
	 *  defer to the component's layout manager.
	 * 
	 *  @return the value of the <code>preferredSize</code> property
	 * 
	 *  @see #setPreferredSize
	 *  @see ComponentUI
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	/**
	 *  Sets the visibility of status bar item.
	 * 
	 *  @param name    the name of the status bar item.
	 *  @param visible true or false
	 */
	public void setItemVisible(String name, boolean visible) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Checks if the children should be opaque.
	 * 
	 *  @return true if children should be opaque.
	 */
	public boolean isChildrenOpaque() {
	}

	/**
	 *  Sets the opaque attribute of status bar items. Please call this method before adding any status bar item to the
	 *  status bar.
	 * 
	 *  @param childrenOpaque true or false.
	 */
	public void setChildrenOpaque(boolean childrenOpaque) {
	}
}
