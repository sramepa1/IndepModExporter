package com.jidesoft.plaf.eclipse;


public class EclipseCollapsiblePaneUI extends com.jidesoft.plaf.basic.BasicCollapsiblePaneUI {

	public EclipseCollapsiblePaneUI() {
	}

	public EclipseCollapsiblePaneUI(com.jidesoft.pane.CollapsiblePane f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}
}
