/**
 *  The package contains the classes related to Alert component for JIDE Components product.
 */
package com.jidesoft.alert;


/**
 *  <code>Alert</code> is a special popup component which can be used to display messages such as new email notification,
 *  warning or error messages. The purpose of Alert is very similar to Swing's JOptionPanes' message box with only OK
 *  button. The problem with message box with OK button is user still has to click on the OK button to dismiss the
 *  dialog. Alert will show to tell user something and then go away automatically.
 *  <p/>
 *  Alert supports several custom animations when entrancing and exiting. For example, it supports fly-in or fly-out,
 *  fade-in or fade-out, resizing. You can also position it any location of the screen including nice pre-set locations
 *  (four corners, four sides and center). When it flies in or out, you can also set different path - straight line or
 *  curve or wave. All those features will enhance the appearance and effect of Alert so that it can deliver the right
 *  message to end users.
 */
public class Alert extends JidePopup {

	/**
	 *  Creates an Alert.
	 */
	public Alert() {
	}

	/**
	 *  Shows alert using custom animation set by setShowAnimation().
	 * 
	 *  @param x the x coordinate
	 *  @param y the y coordinate
	 */
	@java.lang.Override
	protected void internalShowPopup(int x, int y, java.awt.Component owner) {
	}

	/**
	 *  Hides alert using custom animation set by setHideAnimation().
	 */
	@java.lang.Override
	public void hidePopup(boolean cancelled) {
	}

	@java.lang.Override
	public void hidePopupImmediately(boolean cancelled) {
	}

	/**
	 *  Gets hide animation.
	 * 
	 *  @return a custom animation.
	 */
	public com.jidesoft.animation.CustomAnimation getHideAnimation() {
	}

	/**
	 *  Sets the hide animation. The hide animation will be used when hidePopup() method is called. If you want to hide
	 *  the alert without using animation, using {@link #hidePopupImmediately()}.
	 *  <p/>
	 *  Please note, <code>CustomAnimation</code> cannot be shared among different Alert. So you should always create a
	 *  new <code>CustomAnimation</code> and set it to Alert.
	 * 
	 *  @param hideAnimation the hide custom animation
	 */
	public void setHideAnimation(com.jidesoft.animation.CustomAnimation hideAnimation) {
	}

	/**
	 *  Gets hide animation.
	 * 
	 *  @return a custom animation.
	 */
	public com.jidesoft.animation.CustomAnimation getShowAnimation() {
	}

	/**
	 *  Sets the show animation. The show animation will be used when showPopup(...) method is called. If you want to
	 *  show the alert without using animation, using {@link #showPopupImmediately()}.
	 *  <p/>
	 *  Please note, <code>CustomAnimation</code> cannot be shared among different Alert. So you should always create a
	 *  new <code>CustomAnimation</code> and set it to Alert.
	 * 
	 *  @param showAnimation the show custom animation
	 */
	public void setShowAnimation(com.jidesoft.animation.CustomAnimation showAnimation) {
	}

	@java.lang.Override
	protected void showPopupImmediately() {
	}

	/**
	 *  Overrides to make Alert alwaysOnTop. However this is a JDK1.5 only feature.
	 * 
	 *  @return the top level window for the alert.
	 */
	@java.lang.Override
	protected ResizableWindow createHeavyweightPopupContainer(java.awt.Component owner) {
	}

	/**
	 *  Returns whether this alert is an always-on-top window.
	 *  <p/>
	 *  This feature is truely available only on JDK1.5. If it is on JDK1.4, we will simply call toFront() method to make
	 *  it visible but it will not always on top if user clicks on another window and covers it.
	 * 
	 *  @return <code>true</code>, if the alter is in always-on-top state, <code>false</code> otherwise
	 */
	public boolean isAlwaysOnTop() {
	}

	/**
	 *  Sets whether this alert should always be above other windows.
	 *  <p/>
	 *  This feature is truely available only on JDK1.5. If it is on JDK1.4, we will simply call toFront() method to make
	 *  it visible but it will not always on top if user clicks on another window and covers it.
	 * 
	 *  @param alwaysOnTop true if the alert should always be above other windows
	 */
	public void setAlwaysOnTop(boolean alwaysOnTop) {
	}

	public AlertGroup getAlertGroup() {
	}

	public void setAlertGroup(AlertGroup alertGroup) {
	}

	@java.lang.Override
	protected java.awt.Point getDisplayStartLocation(java.awt.Rectangle screenDim, java.awt.Dimension size, int location) {
	}

	@java.lang.Override
	protected void contentResized() {
	}
}
