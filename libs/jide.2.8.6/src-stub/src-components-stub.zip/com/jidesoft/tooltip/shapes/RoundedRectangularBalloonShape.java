/**
 *  The package contains the different shapes for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.shapes;


/**
 *  A balloon shape implemenation which implements the rounded rectangle as the balloon shape.
 */
public class RoundedRectangularBalloonShape implements com.jidesoft.tooltip.BalloonShape {
 {

	/**
	 *  The edge or corner size
	 */
	protected int _cornerSize;

	/**
	 *  The size ratio that a balloon in the whole popup.
	 */
	protected double _balloonSizeRatio;

	/**
	 *  The offset ratio of the sticking arrow to left side of the popup.
	 */
	protected double _arrowLeftRatio;

	/**
	 *  The offset ratio of the sticking arrow to right side of the popup.
	 */
	protected double _arrowRightRatio;

	/**
	 *  The offset ratio of the sticking arrow's vertex relative to the left side of the popup.
	 */
	protected double _vertexPosition;

	public RoundedRectangularBalloonShape() {
	}

	/**
	 *  Create the outline of the balloon.
	 */
	public java.awt.Shape createOutline(java.awt.Dimension balloonSize, java.awt.Dimension contentSize) {
	}

	protected int getRoundedCornerSize() {
	}

	public java.awt.Point getHotSpot(java.awt.Dimension balloonSize) {
	}

	/**
	 *  Get its insets arround the content component
	 */
	public java.awt.Insets getInsets(java.awt.Dimension contentSize) {
	}

	/**
	 *  Caculate the distance of the specified pixel to the balloon tip egde.
	 */
	public double getEdgeDistance(java.awt.Point pixel, com.jidesoft.tooltip.BalloonTip balloonTip) {
	}

	public static double getDistance(java.awt.Point p, java.awt.Point leftVertex, java.awt.Point rightVertex, java.awt.Point topVertex, int cornerSize, boolean contained) {
	}

	/**
	 *  Gets the corner size of the balloon area.
	 * 
	 *  @return the corner size of the balloon area.
	 */
	public int getCornerSize() {
	}

	/**
	 *  Sets the corner size of the balloon area.
	 * 
	 *  @param cornerSize the corner size of the balloon area.
	 */
	public void setCornerSize(int cornerSize) {
	}

	/**
	 *  Gets the ratio between the balloon height and the balloon + arrow height. For example, if the
	 *  ratio is 0.5, it means balloon has the same height as arrow.
	 * 
	 *  @return the ratio between the balloon height and the balloon + arrow height.
	 */
	public double getBalloonSizeRatio() {
	}

	/**
	 *  Sets the ratio between the balloon height and the balloon + arrow height.
	 * 
	 *  @param balloonSizeRatio a new ratio between the balloon height and the balloon + arrow
	 *                          height.
	 */
	public void setBalloonSizeRatio(double balloonSizeRatio) {
	}

	/**
	 *  Gets the ratio between the distance of the border to the arrow leading side and the whole
	 *  balloon size.
	 * 
	 *  @return the ratio between the distance of the left border to the arrow left side and the
	 *          whole balloon width, assuming the ballon position is TOP or BOTTOM. If the position
	 *          is LEFT, it will be the ratio between the distance of the top border to the arrow top
	 *          side and the whole balloon height. If the position is RIGHT, it will be the ratio
	 *          between the distance of the bottom border to the arrow bottom side and the whole
	 *          balloon height.
	 */
	public double getArrowLeftRatio() {
	}

	/**
	 *  Sets the ratio between the distance of the border to the arrow leading side and the whole
	 *  balloon size.
	 * 
	 *  @param arrowLeftRatio a new ratio between the distance of the left border to the arrow left
	 *                        side and the whole balloon width, assuming the ballon position is TOP
	 *                        or BOTTOM. If the position is LEFT, it will be the ratio between the
	 *                        distance of the top border to the arrow top side and the whole balloon
	 *                        height. If the position is RIGHT, it will be the ratio between the
	 *                        distance of the bottom border to the arrow bottom side and the whole
	 *                        balloon height.
	 */
	public void setArrowLeftRatio(double arrowLeftRatio) {
	}

	/**
	 *  Gets the ratio between the distance of the border to the arrow trailing side and the whole
	 *  balloon size.
	 * 
	 *  @return the ratio between the distance of the right border to the arrow right side and the
	 *          whole balloon width, assuming the ballon position is TOP or BOTTOM. If the position
	 *          is LEFT, it will be the ratio between the distance of the bottom border to the arrow
	 *          bottom side and the whole balloon height. If the position is RIGHT, it will be the
	 *          ratio between the distance of the top border to the arrow top side and the whole
	 *          balloon height.
	 */
	public double getArrowRightRatio() {
	}

	/**
	 *  Sets the ratio between the distance of the border to the arrow trailing side and the whole
	 *  balloon size.
	 * 
	 *  @param arrowRightRatio a new ratio between the distance of the right border to the arrow
	 *                         right side and the whole balloon width, assuming the ballon position
	 *                         is TOP or BOTTOM. If the position is LEFT, it will be the ratio
	 *                         between the distance of the bottom border to the arrow bottom side and
	 *                         the whole balloon height. If the position is RIGHT, it will be the
	 *                         ratio between the distance of the top border to the arrow top side and
	 *                         the whole balloon height.
	 */
	public void setArrowRightRatio(double arrowRightRatio) {
	}

	/**
	 *  Gets the vertex horizontal or vertical position.
	 * 
	 *  @return the vertex horizontal position. 0 means the arrow horizontal position is the same as
	 *          the left border of the balloon. 1 means the same as the right border. This is the
	 *          case when the balloon position is TOP or BOTTOM. If the position is LEFT, it is the
	 *          vertex vertical position. 0 means the arrow vertical position is the same as the top
	 *          border of the balloon. 1 means the same as the bottom border. If the position is
	 *          RIGHT, it is the opposite vertex vertical position. 0 means the arrow vertical
	 *          position is the same as the bottom border of the balloon. 1 means the same as the top
	 *          border.
	 */
	public double getVertexPosition() {
	}

	/**
	 *  Sets the vertex horizontal or vertical position.
	 * 
	 *  @param vertexPosition a new vertex horizontal position. 0 means the arrow horizontal position
	 *                        is the same as the left border of the balloon. 1 means the same as the
	 *                        right border. This is the case when the balloon position is TOP or
	 *                        BOTTOM. If the position is LEFT, it is the vertex vertical position. 0
	 *                        means the arrow vertical position is the same as the top border of the
	 *                        balloon. 1 means the same as the bottom border. If the position is
	 *                        RIGHT, it is the opposite vertex vertical position. 0 means the arrow
	 *                        vertical position is the same as the bottom border of the balloon. 1
	 *                        means the same as the top border.
	 */
	public void setVertexPosition(double vertexPosition) {
	}

	/**
	 *  Sets the balloon tip's position : TOP, RIGHT, BOTTOM, LEFT.
	 * 
	 *  @param position a new ratio balloon tip's position.
	 */
	public void setPosition(int position) {
	}

	/**
	 *  Gets the balloon tip's position : TOP, RIGHT, BOTTOM, LEFT.
	 * 
	 *  @return the balloon tip's position.
	 */
	public int getPosition() {
	}
}
