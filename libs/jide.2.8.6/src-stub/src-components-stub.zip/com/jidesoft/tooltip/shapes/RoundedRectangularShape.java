/**
 *  The package contains the different shapes for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.shapes;


/**
 *  A balloon shape implementation, a rounded rectangle shape.
 */
public class RoundedRectangularShape implements com.jidesoft.tooltip.BalloonShape {
 {

	public RoundedRectangularShape() {
	}

	/**
	 *  Create the outline of the rounded rectangle.
	 */
	public java.awt.Shape createOutline(java.awt.Dimension balloonSize, java.awt.Dimension contentSize) {
	}

	public java.awt.Point getHotSpot(java.awt.Dimension balloonSize) {
	}

	public java.awt.Insets getInsets(java.awt.Dimension contentSize) {
	}

	public double getEdgeDistance(java.awt.Point pixel, com.jidesoft.tooltip.BalloonTip balloonTip) {
	}

	/**
	 *  Gets distance from pixel to the rounded rectangle
	 * 
	 *  @param p          point
	 *  @param rect       rectangle
	 *  @param cornerSize the corner size of the rounded rectangle
	 * 
	 *  @return the distance
	 */
	public static double getDistance(java.awt.Point p, java.awt.Rectangle rect, int cornerSize) {
	}

	public int getCornerSize() {
	}

	public void setCornerSize(int cornerSize) {
	}
}
