/**
 *  The package contains the different shapes for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.shapes;


/**
 *  A balloon shape implemenation which implements the rectangular shape.
 */
public class RectangularBalloonShape extends RoundedRectangularBalloonShape {

	public RectangularBalloonShape() {
	}

	@java.lang.Override
	protected int getRoundedCornerSize() {
	}
}
