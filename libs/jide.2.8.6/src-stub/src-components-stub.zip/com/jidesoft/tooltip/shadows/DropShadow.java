/**
 *  The package contains different kinds of shadows for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.shadows;


/**
 *  Drop shadow is a shadow style which does not have perspective effect. It casts
 *  the shadow to a parallel plain.
 */
public abstract class DropShadow implements com.jidesoft.tooltip.ShadowStyle {
 {

	/**
	 *  The shadow shearness on the y-axis direction.
	 */
	protected int _yOffset;

	/**
	 *  The shadow shearness on the x-axis direction.
	 */
	protected int _xOffset;

	/**
	 *  Scale of the shadow, relative to the balloon size.
	 */
	protected double _scale;

	/**
	 *  Creates a new instance of LeftBottomShadow
	 */
	public DropShadow() {
	}

	/**
	 *  Creating the shadow image. Darken specific area including the
	 *  inner of the tip and the egdes.
	 */
	public java.awt.image.BufferedImage createShadow(java.awt.image.BufferedImage image, com.jidesoft.tooltip.BalloonTip balloonTip) {
	}

	public java.awt.Dimension getShadowSize(java.awt.Dimension size) {
	}

	public int getYOffset() {
	}

	public void setYOffset(int yOffset) {
	}

	public int getXOffset() {
	}

	public void setXOffset(int xOffset) {
	}

	public double getScale() {
	}

	public void setScale(double scale) {
	}
}
