/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  BalloonTip is a special tooltip that has a balloon shape. See below.
 *  <p/>
 *  You can put any component inside a BalloonTip. It can be done either through the constructor or use setContent
 *  method. Then all you need to do is to call show(owner, x, y) to display it. Please note the x and y position is
 *  relative to the owner. <p><b>Different balloon shape</b> <p>BalloonTip supports different balloon shapes. By default
 *  we support several shapes such as rounded rectangle balloon, rectangle balloon, rounded rectangle, rectangle and
 *  oval. You can use setBalloonShape method to change it. See below. <p>You can also define your own shapes by
 *  implementing BalloonShape interface or extending one of our existing shapes with overridden methods. <p><b>Shadow
 *  Style</b> <p>BalloonTip also support two different kinds of shadows perspective shadow and drop shadow. It can be
 *  changed using setShadowStyle. Same as BalloonShape, ShadowStyle is also an interface. You can use one of the existing
 *  ShadowStyle we created or you can create your own style. For our default shadow styles, you can adjust various
 *  settings.
 */
public class BalloonTip extends javax.swing.JToolTip {

	/**
	 *  BalloonTip's empty arguments constructor, for java bean specification compatibility.
	 */
	public BalloonTip() {
	}

	/**
	 *  BalloonTip constructor
	 * 
	 *  @param content The content component of the BalloonTip.
	 */
	public BalloonTip(java.awt.Component content) {
	}

	/**
	 *  Use BalloonTipUI to customize the LAF.
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Gets the current content size.
	 * 
	 *  @return the current content size.
	 */
	public java.awt.Dimension getContentSize() {
	}

	/**
	 *  Gets the current balloon size.
	 * 
	 *  @return the current balloon size.
	 */
	public java.awt.Dimension getBalloonSize() {
	}

	/**
	 *  Gets the preferred balloon size.
	 * 
	 *  @return the preferred balloon size.
	 */
	public java.awt.Dimension getBalloonPreferredSize() {
	}

	/**
	 *  Gets the position of the arrow vertex.
	 * 
	 *  @return the position of the arrow vertex.
	 */
	public java.awt.Point getHotSpot() {
	}

	/**
	 *  Gets the current shadow size.
	 * 
	 *  @return the current shadow size.
	 */
	public java.awt.Dimension getShadowSize() {
	}

	/**
	 *  Set the content component of the BalloonTip
	 * 
	 *  @param content The content component of the BalloonTip
	 */
	public void setContent(java.awt.Component content) {
	}

	/**
	 *  For BalloonTip visibility status query.
	 * 
	 *  @return whether the BalloonTip is visible.
	 */
	@java.lang.Override
	public boolean isVisible() {
	}

	/**
	 *  Show the BalloonTip over an owner component. The owner must be visible before the BalloonTip is shown over it.
	 * 
	 *  @param owner The component the BalloonTip will be popup over.
	 *  @param x     The x-axis coordinate where the BalloonTip will be. The coordinate system is that of the owner
	 *               component.
	 *  @param y     The y-axis coordinate where the BalloonTip will be. The coordinate system is that of the owner
	 *               component.
	 */
	public void show(javax.swing.JComponent owner, int x, int y) {
	}

	/**
	 *  Creates the JidePopup that is used to show the BalloonTip. Here is the default code.
	 *  <pre><code>
	 *  return new JidePopup() {
	 *      public boolean isClickOnPopup(MouseEvent e) {
	 *          Point p = e.getPoint();
	 *          Point point = SwingUtilities.convertPoint((Component) e.getSource(), p, getContent().getParent());
	 *          return getContent().getParent().contains(point);
	 *      }
	 *  };
	 *  </code></pre>
	 * 
	 *  @return a new instance of JidePopup.
	 */
	protected JidePopup createPopup() {
	}

	protected void customizePopup(JidePopup popup) {
	}

	/**
	 *  Hide the BalloonTip if it is visible.
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Override
	public void hide() {
	}

	/**
	 *  Get the BalloonTip model. The BalloonShape controls the outline of the BalloonTip. By querying this shape,
	 *  developers can customized the look of the popped balloon.
	 * 
	 *  @return the ToolTip shape.
	 */
	public BalloonShape getBalloonShape() {
	}

	/**
	 *  Set a different BalloonShape for BalloonTip
	 * 
	 *  @param shape the new shape.
	 */
	public void setBalloonShape(BalloonShape shape) {
	}

	/**
	 *  Gets the content component.
	 * 
	 *  @return the content component.
	 */
	public java.awt.Component getContent() {
	}

	/**
	 *  Gets the shadow style.
	 * 
	 *  @return the shadow style.
	 */
	public ShadowStyle getShadowStyle() {
	}

	/**
	 *  Set the shadow style of the balloon
	 * 
	 *  @param shadowStyle the new shadow style.
	 */
	public void setShadowStyle(ShadowStyle shadowStyle) {
	}

	/**
	 *  Gets the shadow composite. The shadow composite is used to paint the shadow.
	 * 
	 *  @return the shadow composite.
	 */
	public ShadowSettings getShadowSettings() {
	}

	/**
	 *  Sets the shadow composite.
	 * 
	 *  @param shadowSettings the new shadow composite.
	 */
	public void setShadowSettings(ShadowSettings shadowSettings) {
	}

	/**
	 *  Paints the balloon background.
	 * 
	 *  @param g2d   the Graphics2D object
	 *  @param shape the shape of the balloon. By default, we will fill the shape with the color from getBackground();
	 */
	public void paintBalloonBackground(java.awt.Graphics2D g2d, java.awt.Shape shape) {
	}

	/**
	 *  Paints the balloon foreground.
	 * 
	 *  @param g2d   the Graphics2D object
	 *  @param shape the shape of the balloon. By default, we will draw a line using the shape with the color from
	 *               getForeground();
	 */
	public void paintBalloonForeground(java.awt.Graphics2D g2d, java.awt.Shape shape) {
	}

	/**
	 *  Packs the balloon popup.
	 */
	public void packPopup() {
	}
}
