/**
 *  The package contains different kinds of shadow composites for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.composite;


/**
 *  Opaque shadow composite
 */
public class DefaultShadowComposite implements com.jidesoft.tooltip.ShadowComposite {
 {

	public DefaultShadowComposite() {
	}

	public int compose(double distance) {
	}
}
