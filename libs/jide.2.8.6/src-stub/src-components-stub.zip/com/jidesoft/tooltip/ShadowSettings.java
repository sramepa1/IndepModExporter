/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  Shadow composite interface is responsible for compositing the color of the
 *  shadowing image, using different compositing rules, such as transparent
 *  or opaque.
 */
public class ShadowSettings {

	public ShadowSettings() {
	}

	public java.awt.Color getColor() {
	}

	public void setColor(java.awt.Color color) {
	}

	public float getOpacity() {
	}

	public void setOpacity(float opacity) {
	}

	public int getSize() {
	}

	public void setSize(int size) {
	}

	public ShadowComposite getShadowComposite() {
	}

	public void setShadowComposite(ShadowComposite shadowComposite) {
	}
}
