/**
 *  The package contains the several panes such as OutlookTabbedPane, FloorTabbedPane, CollapsiblePane, BookmarkPane etc which can be used for navigation purpose for JIDE Components product.
 */
package com.jidesoft.pane;


/**
 *  CollapsibePane, as the name indicates, is a pane which can be collapsed. Users can expand the pane so that they can
 *  work on it. When it is done, they can collapse it to save place.
 *  <p/>
 *  All you need to do is to create a CollapsiblePane by passing in the title and icon (if any), and set the content
 *  panel which will be expanded or collapsed.
 *  <p/>
 *  CollapsiblePane has several different styles built-in. They are <ul> <li> DROPDOWN_STYLE: this is the default style
 *  which looks like the the task pane as in the Windows XP. In this style, the icon is on the left, then the title. The
 *  collapsible/expand icon is on the far right. <li> TREE_STYLE: in this style, the collapsible/expand icon will be the
 *  same icon as in JTree. It is aligned to the left, then the icon, then the title. <li> PLAIN_STYLE: This style is
 *  almost the same as TREE_STYLE except it doesn't have its own background. If you are using CollapsiblePane inside
 *  CollapsiblePanes, the CollapsiblePanes background will be seen. <li> SEPARATOR_STYLE: The style, if used with
 *  CollapsiblePanes, makes the title pane looking like a separator that divides the CollapsiblePanes into several areas.
 *  </ul> It might be diffcult to understand what each style looks like so if you run the CollapsiblePaneDemo, it would
 *  be easy to see all four styles.
 *  <p/>
 *  CollapsiblePane also supports sliding in all four directions. Typically, the sliding direction is south just like
 *  Windows XP's task pane. But sliding in other directions is also useful. For example, if the CollapsiblePane is on the
 *  left and there is only one, you can make it sliding east to create an effect like the autohidden feature in JIDE
 *  Docking Framework.
 */
public class CollapsiblePane extends javax.swing.JPanel implements javax.swing.SwingConstants, javax.swing.WindowConstants {
 {

	/**
	 *  Bound property name.
	 */
	public static final String CONTENT_PANE_PROPERTY = "contentPane";

	/**
	 *  Bound property name.
	 */
	public static final String TITLE_PROPERTY = "title";

	/**
	 *  Bound property name.
	 */
	public static final String ICON_PROPERTY = "icon";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_TITLE_ICON = "titleIcon";

	/**
	 *  Constrained property name indicating that the CollapsiblePane is collapsed.
	 */
	public static final String COLLAPSED_PROPERTY = "collapsed";

	public static final String STYLE_PROPERTY = "style";

	public static final String PROPERTY_COLLAPSED_ICON = "collapsedIcon";

	public static final String PROPERTY_EXPANDED_ICON = "expandedIcon";

	/**
	 *  true if the pane is collapsed.
	 */
	protected boolean _collapsed;

	/**
	 *  The height of content pane. You can set it if you want to override the default value getting from the content
	 *  pane. If you haven't set it, it will be the preferred size of content pane.
	 */
	protected int _contentPaneHeight;

	/**
	 *  The width of content pane. You can set it if you want to override the default value getting from the content
	 *  pane. If you haven't set it, it will be the preferred size of content pane.
	 */
	protected int _contentPaneWidth;

	public static final int DROPDOWN_STYLE = 0;

	public static final int TREE_STYLE = 1;

	public static final int PLAIN_STYLE = 2;

	public static final int SEPARATOR_STYLE = 3;

	public static final String EMPHASIZED_PROPERTY = "emphasized";

	protected boolean _rollover;

	public static final String ICONTEXTGAP_PROPERTY = "iconTextGap";

	public static final String VERTICAL_ALIGNMENT_PROPERTY = "verticalAlignment";

	public static final String HORIZONTAL_ALIGNMENT_PROPERTY = "horizontalAlignment";

	public static final String VERTICAL_TEXTPOSITION_PROPERTY = "verticalTextPosition";

	public static final String HORIZONTAL_TEXTPOSITION_PROPERTY = "horizontalTextPosition";

	public static final String PROPERTY_COLLAPSIBLE = "collapsible";

	public static final String PROPERTY_SHOW_TITLE_BAR = "showTitleBar";

	public static final String PROPERTY_SHOW_EXPAND_BUTTON = "showExpandButton";

	public static final String PROPERTY_SLIDING_DIRECTION = "slidingDirection";

	public static final String PROPERTY_FOCUS_PAINTED = "focusPainted";

	public static final String PROPERTY_CONTENTAREA_FILLED = "contentAreaFilled";

	public static final String PROPERTY_TITLE_PANE_OPAQUE = "titlePaneOpaque";

	public static final String PROPERTY_AUTO_EXPAND_ON_DRAGOVER = "autoExpandOnDragover";

	public static final String PROPERTY_TITLE_COMPONENT = "titleComponent";

	public static final String PROPERTY_TITLE_LABEL_COMPONENT = "titleLabelComponent";

	public static final String PROPERTY_COLLAPSE_ON_TITLE_CLICK = "collapseOnTitleClick";

	/**
	 *  Create an CollapsiblePanew with no name and default icon.
	 */
	public CollapsiblePane() {
	}

	/**
	 *  Create an CollapsiblePanew with <code>title</code> and default icon.
	 * 
	 *  @param title title of the collapsible pane
	 */
	public CollapsiblePane(String title) {
	}

	public CollapsiblePane(String title, int slidingDirection) {
	}

	public CollapsiblePane(String title, javax.swing.Icon icon, int initDelay, int stepDelay, int steps) {
	}

	public CollapsiblePane(String title, javax.swing.Icon icon, int initDelay, int stepDelay, int steps, int slidingDirection) {
	}

	/**
	 *  Create an CollapsiblePanew with <code>title</code> and icon.
	 * 
	 *  @param title title of the collapsible pane
	 *  @param icon  icon of the collapsible pane
	 */
	public CollapsiblePane(String title, javax.swing.Icon icon) {
	}

	/**
	 *  Create an CollapsiblePanew with <code>title</code> and icon.
	 * 
	 *  @param title            title of the collapsible pane
	 *  @param icon             icon of the collapsible pane
	 *  @param slidingDirection the sliding direction.
	 */
	public CollapsiblePane(String title, javax.swing.Icon icon, int slidingDirection) {
	}

	/**
	 *  Returns the look-and-feel object that renders this component.
	 * 
	 *  @return the <code>CollapsiblePaneUI</code> object that renders this component
	 */
	@java.lang.Override
	public javax.swing.plaf.PanelUI getUI() {
	}

	/**
	 *  Sets the UI delegate for this <code>CollapsiblePane</code>.
	 * 
	 *  @param ui the UI delegate
	 */
	public void setUI(com.jidesoft.plaf.CollapsiblePaneUI ui) {
	}

	/**
	 *  Notification from the <code>UIManager</code> that the look and feel has changed. Replaces the current UI object
	 *  with the latest version from the <code>UIManager</code>.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the name of the look-and-feel class that renders this component.
	 * 
	 *  @return the string "CollapsiblePaneUI"
	 * 
	 *  @see JComponent#getUIClassID
	 *  @see UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  Returns whether calls to <code>add</code> and <code>setLayout</code> cause an exception to be thrown.
	 * 
	 *  @return <code>true</code> if <code>add</code> and <code>setLayout</code> are checked
	 * 
	 *  @see #addImpl
	 *  @see #setLayout
	 *  @see #setContentPaneCheckingEnabled
	 */
	protected boolean isContentPaneCheckingEnabled() {
	}

	/**
	 *  Determines whether calls to <code>add</code> and <code>setLayout</code> cause an exception to be thrown.
	 * 
	 *  @param enabled a boolean value, <code>true</code> if checking is to be enabled, which cause the exceptions to be
	 *                 thrown
	 *  @see #addImpl
	 *  @see #setLayout
	 *  @see #isContentPaneCheckingEnabled
	 */
	protected void setContentPaneCheckingEnabled(boolean enabled) {
	}

	/**
	 *  Ensures that, by default, children cannot be added directly to this component. Instead, children must be added to
	 *  its content pane. For example:
	 *  <pre>
	 *  thisComponent.getContentPane().add(child)
	 *  </pre>
	 *  An attempt to add to directly to this component will cause a runtime exception to be thrown. Subclasses can
	 *  disable this behavior.
	 * 
	 *  @param comp        the <code>Component</code> to be added
	 *  @param constraints the object containing the constraints, if any
	 *  @param index       the index
	 *  @throws Error if called with <code>isRootPaneChecking</code> <code>true</code>
	 *  @see #setContentPaneCheckingEnabled
	 */
	@java.lang.Override
	protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	}

	/**
	 *  Removes the specified component from this container.
	 * 
	 *  @param comp the component to be removed
	 *  @see #add
	 */
	@java.lang.Override
	public void remove(java.awt.Component comp) {
	}

	/**
	 *  Ensures that, by default, the layout of this component cannot be set. Instead, the layout of its content pane
	 *  should be set. For example:
	 *  <pre>
	 *  thisComponent.getContentPane().setLayout(new GridLayout(1,2))
	 *  </pre>
	 *  An attempt to set the layout of this component will cause an runtime exception to be thrown. Subclasses can
	 *  disable this behavior.
	 * 
	 *  @param manager the <code>LayoutManager</code>
	 *  @throws Error if called with <code>isRootPaneChecking</code> <code>true</code>
	 *  @see #setContentPaneCheckingEnabled
	 */
	@java.lang.Override
	public void setLayout(java.awt.LayoutManager manager) {
	}

	/**
	 *  Returns the content pane for this collapsible pane.
	 * 
	 *  @return the content pane
	 */
	public javax.swing.JComponent getContentPane() {
	}

	/**
	 *  Sets this <code>CollapsiblePane</code>'s <code>contentPane</code> property.
	 * 
	 *  @param c the content pane for this collapsible pane
	 *  @throws IllegalComponentStateException (a runtime exception) if the content pane parameter is <code>null</code>
	 *  @see RootPaneContainer#getContentPane
	 */
	public void setContentPane(javax.swing.JComponent c) {
	}

	/**
	 *  @param b a boolean value, where <code>true</code> means this collapsible pane is collapsed
	 *  @throws java.beans.PropertyVetoException
	 *           if the property change is vetoed.
	 */
	public void setCollapsed(boolean b) {
	}

	/**
	 *  Checks if the CollapsiblePane is collapsed.
	 * 
	 *  @return <code>true</code> if this collapsible pane is collapsed.
	 */
	public boolean isCollapsed() {
	}

	/**
	 *  Checks if the CollapsiblePane is expanded.
	 * 
	 *  @return <code>true</code> if this collapsible pane is expanded.
	 */
	public boolean isExpanded() {
	}

	/**
	 *  Returns the title of the <code>CollapsiblePane</code>.
	 * 
	 *  @return a <code>String</code> containing this collapsible pane's title
	 * 
	 *  @see #setName
	 */
	public String getTitle() {
	}

	/**
	 *  Sets the <code>CollapsiblePane</code> title. <code>title</code> may have a <code>null</code> value.
	 * 
	 *  @param title the <code>String</code> to display in the title bar
	 */
	public void setTitle(String title) {
	}

	/**
	 *  Sets an image to be displayed in the titlebar of this collapsible pane (usually in the top-left corner).
	 * 
	 *  @param icon the <code>Icon</code> to display in the title bar
	 *  @see #getIcon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Returns the image displayed in the title bar of this collapsible pane (usually in the top-left corner).
	 * 
	 *  @return the <code>Icon</code> displayed in the title bar
	 * 
	 *  @see #setIcon
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Sets an image to be displayed in the titlebar of this collapsible pane (usually in the top-left corner).
	 * 
	 *  @param icon the <code>Icon</code> to display in the title bar
	 *  @see #getIcon
	 */
	public void setTitleIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Returns the image displayed in the title bar of this collapsible pane (usually in the top-left corner).
	 * 
	 *  @return the <code>Icon</code> displayed in the title bar
	 * 
	 *  @see #setIcon
	 */
	public javax.swing.Icon getTitleIcon() {
	}

	/**
	 *  Verify that key is a legal value for the horizontalAlignment properties.
	 * 
	 *  @param key     the property value to check
	 *  @param message the IllegalArgumentException detail message
	 *  @return the key if it is a valid horizontal key. Otherwise IllegalArgumentException will be thrown.
	 * 
	 *  @throws IllegalArgumentException if key isn't LEFT, CENTER, RIGHT, LEADING or TRAILING.
	 *  @see #setHorizontalTextPosition
	 *  @see #setHorizontalAlignment
	 */
	protected int checkHorizontalKey(int key, String message) {
	}

	/**
	 *  Verify that key is a legal value for the verticalAlignment or verticalTextPosition properties.
	 * 
	 *  @param key     the property value to check
	 *  @param message the IllegalArgumentException detail message
	 *  @return the key if it is a valid vertical key. Otherwise IllegalArgumentException will be thrown.
	 * 
	 *  @throws IllegalArgumentException if key isn't TOP, CENTER, or BOTTOM.
	 *  @see #setVerticalAlignment
	 *  @see #setVerticalTextPosition
	 */
	protected int checkVerticalKey(int key, String message) {
	}

	/**
	 *  Returns the amount of space between the text and the icon displayed in this label.
	 * 
	 *  @return an int equal to the number of pixels between the text and the icon.
	 * 
	 *  @see #setIconTextGap
	 */
	public int getIconTextGap() {
	}

	/**
	 *  If both the icon and text properties are set, this property defines the space between them.
	 *  <p/>
	 *  The default value of this property is 4 pixels.
	 *  <p/>
	 *  This is a JavaBeans bound property.
	 *  <p/>
	 *  attribute: visualUpdate true description: If both the icon and text properties are set, this property defines the
	 *  space between them.
	 * 
	 *  @param iconTextGap the new gap between icon and text.
	 *  @see #getIconTextGap
	 */
	public void setIconTextGap(int iconTextGap) {
	}

	/**
	 *  Returns the alignment of the label's contents along the Y axis.
	 * 
	 *  @return The value of the verticalAlignment property, one of the following constants defined in
	 *          <code>SwingConstants</code>: <code>TOP</code>, <code>CENTER</code>, or <code>BOTTOM</code>.
	 * 
	 *  @see SwingConstants
	 *  @see #setVerticalAlignment
	 */
	public int getVerticalAlignment() {
	}

	/**
	 *  Sets the alignment of the label's contents along the Y axis.
	 *  <p/>
	 *  The default value of this property is CENTER.
	 * 
	 *  @param alignment One of the following constants defined in <code>SwingConstants</code>: <code>TOP</code>,
	 *                   <code>CENTER</code> (the default), or <code>BOTTOM</code>. enum: TOP    SwingConstants.TOP
	 *                   CENTER SwingConstants.CENTER BOTTOM SwingConstants.BOTTOM attribute: visualUpdate true
	 *                   description: The alignment of the label's contents along the Y axis.
	 *  @see SwingConstants
	 *  @see #getVerticalAlignment
	 */
	public void setVerticalAlignment(int alignment) {
	}

	/**
	 *  Returns the alignment of the label's contents along the X axis.
	 * 
	 *  @return The value of the horizontalAlignment property, one of the following constants defined in
	 *          <code>SwingConstants</code>: <code>LEFT</code>, <code>CENTER</code>, <code>RIGHT</code>,
	 *          <code>LEADING</code> or <code>TRAILING</code>.
	 * 
	 *  @see #setHorizontalAlignment
	 *  @see SwingConstants
	 */
	public int getHorizontalAlignment() {
	}

	/**
	 *  Sets the alignment of the label's contents along the X axis.
	 *  <p/>
	 *  This is a JavaBeans bound property.
	 * 
	 *  @param alignment One of the following constants defined in <code>SwingConstants</code>: <code>LEFT</code>,
	 *                   <code>CENTER</code> (the default for image-only labels), <code>RIGHT</code>,
	 *                   <code>LEADING</code> (the default for text-only labels) or <code>TRAILING</code>. enum: LEFT
	 *                   SwingConstants.LEFT CENTER SwingConstants.CENTER RIGHT    SwingConstants.RIGHT LEADING
	 *                   SwingConstants.LEADING TRAILING SwingConstants.TRAILING attribute: visualUpdate true
	 *                   description: The alignment of the label's content along the X axis.
	 *  @see SwingConstants
	 *  @see #getHorizontalAlignment
	 */
	public void setHorizontalAlignment(int alignment) {
	}

	/**
	 *  Returns the vertical position of the label's text, relative to its image.
	 * 
	 *  @return One of the following constants defined in <code>SwingConstants</code>: <code>TOP</code>,
	 *          <code>CENTER</code>, or <code>BOTTOM</code>.
	 * 
	 *  @see #setVerticalTextPosition
	 *  @see SwingConstants
	 */
	public int getVerticalTextPosition() {
	}

	/**
	 *  Sets the vertical position of the label's text, relative to its image.
	 *  <p/>
	 *  The default value of this property is CENTER.
	 *  <p/>
	 *  This is a JavaBeans bound property.
	 * 
	 *  @param textPosition One of the following constants defined in <code>SwingConstants</code>: <code>TOP</code>,
	 *                      <code>CENTER</code> (the default), or <code>BOTTOM</code>. enum: TOP    SwingConstants.TOP
	 *                      CENTER SwingConstants.CENTER BOTTOM SwingConstants.BOTTOM expert: true attribute:
	 *                      visualUpdate true description: The vertical position of the text relative to it's image.
	 *  @see SwingConstants
	 *  @see #getVerticalTextPosition
	 */
	public void setVerticalTextPosition(int textPosition) {
	}

	/**
	 *  Returns the horizontal position of the label's text, relative to its image.
	 * 
	 *  @return One of the following constants defined in <code>SwingConstants</code>: <code>LEFT</code>,
	 *          <code>CENTER</code>, <code>RIGHT</code>, <code>LEADING</code> or <code>TRAILING</code>.
	 * 
	 *  @see SwingConstants
	 */
	public int getHorizontalTextPosition() {
	}

	/**
	 *  Sets the horizontal position of the label's text, relative to its image.
	 * 
	 *  @param textPosition One of the following constants defined in <code>SwingConstants</code>: <code>LEFT</code>,
	 *                      <code>CENTER</code>, <code>RIGHT</code>, <code>LEADING</code>, or <code>TRAILING</code> (the
	 *                      default).
	 *  @throws IllegalArgumentException bound: true enum: LEFT     SwingConstants.LEFT CENTER SwingConstants.CENTER
	 *                                   RIGHT    SwingConstants.RIGHT LEADING SwingConstants.LEADING TRAILING
	 *                                   SwingConstants.TRAILING attribute: visualUpdate true description: The horizontal
	 *                                   position of the label's text, relative to its image.
	 *  @see SwingConstants
	 */
	public void setHorizontalTextPosition(int textPosition) {
	}

	/**
	 *  Adds the specified listener to receive collapsible pane events from this collapsible frame.
	 * 
	 *  @param l the collapsible pane listener
	 */
	public void addCollapsiblePaneListener(event.CollapsiblePaneListener l) {
	}

	/**
	 *  Removes the specified collapsible pane listener so that it no longer receives collapsible pane events from this
	 *  collapsible pane .
	 * 
	 *  @param l the collapsible pane listener
	 */
	public void removeCollapsiblePaneListener(event.CollapsiblePaneListener l) {
	}

	/**
	 *  Returns an array of all the <code>CollapsiblePaneListener</code>s added to this <code>CollapsiblePane</code> with
	 *  <code>addCollapsiblePaneListener</code>.
	 * 
	 *  @return all of the <code>CollapsiblePaneListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addCollapsiblePaneListener
	 *  @since 1.4
	 */
	public event.CollapsiblePaneListener[] getCollapsiblePaneListeners() {
	}

	/**
	 *  Fires an collapsible pane event.
	 * 
	 *  @param eventID the event id
	 */
	public void fireCollapsiblePaneEvent(int eventID) {
	}

	/**
	 *  Gets the <code>AccessibleContext</code> associated with this <code>CollapsiblePane</code>. For collapsible pane,
	 *  the <code>AccessibleContext</code> takes the form of an <code>AccessibleCollapsiblePane</code> object. A new
	 *  <code>AccessibleCollapsiblePane</code> instance is created if necessary.
	 * 
	 *  @return an <code>AccessibleCollapsiblePane</code> that serves as the <code>AccessibleContext</code> of this
	 *          <code>CollapsiblePane</code>
	 * 
	 *  @see AccessibleCollapsiblePane
	 */
	@java.lang.Override
	public javax.accessibility.AccessibleContext getAccessibleContext() {
	}

	/**
	 *  Get the flag indicating if the pane will be collapsed while mouse clicking on the title.
	 *  <p/>
	 *  By default, the value is true. You can set it to false if you only want the pane to be collapsible when collapse
	 *  button is hit.
	 *  
	 *  @return the flag.
	 */
	public boolean isCollapseOnTitleClick() {
	}

	/**
	 *  Set the flag indicating if the pane will be collapsed while mouse clicking on the title.
	 * 
	 *  @see #isCollapseOnTitleClick()
	 *  @param collapseOnTitleClick the flag
	 */
	public void setCollapseOnTitleClick(boolean collapseOnTitleClick) {
	}

	/**
	 *  Get the gap between the title lable and the title component or the collapse icon in TREE_STYLE or PLAIN_STYLE
	 *  <p/>
	 *  The default value is 4.
	 * 
	 *  @return the gap.
	 */
	public int getTitleLabelGap() {
	}

	/**
	 *  Set the gap between the title lable and the title component or the collapse icon in TREE_STYLE or PLAIN_STYLE
	 * 
	 *  @see #getTitleLabelGap() 
	 *  @param titleLabelGap the gap
	 */
	public void setTitleLabelGap(int titleLabelGap) {
	}

	/**
	 *  Gets the height of content pane. If user sets the content pane height before, it will be what value user set. If
	 *  not, it will be the preferred height of the content pane.
	 * 
	 *  @return the height of content pane.
	 */
	public int getContentPaneHeight() {
	}

	/**
	 *  Set the height of content pane. If the height is smaller then the preferred height, based on the layout of the
	 *  content pane, portion of the content pane may not be visible.
	 * 
	 *  @param contentPaneHeight the new height of content pane
	 */
	public void setContentPaneHeight(int contentPaneHeight) {
	}

	/**
	 *  Gets the width of content pane. If user sets the content pane width before, it will be what value user set. If
	 *  not, it will be the preferred width of the content pane.
	 * 
	 *  @return the width of content pane.
	 */
	public int getContentPaneWidth() {
	}

	/**
	 *  Set the width of content pane. If the width is smaller then the preferred width, based on the layout of the
	 *  content pane, portion of the content pane may not be visible.
	 * 
	 *  @param contentPaneWidth the new width of content pane
	 */
	public void setContentPaneWidth(int contentPaneWidth) {
	}

	/**
	 *  Gets the scroll pane used internally. <b>Note</b>: This method is only used internally. We have to leave it
	 *  public since we used outside package. PLEASE DO NOT USE IT DIRECTLY.
	 * 
	 *  @return the scroll pane used internally.
	 */
	public javax.swing.JComponent getActualComponent() {
	}

	/**
	 *  Gets the initial delay when starts to animate.
	 * 
	 *  @return the initial delay
	 */
	public int getInitDelay() {
	}

	/**
	 *  Sets the initial delay when the button is pressed before it starts to switch, in ms. Default is 50ms.
	 * 
	 *  @param initDelay the initial delay
	 */
	public void setInitDelay(int initDelay) {
	}

	/**
	 *  Gets the delay in each step during animation.
	 * 
	 *  @return the delay in each step
	 */
	public int getStepDelay() {
	}

	/**
	 *  Sets the delay in each step during animation, in ms. Default is 5ms.
	 * 
	 *  @param stepDelay the delay in each step
	 */
	public void setStepDelay(int stepDelay) {
	}

	/**
	 *  Gets how many steps in the animation.
	 * 
	 *  @return number of the steps
	 */
	public int getSteps() {
	}

	/**
	 *  Sets how many steps in the animation, default is 10 steps.
	 * 
	 *  @param steps number of the steps
	 */
	public void setSteps(int steps) {
	}

	/**
	 *  Gets the style.
	 * 
	 *  @return style
	 */
	public int getStyle() {
	}

	/**
	 *  Sets the style. There are three styles available - DROPDOWN_STYLE, TREE_STYLE, PLAIN_STYLE or SEPARATOR_STYLE.
	 * 
	 *  @param style the new style
	 */
	public void setStyle(int style) {
	}

	/**
	 *  Gets the sliding direction. In current release, it could be either SOUTH, NORTH, EAST or WEST. Default is SOUTH,
	 *  meaning content sliding to south direction when expanding.
	 * 
	 *  @return sliding direction.
	 */
	public int getSlidingDirection() {
	}

	/**
	 *  Sets the sliding direction. It could be either {@link SwingConstants#NORTH}, {@link SwingConstants#SOUTH}, {@link
	 *  SwingConstants#EAST} or {@link SwingConstants#WEST}. Default is {@link SwingConstants#SOUTH}.
	 * 
	 *  @param slidingDirection the sliding direction.
	 */
	public void setSlidingDirection(int slidingDirection) {
	}

	/**
	 *  Checks if CollapsiblePane is in emphasized mode.
	 * 
	 *  @return true if the CollapsiblePane is in emphasized mode. Otherwise false.
	 */
	public boolean isEmphasized() {
	}

	/**
	 *  When there are several CollapsiblePane in a group, in case you want to emphasize one of them, you can call
	 *  setEmphasized(true). It will make that CollapsiblePane's title pane has different background.
	 * 
	 *  @param emphasized true or false.
	 */
	public void setEmphasized(boolean emphasized) {
	}

	/**
	 *  Checks if CollapsiblePane is collapsible. By default it is true.
	 * 
	 *  @return true if the CollapsiblePane is collapsible.
	 */
	public boolean isCollapsible() {
	}

	/**
	 *  Sets collapsible flag. By default, it is true.
	 * 
	 *  @param collapsible true or false
	 */
	public void setCollapsible(boolean collapsible) {
	}

	/**
	 *  Checks if the title bar is visible.
	 * 
	 *  @return true if title bar is visible.
	 */
	public boolean isShowTitleBar() {
	}

	/**
	 *  Sets the visibility of title bar.
	 * 
	 *  @param showTitleBar true to show title bar.
	 */
	public void setShowTitleBar(boolean showTitleBar) {
	}

	/**
	 *  Checks if the expand/collapse button is visible.
	 * 
	 *  @return true if expand/collapse button is visible.
	 */
	public boolean isShowExpandButton() {
	}

	/**
	 *  Sets the visibility of expand/collapse button.
	 * 
	 *  @param showExpandButton true to show expand/collapse button.
	 */
	public void setShowExpandButton(boolean showExpandButton) {
	}

	/**
	 *  Expands or collapses the <code>CollapsiblePane</code>. Different from {@link #setCollapsed(boolean)} method which
	 *  is to set the state, this method is an action which will use the animation to expand/collapse this
	 *  <code>CollapsiblePane</code>.
	 * 
	 *  @param collapse true or false.
	 */
	public void collapse(boolean collapse) {
	}

	/**
	 *  Gets the <code>focusPainted</code> property.
	 * 
	 *  @return the <code>focusPainted</code> property
	 * 
	 *  @see #setFocusPainted
	 */
	public boolean isFocusPainted() {
	}

	/**
	 *  Sets the <code>focusPainted</code> property, which must be <code>true</code> for the focus state to be painted.
	 *  The default value for the <code>focusPainted</code> property is <code>true</code>. Some look and feels might not
	 *  paint focus state; they will ignore this property.
	 * 
	 *  @param b if <code>true</code>, the focus state should be painted
	 *  @see #isFocusPainted
	 */
	public void setFocusPainted(boolean b) {
	}

	/**
	 *  Gets the <code>contentAreaFilled</code> property.
	 * 
	 *  @return the <code>contentAreaFilled</code> property
	 * 
	 *  @see #setContentAreaFilled
	 */
	public boolean isContentAreaFilled() {
	}

	/**
	 *  Sets the <code>contentAreaFilled</code> property. The default value for the <code>contentAreaFilled</code>
	 *  property is <code>true</code>. Some look and feels might not paint focus state; they will ignore this property.
	 * 
	 *  @param contentAreaFilled true or false.
	 *  @see #isContentAreaFilled
	 */
	public void setContentAreaFilled(boolean contentAreaFilled) {
	}

	/**
	 *  Gets the <code>titlePaneOpaque</code> property.
	 * 
	 *  @return the <code>titlePaneOpaque</code> property
	 * 
	 *  @see #setTitlePaneOpaque(boolean)
	 */
	public boolean isTitlePaneOpaque() {
	}

	/**
	 *  Sets the <code>titlePaneOpaque</code> property. The default value for the <code>titlePaneOpaque</code> property
	 *  is <code>true</code>. If false, the title pane will not paint the background.
	 * 
	 *  @param opaque true or false.
	 *  @see #isContentAreaFilled
	 */
	public void setTitlePaneOpaque(boolean opaque) {
	}

	/**
	 *  Gets the title component that is displayed on the title pane of CollapsiblePane.
	 * 
	 *  @return the title component.
	 */
	public java.awt.Component getTitleComponent() {
	}

	/**
	 *  Sets the title components. CollapsiblePane will display the title component as the last component on the title
	 *  pane before the expand button. It will always use the preferred size by default although it depends on the
	 *  specific L&F implementation.
	 * 
	 *  @param titleComponent the title component
	 */
	public void setTitleComponent(java.awt.Component titleComponent) {
	}

	/**
	 *  Sets a component which will be used to replace the default title. The default title label is used to display the
	 *  title and the icon. So if you use your own component, you have to set the title as the text on your component.
	 *  You can pass in null so that the default title label will be used.
	 * 
	 *  @param component title label component
	 */
	public void setTitleLabelComponent(javax.swing.JComponent component) {
	}

	/**
	 *  Gets the component which is used to replace the default title. Null if you never set it before.
	 * 
	 *  @return the title label component.
	 */
	public javax.swing.JComponent getTitleLabelComponent() {
	}

	/**
	 *  Gets the <code>autoExpandOnDragover</code> property.
	 * 
	 *  @return the <code>autoExpandOnDropping</code> property
	 * 
	 *  @see #setAutoExpandOnDragover(boolean)
	 */
	public boolean isAutoExpandOnDragover() {
	}

	/**
	 *  Sets the <code>autoExpandOnDragover</code> property. The default value for the <code>autoExpandOnDropping</code>
	 *  property is <code>true</code>. If false, the collapsible pane will not expand when something is dragged over the
	 *  title pane.
	 * 
	 *  @param b true or false.
	 */
	public void setAutoExpandOnDragover(boolean b) {
	}

	/**
	 *  Checks if the mouse is over the title pane.
	 * 
	 *  @return true if the mouse is over the title pane.
	 */
	public boolean isRollover() {
	}

	/**
	 *  Sets rollover. It means the mouse is over the title pane of the CollapsiblePane.
	 * 
	 *  @param rollover true or false
	 */
	public void setRollover(boolean rollover) {
	}

	/**
	 *  Sets the expanded icon which is used for the expand button.
	 * 
	 *  @param icon the <code>ExpandedIcon</code> for the expand button
	 *  @see #getExpandedIcon
	 */
	public void setExpandedIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Gets the expanded icon which is used for the expand button. It is null by default unless you set it. If null, it
	 *  means the default icon will be used depending on the look and feel. Please note, this icon is only used if the
	 *  collapsible pane style is TREE_STYLE or PLAIN_STYLE.
	 * 
	 *  @return the <code>Expandedicon</code> for the expand button.
	 * 
	 *  @see #setExpandedIcon
	 */
	public javax.swing.Icon getExpandedIcon() {
	}

	/**
	 *  Sets the collapsed icon which is used for the expand button.
	 * 
	 *  @param icon the <code>CollapsedIcon</code> for the expand button
	 *  @see #getCollapsedIcon
	 */
	public void setCollapsedIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Gets the collapsed icon which is used for the expand button. It is null by default unless you set it. If null, it
	 *  means the default icon will be used depending on the look and feel. Please note, this icon is only used if the
	 *  collapsible pane style is TREE_STYLE or PLAIN_STYLE.
	 * 
	 *  @return the <code>Collapsedicon</code> for the expand button.
	 * 
	 *  @see #setCollapsedIcon
	 */
	public javax.swing.Icon getCollapsedIcon() {
	}

	/**
	 *  This class implements accessibility support for the <code>CollapsiblePane</code> class.  It provides an
	 *  implementation of the Java Accessibility API appropriate to collapsible pane user-interface elements.
	 */
	protected class AccessibleCollapsiblePane {


		protected CollapsiblePane.AccessibleCollapsiblePane() {
		}

		/**
		 *  Get the accessible name of this object.
		 * 
		 *  @return the localized name of the object -- can be <code>null</code> if this object does not have a name
		 * 
		 *  @see #setAccessibleName
		 */
		@java.lang.Override
		public String getAccessibleName() {
		}

		/**
		 *  Get the role of this object.
		 * 
		 *  @return an instance of AccessibleRole describing the role of the object
		 * 
		 *  @see AccessibleRole
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleRole getAccessibleRole() {
		}

		/**
		 *  Gets the AccessibleValue associated with this object.  In the implementation of the Java Accessibility API
		 *  for this class, returns this object, which is responsible for implementing the <code>AccessibleValue</code>
		 *  interface on behalf of itself.
		 * 
		 *  @return this object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleValue getAccessibleValue() {
		}

		/**
		 *  Get the value of this object as a Number.
		 * 
		 *  @return value of the object -- can be <code>null</code> if this object does not have a value
		 */
		public Number getCurrentAccessibleValue() {
		}

		/**
		 *  Set the value of this object as a Number.
		 * 
		 *  @return <code>true</code> if the value was set
		 */
		public boolean setCurrentAccessibleValue(Number n) {
		}

		/**
		 *  Get the minimum value of this object as a Number.
		 * 
		 *  @return Minimum value of the object; <code>null</code> if this object does not have a minimum value
		 */
		public Number getMinimumAccessibleValue() {
		}

		/**
		 *  Get the maximum value of this object as a Number.
		 * 
		 *  @return Maximum value of the object; <code>null</code> if this object does not have a maximum value
		 */
		public Number getMaximumAccessibleValue() {
		}
	}
}
