/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


/**
 *  This is a subclass of {@link com.jidesoft.database.DatabaseTableModel} to allow the change to the data model be comitted
 *  to the database.
 */
public class CrudDatabaseTableModel extends DatabaseTableModel implements CrudTableModel {
 {

	/**
	 *  Creates a CrudDatabaseTableModel.
	 * 
	 *  @param connection      a database connection.
	 *  @param fromStatement   a SQL from statement. It could be <ul> <li>FROM first_table <li>FROM first_table,
	 *                         second_table <li>FROM first_table LEFT JOIN second_table <li>FROM first_table INNER JOIN
	 *                         second_table </ul>
	 *  @throws SQLException if a database related error happens. It could be because the connection is closed.
	 */
	public CrudDatabaseTableModel(java.sql.Connection connection, String fromStatement) {
	}

	/**
	 *  Creates a CrudDatabaseTableModel.
	 * 
	 *  @param connection      a database connection.
	 *  @param selectStatement a SQL select statement. If null, we default it to "*".
	 *  @param fromStatement   a SQL from statement. It could be <ul> <li>FROM first_table <li>FROM first_table,
	 *                         second_table <li>FROM first_table LEFT JOIN second_table <li>FROM first_table INNER JOIN
	 *                         second_table </ul>
	 *  @throws SQLException if a database related error happens. It could be because the connection is closed.
	 */
	public CrudDatabaseTableModel(java.sql.Connection connection, String selectStatement, String fromStatement) {
	}

	/**
	 *  Creates a CrudDatabaseTableModel.
	 * 
	 *  @param connection      a database connection.
	 *  @param selectStatement a SQL select statement. If null, we default it to "*".
	 *  @param fromStatement   a SQL from statement. It could be <ul> <li>FROM first_table <li>FROM first_table,
	 *                         second_table <li>FROM first_table LEFT JOIN second_table <li>FROM first_table INNER JOIN
	 *                         second_table </ul>
	 *  @param updatable       if the table model is updatable (or editable)
	 *  @throws SQLException if a database related error happens. It could be because the connection is closed.
	 */
	public CrudDatabaseTableModel(java.sql.Connection connection, String selectStatement, String fromStatement, boolean updatable) {
	}

	@java.lang.Override
	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public int getRowCount() {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void refreshData(SortItemSupport sortItemSupport, FilterItemSupport filterItemSupport) {
	}

	@java.lang.Override
	public void commit() {
	}

	/**
	 *  Rollback the current editing.
	 */
	public void rollback() {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public boolean isUpdatable() {
	}

	@java.lang.Override
	public void setUpdatable(boolean updatable) {
	}

	public void deleteRow(int rowIndex) {
	}

	public void updateRow(int rowIndex, Object[] columns) {
	}

	public Object[] readRow(int rowIndex) {
	}

	public void insertRow(Object[] columns) {
	}
}
