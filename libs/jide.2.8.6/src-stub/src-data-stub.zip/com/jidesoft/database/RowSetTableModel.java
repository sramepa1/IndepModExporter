/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


public class RowSetTableModel extends ResultSetTableModel {

	public RowSetTableModel(java.sql.ResultSet resultSet) {
	}

	public RowSetTableModel(java.sql.ResultSet resultSet, int rowCount) {
	}

	public void insertBlankRow() {
	}
}
