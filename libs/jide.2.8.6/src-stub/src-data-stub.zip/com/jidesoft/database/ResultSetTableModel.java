/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


/**
 *  <code>ResultSetTableModel</code> uses an existing <code>ResultSet</code> and display it in a table model.
 */
public class ResultSetTableModel extends javax.swing.table.AbstractTableModel {

	protected int _recordCount;

	protected transient int _currentRow;

	protected TableModelCache _cache;

	protected boolean _forwardOnly;

	protected java.sql.ResultSet _resultSet;

	protected static final java.util.logging.Logger LOGGER;

	/**
	 *  Creates a RecordSetTableModel.
	 * 
	 *  @param resultSet a database ResultSet.
	 *  @throws SQLException if a database related error happens. It could be because the connection is closed.
	 */
	public ResultSetTableModel(java.sql.ResultSet resultSet) {
	}

	/**
	 *  Creates a RecordSetTableModel.
	 * 
	 *  @param resultSet   a database ResultSet.
	 *  @param recordCount the record count in the ResultSet.
	 *  @throws SQLException if a database related error happens. It could be because the connection is closed.
	 */
	public ResultSetTableModel(java.sql.ResultSet resultSet, int recordCount) {
	}

	public int getColumnCount() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	@java.lang.Override
	public Class getColumnClass(int columnIndex) {
	}

	public int getRowCount() {
	}

	public void invalidateCache(int row) {
	}

	public void invalidateCache() {
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Queries the ResultSet and create the column information.
	 * 
	 *  @throws java.sql.SQLException if a database access error occurs, this method is called on a closed
	 *                                <code>Statement</code> or the given SQL statement produces anything other than a
	 *                                single <code>ResultSet</code> object
	 */
	protected void refreshData() {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	public void setUpdatable(boolean updatable) {
	}

	public boolean isUpdatable() {
	}

	public java.sql.ResultSet getResultSet() {
	}

	public boolean isForwardOnly() {
	}

	public void setForwardOnly(boolean forwardOnly) {
	}

	public void close() {
	}

	public int getMaximumCachedRows() {
	}

	public void setMaximumCachedRows(int maximumCachedRows) {
	}
}
