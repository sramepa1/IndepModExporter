/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


/**
 *  An adapter class for the interface {@link com.jidesoft.database.CrudTableModel} for easy implementation.
 */
public class CrudTableModelAdapter implements javax.swing.table.TableModel, CrudTableModel {
 {

	protected final javax.swing.table.TableModel tableModel;

	public CrudTableModelAdapter(javax.swing.table.TableModel tableModel) {
	}

	public void addTableModelListener(javax.swing.event.TableModelListener l) {
	}

	public void removeTableModelListener(javax.swing.event.TableModelListener l) {
	}

	public int getColumnCount() {
	}

	public String getColumnName(int column) {
	}

	public Class getColumnClass(int columnIndex) {
	}

	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	public int getRowCount() {
	}

	public void insertRow(Object[] columns) {
	}

	public Object[] readRow(int rowIndex) {
	}

	public void updateRow(int rowIndex, Object[] columns) {
	}

	public void deleteRow(int rowIndex) {
	}
}
