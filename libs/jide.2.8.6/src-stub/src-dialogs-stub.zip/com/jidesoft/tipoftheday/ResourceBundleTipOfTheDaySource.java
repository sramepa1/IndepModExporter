/**
 *  The package contains classes related for TipOfTheDay dialog for JIDE Dialogs product.
 */
package com.jidesoft.tipoftheday;


/**
 *  This is TipOfTheDay source based on resource bundle.
 */
public class ResourceBundleTipOfTheDaySource implements TipOfTheDaySource {
 {

	public ResourceBundleTipOfTheDaySource(java.util.ResourceBundle bundle) {
	}

	public ResourceBundleTipOfTheDaySource(java.util.ResourceBundle bundle, String bundleKeyPattern) {
	}

	public int getCurrentTipIndex() {
	}

	public void setCurrentTipIndex(int currentTipIndex) {
	}

	public String getNextTip() {
	}

	public String getPreviousTip() {
	}

	protected String getTip() {
	}
}
