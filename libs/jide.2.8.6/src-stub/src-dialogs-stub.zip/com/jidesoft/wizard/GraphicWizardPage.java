/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  GraphicWizardPage is a wizard page with left pane to display
 *  a graphic.
 *  <p/>
 *  If the wizard follows Wizard 97 standard, it will add
 *  title with a larger font and add a description in
 *  content area as well.
 */
public class GraphicWizardPage extends DefaultWizardPage {

	/**
	 *  Creates a GraphicWizardPage with title.
	 * 
	 *  @param title
	 */
	public GraphicWizardPage(String title) {
	}

	/**
	 *  Creates a GraphicWizardPage with title and description.
	 * 
	 *  @param title
	 *  @param description
	 */
	public GraphicWizardPage(String title, String description) {
	}

	@java.lang.Override
	public boolean showBannerPane() {
	}

	@java.lang.Override
	public int getLeftPaneItems() {
	}

	@java.lang.Override
	protected void initContentPane() {
	}

	@java.lang.Override
	public java.awt.Color getBackground() {
	}
}
