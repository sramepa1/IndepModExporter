/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  WizardStyle is a center place to control the style of all wizards in an JVM.
 */
public class WizardStyle {

	/**
	 *  Predefined style of WizardDialog. See detailed information at <a href=http://msdn.microsoft.com/library/default.asp?url=/library/en-us/wizard/sdkwizv4_7awn.asp>Micrsoft
	 *  Wizard 97 Standard</a>
	 */
	public static final int WIZARD97_STYLE = 0;

	/**
	 *  Predefined style of WizardDialog See detailed information at <a href=http://java.sun.com/products/jlf/at/book/Wizards.html>Java
	 *  LookAndFeel Wizard Standard</a>
	 */
	public static final int JAVA_STYLE = 2;

	/**
	 *  Predefined style of WizardDialog
	 */
	public static final int MACOSX_STYLE = 3;

	public WizardStyle() {
	}

	/**
	 *  Gets the wizard style.
	 * 
	 *  @return the wizard style
	 */
	public static int getStyle() {
	}

	/**
	 *  Sets the wizard style.
	 * 
	 *  @param style
	 */
	public static void setStyle(int style) {
	}

	/**
	 *  Returns the default values for this wizard style.
	 * 
	 *  @return a <code>UIDefaults</code> object containing the default values
	 */
	public static javax.swing.UIDefaults getDefaults() {
	}

	/**
	 *  Returns a drawing font from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the font
	 *  @return the <code>Font</code> object
	 */
	public static java.awt.Font getFont(Object key) {
	}

	/**
	 *  Returns a drawing font from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the font
	 *  @param l   the <code>Locale</code> for which the font is desired
	 *  @return the <code>Font</code> object
	 * 
	 *  @since 1.4
	 */
	public static java.awt.Font getFont(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns a drawing color from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the color
	 *  @return the <code>Color</code> object
	 */
	public static java.awt.Color getColor(Object key) {
	}

	/**
	 *  Returns a drawing color from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the color
	 *  @param l   the <code>Locale</code> for which the color is desired
	 *  @return the <code>Color</code> object
	 * 
	 *  @since 1.4
	 */
	public static java.awt.Color getColor(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns an <code>Icon</code> from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the icon
	 *  @return the <code>Icon</code> object
	 */
	public static javax.swing.Icon getIcon(Object key) {
	}

	/**
	 *  Returns an <code>Icon</code> from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the icon
	 *  @param l   the <code>Locale</code> for which the icon is desired
	 *  @return the <code>Icon</code> object
	 * 
	 *  @since 1.4
	 */
	public static javax.swing.Icon getIcon(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns a border from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the border
	 *  @return the <code>Border</code> object
	 */
	public static javax.swing.border.Border getBorder(Object key) {
	}

	/**
	 *  Returns a border from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the border
	 *  @param l   the <code>Locale</code> for which the border is desired
	 *  @return the <code>Border</code> object
	 * 
	 *  @since 1.4
	 */
	public static javax.swing.border.Border getBorder(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns a string from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the string
	 *  @return the <code>String</code>
	 */
	public static String getString(Object key) {
	}

	/**
	 *  Returns a string from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the string
	 *  @param l   the <code>Locale</code> for which the string is desired
	 *  @return the <code>String</code>
	 */
	public static String getString(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns an integer from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the int
	 *  @return the int
	 */
	public static int getInt(Object key) {
	}

	/**
	 *  Returns an integer from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the int
	 *  @param l   the <code>Locale</code> for which the int is desired
	 *  @return the int
	 * 
	 *  @since 1.4
	 */
	public static int getInt(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns a boolean from the defaults table which is associated with the key value. If the key is not found or the
	 *  key doesn't represent a boolean value then false will be returned.
	 * 
	 *  @param key an <code>Object</code> specifying the key for the desired boolean value
	 *  @return the boolean value corresponding to the key
	 * 
	 *  @since 1.4
	 */
	public static boolean getBoolean(Object key) {
	}

	/**
	 *  Returns a boolean from the defaults table which is associated with the key value and the given
	 *  <code>Locale</code>. If the key is not found or the key doesn't represent a boolean value then false will be
	 *  returned.
	 * 
	 *  @param key an <code>Object</code> specifying the key for the desired boolean value
	 *  @param l   the <code>Locale</code> for which the boolean is desired
	 *  @return the boolean value corresponding to the key
	 * 
	 *  @since 1.4
	 */
	public static boolean getBoolean(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns an <code>Insets</code> object from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the <code>Insets</code> object
	 *  @return the <code>Insets</code> object
	 */
	public static java.awt.Insets getInsets(Object key) {
	}

	/**
	 *  Returns an <code>Insets</code> object from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the <code>Insets</code> object
	 *  @param l   the <code>Locale</code> for which the object is desired
	 *  @return the <code>Insets</code> object
	 * 
	 *  @since 1.4
	 */
	public static java.awt.Insets getInsets(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns a dimension from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the dimension object
	 *  @return the <code>Dimension</code> object
	 */
	public static java.awt.Dimension getDimension(Object key) {
	}

	/**
	 *  Returns a dimension from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the dimension object
	 *  @param l   the <code>Locale</code> for which the object is desired
	 *  @return the <code>Dimension</code> object
	 * 
	 *  @since 1.4
	 */
	public static java.awt.Dimension getDimension(Object key, java.util.Locale l) {
	}

	/**
	 *  Returns an object from the defaults table.
	 * 
	 *  @param key an <code>Object</code> specifying the desired object
	 *  @return the <code>Object</code>
	 */
	public static Object get(Object key) {
	}

	/**
	 *  Returns an object from the defaults table that is appropriate for the given locale.
	 * 
	 *  @param key an <code>Object</code> specifying the desired object
	 *  @param l   the <code>Locale</code> for which the object is desired
	 *  @return the <code>Object</code>
	 */
	public static Object get(Object key, java.util.Locale l) {
	}

	/**
	 *  Stores an object in the defaults table.
	 * 
	 *  @param key   an <code>Object</code> specifying the retrieval key
	 *  @param value the <code>Object</code> to store
	 *  @return the <code>Object</code> returned by {@link UIDefaults#put}
	 */
	public static Object put(Object key, Object value) {
	}

	protected static void installJavaWizardStyle() {
	}

	protected static void installWizard97Style() {
	}

	protected static void installMacOSXWizardStyle() {
	}
}
