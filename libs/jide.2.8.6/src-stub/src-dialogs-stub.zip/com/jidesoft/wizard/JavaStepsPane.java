/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  JavaStepsPane is a pane used by Java L&F wizard standard to display a a list of steps in the left pane.
 */
public class JavaStepsPane extends StepsPane {

	protected java.awt.Color _selectionBackground;

	protected java.awt.Color _selectionForeground;

	protected boolean _contentNumbered;

	protected boolean _navigable;

	protected WizardDialogPane _wizardDialogPane;

	/**
	 *  The JList contains the steps.
	 */
	protected javax.swing.JList _contentList;

	protected JavaWizardHeader _header;

	/**
	 *  Creates JavaStepsPane.
	 */
	public JavaStepsPane() {
	}

	public JavaStepsPane(java.awt.Image image) {
	}

	/**
	 *  Sets the page list.
	 * 
	 *  @param list PageList
	 */
	@java.lang.Override
	public void setPageList(PageList list) {
	}

	@java.lang.Override
	public void setSelectedPage(String title) {
	}

	/**
	 *  Sets the selected page in the list.
	 * 
	 *  @param title     the selected page title.
	 *  @param fireEvent true to call setCurrentPage to set the current page in the wizard. False to select the step in
	 *                   the list only and do not call setCurrentPage.
	 */
	@java.lang.Override
	public void setSelectedPage(String title, boolean fireEvent) {
	}

	@java.lang.Override
	public void setSelectedIndex(int index) {
	}

	/**
	 *  Sets the selected page using the index.
	 * 
	 *  @param index     the selected page index.
	 *  @param fireEvent true to call setCurrentPage to set the current page in the wizard. False to select the step in
	 *                   the list only and do not call setCurrentPage.
	 */
	@java.lang.Override
	public void setSelectedIndex(int index, boolean fireEvent) {
	}

	/**
	 *  Gets the selection background in the step list.
	 * 
	 *  @return the selection background.
	 */
	public java.awt.Color getSelectionBackground() {
	}

	/**
	 *  Sets the selection background.
	 * 
	 *  @param selectionBackground the new selection background when the step in the list is selected.
	 */
	public void setSelectionBackground(java.awt.Color selectionBackground) {
	}

	/**
	 *  Gets the selection foreground in the step list.
	 * 
	 *  @return the selection foreground.
	 */
	public java.awt.Color getSelectionForeground() {
	}

	/**
	 *  Sets the selection foreground.
	 * 
	 *  @param selectionForeground the new selection foreground when the step in the list is selected.
	 */
	public void setSelectionForeground(java.awt.Color selectionForeground) {
	}

	/**
	 *  Gets the JList that shows the steps.
	 * 
	 *  @return the JList that shows the steps.
	 */
	public javax.swing.JList getStepsList() {
	}

	@java.lang.Override
	public boolean isNavigable() {
	}

	/**
	 *  Makes the StepsPane navigable.
	 * 
	 *  @param navigable true or false.
	 */
	@java.lang.Override
	public void setNavigable(boolean navigable) {
	}

	@java.lang.Override
	public WizardDialogPane getWizardDialogPane() {
	}

	@java.lang.Override
	public void setWizardDialogPane(WizardDialogPane wizardDialogPane) {
	}
}
