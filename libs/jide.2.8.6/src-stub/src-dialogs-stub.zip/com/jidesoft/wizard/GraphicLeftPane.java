/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  A JPanel that renders an image, tiling as necessary to fill the panel.
 */
public class GraphicLeftPane extends LeftPane {

	protected java.awt.Image _image;

	protected int _imageWidth;

	protected int _imageHeight;

	/**
	 *  Creates a graphic panel without image.
	 */
	public GraphicLeftPane() {
	}

	/**
	 *  Creates a graphic panel with image.
	 * 
	 *  @param image the image
	 */
	public GraphicLeftPane(java.awt.Image image) {
	}

	/**
	 *  Override to paint the image.
	 * 
	 *  @param g the Graphics
	 */
	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Override to get preferred size. If image is not null, the preferred size will equal to image size.
	 * 
	 *  @return the preferred size.
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}
}
