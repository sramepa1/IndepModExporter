/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


public interface SubEntryGanttEntry extends MutableGanttEntry {
 {

	public java.util.List getSubEntries();

	public void setSubEntries(java.util.List subEntries);

	public void addSubEntry(GanttEntry entry);

	public void removeSubEntry(GanttEntry entry);
}
