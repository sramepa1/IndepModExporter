/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  A utility class so you can easily create a TexturePaint by painting the pattern in Java 2D.
 */
public abstract class PaintedTexture {

	/**
	 *  @param width  The width of the pattern tile.
	 *  @param height The height of the pattern tile.
	 */
	public PaintedTexture(int width, int height) {
	}

	public int getWidth() {
	}

	public int getHeight() {
	}

	/**
	 *  Sub classes should paint the pattern in the rectangle (0, 0, width, height).
	 * 
	 *  @param graphics The graphics to paint with.
	 */
	protected abstract void drawTexture(java.awt.Graphics2D graphics) {
	}

	public java.awt.TexturePaint createTexturePaint() {
	}

	public static java.awt.TexturePaint createDiagonalLines(int width, int height, java.awt.Paint paint, boolean forward, boolean backward) {
	}

	public static java.awt.TexturePaint createLines(int width, int height, java.awt.Paint paint, boolean horizontal, boolean vertical) {
	}
}
