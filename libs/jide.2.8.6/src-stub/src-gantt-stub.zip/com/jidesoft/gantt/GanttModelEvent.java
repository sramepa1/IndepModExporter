/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>GanttModelEvent</code> is used to notify listeners that a gantt model has changed. The model event describes
 *  changes to a GanttModel and all references to rows are in the co-ordinate system of the model. Depending on the
 *  parameters used in the constructors, the GanttModelEvent can be used to specify the following types of changes: <p>
 *  <p/>
 *  <pre>
 *  GanttModelEvent(source);              //  The data, ie. all rows changed
 *  GanttModelEvent(source, 1);           //  Row 1 changed
 *  GanttModelEvent(source, 3, 6);        //  Rows 3 to 6 inclusive changed
 *  GanttModelEvent(source, 3, 6, INSERT); // Rows (3, 6) were inserted
 *  GanttModelEvent(source, 3, 6, DELETE); // Rows (3, 6) were deleted
 *  </pre>
 *  <p/>
 *  It is possible to use other combinations of the parameters, not all of them are meaningful.
 *  <p/>
 */
public class GanttModelEvent extends java.util.EventObject {

	public static final int UPDATE = 0;

	public static final int INSERT = 1;

	public static final int DELETE = -1;

	/**
	 *  Identifies the Range of the GanttModel.
	 */
	public static final int RANGE = -2;

	protected int _type;

	protected int _firstRow;

	protected int _lastRow;

	public GanttModelEvent(Object source) {
	}

	/**
	 *  All row data in the table has changed, listeners should discard any state that was based on the rows and requery
	 *  the <code>GanttModel</code> to get the new row count and all the appropriate values. The <code>JTable</code> will
	 *  repaint the entire visible region on receiving this event, querying the model for the cell values that are
	 *  visible. The structure of the table ie, the column names, types and order have not changed.
	 * 
	 *  @param source the source of the GanttModelEvent.
	 */
	public GanttModelEvent(GanttModel source) {
	}

	/**
	 *  This row of data has been updated. To denote the arrival of a completely new table with a different structure use
	 *  <code>HEADER_ROW</code> as the value for the <code>row</code>. When the <code>JTable</code> receives this event
	 *  and its <code>autoCreateColumnsFromModel</code> flag is set it discards any TableColumns that it had and
	 *  reallocates default ones in the order they appear in the model. This is the same as calling
	 *  <code>setModel(GanttModel)</code> on the <code>JTable</code>.
	 * 
	 *  @param source the source of the GanttModelEvent.
	 *  @param row    the row.
	 */
	public GanttModelEvent(GanttModel source, int row) {
	}

	/**
	 *  The rows in rows [<I>firstRow</I>, <I>lastRow</I>] have been updated.
	 * 
	 *  @param source   the source of the GanttModelEvent.
	 *  @param firstRow the first row of the event.
	 *  @param lastRow  the last row of the event.
	 */
	public GanttModelEvent(GanttModel source, int firstRow, int lastRow) {
	}

	/**
	 *  The rows from firstRow to lastRow have been changed. The change could be inserted, deleted or updated.
	 *  <p/>
	 *  The <I>type</I> should be one of: INSERT, UPDATE and DELETE.
	 * 
	 *  @param source   the source of the GanttModelEvent.
	 *  @param firstRow the first row of the event.
	 *  @param lastRow  the last row of the event.
	 *  @param type     the type of the event.
	 */
	public GanttModelEvent(GanttModel source, int firstRow, int lastRow, int type) {
	}

	/**
	 *  Returns the first row that changed.
	 * 
	 *  @return the first row that changed.
	 */
	public int getFirstRow() {
	}

	/**
	 *  Returns the last row that changed.
	 * 
	 *  @return the last row that changed.
	 */
	public int getLastRow() {
	}

	/**
	 *  Returns the type of event - one of: INSERT, UPDATE and DELETE.
	 * 
	 *  @return the type of the event.
	 */
	public int getType() {
	}
}
