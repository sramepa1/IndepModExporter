/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DefaultGanttEntryRenderer</code> is a default implementation of <code>GanttEntryRenderer</code>. It uses the
 *  {@link TaskBar} as the component to paint the entry.
 */
public class DefaultGanttEntryRenderer extends TaskBar implements GanttEntryRenderer {
 {

	public DefaultGanttEntryRenderer() {
	}

	public java.awt.Component getGanttEntryRendererComponent(GanttChart chart, GanttEntry entry, boolean isSelected, boolean hasFocus, int row, java.awt.Insets insets) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public boolean isOpaque() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 * 
	 *  @since 1.5
	 */
	@java.lang.Override
	public void invalidate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void validate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void revalidate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void repaint(long tm, int x, int y, int width, int height) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void repaint(java.awt.Rectangle r) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void repaint() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}
}
