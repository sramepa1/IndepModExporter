/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DateGanttChartPane</code> is a GanttChartPane that uses the Date.class as the unit for the scale. It uses
 *  {@link DateGanttChart} internally.
 * 
 *  @param <S> The type of the GanttEntry in the model.
 */
public class DateGanttChartPane extends GanttChartPane {

	public DateGanttChartPane(GanttModel ganttModel) {
	}

	/**
	 *  Overridden to install various default DatePeriod converters.
	 */
	@java.lang.Override
	protected GanttChart createGanttChart(GanttModel ganttModel) {
	}
}
