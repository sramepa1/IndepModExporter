/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  Marks an interval of the scale independent of any Period of the ScaleModel. The Interval marker can also be used to
 *  mark just an instant by specifying the same start and end instant.
 * 
 *  @param <T> The base unit of the scale.
 */
public class IntervalMarker extends AbstractPeriodBackgroundPainter {

	public IntervalMarker(java.awt.Paint paint, java.awt.Stroke stroke, Object instant) {
	}

	public IntervalMarker(java.awt.Paint backgroundPaint, java.awt.Paint outlinePaint, java.awt.Stroke outlineStroke, int outlineSides, Object startInstant, Object endInstant) {
	}

	public IntervalMarker() {
	}

	@java.lang.Override
	protected java.awt.Paint getBackgroundPaint(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	protected java.awt.Paint getOutlinePaint(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	protected int getOutlineSides(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	protected java.awt.Stroke getOutlineStroke(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	public void paintPeriodBackground(GanttChart ganttChart, java.awt.Graphics2D graphics, Object startInstant, Object endInstant, int periodStartX, int periodStartY, int periodEndX, int periodEndY) {
	}

	public Object getStartInstant() {
	}

	public void setStartInstant(Object startInstant) {
	}

	public Object getEndInstant() {
	}

	public void setEndInstant(Object endInstant) {
	}

	public java.awt.Paint getBackgroundPaint() {
	}

	public void setBackgroundPaint(java.awt.Paint backgroundPaint) {
	}

	public java.awt.Paint getOutlinePaint() {
	}

	public void setOutlinePaint(java.awt.Paint outlinePaint) {
	}

	public java.awt.Stroke getOutlineStroke() {
	}

	public void setOutlineStroke(java.awt.Stroke outlineStroke) {
	}

	public int getOutlineSides() {
	}

	public void setOutlineSides(int outlineSides) {
	}
}
