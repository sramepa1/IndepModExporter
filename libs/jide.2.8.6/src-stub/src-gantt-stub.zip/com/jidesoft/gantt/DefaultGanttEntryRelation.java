/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DefaultGanttEntryRelation</code> is the default implementation of <code>GanttEntryRelation</code>.
 * 
 *  @param <S> The type of the GanttEntry in the model.
 */
public class DefaultGanttEntryRelation implements GanttEntryRelation {
 {

	public DefaultGanttEntryRelation(GanttEntry predecessorEntry, GanttEntry successorEntry, int type) {
	}

	public GanttEntry getSuccessorEntry() {
	}

	public int getRelationType() {
	}

	public GanttEntry getPredecessorEntry() {
	}

	@java.lang.Override
	public String toString() {
	}
}
