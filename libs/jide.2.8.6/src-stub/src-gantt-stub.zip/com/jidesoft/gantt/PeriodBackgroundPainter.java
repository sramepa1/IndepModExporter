/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  PeriodBackgroundPainter is an interface used by GanttChart to paint the period background.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 */
public interface PeriodBackgroundPainter {

	/**
	 *  Paints the background.
	 * 
	 *  @param ganttChart   the gantt chart.
	 *  @param g            the graphics
	 *  @param startInstant the starting value of the current period. The painter will paint the background of gantt
	 *                      chart period by period. Each time, this method will be called for each period. The
	 *                      startInstant is the starting value of the current period.
	 *  @param endInstant   the ending value of the current period.
	 *  @param periodStartX the startX of the current period.
	 *  @param periodStartY the startY of the current period.
	 *  @param periodEndX   the endX of the current period.
	 *  @param periodEndY   the endY of the current period.
	 */
	public void paintPeriodBackground(GanttChart ganttChart, java.awt.Graphics2D g, Object startInstant, Object endInstant, int periodStartX, int periodStartY, int periodEndX, int periodEndY);

	/**
	 *  If the period is null, paint periodChartBackground will be called once, but the start and end instant will be
	 *  null and the coordinates will be invalid. The latter should be calculated by the painter itself using the scale
	 *  area and model.
	 * 
	 *  @return The Period this painter paints a background for or null to mark a specific interval.
	 */
	public com.jidesoft.scale.Period getPeriod();
}
