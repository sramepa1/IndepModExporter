/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  @param <S> The type of the GanttEntries in the model.
 */
public interface GanttEntryRelationModel {

	/**
	 *  Adds a new GanttEntryRelation.
	 * 
	 *  @param relation the GanttEntryRelation.
	 */
	public void addEntryRelation(GanttEntryRelation relation);

	/**
	 *  Removes an existing GanttEntryRelation.
	 * 
	 *  @param relation the GanttEntryRelation.
	 */
	public void removeEntryRelation(GanttEntryRelation relation);

	/**
	 *  Removes all relations associated with the specified entry.
	 * 
	 *  @param entry the entry
	 */
	public void removeEntryRelations(GanttEntry entry);

	/**
	 *  Gets the GanttEntryRelations for the specified GanttEntry.
	 * 
	 *  @param entry the GanttEntry.
	 *  @return the GanttEntryRelations associated with the specified GanttEntry.
	 */
	public java.util.Set getEntryRelations(GanttEntry entry);

	/**
	 *  Gets the GanttEntryRelations for the specified GanttEntry.
	 * 
	 *  @param start the GanttEntry.
	 *  @param end   the GanttEntry.
	 *  @return the GanttEntryRelations associated with the specified GanttEntry.
	 */
	public GanttEntryRelation getEntryRelation(GanttEntry start, GanttEntry end);

	/**
	 *  Adds a GanttEntryRelationListener.
	 * 
	 *  @param listener the GanttEntryRelationListener.
	 */
	public void addGanttEntryRelationListener(GanttEntryRelationListener listener);

	/**
	 *  Removes a GanttEntryRelationListener.
	 * 
	 *  @param listener the GanttEntryRelationListener.
	 */
	public void removeGanttEntryRelationListener(GanttEntryRelationListener listener);
}
