/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>GanttModel</code> is the model for <code>GanttChart</code>. It specifies methods that <code>GanttChart</code>
 *  will use to interrogate the underlying gantt entires.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 *  @param <S> The type of the GanttEntries in the model.
 */
public interface GanttModel {

	/**
	 *  Gets the total entry count.
	 *  <p/>
	 *  Please note, if an entry has children and the entry itself is collapsed, the children will not be included in the
	 *  total entry count.
	 * 
	 *  @return the total entry count.
	 */
	public int getEntryCount();

	/**
	 *  Gets the entry at the entry index.
	 * 
	 *  @param index the entry index.
	 *  @return Returns the GanttEntry at the index or null if the index is out of bounds.
	 */
	public GanttEntry getEntryAt(int index);

	/**
	 *  Gets the index of the entry.
	 * 
	 *  @param entry the entry
	 *  @return the index.
	 */
	public int getIndexOf(GanttEntry entry);

	/**
	 *  Returns the <code>TreeTableModel</code> instance.
	 *  <p/>
	 *  The returned model should also be a {@link TableModel} instance! Enforcing this through the type system would
	 *  introduce another generic type.
	 * 
	 *  @return The TreeTableModel to be displayed in the TreeTable of the GanttChartPane.
	 */
	public <any> getTreeTableModel();

	/**
	 *  Gets the range of the <code>GanttModel</code>. It is the union of the ranges in all the gantt entries.
	 * 
	 *  @return the range.
	 */
	public <any> getRange();

	/**
	 *  Gets the ScaleModel.
	 * 
	 *  @return the ScaleModel.
	 */
	public com.jidesoft.scale.ScaleModel getScaleModel();

	/**
	 *  Gets the model that defines the relationship among gantt entries.
	 * 
	 *  @return the GanttEntryRelationModel.
	 */
	public GanttEntryRelationModel getGanttEntryRelationModel();

	/**
	 *  Adds a GanttModelListener.
	 * 
	 *  @param listener the GanttModelListener.
	 */
	public void addGanttModelListener(GanttModelListener listener);

	/**
	 *  Removes a GanttModelListener.
	 * 
	 *  @param listener a GanttModelListener.
	 */
	public void removeGanttModelListener(GanttModelListener listener);
}
