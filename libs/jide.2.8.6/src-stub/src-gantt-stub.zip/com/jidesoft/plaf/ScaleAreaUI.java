package com.jidesoft.plaf;


/**
 *  Pluggable Look & Feel for the the ScaleArea of the GanttChart.
 *  <p/>
 *  Note on generics: The generics of the ScaleArea and related classes are not preserved through the UIManager. The cast
 *  to ScaleArea<Object> where needed should be save.
 */
public abstract class ScaleAreaUI extends javax.swing.plaf.ComponentUI {

	public ScaleAreaUI() {
	}

	/**
	 *  Note: the components left-to-right orientation should be taken into account.
	 */
	public abstract long getPositionAt(int x) {
	}

	/**
	 *  Note: the components left-to-right orientation should be taken into account.
	 */
	public abstract int getX(long position) {
	}

	public abstract java.awt.Dimension getPreferredPeriodSize(com.jidesoft.scale.Period period) {
	}

	public abstract com.jidesoft.scale.Period getPeriodAt(int y) {
	}
}
