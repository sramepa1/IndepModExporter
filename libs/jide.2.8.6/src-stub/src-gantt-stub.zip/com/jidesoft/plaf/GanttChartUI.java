package com.jidesoft.plaf;


public abstract class GanttChartUI extends javax.swing.plaf.ComponentUI {

	public GanttChartUI() {
	}

	public abstract java.awt.Dimension getPreferredScrollableViewportSize(com.jidesoft.gantt.GanttChart ganttChart) {
	}
}
