package com.jidesoft.plaf.basic;


public class BasicTaskBarUI extends com.jidesoft.plaf.TaskBarUI {

	public BasicTaskBarUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults() {
	}

	protected void uninstallDefaults() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}
}
