package com.jidesoft.plaf.basic;


public class BasicScaleAreaUI extends com.jidesoft.plaf.ScaleAreaUI {

	public static final String UI_PERIOD_HEADER_PAINTER = "ScaleArea.periodHeaderPainter";

	public static final String UI_MOUSE_DRAG_RESIZABLE = "ScaleAreaUI.mouseDragResizable";

	public BasicScaleAreaUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected com.jidesoft.scale.ScaleArea getScaleArea() {
	}

	@java.lang.SuppressWarnings("unchecked")
	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	@java.lang.SuppressWarnings("unused")
	protected com.jidesoft.plaf.PeriodHeaderPainter createDefaultPeriodHeaderPainter(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	@java.lang.SuppressWarnings("unused")
	protected void uninstallDefaults(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	protected void installListeners(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	protected BasicScaleAreaUI.Handler createHandler() {
	}

	protected void uninstallListeners(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	protected void paintBackground(java.awt.Graphics g, com.jidesoft.scale.ScaleArea scaleArea) {
	}

	@java.lang.SuppressWarnings("unchecked")
	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	@java.lang.SuppressWarnings("unchecked")
	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	protected void recalculateScale(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	@java.lang.Override
	public long getPositionAt(int x) {
	}

	@java.lang.Override
	public int getX(long position) {
	}

	protected int getLeftToRightX(long position) {
	}

	protected void setPreferredPeriodSize(java.awt.Dimension size) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredPeriodSize(com.jidesoft.scale.Period period) {
	}

	@java.lang.Override
	public com.jidesoft.scale.Period getPeriodAt(int y) {
	}

	protected static class Handler {


		protected static final java.util.Set SCALE_PROPERTIES;

		protected static final int MINIMUM_PERIOD_WIDTH = 10;

		protected static final int AREA_SIZE_RESIZE = 2;

		protected static final int NONE = 0;

		protected static final int RESIZE_PERIOD = 1;

		protected final BasicScaleAreaUI _ui;

		protected final boolean _resizable;

		public BasicScaleAreaUI.Handler(BasicScaleAreaUI ui) {
		}

		protected int getCurrentAction() {
		}

		@java.lang.SuppressWarnings("unchecked")
		public void propertyChange(java.beans.PropertyChangeEvent evt) {
		}

		public void mouseClicked(java.awt.event.MouseEvent e) {
		}

		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		public void mouseExited(java.awt.event.MouseEvent e) {
		}

		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		@java.lang.SuppressWarnings("unchecked")
		protected void maybeShowPopup(java.awt.event.MouseEvent e) {
		}

		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		public void mouseDragged(java.awt.event.MouseEvent e) {
		}
	}
}
