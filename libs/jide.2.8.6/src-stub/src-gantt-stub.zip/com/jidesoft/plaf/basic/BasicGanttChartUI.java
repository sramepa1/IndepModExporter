package com.jidesoft.plaf.basic;


public class BasicGanttChartUI extends com.jidesoft.plaf.GanttChartUI {

	public static final String UI_GANTT_CHART_FONT = "GanttChart.font";

	public static final String UI_GANTT_CHART_FOREGROUND = "GanttChart.foreground";

	public static final String UI_GANTT_CHART_BACKGROUND = "GanttChart.background";

	public static final String UI_GANTT_CHART_BACKGROUND_PAINTER = "GanttChart.backgroundPainter";

	/**
	 *  The UIManager key for an int specifying how many relations are painted. <ul><li>If visibleRelationsThreshold < 0
	 *  all relations are painted. <li>If visibleRelationsThreshold >= 0 only the relations of the visible row are
	 *  painted plus the relations of the threshold row count above and below the visible rows.</ul> For example, if the
	 *  visible row are 10 to 20 and the threshold is 25 then the relations of the entries at 0-10 and 21-45 are painted
	 *  if they cross over the visible part of the gantt chart.
	 */
	public static final String UI_VISIBLE_RELATIONS_THRESHOLD = "GanttChart.visibleRelationsThreshold";

	public static final int DEFAULT_VISIBLE_RELATIONS_THRESHOLD = 25;

	protected com.jidesoft.gantt.GanttChart _chart;

	protected javax.swing.CellRendererPane _rendererPane;

	public BasicGanttChartUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.SuppressWarnings("unchecked")
	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.SuppressWarnings("unchecked")
	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults(com.jidesoft.gantt.GanttChart ganttChart) {
	}

	protected void initializePainters(com.jidesoft.gantt.GanttChart ganttChart) {
	}

	protected void setPainterIfResource(com.jidesoft.gantt.GanttChart ganttChart, int type, com.jidesoft.plaf.GanttEntryRelationPainter painter) {
	}

	protected void uninstallDefaults(com.jidesoft.gantt.GanttChart ganttChart) {
	}

	protected void installKeyboardActions() {
	}

	public static void loadActionMap(LazyActionMap map) {
	}

	protected void uninstallKeyboardActions() {
	}

	protected void installListeners(com.jidesoft.gantt.GanttChart ganttChart) {
	}

	protected void uninstallListeners(com.jidesoft.gantt.GanttChart ganttChart) {
	}

	protected void paintBackground(java.awt.Graphics g, com.jidesoft.gantt.GanttChart ganttChart) {
	}

	protected void paintEntries(java.awt.Graphics g, com.jidesoft.gantt.GanttChart ganttChart, int firstRow, int lastRow) {
	}

	protected void paintGanttEntry(java.awt.Graphics g, com.jidesoft.gantt.GanttChart ganttChart, int row, java.awt.Rectangle rect, java.awt.Insets insets) {
	}

	protected void paintGanttLabel(java.awt.Graphics g, com.jidesoft.gantt.GanttChart ganttChart, int row, java.awt.Rectangle rect) {
	}

	@java.lang.SuppressWarnings("unchecked")
	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected void paintPeriodBackgrounds(java.awt.Graphics g, com.jidesoft.gantt.GanttChart ganttChart) {
	}

	protected void paintGrid(java.awt.Graphics g, com.jidesoft.gantt.GanttChart ganttChart, int rMin, int rMax) {
	}

	protected void paintSelection(java.awt.Graphics g, com.jidesoft.gantt.GanttChart ganttChart, int firstRow, int lastRow) {
	}

	protected void paintGanttEntryRelations(java.awt.Graphics g, com.jidesoft.gantt.GanttChart ganttChart, int firstRow, int lastRow) {
	}

	protected void paintGanttEntryRelation(java.awt.Graphics graphics, com.jidesoft.gantt.GanttChart ganttChart, com.jidesoft.gantt.GanttEntryRelation relation) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredScrollableViewportSize(com.jidesoft.gantt.GanttChart ganttChart) {
	}

	public static class BasicRelationPainter {


		public static final java.awt.Shape BLOCK;

		public static final java.awt.Shape ARROW;

		public static final int DEFAULT_EXTEND_WIDTH = 10;

		public BasicGanttChartUI.BasicRelationPainter(int width, java.awt.Shape startShape, java.awt.Shape endShape, java.awt.Insets entryPadding) {
		}
	}
}
