package com.jidesoft.plaf.basic;


public class TableCellRendererScaleAreaUI extends BasicScaleAreaUI {

	public TableCellRendererScaleAreaUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	protected com.jidesoft.plaf.PeriodHeaderPainter createDefaultPeriodHeaderPainter(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	protected void installDefaults(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	protected void calculatePreferredPeriodSize(com.jidesoft.scale.Period period) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredPeriodSize(com.jidesoft.scale.Period period) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected javax.swing.CellRendererPane getCellRendererPane() {
	}

	@java.lang.Override
	protected BasicScaleAreaUI.Handler createHandler() {
	}

	protected boolean isPeriodSelected(com.jidesoft.scale.Period period, Object startInstant, Object endInstant) {
	}

	protected void repaintPeriod(Object period, Object start, Object end) {
	}

	protected static class RendererPropertyChangeHandler {


		public TableCellRendererScaleAreaUI.RendererPropertyChangeHandler(TableCellRendererScaleAreaUI ui) {
		}

		@java.lang.Override
		public void propertyChange(java.beans.PropertyChangeEvent evt) {
		}

		protected TableCellRendererScaleAreaUI getUI() {
		}

		@java.lang.Override
		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseExited(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		protected void updateSelectedPeriod(java.awt.event.MouseEvent e) {
		}
	}
}
