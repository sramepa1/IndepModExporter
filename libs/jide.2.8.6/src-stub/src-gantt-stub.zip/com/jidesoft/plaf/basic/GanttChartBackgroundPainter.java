package com.jidesoft.plaf.basic;


public class GanttChartBackgroundPainter extends AbstractPeriodPainter implements javax.swing.plaf.UIResource {
 {

	public GanttChartBackgroundPainter() {
	}

	@java.lang.Override
	protected void paintPeriodInterval(com.jidesoft.scale.ScaleArea scaleArea, java.awt.Graphics2D graphics2D, com.jidesoft.scale.Period period, Object startInstant, Object endInstant, int periodStartX, int periodStartY, int periodEndX, int periodEndY) {
	}

	protected void paintPeriodBackgrounds(com.jidesoft.gantt.GanttChart ganttChart, java.awt.Graphics g, java.util.List painters) {
	}
}
