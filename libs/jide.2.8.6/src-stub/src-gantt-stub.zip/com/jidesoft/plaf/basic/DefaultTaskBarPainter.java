package com.jidesoft.plaf.basic;


public class DefaultTaskBarPainter implements TaskBarPainter {
 {

	public DefaultTaskBarPainter() {
	}

	public void paintTask(java.awt.Graphics2D g2d, com.jidesoft.gantt.TaskBar taskBar, java.awt.Rectangle rect, java.awt.Insets insets, java.awt.Color color, java.awt.Color borderColor, java.awt.Color percentageColor) {
	}

	public void paintTaskGroup(java.awt.Graphics2D g2d, com.jidesoft.gantt.TaskBar taskBar, java.awt.Rectangle rect, java.awt.Insets insets, java.awt.Color color, java.awt.Color border, java.awt.Color percentageColor) {
	}

	public void paintMilestone(java.awt.Graphics2D g2d, com.jidesoft.gantt.TaskBar taskBar, java.awt.Rectangle rect, java.awt.Insets insets, java.awt.Color color, java.awt.Color border, java.awt.Color percentageColor) {
	}
}
