package com.jidesoft.plaf;


public class GanttUIDefaultsCustomizer {

	public GanttUIDefaultsCustomizer() {
	}

	public void customize(javax.swing.UIDefaults defaults) {
	}
}
