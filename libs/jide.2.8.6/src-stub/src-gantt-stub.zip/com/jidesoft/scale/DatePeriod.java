package com.jidesoft.scale;


/**
 *  A DatePeriod defines a period based on {@link java.util.Calendar} fields for use in a {@link DateScaleModel}.
 *  <p/>
 *  Typically you'll want to use the defined constants, but you can create you own instance for a (regular) period of a
 *  Calendar field with your own amount and offset.
 * 
 *  @see #getDefaultDatePeriods()
 */
public class DatePeriod implements Period, java.io.Serializable {
 {

	public static final DatePeriod MILLENIUM;

	public static final DatePeriod CENTURY;

	public static final DatePeriod DECENNIUM;

	public static final DatePeriod YEAR;

	public static final DatePeriod QUARTER;

	public static final DatePeriod MONTH;

	public static final DatePeriod WEEK_OF_YEAR;

	public static final DatePeriod FIRST_DAY_OF_WEEK;

	public static final DatePeriod WEEK_OF_MONTH;

	public static final DatePeriod DAY_OF_WEEK;

	public static final DatePeriod DAY_OF_MONTH;

	public static final DatePeriod DAY_OF_WEEK_IN_MONTH;

	public static final DatePeriod DAY_OF_YEAR;

	public static final DatePeriod AM_PM;

	public static final DatePeriod HOUR;

	public static final DatePeriod HOUR_OF_DAY;

	public static final DatePeriod MINUTE;

	public static final DatePeriod SECOND;

	public static final DatePeriod MILLISECOND;

	/**
	 *  Defines a new period with last the amount of calendar field starting at the specified offset.
	 * 
	 *  @param calendarField The base Calendar field of this period, for example Calendar.MONTH.
	 *  @param amount        The amount of base field per period, for example 6 for six months.
	 *  @param offset        The offset from the Calendar field start, for example Calendar.APRIL to start the periods
	 *                       interval at April.
	 */
	public DatePeriod(int calendarField, int amount, int offset) {
	}

	/**
	 *  Gets The base Calendar field of this period as in the Calendar class. For example Calendar.MONTH, Calendar.YEAR
	 *  etc.
	 * 
	 *  @return The base Calendar field of this period
	 */
	public int getCalendarField() {
	}

	/**
	 *  Gets the amount of base field per period.
	 * 
	 *  @return the amount of base field per period.
	 */
	public int getAmount() {
	}

	/**
	 *  Gets the offset from the Calendar field start
	 * 
	 *  @return the offset from the Calendar field start.
	 */
	public int getOffset() {
	}

	@java.lang.Override
	public String toString() {
	}

	/**
	 *  Gets the list of predefined DatePeriods, from smallest to the largest.
	 * 
	 *  @return the list of predefined DatePeriods.
	 */
	public static java.util.List getDefaultDatePeriods() {
	}
}
