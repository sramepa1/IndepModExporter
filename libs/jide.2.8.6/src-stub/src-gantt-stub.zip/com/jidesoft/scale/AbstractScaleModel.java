package com.jidesoft.scale;


/**
 *  Abstract implementation of <code>ScaleModel</code>. It implements all other methods except {@link
 *  #getPosition(Object)}, {@link #getInstantAt(long)}, {@link #getPeriodStart(Period, Object)} and {@link
 *  #getPeriodEnd(Period, Object)}.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 */
public abstract class AbstractScaleModel implements ScaleModel, java.io.Serializable {
 {

	public AbstractScaleModel(Object defaultStart, Object defaultEnd, Period[] periods) {
	}

	public Object getDefaultEnd() {
	}

	public Object getDefaultStart() {
	}

	public java.util.List getPeriods() {
	}

	/**
	 *  Default implementation using getPeriodStart/End(Period, T) and getPosition(T).
	 *  <p/>
	 *  {@inheritDoc}
	 */
	public java.util.List getPeriodBoundaries(Period period, Object startInstant, Object endInstant) {
	}
}
