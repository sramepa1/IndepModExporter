package com.jidesoft.scale;


/**
 *  A simple integer numbers scale that ranges from 0 to 100.
 */
public class NumberScaleModel extends AbstractScaleModel {

	public NumberScaleModel() {
	}

	public Integer getInstantAt(long position) {
	}

	public Integer getPeriodEnd(Period period, Integer instant) {
	}

	public Integer getPeriodStart(Period period, Integer instant) {
	}

	public long getPosition(Integer instant) {
	}
}
