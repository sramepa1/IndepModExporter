package com.jidesoft.scale;


/**
 *  <code>DefaultPeriodConverter</code> is a default implementation of <code>PeriodConverter</code>.
 * 
 *  @param <T> The base unit of the ScaleModel to render the periods for.
 */
public class DefaultPeriodConverter extends AbstractPeriodConverter {

	public DefaultPeriodConverter() {
	}

	public DefaultPeriodConverter(String periodName) {
	}

	public String getText(Object startInstant, Object endInstant) {
	}

	public String getDescription(Object startInstant, Object endInstant) {
	}
}
