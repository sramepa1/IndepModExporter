package com.jidesoft.scale;


/**
 *  Abstract implementation of PeriodConverter.
 * 
 *  @param <T> The base unit of the ScaleModel to render the periods for.
 */
public abstract class AbstractPeriodConverter implements PeriodConverter, java.io.Serializable {
 {

	public AbstractPeriodConverter() {
	}

	public AbstractPeriodConverter(String periodName) {
	}

	public Object getPrototypeDisplayValue() {
	}

	public String getDisplayName() {
	}

	public void setPrototypeDisplayValue(Object prototypeDisplayValue) {
	}
}
