package com.jidesoft.scale;


public class ScaleAreaResources {

	public ScaleAreaResources() {
	}

	public static java.util.ResourceBundle getResourceBundle(java.util.Locale locale) {
	}
}
