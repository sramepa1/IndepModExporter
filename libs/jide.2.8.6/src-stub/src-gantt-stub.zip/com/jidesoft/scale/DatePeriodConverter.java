package com.jidesoft.scale;


/**
 *  A PeriodConverter which converts the Date to text using the specified date formats.
 */
public class DatePeriodConverter extends AbstractPeriodConverter {

	public static final String RESOURCE_PREFIX = "ScaleArea.Date.";

	public DatePeriodConverter(String periodName, java.text.DateFormat labelFormat, java.text.DateFormat toolTipFormat) {
	}

	public DatePeriodConverter(String periodName, java.text.DateFormat labelFormat, java.text.DateFormat toolTipFormat, int endFormatField) {
	}

	public void setFormatEndDate(boolean formatEndDate, int endFormatField) {
	}

	public String getText(java.util.Date startInstant, java.util.Date endInstant) {
	}

	public String getDescription(java.util.Date startInstant, java.util.Date endInstant) {
	}

	public String getText(java.text.DateFormat format, java.util.Date startInstant, java.util.Date endInstant) {
	}

	protected String format(java.text.DateFormat format, java.util.Date date) {
	}

	public static PeriodConverter createDefaultPeriodConverter(ScaleArea scaleArea) {
	}

	public static PeriodConverter createPeriodConverter(ScaleArea scaleArea, DatePeriod period) {
	}
}
