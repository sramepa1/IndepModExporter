/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>SingleDashboardHolder</code> creates a single dashboard that implements DashboardHolder interface.
 */
public class SingleDashboardHolder extends Dashboard implements GadgetPaletteInstaller, DashboardHolder {
 {

	protected GadgetManager _gadgetManager;

	public SingleDashboardHolder() {
	}

	public SingleDashboardHolder(GadgetManager gadgetManager) {
	}

	public SingleDashboardHolder(String key) {
	}

	public SingleDashboardHolder(String key, String title) {
	}

	public SingleDashboardHolder(String key, String title, int columnCount) {
	}

	@java.lang.Override
	protected void initDashboard() {
	}

	public GadgetManager getGadgetManager() {
	}

	public Dashboard getActiveDashboard() {
	}

	public Dashboard createDashboard(String key) {
	}

	public boolean isUseFloatingPalette() {
	}

	public void setUseFloatingPalette(boolean useFloatingPalette) {
	}

	protected GadgetPalette createGadgetPalette() {
	}

	public java.awt.Container getValidParent(java.awt.Component c) {
	}

	public void showPalette() {
	}

	/**
	 *  Shows the palette.
	 */
	public void showPalette(java.awt.Component invoker) {
	}

	public void hidePalette() {
	}

	/**
	 *  Checks if the palette is visible.
	 * 
	 *  @return true if the palette is visible. Otherwise false.
	 */
	public boolean isPaletteVisible() {
	}

	/**
	 *  Toggles the palette visibility.
	 * 
	 *  @param invoker the invoker that calls to this togglePalette method.
	 */
	public void togglePalette(java.awt.Component invoker) {
	}
}
