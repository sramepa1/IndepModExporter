/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>Dashboard</code> is the container that contain the <code>GadgetContainer</code>s. <code>GadgetContainer</code>
 *  contains the <code>GadgetComponent</code>. Ideally, we would like <code>Dashboard</code> to contain the gadget
 *  directly without the help of the gadget container in between. It will require a customized layout manager which we
 *  currently don't have. So right now we set the dashboard to grid layout and add gadget container to this grid layout.
 *  Each gadget container is using JideBoxLayout.
 */
public class Dashboard extends javax.swing.JPanel implements javax.swing.Scrollable {
 {

	public static final int H_GAP = 6;

	public static final int V_GAP = 6;

	public static final String PROPERTY_KEY = "key";

	public static final String PROPERTY_TITLE = "title";

	public static final String PROPERTY_ICON = "icon";

	public static final String PROPERTY_COLUMN_COUNT = "columnCount";

	/**
	 *  The value return by {@link #getColumnIndex(javax.swing.JComponent)} if the component is maximized
	 *  GadgetComponent.
	 */
	public static final int COMPONENT_MAXIMIZED = -2;

	public Dashboard() {
	}

	public Dashboard(String key) {
	}

	public Dashboard(String key, String title) {
	}

	public Dashboard(String key, String title, javax.swing.Icon icon) {
	}

	public Dashboard(String key, String title, int columnCount) {
	}

	public Dashboard(String key, String title, javax.swing.Icon icon, int columnCount) {
	}

	/**
	 *  Gets the default column count. It is 3 by default.
	 * 
	 *  @return the default column count.
	 */
	public static int getDefaultColumnCount() {
	}

	/**
	 *  Sets the default column count. If you use create a dashboard without specifying the column count, the default
	 *  column count will be used.
	 *  <p/>
	 *  Please note, this method will only have effect on dashboards created after this call. All previous created
	 *  dashboard will still have its old column count.
	 * 
	 *  @param defaultColumnCount the new default column count.
	 */
	public static void setDefaultColumnCount(int defaultColumnCount) {
	}

	/**
	 *  Initializes the dashboard. Subclass can override it. By default, we set the background, set the border.
	 */
	protected void initDashboard() {
	}

	/**
	 *  Get the column index of the GadgetComponent instance inside the dashboard.
	 * 
	 *  @param gadgetComponent the gadget component instance
	 *  @return the column index. -1 if it is not found in the dashboard. {@link #COMPONENT_MAXIMIZED} if it is
	 *          maximized.
	 */
	public int getColumnIndex(javax.swing.JComponent gadgetComponent) {
	}

	/**
	 *  Get the row index of the GadgetComponent instance inside the dashboard.
	 * 
	 *  @param gadgetComponent the gadget component instance
	 *  @return the row index. -1 if it is not found in the dashboard. {@link #COMPONENT_MAXIMIZED} if it is maximized.
	 */
	public int getRowIndex(javax.swing.JComponent gadgetComponent) {
	}

	/**
	 *  Create normal gadget container. By default, it will create a JideSplitPane to contain GadgetContainer so that the
	 *  customer can resize the width of each GadgetContainer.
	 * 
	 *  @return the normal gadget container.
	 * 
	 *  @deprecated replaced by {@link #createNormalGadgetContainer(boolean)}
	 */
	@java.lang.Deprecated
	protected javax.swing.JPanel createNormalGadgetContainer() {
	}

	/**
	 *  Create normal gadget container. By default, it will create a JideSplitPane to contain GadgetContainers so that
	 *  the customer can resize the width of each GadgetContainer. If column resizable is disabled, a JPanel will be
	 *  returned.
	 *  <p/>
	 * 
	 *  @param columnResizable if the column is resizable.
	 *  @return the normal gadget container.
	 */
	protected javax.swing.JPanel createNormalGadgetContainer(boolean columnResizable) {
	}

	/**
	 *  Create maximized gadget container. By default, it will create a JPanel to contain the maximized Gadget so that
	 *  the customer can show this container if he/she maximized any GadgetComponent.
	 * 
	 *  @return the maximized gadget container.
	 */
	protected javax.swing.JPanel createMaximizedGadgetContainer() {
	}

	/**
	 *  Show normal gadget container.
	 */
	public void showNormalGadgetContainer() {
	}

	/**
	 *  Show maximized gadget container.
	 */
	public void showMaximizedGadgetContainer() {
	}

	/**
	 *  Maximize the designated GadgetComponent. It will do nothing if the GadgetComponent does not exist in normal
	 *  gadget container.
	 * 
	 *  @param component the gadget component
	 */
	public void maximizeGadget(GadgetComponent component) {
	}

	/**
	 *  Maximize the GadgetComponent in designated column and row. It will do nothing if the parameter is invalid.
	 * 
	 *  @param column the column index
	 *  @param row    the row index
	 */
	public void maximizeGadget(int column, int row) {
	}

	/**
	 *  Restore the maximized GadgetComponent.
	 */
	public void restoreGadget() {
	}

	/**
	 *  Set the flag indicating if Dashboard will show the gripper.
	 *  <p/>
	 *  If the normal gadget container is a subclass of JideSplitPane, we will just invoke {@link
	 *  com.jidesoft.swing.JideSplitPane#setShowGripper(boolean)}.
	 * 
	 *  @param showGripper the flag
	 */
	public void setShowGripper(boolean showGripper) {
	}

	/**
	 *  Get the flag indicating if Dashboard will show the gripper.
	 * 
	 *  @return true if the normal gadget container is a subclass of JideSplitPane and {@link
	 *          com.jidesoft.swing.JideSplitPane#isShowGripper()} is true. Otherwise false.
	 */
	public boolean isShowGripper() {
	}

	/**
	 *  Creates the panel for each column.
	 * 
	 *  @return the panel for each column.
	 */
	protected javax.swing.JPanel createSubpanel() {
	}

	/**
	 *  Gets the number of columns.
	 * 
	 *  @return the column count.
	 */
	public int getColumnCount() {
	}

	/**
	 *  Sets the column count. It will fire PropertyChangeEvent on PROPERTY_COLUMN_COUNT.
	 * 
	 *  @param columnCount the new column count.
	 */
	public void setColumnCount(int columnCount) {
	}

	@java.lang.Override
	public void doLayout() {
	}

	/**
	 *  Gets the title of this dashboard. If you never set the title, the key will be used. The difference of the key and
	 *  the title is the key can be non-localized string and the title should be localized. The key has to be uniquely if
	 *  there are several dashboards managed by {@link com.jidesoft.dashboard.GadgetManager}.
	 * 
	 *  @return the title of this dashboard.
	 */
	public String getTitle() {
	}

	/**
	 *  Sets the title.
	 * 
	 *  @param title the new title.
	 */
	public void setTitle(String title) {
	}

	/**
	 *  Gets the key of this dashboard.
	 * 
	 *  @return the key.
	 */
	public String getKey() {
	}

	/**
	 *  Sets the key.
	 * 
	 *  @param key the new key.
	 */
	public void setKey(String key) {
	}

	/**
	 *  Gets the icon for the dashboard.
	 * 
	 *  @return the icon.
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Sets the icon for the dashboard.
	 * 
	 *  @param icon the icon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Gets the settings.
	 * 
	 *  @return a map of the settings. The key is the name of the setting and the value of the map is the value of the
	 *          setting. The value must be a string in order to be persisted in the xml format. If your original data
	 *          format is not string, you need to convert to string first. You could leverage ObjectConverterManager and
	 *          ObjectConverter to do it.
	 */
	public java.util.Map getSettings() {
	}

	public void setSettings(java.util.Map settings) {
	}

	public java.awt.Dimension getPreferredScrollableViewportSize() {
	}

	public int getScrollableBlockIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	public boolean getScrollableTracksViewportHeight() {
	}

	public boolean getScrollableTracksViewportWidth() {
	}

	public int getScrollableUnitIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	/**
	 *  Gets all GadgetComponents inside the dashboard.
	 * 
	 *  @return all GadgetComponents inside the dashboard.
	 */
	public GadgetComponent[] getGadgetComponents() {
	}

	/**
	 *  Get the GadgetContainer instance in the designated column.
	 * 
	 *  @param column the column index
	 *  @return the gadget container instance.
	 */
	public GadgetContainer getGadgetContainer(int column) {
	}

	/**
	 *  Get the flag indicating if the column is resizable.
	 *  <p/>
	 *  The default value of this flag is false to keep consistent behavior with earlier release.
	 * 
	 *  @return the flag
	 */
	public boolean isColumnResizable() {
	}

	/**
	 *  Set the flag indicating if the column is resizable.
	 * 
	 *  @param columnResizable the flag
	 */
	public void setColumnResizable(boolean columnResizable) {
	}
}
