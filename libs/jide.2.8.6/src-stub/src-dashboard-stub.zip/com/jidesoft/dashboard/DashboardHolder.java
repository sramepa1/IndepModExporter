/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>DashboardHolder</code> interface is used to indicate the container can hold <code>Dashboard</code>.
 * 
 *  @see com.jidesoft.dashboard.Dashboard
 */
public interface DashboardHolder {

	/**
	 *  Gets the gadget manager.
	 * 
	 *  @return the gadget manager.
	 */
	public GadgetManager getGadgetManager();

	public Dashboard getActiveDashboard();

	public Dashboard createDashboard(String key);
}
