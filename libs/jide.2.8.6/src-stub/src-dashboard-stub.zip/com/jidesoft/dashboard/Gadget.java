/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  The interface for the gadget in the Dashboard.
 */
public interface Gadget {

	/**
	 *  Gadget must be added to a GadgetManager. This method will return the GadgetManager.
	 * 
	 *  @return the GadgetManager.
	 */
	public GadgetManager getGadgetManager();

	/**
	 *  Sets the GadgetManager. This method is called automatically when the Gadget is added to GadgetManager using
	 *  {@link GadgetManager#addGadget(Gadget)} method.
	 * 
	 *  @param manager the GadgetManager.
	 */
	public void setGadgetManager(GadgetManager manager);

	/**
	 *  Returns the key of the <code>Gadget</code>. The key is used to uniquely identify a Gadget in one GadgetManager.
	 *  The key is not displayed anywhere in the user interface so it is OK to be a non-localized string. The strings for
	 *  the name should be localized although if you never set the name, the key will be used as the name.
	 * 
	 *  @return a <code>String</code> containing this Gadget's key
	 */
	public String getKey();

	/**
	 *  Returns the name of the <code>Gadget</code>. The name is displayed on the title bar of the Gadget if any. If the
	 *  <code>name</code> is never set, the key will be used.
	 * 
	 *  @return the name
	 */
	public String getName();

	/**
	 *  Returns the description of the <code>Gadget</code>. Description is used in the <code>GadgetPalette</code> to give
	 *  user an idea of what the gadget is.
	 * 
	 *  @return the description.
	 */
	public String getDescription();

	/**
	 *  Gets the icon. The icon is usually displayed on the title bar of the gadget component, although it depends on how
	 *  the gadget component is implemented. You can specify two icons for each gadget. This is the smaller one of the
	 *  two. We didn't specify the exact size of this icon. But all gadgets' icon should have the same size to look good
	 *  on when they displayed on the dashboard.
	 * 
	 *  @return the icon.
	 */
	public javax.swing.Icon getIcon();

	/**
	 *  Gets the large icon. The icon is used by the <code>GadgetPalette</code> to represent a gadget. You can specify
	 *  two icons for each gadget. This is the larger one of the two. We didn't specify the exact size of this icon. But
	 *  all gadgets' icon should have the same size to look good on the palette.
	 * 
	 *  @return the large icon.
	 */
	public javax.swing.Icon getLargeIcon();

	/**
	 *  Creates the <code>GadgetComponent</code>. The <code>Gadget</code> is just an interface. It doesn't need to be a
	 *  <code>Component</code>. The actual component is created by this method. Please note, if you want to support
	 *  multiple instances of the same gadget on the dashboard, you need to create a new component every time when this
	 *  method is called.
	 * 
	 *  @return the gadget component.
	 */
	public GadgetComponent createGadgetComponent();

	/**
	 *  Disposes the <code>GadgetComponent</code>. This method indicates the end of the life cycle of the
	 *  <code>GadgetComponent</code> to give you a chance to free whatever resource is used by this
	 *  <code>GadgetComponent</code>.
	 * 
	 *  @param component the <code>GadgetComponent</code>.
	 */
	public void disposeGadgetComponent(GadgetComponent component);
}
