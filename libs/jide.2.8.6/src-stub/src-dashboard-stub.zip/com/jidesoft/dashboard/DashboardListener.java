/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  The listener interface for receiving dashboard events.
 */
public interface DashboardListener extends java.util.EventListener {
 {

	/**
	 *  Invoked when a <code>Gadget</code> event happened
	 * 
	 *  @param e GadgetEvent
	 */
	public void eventHappened(DashboardEvent e);
}
