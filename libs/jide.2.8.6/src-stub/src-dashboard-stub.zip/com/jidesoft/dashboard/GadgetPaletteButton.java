/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>GadgetPaletteButton</code> is the button on the palette.
 */
public class GadgetPaletteButton extends JideToggleButton {

	public GadgetPaletteButton(GadgetPalette gadgetPalette, Gadget element) {
	}

	public Gadget getGadget() {
	}

	public GadgetPalette getGadgetPalette() {
	}
}
