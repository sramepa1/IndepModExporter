/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  An <code>AWTEvent</code> that adds support for <code>Gadget</code> objects as the event source.
 * 
 *  @see Gadget
 *  @see GadgetListener
 */
public class GadgetEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>Gadget</code> events.
	 */
	public static final int GADGET_FIRST = 13199;

	/**
	 *  The last number in the range of IDs used for <code>Gadget</code> events.
	 */
	public static final int GADGET_LAST = 13207;

	/**
	 *  This event is delivered when the <code>Gadget</code> is first added to GadgetManager.
	 */
	public static final int GADGET_ADDED = 13199;

	/**
	 *  This event is delivered when the <code>Gadget</code> is removed from GadgetManager.
	 */
	public static final int GADGET_REMOVED = 13200;

	/**
	 *  This event is delivered when gadget component is shown on a <code>Dashboard</code>
	 */
	public static final int GADGET_COMPONENT_SHOWN = 13201;

	/**
	 *  This event is delivered when gadget component is hidden from the <code>Dashboard</code>
	 */
	public static final int GADGET_COMPONENT_HIDDEN = 13202;

	/**
	 *  This event is delivered when gadget component is created by the gadget when {@link
	 *  com.jidesoft.dashboard.Gadget#createGadgetComponent()} is called.
	 */
	public static final int GADGET_COMPONENT_CREATED = 13203;

	/**
	 *  This event is delivered when gadget component is disposed by the gadget when {@link
	 *  com.jidesoft.dashboard.Gadget#disposeGadgetComponent(GadgetComponent)} is called.
	 */
	public static final int GADGET_COMPONENT_DISPOSED = 13204;

	/**
	 *  This event is delivered when gadget component is disposed by the gadget when {@link
	 *  com.jidesoft.dashboard.Gadget#disposeGadgetComponent(GadgetComponent)} is called.
	 */
	public static final int GADGET_COMPONENT_MAXIMIZED = 13205;

	/**
	 *  This event is delivered when gadget component is disposed by the gadget when {@link
	 *  com.jidesoft.dashboard.Gadget#disposeGadgetComponent(GadgetComponent)} is called.
	 */
	public static final int GADGET_COMPONENT_RESTORED = 13206;

	/**
	 *  This event is delivered when gadget component is disposed by the gadget when {@link
	 *  com.jidesoft.dashboard.Gadget#disposeGadgetComponent(GadgetComponent)} is called.
	 */
	public static final int GADGET_COMPONENT_RESIZED = 13207;

	/**
	 *  Constructs an <code>GadgetEvent</code> object.
	 * 
	 *  @param source the <code>Gadget</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 */
	public GadgetEvent(Gadget source, int id) {
	}

	public GadgetEvent(Object source, int id, GadgetComponent gadgetComponent) {
	}

	/**
	 *  Returns a parameter string identifying this event. This method is useful for event logging and for debugging.
	 * 
	 *  @return a string identifying the event and its attributes
	 */
	@java.lang.Override
	public String paramString() {
	}

	/**
	 *  Returns the originator of the event.
	 * 
	 *  @return the <code>Gadget</code> object that originated the event
	 */
	public Gadget getGadget() {
	}

	public GadgetComponent getGadgetComponent() {
	}
}
