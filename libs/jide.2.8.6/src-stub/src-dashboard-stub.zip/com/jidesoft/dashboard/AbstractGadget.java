/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>AbstractGadget</code> is the abstract implementation of <code>Gadget</code> which implements all methods except
 *  {@link #createGadgetComponent()} and {@link #disposeGadgetComponent(GadgetComponent)}.
 */
public abstract class AbstractGadget implements Gadget {
 {

	public static final String PROPERTY_KEY = "key";

	public static final String PROPERTY_NAME = "name";

	public static final String PROPERTY_DESCRIPTION = "description";

	public static final String PROPERTY_LARGE_ICON = "largeIcon";

	public static final String PROPERTY_ICON = "icon";

	public static final String PROPERTY_GADGET_MANAGER = "gadgetManager";

	public AbstractGadget(String key) {
	}

	public AbstractGadget(String key, javax.swing.Icon icon) {
	}

	public AbstractGadget(String key, javax.swing.Icon icon, javax.swing.Icon largeIcon) {
	}

	/**
	 *  Returns the key of the <code>Gadget</code>. The key is used to uniquely identify a Gadget in one GadgetManager.
	 *  The key is not displayed anywhere in the user interface so it is OK to be a non-localized string. The strings for
	 *  the name should be localized although if you never set the name, the key will be used as the name.
	 * 
	 *  @return a <code>String</code> containing this Gadget's key
	 */
	public String getKey() {
	}

	/**
	 *  Returns the name of the <code>Gadget</code>. The name is displayed on the title bar of the Gadget if any. If the
	 *  <code>name</code> is never set, the key will be used.
	 * 
	 *  @return the name
	 */
	public String getName() {
	}

	/**
	 *  Sets the name of the <code>Gadget</code>. The name is displayed on the title bar of the Gadget if any. If the
	 *  <code>name</code> is never set, the key will be used.
	 *  <p/>
	 *  This setter will fire PROPERTY_NAME property change event.
	 * 
	 *  @param name the new name
	 */
	public void setName(String name) {
	}

	/**
	 *  Returns the description of the <code>Gadget</code>. Description is used in the <code>GadgetPalette</code> to give
	 *  user an idea of what the gadget is.
	 * 
	 *  @return the description.
	 */
	public String getDescription() {
	}

	/**
	 *  Sets the description of the <code>Gadget</code>. The description is displayed on the title bar of the Gadget if
	 *  any.
	 *  <p/>
	 *  This setter will fire PROPERTY_DESCRIPTION property change event.
	 * 
	 *  @param description the new description
	 */
	public void setDescription(String description) {
	}

	/**
	 *  Gets the large icon. The icon is used by the <code>GadgetPalette</code> to represent a gadget. You can specify
	 *  two icons for each gadget. This is the larger one of the two. We didn't specify the exact size of this icon. But
	 *  all gadgets' icon should have the same size to look good on the palette.
	 * 
	 *  @return the large icon.
	 */
	public javax.swing.Icon getLargeIcon() {
	}

	/**
	 *  Sets the large icon. The icon is used by the <code>GadgetPalette</code> to represent a gadget. You can specify
	 *  two icons for each gadget. This is the larger one of the two. We didn't specify the exact size of this icon. But
	 *  all gadgets' icon should have the same size to look good on the palette.
	 * 
	 *  @param largeIcon the large icon.
	 */
	public void setLargeIcon(javax.swing.Icon largeIcon) {
	}

	/**
	 *  Gets the icon. The icon is usually displayed on the title bar of the gadget component, although it depends on how
	 *  the gadget component is implemented. You can specify two icons for each gadget. This is the smaller one of the
	 *  two. We didn't specify the exact size of this icon. But all gadgets' icon should have the same size to look good
	 *  on when they displayed on the dashboard.
	 * 
	 *  @return the icon.
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Sets the icon. The icon is usually displayed on the title bar of the gadget component, although it depends on how
	 *  the gadget component is implemented. You can specify two icons for each gadget. This is the smaller one of the
	 *  two. We didn't specify the exact size of this icon. But all gadgets' icon should have the same size to look good
	 *  on when they displayed on the dashboard.
	 * 
	 *  @param icon the icon.
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Sets the gadget manager that manages this gadget. Although this is a public method, as the user of the API, you
	 *  probably should never use this setter directly. Instead, you can add the <code>Gadget</code> to a
	 *  <code>GadgetManager</code> which will call this method indirectly.
	 * 
	 *  @param gadgetManager the gadget manager.
	 */
	public void setGadgetManager(GadgetManager gadgetManager) {
	}

	/**
	 *  Gets the gadget manager.
	 * 
	 *  @return the gadget manager.
	 */
	public GadgetManager getGadgetManager() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method should be used to remove
	 *  PropertyChangeListeners that were registered for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(String)
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific property. This method should be used to
	 *  remove PropertyChangeListeners that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated with the named property.
	 * 
	 *  @param propertyName the property name.
	 *  @return all of the <code>PropertyChangeListeners</code> associated with the named property or an empty array if
	 *          no listeners have been added
	 * 
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}
}
