package com.jidesoft.plaf.synthetica;


public class SyntheticaNestedTableHeaderUI extends BasicNestedTableHeaderUI {

	public SyntheticaNestedTableHeaderUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}
}
