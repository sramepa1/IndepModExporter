package com.jidesoft.plaf.synthetica;


public class SyntheticaJideTabbedPaneUI extends VsnetJideTabbedPaneUI {

	public SyntheticaJideTabbedPaneUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	protected void paintTabAreaBackground(java.awt.Graphics g, java.awt.Rectangle rect, int tabPlacement) {
	}

	@java.lang.Override
	protected void paintTabBorder(java.awt.Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
	}

	@java.lang.Override
	protected void paintTabBackground(java.awt.Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
	}

	@java.lang.Override
	protected void paintContentBorder(java.awt.Graphics g, int x, int y, int w, int h) {
	}

	@java.lang.Override
	protected void paintContentBorderTopEdge(java.awt.Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
	}

	@java.lang.Override
	protected void paintContentBorderBottomEdge(java.awt.Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
	}

	@java.lang.Override
	protected void paintContentBorderLeftEdge(java.awt.Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
	}

	@java.lang.Override
	protected void paintContentBorderRightEdge(java.awt.Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
	}
}
