package com.jidesoft.swing;


/**
 *  An interface to support persist layout.
 */
public interface LayoutPersistence {

	/**
	 *  Sets profile key. Profile key is used in the registry (on Windows, under HKEY_CURRENT_USER\Software\JavaSoft\Prefs)
	 *  or a folder name (on UNIX or Linux, JDK will automatically prefix with "." so that it is hidden) where the layout
	 *  data will be stored.
	 * 
	 *  @param key the profile key
	 */
	public void setProfileKey(String key);

	/**
	 *  Gets version number of profile.
	 * 
	 *  @return version of profile
	 */
	public short getVersion();

	/**
	 *  Sets version number of profile. User can set a new version so that application restart, it will ignore previous
	 *  layout information.
	 * 
	 *  @param version new version
	 */
	public void setVersion(short version);

	/**
	 *  If true, we will use javax.util.pref to store the layout information.
	 *  <p/>
	 *  Here is the difference when this flag is true or false.
	 *  <p/>
	 *  If <code>usePref</code> is true, you will also need to call {@link #setProfileKey(String)} to specify a profile
	 *  key. <ul> <li>On Windows: the layout will be stored under <code>HKEY_CURRENT_USER\Software\JavaSoft\Prefs</code>
	 *  in Windows Registry. First you will see a profileKey folder (you can use {@link #setProfileKey(String)} to set
	 *  it). Then under it you will see a key with the layout name. <li>On UNIX, Linx or Mac OSX: the layout will be
	 *  stored under {user.home}\.profileKey folder. Each layout is one file whose suffix is .layout. </ul> If
	 *  <code>usePref</code> is false, you will also need to call {@link #setLayoutDirectory(String)} to specify a
	 *  folder. If you never set a layout directory, by default the layout directory is {user.home}/.profileKey which is
	 *  actually the same on Linux/UNIX when usePref is true. <ul> <li>On all platforms: the layout will be stored under
	 *  the layoutDirectory folder. Each layout is one file whose suffix is .layout. </ul> Please note, {@link
	 *  #saveLayoutDataToFile(String)} and {@link #loadLayoutDataFromFile(String)} use absolute file path so it will not
	 *  be affected by <code>usePref</code> flag or the <code>profileKey</code> or <code>layoutDirectory</code> setting.
	 * 
	 *  @param use use java.util.pref or not. Default is true.
	 */
	public void setUsePref(boolean use);

	/**
	 *  Gets the list of available layout names. If <code>usePref</code> is true and <code>profileKey</code> has been
	 *  set, the method will return the list of save layouts. If <code>usePref</code> is false, it will find out the
	 *  layout file in layout directory.
	 * 
	 *  @return the list of available layout names.
	 */
	public java.util.List getAvailableLayouts();

	/**
	 *  Checks if the layout is available.
	 * 
	 *  @param layoutName the layout name. In Window registry, the layout name is the registry key name. If it's a layout
	 *                    file, the layout name is the file name with ".layout" as suffix.
	 *  @return true if the layout is available
	 */
	public boolean isLayoutAvailable(String layoutName);

	/**
	 *  Removes the layout.
	 * 
	 *  @param layoutName the layout name. In Window registry, the layout name is the registry key name. If it's a layout
	 *                    file, the layout name is the file name with ".layout" as suffix.
	 */
	public void removeLayout(String layoutName);

	/**
	 *  Loads layout from default layout data from profile.
	 */
	public void loadLayoutData();

	/**
	 *  Load layout data from the profile name specified in <code>layoutName<code>. Please note: we suggest you to use
	 *  all lower cases for layoutName because we found some problems when it is upper case on Windows.
	 * 
	 *  @param layoutName the layout name. In Window registry, the layout name is the registry key name. If it's a layout
	 *                    file, the layout name is the file name with ".layout" as suffix.
	 */
	public void loadLayoutDataFrom(String layoutName);

	/**
	 *  Checks if the layout is valid. It will return true if and only if the version number in layout file matches with
	 *  the version number set on LayoutPersistence. If there is any IO exception during checking, it will return false
	 *  as well.
	 * 
	 *  @param layoutName the layout name. In Window registry, the layout name is the registry key name. If it's a layout
	 *                    file, the layout name is the file name with ".layout" as suffix.
	 *  @return true if the layout version valid.
	 */
	public boolean isLayoutDataVersionValid(String layoutName);

	/**
	 *  Loads layout from a file.
	 * 
	 *  @param layoutFileName a layout file name.
	 */
	public void loadLayoutDataFromFile(String layoutFileName);

	/**
	 *  Load layout data from an <code>InputStream</code> that specified as <code>in</code> parameter. If any exception
	 *  happens during the read, it will call resetLayout() to use default layout.
	 * 
	 *  @param in the InputStream where the layout data will be read from.
	 *  @return boolean did it load successfully from the input stream (false indicates that it called resetToDefault to
	 *          load the layout.)
	 */
	public boolean loadLayoutFrom(java.io.InputStream in);

	/**
	 *  Checks if the loadLayoutFrom(InputStream in) method load successfully from the input stream (false indicates that
	 *  it called resetToDefault to load the layout.) This method can be called immediately after the
	 *  loadLayoutFrom(InputStream in) call to determine if a specific LayoutPersistence was forced to call
	 *  resetToDefault.
	 * 
	 *  @return boolean did it load successfully from the input stream (false indicates that it called resetToDefault to
	 *          load the layout.)
	 */
	public boolean isLoadDataSuccessful();

	/**
	 *  Save layout data to default layout.
	 */
	public void saveLayoutData();

	/**
	 *  Save layout data to the layout that specified in <code>layoutName</code> Note: Always use all lower case. I found
	 *  some problems with upper case on Windows.
	 * 
	 *  @param layoutName the layout name. In Window registry, the layout name is the registry key name. If it's a layout
	 *                    file, the layout name is the file name with ".layout" as suffix.
	 */
	public void saveLayoutDataAs(String layoutName);

	/**
	 *  Save layout data to file that specified in <code>layoutFileName</code>. The fileName should be full qualified
	 *  file name. If the file exists, it will be overwritten.
	 * 
	 *  @param layoutFileName full path to the layout file.
	 */
	public void saveLayoutDataToFile(String layoutFileName);

	/**
	 *  Save layout data to an OutputStream that specified as <code>out</code> parameter.
	 * 
	 *  @param out the OutputStream where the layout data will be written to.
	 *  @throws java.io.IOException if any IO exception happens when writing to the <code>OutputStream</code>.
	 */
	public void saveLayoutTo(java.io.OutputStream out);

	/**
	 *  Gets layout raw data in byte array. You can keep the value returned and pass it in to
	 *  <code>setLayoutRawData</code> to set the layout.
	 * 
	 *  @return layout data
	 */
	public byte[] getLayoutRawData();

	/**
	 *  Sets the layout using layout raw data.
	 * 
	 *  @param layoutData the byte array that returned from <code>getLayoutRawData</code>
	 */
	public void setLayoutRawData(byte[] layoutData);

	/**
	 *  Gets the directory that used for storing layout files. It is used only when <code>usePref</code> is false.
	 * 
	 *  @return the directory so store layout files.
	 */
	public String getLayoutDirectory();

	/**
	 *  Sets the layout directory. It is used only when <code>usePref</code> is false.
	 * 
	 *  @param layoutDirectory the layout directory.
	 */
	public void setLayoutDirectory(String layoutDirectory);

	/**
	 *  Resets layout. It could be called either when there is no saved layout or the saved layout file is corrupted.
	 */
	public void resetToDefault();

	/**
	 *  If true, the main frame will be set to the frame state information will be restored from the layout data.
	 *  Otherwise, loadLayoutData will ignore the main frame state saved in the layout data. By default, if the frame is
	 *  invisible when loadLayoutData is called, we will use the saved frame state. If the frame is already visible, we
	 *  will ignore it. Typically, for all nested LayoutPersistences (including DockingManager and DockableBarManager),
	 *  you should call both setUseFrameBounds(false) and setUseFrameState(false) before loadLayoutData so that only the
	 *  top level LayoutPersistence will set the frame bounds and state. If you have two or more top level
	 *  LayoutPersistence, you should designate one LayoutPersistence as the main one. One way to do this is to add all
	 *  top level LayoutPersistences to {@link com.jidesoft.swing.LayoutPersistenceManager}.
	 *  <code>LayoutPersistenceManager</code> will automatically designate the last docking manager as the main one which
	 *  will set the frame state.
	 * 
	 *  @param useFrameState true if the state of main frame will be restored from the layout data.
	 *  @see #setUseFrameBounds(boolean)
	 */
	public void setUseFrameState(boolean useFrameState);

	/**
	 *  If true, the main frame will be set to the frame bounds information restored from the layout data. Otherwise,
	 *  loadLayoutData will ignore the main frame bounds saved in the layout data. By default, if the frame is invisible
	 *  when loadLayoutData is called, we will use the saved frame bounds. If the frame is already visible, we will
	 *  ignore it. Typically, for all nested LayoutPersistences (including DockingManager and DockableBarManager), you
	 *  should call both setUseFrameBounds(false) and setUseFrameState(false) before loadLayoutData so that only the top
	 *  level LayoutPersistence will set the frame bounds and state. If you have two or more top level LayoutPersistence,
	 *  you should designate one LayoutPersistence as the main one. One way to do this is to add all top level
	 *  LayoutPersistences to {@link com.jidesoft.swing.LayoutPersistenceManager}. <code>LayoutPersistenceManager</code>
	 *  will automatically designate the last docking manager as the main one which will set the frame bounds.
	 * 
	 *  @param useFrameBounds true if the bounds of main frame will be restored from layout data.
	 *  @see #setUseFrameState(boolean)
	 */
	public void setUseFrameBounds(boolean useFrameBounds);

	/**
	 *  Starts a process to add/remove frame or dockable bar without showing on screen immediately. Any call to
	 *  loadLayoutDataXxx methods or resetToDefault() will mark the process.
	 */
	public void beginLoadLayoutData();

	/**
	 *  Checks if it is the last one during when loading several several <code>LayoutPersistence</code>s. Only the last
	 *  <code>LayoutPersistence</code> will restore the main window's state and bounds and make the main window visible.
	 * 
	 *  @return true or false.
	 */
	public boolean isLast();

	/**
	 *  Sets the LayoutPersistence as the last one (or not the last one) when loading several LayoutPersistences.
	 * 
	 *  @param last true if the layout persistence is the last one in the {@link com.jidesoft.swing.LayoutPersistenceManager}.
	 */
	public void setLast(boolean last);

	/**
	 *  Load initial layout from an initial layout file designed by Visual Designer.
	 * 
	 *  @param initialLayoutFileName the full file path to the .ilayout file.
	 *  @throws ParserConfigurationException when DocumentBuilder cannot be created which satisfies the configuration
	 *                                       requested.
	 *  @throws SAXException                 when DocumentBuilder has trouble parsing the initial layout xml file.
	 *  @throws IOException                  when DocumetnBuilder encounters any errors when reading the initial layout
	 *                                       xml file.
	 */
	public void loadInitialLayout(String initialLayoutFileName);

	/**
	 *  Load initial layout from an initial layout file designed by Visual Designer. To use this method, you should
	 *  bundle initial layout files into jars, then use ClassLoader to load the file as InputStream.
	 * 
	 *  @param initialLayoutStream an input stream containing an initial layout.
	 *  @throws ParserConfigurationException when DocumentBuilder cannot be created which satisfies the configuration
	 *                                       requested.
	 *  @throws SAXException                 when DocumentBuilder has trouble parsing the initial layout xml file.
	 *  @throws IOException                  when DocumetnBuilder encounters any errors when reading the initial layout
	 *                                       xml file.
	 */
	public void loadInitialLayout(java.io.InputStream initialLayoutStream);

	/**
	 *  Load initial layout from an initial layout file designed by Visual Designer. To use this method, you need to load
	 *  the initial layout into Document which represents XML document.
	 * 
	 *  @param initialLayoutDocument the Document contains an initial layout.
	 */
	public void loadInitialLayout(org.w3c.dom.Document initialLayoutDocument);
}
