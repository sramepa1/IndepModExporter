package com.jidesoft.swing;


public class PersistenceUtils {

	/**
	 *  Component node for every layout persistence utility class.
	 */
	public static final String NODE_COMPONENT = "component";

	/**
	 *  Version attribute for every layout persistence utility class.
	 */
	public static final String ATTRIBUTE_VERSION = "version";

	public PersistenceUtils() {
	}

	/**
	 *  Save XML document to designated file.
	 * 
	 *  @param document the XML ready to be saved
	 *  @param fileName the file name to be saved to
	 *  @param encoding the encoding type
	 *  @throws java.io.IOException possibly IO exceptions during file writing.
	 */
	public static void saveXMLDocumentToFile(org.w3c.dom.Document document, String fileName, String encoding) {
	}

	/**
	 *  Save XML document to designated output stream.
	 * 
	 *  @param document the XML ready to be saved
	 *  @param out      the output stream to be saved to
	 *  @param encoding the encoding type
	 *  @throws java.io.IOException possibly IO exceptions during stream output.
	 */
	public static void saveXMLDocumentToStream(org.w3c.dom.Document document, java.io.OutputStream out, String encoding) {
	}

	/**
	 *  Get default XML encoding type.
	 * 
	 *  @return The default XML encoding.
	 */
	public static String getDefaultXmlEncoding() {
	}

	/**
	 *  Set default XML encoding type.
	 * 
	 *  @param defaultXmlEncoding the default XML encoding
	 */
	public static void setDefaultXmlEncoding(String defaultXmlEncoding) {
	}

	/**
	 *  Get default XML encoding version.
	 * 
	 *  @return The default XML version.
	 */
	public static String getDefaultXmlVersion() {
	}

	/**
	 *  Set default XML encoding version.
	 * 
	 *  @param defaultXmlVersion the default XML version
	 */
	public static void setDefaultXmlVersion(String defaultXmlVersion) {
	}

	/**
	 *  Get Document from the input stream.
	 * 
	 *  @param in the input stream
	 *  @return the parsed document.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *                                       requested.
	 *  @throws SAXException                 If any parse errors occur.
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static org.w3c.dom.Document getDocument(java.io.InputStream in) {
	}

	/**
	 *  Get Document from the file.
	 * 
	 *  @param fileName the file name
	 *  @return the parsed document.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *                                       requested.
	 *  @throws SAXException                 If any parse errors occur.
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static org.w3c.dom.Document getDocument(String fileName) {
	}

	/**
	 *  Get version from the document.
	 * 
	 *  @param document the document
	 *  @return the version.
	 */
	public static String getVersion(org.w3c.dom.Document document) {
	}

	/**
	 *  Translate string in a document to an Integer array.
	 * 
	 *  @param s the string
	 *  @return the Integer array.
	 */
	public static int[] stringToIntArray(String s) {
	}

	/**
	 *  Translate an Integer array to a string in a document.
	 * 
	 *  @param indices the Integer array
	 *  @return the string.
	 */
	public static String intArrayToString(int[] indices) {
	}
}
