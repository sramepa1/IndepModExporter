package com.jidesoft.swing;


/**
 *  Abstract implementation of <code>LayoutPersistence</code>.
 */
public abstract class AbstractLayoutPersistence implements LayoutPersistence {
 {

	/**
	 *  The persistence version in place at the end of 2004.
	 */
	public static final short V2004 = 19;

	/**
	 *  The persistence version in place starting September 2005.
	 */
	public static final short V2005_09 = 20;

	/**
	 *  Version. Used to invalid previous save layout in case format changes.
	 */
	protected short _version;

	/**
	 *  Default profile name if user didn't select any profile name.
	 */
	protected static final String DEFAULT_PROFILE_NAME = "default";

	public static final String PROPERTY_PROFILE_KEY = "profileKey";

	public static final String PROPERTY_USE_PREF = "usePref";

	public static final String PROPERTY_VERSION = "version";

	/**
	 *  Key of profile.
	 */
	protected String _profileKey;

	protected static final int MAX_PREF_BYTE_ARRAY_LENGTH = 6144;

	protected boolean _loadingLayoutData;

	/**
	 *  true if the main frame bounds is persisted
	 */
	protected boolean _useFrameBounds;

	protected boolean _useFrameBoundsSet;

	/**
	 *  true if the main frame state is persisted.
	 */
	protected boolean _useFrameState;

	protected boolean _useFrameStateSet;

	/**
	 *  Whether use javax.utils.pref.
	 */
	protected boolean _usePref;

	protected static final String LAYOUT_COUNT_STRING = "_count";

	protected final String LAYOUT_POSTFIX = ".layout";

	protected String _layoutDirectory;

	public AbstractLayoutPersistence() {
	}

	/**
	 *  Gets version number of profile.
	 * 
	 *  @return version of profile
	 */
	public short getVersion() {
	}

	/**
	 *  Sets version number of profile. User can set a new version so that application restart, it will ignore previous
	 *  layout information.
	 * 
	 *  @param version new version
	 */
	public void setVersion(short version) {
	}

	/**
	 *  Gets profile key.
	 * 
	 *  @return the profile key.
	 */
	public String getProfileKey() {
	}

	/**
	 *  Sets the profile key to be used to store layout information. If usePref is true, profileKey will be used to
	 *  create a node in registry. If usePref is false, it will be used to create a folder named as ".profileKey" and all
	 *  layout files will be saved under that folder.
	 * 
	 *  @param profileKey profile key
	 */
	public void setProfileKey(String profileKey) {
	}

	/**
	 *  Load layout from default layout data from profile. <br> This method is Swing thread safe.
	 */
	public void loadLayoutData() {
	}

	public boolean isLayoutAvailable(String layoutName) {
	}

	public java.util.List getAvailableLayouts() {
	}

	public void removeLayout(String layoutName) {
	}

	/**
	 *  Load layout from default layout data from named profile. <br> This method is Swing thread safe.
	 */
	public void loadLayoutDataFrom(String layoutName) {
	}

	/**
	 *  Checks if the layout version of the named layout is valid.
	 */
	public boolean isLayoutDataVersionValid(String layoutName) {
	}

	/**
	 *  Tells whether the given version is compatible with our current version.  It is compatible if it is the same as
	 *  our version number, or if our version number is the current version and the given number is a supported older
	 *  version.
	 * 
	 *  @param version the version to be checked
	 *  @return true if the version is compatible.
	 */
	protected boolean isVersionCompatible(int version) {
	}

	/**
	 *  Loads layout from default layout data from a file. <br> This method is Swing thread safe.
	 */
	public void loadLayoutDataFromFile(String fileName) {
	}

	/**
	 *  Save layout information to default profile.
	 */
	public void saveLayoutData() {
	}

	/**
	 *  Gets setting file directory.
	 * 
	 *  @return the setting directory
	 */
	public String getLayoutDirectory() {
	}

	public void setLayoutDirectory(String layoutDirectory) {
	}

	/**
	 *  Save layout data to profile that specified in <code>layoutName</code> Note: Always use all lower case. We found
	 *  some problems with upper case on Windows.
	 * 
	 *  @param layoutName the layout name
	 */
	public void saveLayoutDataAs(String layoutName) {
	}

	/**
	 *  Save layout data to file that specified in <code>layoutFileName</code>. The layoutFileName should be full
	 *  qualified file name. If the file exists, it will be overwritten.
	 * 
	 *  @param layoutFileName the layout file name
	 */
	public void saveLayoutDataToFile(String layoutFileName) {
	}

	public void setLayoutRawData(byte[] layoutData) {
	}

	public byte[] getLayoutRawData() {
	}

	/**
	 *  Checks if the layout will be saved using javax.util.pref package.
	 * 
	 *  @return true if layout will be saved using javax.util.pref package.
	 */
	public boolean isUsePref() {
	}

	/**
	 *  If true, use javax.util.pref to store frames layout data. The setting only has effect on Windows. On UNIX or
	 *  Linux, javax.util.pref is never used because it has problem to store binary data
	 * 
	 *  @param usePref use javax pref or not. Default is true
	 */
	public void setUsePref(boolean usePref) {
	}

	/**
	 *  If true, the state of main frame will be persisted in layout data.
	 * 
	 *  @param useFrameState true if the state of main frame will be persisted in layout data.
	 */
	public void setUseFrameState(boolean useFrameState) {
	}

	/**
	 *  If true, the bounds of main frame will be persisted in layout data.
	 * 
	 *  @param useFrameBounds true if the bounds of main frame will be persisted in layout data.
	 */
	public void setUseFrameBounds(boolean useFrameBounds) {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method should be used to remove
	 *  PropertyChangeListeners that were registered for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific property. This method should be used to
	 *  remove PropertyChangeListeners that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated with the named property.
	 * 
	 *  @param propertyName the property name.
	 *  @return all of the <code>PropertyChangeListeners</code> associated with the named property or an empty array if
	 *          no listeners have been added
	 * 
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}

	public void loadInitialLayout(String layoutFile) {
	}

	public void loadInitialLayout(java.io.InputStream layoutStream) {
	}

	protected boolean shouldUseFrameState(boolean wasVisible) {
	}

	protected boolean shouldUseFrameBounds(boolean wasVisible) {
	}

	public boolean isLast() {
	}

	public void setLast(boolean last) {
	}
}
