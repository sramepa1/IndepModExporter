package com.jidesoft.utils;


/**
 *  License manager.
 *  <p/>
 *  The only public method that user needs to use is {@link #verifyLicense(String,String,String)}.
 */
public final class Lm {

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean DOC_DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean CM_DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean RA_DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean ID_DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean PG_DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean CB_DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean HG_DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean AF_DEBUG = false;

	/**
	 *  @deprecated no longer used
	 */
	public static final boolean BP_DEBUG = false;

	public static final boolean DOCK_DEBUG = false;

	public static final boolean DOCK_ID_DEBUG = false;

	public static final boolean ACTION_DEBUG = false;

	public static final boolean COMPONENT_DEBUG = false;

	public static final boolean PROPERTY_TABLE_DEBUG = false;

	public static final boolean COMBOBOX_DEBUG = false;

	public static final boolean BEAN_INTROSPECTOR_DEBUG = false;

	public static final boolean DEMO = false;

	public Lm() {
	}

	/**
	 *  Gets the product version. We used the same version number for all JIDE products. So you will get a version string
	 *  that applies to all JIDE products. It's in the format of x.x.x.xx. or x.x.x. Those numbers are milestone version,
	 *  major version, minor version and patch version respectively.
	 * 
	 *  @return the product version.
	 */
	public static String getProductVersion() {
	}

	public static boolean showDemoMessageBoxDocking() {
	}

	public static void showAboutMessageBox() {
	}

	protected static String getProductName(int[] products) {
	}

	public static void showInvalidProductMessage(String className, int productName) {
	}

	public static void z() {
	}

	/**
	 *  Verifies the license key.
	 *  <p/>
	 *  In order to use our product without the license key warning dialog, you need to get a license key from us. The
	 *  license key will only enable you to use the products you purchased.
	 *  <p/>
	 *  To get the license key, please send email to support@jidesoft.com. We need following two things from you in order
	 *  to generate a license key. So please make sure you have the two things in the email when asking for the license
	 *  key.
	 *  <p/>
	 *  <br>1. Company name. If you purchase this product as person, your name is also fine. <br>2. The project/product
	 *  name where JIDE products are used. We need this in order to differentiate in case there are two projects in the
	 *  same company using JIDE.
	 *  <p/>
	 *  Once you get the license key from us, just add this line to the beginning of your application's main method.
	 *  <p/>
	 *  <pre><code>
	 *      com.jidesoft.utils.Lm.verifyLicense("COMPANY NAME", "PROJECT NAME", "LICENSE KEY");
	 *  </code></pre>
	 *  <p/>
	 *  It will work in most cases. Sometimes you might use one of our components as static field which will get
	 *  initialized before the main method. In this case, you can add a static block before that field.
	 *  <p/>
	 *  <pre><code>
	 *  static {
	 *      com.jidesoft.utils.Lm.verifyLicense("COMPANY NAME", "PROJECT NAME", "LICENSE KEY");
	 *  }
	 *  </code></pre>
	 * 
	 *  @param companyName your company name. If you purchased this product for personal usage, you can use your name as
	 *                     well.
	 *  @param projectName your project name. It is the project or product where you will use JIDE products.
	 *  @param licenseKey  the license key we sent to you by email.
	 */
	public static void verifyLicense(String companyName, String projectName, String licenseKey) {
	}

	/**
	 *  Clears the license information.
	 */
	public static void clearLicense() {
	}

	/**
	 *  Sets a parent frame for any message boxes from this class. You don't need to call it in your application.
	 * 
	 *  @param parent the parent
	 */
	public static void setParent(javax.swing.JFrame parent) {
	}

	public static void showPopupMessageBox(String message) {
	}

	public static void main(String[] args) {
	}

	public static void getUIError(String componentName) {
	}
}
