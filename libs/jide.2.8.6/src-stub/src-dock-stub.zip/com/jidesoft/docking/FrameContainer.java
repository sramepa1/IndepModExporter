/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Container to hold DockableFrame when they are tabbed.
 */
@java.lang.SuppressWarnings("serial")
public class FrameContainer extends JideTabbedPane implements java.awt.event.ComponentListener, java.awt.event.ContainerListener, DragableDockable, java.beans.PropertyChangeListener {
 {

	public FrameContainer(DockingManager dockingManager) {
	}

	public FrameContainer(DockingManager dockingManager, int tabPlacement, int tabLayoutPolicy) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Invoked when a component has been added to the container.
	 */
	public void componentAdded(java.awt.event.ContainerEvent e) {
	}

	/**
	 *  Invoked when a component has been removed from the container.
	 */
	public void componentRemoved(java.awt.event.ContainerEvent e) {
	}

	/**
	 *  Invoked when the FrameContainer's size changes. It will reset undocked bounds if it's floating or setDockedWidth
	 *  and setDockedHeight if it's FRAMEDOCKED
	 */
	public void componentResized(java.awt.event.ComponentEvent e) {
	}

	/**
	 *  Invoked when the component's position changes.
	 */
	public void componentMoved(java.awt.event.ComponentEvent e) {
	}

	/**
	 *  Invoked when the component has been made visible.
	 */
	public void componentShown(java.awt.event.ComponentEvent e) {
	}

	/**
	 *  Invoked when the component has been made invisible.
	 */
	public void componentHidden(java.awt.event.ComponentEvent e) {
	}

	/**
	 *  A shortcut to add DOckableFrame as tab.
	 * 
	 *  @param frame a new dockable frame to be added.
	 */
	public void addTab(DockableFrame frame) {
	}

	public void addTab(DockableFrame frame, boolean suppressEvents) {
	}

	/**
	 *  A shortcut to insert DockableFrame as tab.
	 * 
	 *  @param frame a new dockable frame
	 *  @param index the index to be inserted
	 */
	public void insertTab(DockableFrame frame, int index) {
	}

	public void insertTab(DockableFrame frame, int index, boolean suppressEvents) {
	}

	public void setTitleAt(int index, String title) {
	}

	public void remove(java.awt.Component component, boolean suppressEvents) {
	}

	@java.lang.Override
	public void setSelectedComponent(java.awt.Component c) {
	}

	public void setSelectedIndex(int index, boolean suppressEvents) {
	}

	@java.lang.Override
	public void setSelectedIndex(int index) {
	}

	public void popupSelectedIndex(int index) {
	}

	public DockingManager getDockingManager() {
	}

	public void setDockingManager(DockingManager dockingManager) {
	}

	public void setDockedWidth(int w) {
	}

	public void setDockedHeight(int h) {
	}

	public void setAutohideWidth(int w) {
	}

	public void setAutohideHeight(int h) {
	}

	public int getDockedWidth() {
	}

	public int getDockedHeight() {
	}

	public int getAutohideWidth() {
	}

	public int getAutohideHeight() {
	}

	public void setUndockedBounds(java.awt.Rectangle bounds) {
	}

	public java.awt.Rectangle getUndockedBounds() {
	}

	public int getDockID() {
	}

	public void setDockID(int id) {
	}

	public void resetDockID() {
	}

	public DockableFrame getSelectedFrame() {
	}

	public DockableFrame getFrame(int index) {
	}

	public int getFrameIndex(DockableFrame frame) {
	}

	public void setHiddenPreviousState(PreviousState state) {
	}

	public PreviousState getHiddenPreviousState() {
	}

	public void setDockPreviousState(PreviousState state) {
	}

	public PreviousState getDockPreviousState() {
	}

	public void setFloatPreviousState(PreviousState state) {
	}

	public PreviousState getFloatPreviousState() {
	}

	public void setAutohidePreviousState(PreviousState state) {
	}

	public PreviousState getAutohidePreviousState() {
	}

	/**
	 *  This method gets called when a bound property is changed.
	 * 
	 *  @param evt A PropertyChangeEvent object describing the event source and the property that has changed.
	 */
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Checks if all dockable frames in it is floatable. If one of them is not floatable, return false. Otherwise,
	 *  return true.
	 * 
	 *  @return true if all are floatable. Otherwise return false.
	 */
	public boolean isAllFloatable() {
	}

	/**
	 *  Checks if all dockable frames in it is autohidable. If one of them is not autohidable, return false. Otherwise,
	 *  return true.
	 * 
	 *  @return true if all are autohidable. Otherwise return false.
	 */
	public boolean isAllAutohidable() {
	}

	/**
	 *  Checks if all dockable frames in it is autohidable and its preferred autohide side matches with the side passed
	 *  in. If one of them is not true, return false. Otherwise, return true.
	 * 
	 *  @param side the autohide side.
	 *  @return true if all are autohidable. Otherwise return false.
	 */
	public boolean isAllAutohidable(int side) {
	}

	/**
	 *  Checks if all dockable frames in it is hidable. If one of them is not hidable, return false. Otherwise, return
	 *  true.
	 * 
	 *  @return true if all are hidable. Otherwise return false.
	 */
	public boolean isAllHidable() {
	}

	/**
	 *  Overrides to get the isHidable value from dockable frame.
	 * 
	 *  @param tabIndex the tab index.
	 *  @return the corresponding dockable frame's hidable attribute.
	 */
	@java.lang.Override
	public boolean isTabClosableAt(int tabIndex) {
	}

	@java.lang.Override
	public boolean hasFocusComponent() {
	}

	@java.lang.Override
	public void repaintTabAreaAndContentBorder() {
	}
}
