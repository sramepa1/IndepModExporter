/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Default implementation of <code>DockableHolder</code> for JDialog.
 */
@java.lang.SuppressWarnings("serial")
public class DefaultDialogDockableHolder extends javax.swing.JDialog implements DockableHolder {
 {

	protected boolean _autoDispose;

	public DefaultDialogDockableHolder() {
	}

	public DefaultDialogDockableHolder(java.awt.Frame owner) {
	}

	public DefaultDialogDockableHolder(java.awt.Frame owner, boolean modal) {
	}

	public DefaultDialogDockableHolder(java.awt.Frame owner, String title) {
	}

	public DefaultDialogDockableHolder(java.awt.Frame owner, String title, boolean modal) {
	}

	public DefaultDialogDockableHolder(java.awt.Dialog owner) {
	}

	public DefaultDialogDockableHolder(java.awt.Dialog owner, boolean modal) {
	}

	public DefaultDialogDockableHolder(java.awt.Dialog owner, String title) {
	}

	public DefaultDialogDockableHolder(java.awt.Dialog owner, String title, boolean modal) {
	}

	/**
	 *  Creates a content container and add it to CENTER of JFrame content pane. It will also create a default
	 *  DockingManager.
	 * 
	 *  @param container the container where the docking manager is installed.
	 */
	protected void initFrame(java.awt.Container container) {
	}

	protected DockingManager createDockingManager(java.awt.Container contentContainer) {
	}

	/**
	 *  Gets the default docking manager.
	 * 
	 *  @return docking manager
	 */
	public DockingManager getDockingManager() {
	}

	/**
	 *  Gets the layout persistence. In the case of DefaultDockableHolder, it's the same value that is returned from
	 *  getDockingManager().
	 * 
	 *  @return layout persistence.
	 */
	public LayoutPersistence getLayoutPersistence() {
	}

	/**
	 *  Releases all of the native screen resources used by this Window, its subcomponents, and all of its owned
	 *  children. That is, the resources for these Components will be destroyed, any memory they consume will be returned
	 *  to the OS, and they will be marked as undisplayable. <p/> The Window and its subcomponents can be made
	 *  displayable again by rebuilding the native resources with a subsequent call to <code>pack</code> or
	 *  <code>show</code>. The states of the recreated Window and its subcomponents will be identical to the states of
	 *  these objects at the point where the Window was disposed (not accounting for additional modifcations between
	 *  those actions). </p>
	 * 
	 *  @see Component#isDisplayable
	 *  @see #pack
	 *  @see #show
	 */
	@java.lang.Override
	public void dispose() {
	}

	protected boolean isContentPaneCheckingEnabled() {
	}

	protected void setContentPaneCheckingEnabled(boolean contentPaneCheckingEnabled) {
	}

	/**
	 *  Checks if the docking manager will be disposed when the JFrame is disposed.
	 * 
	 *  @return true or false.
	 */
	public boolean isAutoDispose() {
	}

	/**
	 *  Sets the auto dispose flag. If true, the docking manager will be disposed when the JFrame is disposed.
	 * 
	 *  @param autoDispose true or false.
	 */
	public void setAutoDispose(boolean autoDispose) {
	}
}
