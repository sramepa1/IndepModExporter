/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  An interface to indicate the component can be docked to a DockableHolder.
 *  Common things about all Dockable components is they are all have a
 *  {@link DockingManager} and they all have an ID.
 */
public interface Dockable {

	/**
	 *  Gets the docking manager.
	 * 
	 *  @return the Docking Manager that manages this Dockable.
	 */
	public DockingManager getDockingManager();

	/**
	 *  Sets the docking Manager.
	 * 
	 *  @param dockingManager new docking manager
	 */
	public void setDockingManager(DockingManager dockingManager);

	/**
	 *  Gets dock id.
	 * 
	 *  @return the an int id that unique identify the component.
	 */
	public int getDockID();

	/**
	 *  Sets dock id.
	 * 
	 *  @param id new id
	 */
	public void setDockID(int id);

	/**
	 *  Resets dock id. It basically get a new id and discard the old one.
	 */
	public void resetDockID();
}
