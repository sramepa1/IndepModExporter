/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  An ActionListener with timer. It is used to animate the sliding window.
 */
public class NotificationFlasher implements java.awt.event.ActionListener {
 {

	public NotificationFlasher(FrameContainer fc, DockableFrame frame, int initDelay, int delay, int steps) {
	}

	public NotificationFlasher(AutoHideContainer ac, DockableFrame frame, int initDelay, int delay, int steps) {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}

	public void start() {
	}

	public void stop() {
	}

	public void interrupt() {
	}

	public boolean isRunning() {
	}
}
