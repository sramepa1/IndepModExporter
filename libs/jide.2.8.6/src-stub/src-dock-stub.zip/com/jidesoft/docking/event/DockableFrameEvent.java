/**
 *  The package contains events and listeners for JIDE Docking Framework product.
 */
package com.jidesoft.docking.event;


/**
 *  An <code>AWTEvent</code> that adds support for <code>DockableFrame</code> objects as the event source.
 * 
 *  @see com.jidesoft.docking.DockableFrame
 *  @see DockableFrameListener
 */
public class DockableFrameEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>DockableFrame</code> events.
	 */
	public static final int DOCKABLE_FRAME_FIRST = 3999;

	/**
	 *  The last number in the range of IDs used for <code>DockableFrame</code> events.
	 */
	public static final int DOCKABLE_FRAME_LAST = 4012;

	/**
	 *  This event is delivered when the <code>DockableFrame</code> is first added to DockingManager.
	 */
	public static final int DOCKABLE_FRAME_ADDED = 3999;

	/**
	 *  This event is delivered when the <code>DockableFrame</code> is removed from DockingManager.
	 */
	public static final int DOCKABLE_FRAME_REMOVED = 4000;

	/**
	 *  This event is delivered when showFrame is called on the <code>DockableFrame</code> .
	 */
	public static final int DOCKABLE_FRAME_SHOWN = 4001;

	/**
	 *  This event is delivered when hideFrame is called on the <code>DockableFrame</code>. You can veto this event by
	 *  overriding {@link com.jidesoft.docking.DockableFrame#shouldVetoHiding()} method and return true.
	 */
	public static final int DOCKABLE_FRAME_HIDDEN = 4002;

	/**
	 *  This event indicates that the <code>DockableFrame</code> has been changed from other states to the docking state
	 *  or position changed while in the docking state.
	 */
	public static final int DOCKABLE_FRAME_DOCKED = 4003;

	/**
	 *  This event indicates that the <code>DockableFrame</code> has been changed from other states to the floating state
	 *  or position changed while in the floating state.
	 */
	public static final int DOCKABLE_FRAME_FLOATING = 4004;

	/**
	 *  This event indicates that the <code>DockableFrame</code> has been changed from other states to the autohide
	 *  state.
	 * 
	 *  @see com.jidesoft.docking.DockableFrame#show
	 */
	public static final int DOCKABLE_FRAME_AUTOHIDDEN = 4005;

	/**
	 *  This event indicates that the <code>DockableFrame</code> has been changed from other states to the
	 *  autohide-showing state.
	 * 
	 *  @see com.jidesoft.docking.DockableFrame#show
	 */
	public static final int DOCKABLE_FRAME_AUTOHIDESHOWING = 4006;

	/**
	 *  This event indicates that the <code>DockableFrame</code> becomes active.
	 */
	public static final int DOCKABLE_FRAME_ACTIVATED = 4007;

	/**
	 *  This event indicates that the <code>DockableFrame</code> becomes inactive.
	 */
	public static final int DOCKABLE_FRAME_DEACTIVATED = 4008;

	/**
	 *  This event indicates that the <code>DockableFrame</code> becomes visible because its tab is selected.
	 */
	public static final int DOCKABLE_FRAME_TABSHOWN = 4009;

	/**
	 *  This event indicates that the <code>DockableFrame</code> becomes invisible because its tab is deselected.
	 */
	public static final int DOCKABLE_FRAME_TABHIDDEN = 4010;

	/**
	 *  This event indicates that the <code>DockableFrame</code> becomes maximized.
	 */
	public static final int DOCKABLE_FRAME_MAXIMIZED = 4011;

	/**
	 *  This event indicates that the <code>DockableFrame</code> restored from maximized state.
	 */
	public static final int DOCKABLE_FRAME_RESTORED = 4012;

	/**
	 *  Constructs an <code>DockableFrameEvent</code> object.
	 * 
	 *  @param source the <code>DockableFrame</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 */
	public DockableFrameEvent(com.jidesoft.docking.DockableFrame source, int id) {
	}

	/**
	 *  Constructs an <code>DockableFrameEvent</code> object.
	 * 
	 *  @param source   the <code>DockableFrame</code> object that originated the event
	 *  @param id       an integer indicating the type of event
	 *  @param opposite the opppsote DockableFrame. This is only used by activated and deactivated event.
	 */
	public DockableFrameEvent(com.jidesoft.docking.DockableFrame source, int id, com.jidesoft.docking.DockableFrame opposite) {
	}

	/**
	 *  Returns a parameter string identifying this event. This method is useful for event logging and for debugging.
	 * 
	 *  @return a string identifying the event and its attributes
	 */
	@java.lang.Override
	public String paramString() {
	}

	/**
	 *  Returns the originator of the event.
	 * 
	 *  @return the <code>DockableFrame</code> object that originated the event
	 */
	public com.jidesoft.docking.DockableFrame getDockableFrame() {
	}

	/**
	 *  Gets the opposite dockable frame. It is set only when the event id is DOCKABLE_FRAME_ACTIVATED or
	 *  DOCKABLE_FRAME_DEACTIVATED. When a frame is activated, opposite dockable frame is the one that is deactivated if
	 *  there is one.
	 * 
	 *  @return the opposite dockable frame. It could return null if there is no opposite dockable frame.
	 */
	public com.jidesoft.docking.DockableFrame getOppositeDockableFrame() {
	}
}
