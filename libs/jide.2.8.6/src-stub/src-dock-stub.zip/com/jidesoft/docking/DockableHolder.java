/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  <code>DockableHolder</code> inteface is used to indicate the container can hold <code>Dockable</code>. <br> You can
 *  make <code>JFrame</code> a <code>DockableHolder</code> simply by implementing this interface.
 * 
 *  @see Dockable
 */
public interface DockableHolder {

	/**
	 *  Return the DockingManager that manages the <code>DockableHolder</code>. There is only one
	 *  <code>Dockingmanager</code> allowed in each <code>DockableHolder</code>.
	 * 
	 *  @return the DockingManager that manages the <code>DockableHolder</code>.
	 */
	public DockingManager getDockingManager();
}
