/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  A lightweight frame that provides many of the features of a native frame, including dragging, hiding, resizing, title
 *  display, and support docking, auto-hiding and floating.
 *  <p/>
 *  <p/>
 *  Generally, you add <code>DockableFrame</code>s to any <code>JFrame</code> as long as that JFrame implements
 *  <code>DockableHolder</code>. The UI delegates the look-and-feel-specific actions to the <code>DockingManager</code>
 *  object maintained by the <code>JFrame</code>.
 *  <p/>
 *  The <code>DockableFrame</code> content pane is where you add child components. So, to create a
 *  <code>DockableFrame</code> that has a number of buttons arranged with the content pane's default
 *  <code>BorderLayout</code> object, you might do something like this:
 *  <pre>
 *     JComponent c = (JComponent) dockableFrame.getContentPane();
 *     c.add(new JScrollPane(new JTextArea()), BorderLayout.NORTH);
 *     c.add(new JButton(), BorderLayout.CENTER);
 *  </pre>
 * 
 *  @see com.jidesoft.docking.event.DockableFrameEvent
 *  @see com.jidesoft.docking.DockingManager
 */
@java.lang.SuppressWarnings("serial")
public class DockableFrame extends javax.swing.JComponent implements javax.accessibility.Accessible, javax.swing.WindowConstants, DragableDockable, Refocusable, DockableHolder {
 {

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_CONTENT_PANE = "contentPane";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_MENU_BAR = "JMenuBar";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_TAB_TITLE = "tabTitle";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_SIDE_TITLE = "sideTitle";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_TITLE = "title";

	/**
	 *  Bound property key.
	 */
	public static final String PROPERTY_KEY = "key";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_LAYERED_PANE = "layeredPane";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_ROOT_PANE = "rootPane";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_GLASS_PANE = "glassPane";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_FRAME_ICON = "frameIcon";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_AVAILABLE_BUTTONS = "availableButtons";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_BUTTONS_ORDER = "buttonsOrder";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_TITLE_BAR_COMPONENT = "titleBarComponent";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_TITLE_LABEL_COMPONENT = "titleLabelComponent";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_VISIBLE = "visible";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_AVAILABLE = "available";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_SLIDING_AUTOHIDE = "slidingAutohide";

	/**
	 *  Bound property name.
	 */
	public static final String PROPERTY_TRANSIENT = "transient";

	/**
	 *  Constrained property name indicating that the dockable frame is floatable.
	 */
	public static final String PROPERTY_FLOATABLE = "floatable";

	/**
	 *  Constrained property name indicating that the dockable frame can be hided.
	 */
	public static final String PROPERTY_HIDABLE = "hidable";

	/**
	 *  Constrained property name indicating that the dockable frame can be docked.
	 */
	public static final String PROPERTY_DOCKABLE = "dockable";

	/**
	 *  Constrained property name indicating that the dockable frame can be autohidden.
	 */
	public static final String PROPERTY_AUTOHIDABLE = "autohidable";

	/**
	 *  Constrained property name indicating that the dockable frame can be maximized.
	 */
	public static final String PROPERTY_MAXIMIZABLE = "maximizable";

	/**
	 *  Constrained property name indicating that the dockable frame can be rearranged.
	 */
	public static final String PROPERTY_REARRANGABLE = "rearrangable";

	/**
	 *  Constrained property name indicating that the dockable frame is selected.
	 */
	public static final String PROPERTY_ACTIVE = "active";

	/**
	 *  Constrained property name indicating that the dockable frame is maximized.
	 */
	public static final String PROPERTY_MAXIMIZED = "maximized";

	/**
	 *  Constrained property name indicating that the dockable frame is hidden.
	 */
	public static final String PROPERTY_HIDDEN = "hidden";

	/**
	 *  Constrained property name indicating that the dockable frame is docked.
	 */
	public static final String PROPERTY_DOCKED = "docked";

	/**
	 *  Constrained property name indicating that the dockable frame is floated.
	 */
	public static final String PROPERTY_FLOATED = "floated";

	/**
	 *  Constrained property name indicating that the dockable frame is autohide.
	 */
	public static final String PROPERTY_AUTOHIDE = "autohide";

	/**
	 *  Constrained property name indicating that the dockable frame is autohide but showing.
	 */
	public static final String PROPERTY_AUTOHIDE_SHOWING = "autohideShowing";

	public static final String PROPERTY_TAB_DOCK_ALLOWED = "tabDockAllowed";

	public static final String PROPERTY_SIDE_DOCK_ALLOWED = "sideDockAllowed";

	/**
	 *  Bound property name for gripper.
	 */
	public static final String PROPERTY_SHOW_GRIPPER = "showGripper";

	public static final String PROPERTY_SHOW_TITLE_BAR = "showTitleBar";

	public static final String PROPERTY_SHOW_CONTENT_PANE = "showContentPane";

	public static final String PROPERTY_SHOW_CONTEXT_MENU = "showContextMenu";

	public static final String PROPERTY_INIT_SIDE = "initSide";

	public static final String PROPERTY_INIT_MODE = "initMode";

	public static final String PROPERTY_INIT_INDEX = "initIndex";

	public static final String PROPERTY_DOCKED_WIDTH = "dockedWidth";

	public static final String PROPERTY_DOCKED_HEIGHT = "dockedHeight";

	public static final String PROPERTY_AUTOHIDE_WIDTH = "autohideWidth";

	public static final String PROPERTY_AUTOHIDE_HEIGHT = "autohideHeight";

	public static final String PROPERTY_UNDOCKED_BOUNDS = "undockedBounds";

	public static final String PROPERTY_PREFERRED_AUTOHIDE_SIDE = "preferredAutohideSide";

	public static final String PROPERTY_CLOSE_ACTION = "closeAction";

	public static final String PROPERTY_AUTOHIDE_ACTION = "autohideAction";

	public static final String PROPERTY_HIDE_AUTOHIDE_ACTION = "hideAutohideAction";

	public static final String PROPERTY_FLOATING_ACTION = "floatingAction";

	public static final String PROPERTY_MAXIMIZE_ACTION = "maximizeAction";

	public static final String PROPERTY_DOCKABLE_ACTION = "dockableAction";

	public static final String PROPERTY_DOUBLE_CLICK_ACTION = "doubleClickAction";

	public static final String PROPERTY_DEFAULT_CLOSE_ACTION = "defaultCloseAction";

	public static final String PROPERTY_DEFAULT_AUTOHIDE_ACTION = "defaultAutohideAction";

	public static final String PROPERTY_DEFAULT_ESCAPE_ACTION = "defaultEscapeAction";

	public static final String PROPERTY_AUTOHIDE_WHEN_ACTIVE = "autohideWhenActive";

	/**
	 *  Constrained property name indicating that the additional buttons currently have.
	 */
	public static final String PROPERTY_ADDITONAL_BUTTON_ACTIONS = "addtionalButtonActions";

	/**
	 *  The value of each buttons. It's a bit wise OR to combine them together if several buttons are visible.
	 */
	public static final int BUTTON_CLOSE = 1;

	public static final int BUTTON_HIDE_AUTOHIDE = 2;

	public static final int BUTTON_AUTOHIDE = 4;

	public static final int BUTTON_FLOATING = 8;

	public static final int BUTTON_MAXIMIZE = 16;

	public static final int BUTTON_ALL = -1;

	protected java.beans.PropertyChangeListener _focusChangeListener;

	protected javax.swing.Action _closeAction;

	protected javax.swing.Action _hideAutohideAction;

	protected javax.swing.Action _floatingAction;

	protected javax.swing.Action _autohideAction;

	protected javax.swing.Action _maximizeAction;

	protected javax.swing.Action _dockableAction;

	protected javax.swing.Action _customDoubleClickAction;

	protected boolean _showContextMenu;

	/**
	 *  One of the default close actions. If the close button key is pressed, the dockable frame will be hidden.
	 */
	public static final int CLOSE_ACTION_TO_HIDE = 0;

	/**
	 *  One of the default close actions. If the close button key is pressed, the dockable frame will be removed from the
	 *  docking manager.
	 */
	public static final int CLOSE_ACTION_TO_REMOVE = 1;

	/**
	 *  One of the default close actions. If this close button key is pressed, the dockable frame will, hide, remove
	 *  itself and then call dispose.
	 */
	public static final int CLOSE_ACTION_TO_REMOVE_AND_DISPOSE = 2;

	/**
	 *  One of the default autohide actions. If the autohide button key is pressed, the frame will remain active.
	 */
	public static final int AUTOHIDE_ACTION_TO_REMAIN_ACTIVE = 0;

	/**
	 *  One of the default escape actions. If the escape key is pressed, the focus will be transferred to
	 *  DockingManager#getEscapeKeyTargetComponent in this case.
	 */
	public static final int ESCAPE_ACTION_TO_YIELD_FOCUS = 0;

	/**
	 *  One of the default escape actions. If the escape key is pressed, nothing will happen.
	 */
	public static final int ESCAPE_ACTION_DO_NOTING = 1;

	/**
	 *  One of the default escape actions. If the escape key is pressed, the dockable frame will be hidden and the focus
	 *  will be transferred to DockingManager#getEscapeKeyTargetComponent in this case.
	 */
	public static final int ESCAPE_ACTION_TO_HIDE = 2;

	/**
	 *  One of the default escape actions. If the escape key is pressed, the dockable frame will be removed from the
	 *  docking manager and the focus will be transferred to DockingManager#getEscapeKeyTargetComponent in this case.
	 */
	public static final int ESCAPE_ACTION_TO_REMOVE = 3;

	/**
	 *  Create an DockableFramew with empty key and default icon. Please note, you must call setKey() to set a key before
	 *  adding it to DockingManager.
	 */
	public DockableFrame() {
	}

	/**
	 *  Create an DockableFramew with <code>key</code> and default icon.
	 * 
	 *  @param key key of the dockable frame
	 */
	public DockableFrame(String key) {
	}

	/**
	 *  Create an DockableFramew with empty key and specified icon. Please note, you must call setKey() to set a key
	 *  before adding it to DockingManager.
	 * 
	 *  @param frameIcon icon of the dockable frame
	 */
	public DockableFrame(javax.swing.Icon frameIcon) {
	}

	/**
	 *  Create an DockableFramew with <code>key</code> and icon.
	 * 
	 *  @param key       key of the dockable frame
	 *  @param frameIcon icon of the dockable frame
	 */
	public DockableFrame(String key, javax.swing.Icon frameIcon) {
	}

	protected void addFocusTracker() {
	}

	/**
	 *  Returns true if this component is completely opaque.
	 *  <p/>
	 *  An opaque component paints every pixel within its rectangular bounds. A non-opaque component paints only a subset
	 *  of its pixels or none at all, allowing the pixels underneath it to "show through".  Therefore, a component that
	 *  does not fully paint its pixels provides a degree of transparency.
	 *  <p/>
	 *  Subclasses that guarantee to always completely paint their contents should override this method and return true.
	 * 
	 *  @return true if this component is completely opaque
	 * 
	 *  @see #setOpaque
	 */
	@java.lang.Override
	public boolean isOpaque() {
	}

	/**
	 *  Create a <code>DockableFrameMouseInputAdapter</code> and return it.
	 * 
	 *  @return a MouseInputAdapter that can handle mouse input in <code>DockableFrame</code>.
	 */
	public javax.swing.event.MouseInputListener createDockableFrameMouseInputListener() {
	}

	/**
	 *  Uninstalls the mouse listener.
	 */
	protected void deinstallMouseHandlers() {
	}

	/**
	 *  Install mouse listener to title bar of <code>DockableFrame<code>.
	 */
	protected void installMouseHandlers() {
	}

	/**
	 *  Called by the constructor to set up the <code>JRootPane</code>.
	 * 
	 *  @return a new <code>JRootPane</code>
	 * 
	 *  @see javax.swing.JRootPane
	 */
	protected javax.swing.JRootPane createRootPane() {
	}

	/**
	 *  Returns the look-and-feel object that renders this component.
	 * 
	 *  @return the <code>DockableFrameUI</code> object that renders this component
	 */
	public com.jidesoft.plaf.DockableFrameUI getUI() {
	}

	/**
	 *  Sets the UI delegate for this <code>DockableFrame</code>.
	 * 
	 *  @param ui the UI delegate
	 */
	public void setUI(com.jidesoft.plaf.DockableFrameUI ui) {
	}

	/**
	 *  Notification from the <code>UIManager</code> that the look and feel has changed. Replaces the current UI object
	 *  with the latest version from the <code>UIManager</code>.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the name of the look-and-feel class that renders this component.
	 * 
	 *  @return the string "DockableFrameUI"
	 * 
	 *  @see javax.swing.JComponent#getUIClassID
	 *  @see javax.swing.UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  Returns whether calls to <code>add</code> and <code>setLayout</code> cause an exception to be thrown.
	 * 
	 *  @return <code>true</code> if <code>add</code> and <code>setLayout</code> are checked
	 * 
	 *  @see #addImpl
	 *  @see #setLayout
	 *  @see #setRootPaneCheckingEnabled
	 */
	protected boolean isRootPaneCheckingEnabled() {
	}

	/**
	 *  Determines whether calls to <code>add</code> and <code>setLayout</code> cause an exception to be thrown.
	 * 
	 *  @param enabled a boolean value, <code>true</code> if checking is to be enabled, which cause the exceptions to be
	 *                 thrown
	 *  @see #addImpl
	 *  @see #setLayout
	 *  @see #isRootPaneCheckingEnabled
	 */
	protected void setRootPaneCheckingEnabled(boolean enabled) {
	}

	/**
	 *  Ensures that, by default, children cannot be added directly to this component. Instead, children must be added to
	 *  its content pane. For example:
	 *  <pre>
	 *  thisComponent.getContentPane().add(child)
	 *  </pre>
	 *  An attempt to add to directly to this component will cause a runtime exception to be thrown. Subclasses can
	 *  disable this behavior.
	 * 
	 *  @param comp        the <code>Component</code> to be added
	 *  @param constraints the object containing the constraints, if any
	 *  @param index       the index
	 *  @throws java.lang.Error if called with <code>isRootPaneChecking</code> <code>true</code>
	 *  @see #setRootPaneCheckingEnabled
	 */
	@java.lang.Override
	protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	}

	/**
	 *  Removes the specified component from this container.
	 * 
	 *  @param comp the component to be removed
	 *  @see #add
	 */
	@java.lang.Override
	public void remove(java.awt.Component comp) {
	}

	/**
	 *  Ensures that, by default, the layout of this component cannot be set. Instead, the layout of its content pane
	 *  should be set. For example:
	 *  <pre>
	 *  thisComponent.getContentPane().setLayout(new GridLayout(1,2))
	 *  </pre>
	 *  An attempt to set the layout of this component will cause an runtime exception to be thrown. Subclasses can
	 *  disable this behavior.
	 * 
	 *  @param manager the <code>LayoutManager</code>
	 *  @throws java.lang.Error if called with <code>isRootPaneChecking</code> <code>true</code>
	 *  @see #setRootPaneCheckingEnabled
	 */
	@java.lang.Override
	public void setLayout(java.awt.LayoutManager manager) {
	}

	/**
	 *  Returns the current <code>JMenuBar</code> for this <code>DockableFrame</code>, or <code>null</code> if no menu
	 *  bar has been set.
	 * 
	 *  @return the <code>JMenuBar</code> used by this dockable frame
	 * 
	 *  @see #setJMenuBar
	 */
	public javax.swing.JMenuBar getJMenuBar() {
	}

	/**
	 *  Sets the <code>menuBar</code> property for this <code>DockableFrame</code>.
	 * 
	 *  @param m the <code>JMenuBar</code> to use in this dockable frame
	 *  @see #getJMenuBar
	 */
	public void setJMenuBar(javax.swing.JMenuBar m) {
	}

	/**
	 *  Returns the content pane for this dockable frame.
	 * 
	 *  @return the content pane
	 */
	public java.awt.Container getContentPane() {
	}

	/**
	 *  Sets this <code>DockableFrame</code>'s <code>contentPane</code> property.
	 * 
	 *  @param c the content pane for this dockable frame
	 *  @throws java.awt.IllegalComponentStateException
	 *           (a runtime exception) if the content pane parameter is <code>null</code>
	 *  @see javax.swing.RootPaneContainer#getContentPane
	 */
	public void setContentPane(java.awt.Container c) {
	}

	/**
	 *  Returns the layered pane for this dockable frame.
	 * 
	 *  @return a <code>JLayeredPane</code> object
	 * 
	 *  @see javax.swing.RootPaneContainer#setLayeredPane
	 *  @see javax.swing.RootPaneContainer#getLayeredPane
	 */
	public javax.swing.JLayeredPane getLayeredPane() {
	}

	/**
	 *  Sets this <code>DockableFrame</code>'s <code>layeredPane</code> property.
	 * 
	 *  @param layered the <code>JLayeredPane</code> for this dockable frame
	 *  @throws java.awt.IllegalComponentStateException
	 *           (a runtime exception) if the layered pane parameter is <code>null</code>
	 *  @see javax.swing.RootPaneContainer#setLayeredPane
	 */
	public void setLayeredPane(javax.swing.JLayeredPane layered) {
	}

	/**
	 *  Returns the glass pane for this dockable frame.
	 * 
	 *  @return the glass pane
	 * 
	 *  @see javax.swing.RootPaneContainer#setGlassPane
	 */
	public java.awt.Component getGlassPane() {
	}

	/**
	 *  Sets this <code>DockableFrame</code>'s <code>glassPane</code> property.
	 * 
	 *  @param glass the glass pane for this dockable frame
	 *  @see javax.swing.RootPaneContainer#getGlassPane
	 */
	public void setGlassPane(java.awt.Component glass) {
	}

	/**
	 *  Returns the <code>rootPane</code> object for this dockable frame.
	 * 
	 *  @return the <code>rootPane</code> property
	 * 
	 *  @see javax.swing.RootPaneContainer#getRootPane
	 */
	@java.lang.Override
	public javax.swing.JRootPane getRootPane() {
	}

	/**
	 *  Sets the <code>rootPane</code> property for this <code>DockableFrame</code>. This method is called by the
	 *  constructor.
	 * 
	 *  @param root the new <code>JRootPane</code> object
	 */
	protected void setRootPane(javax.swing.JRootPane root) {
	}

	/**
	 *  Gets the buttons that are visible on the title bar of dockable frame.
	 * 
	 *  @return the visibilities of each buttons. It's a bit wise OR of values specified at BUTTON_XXX.
	 */
	public int getAvailableButtons() {
	}

	/**
	 *  Sets the visibilities of each buttons on the title bar of dockable frame.
	 * 
	 *  @param availableButtons the visibilities of each buttons. It's a bit wise OR of values specified at BUTTON_XXX.
	 */
	public void setAvailableButtons(int availableButtons) {
	}

	/**
	 *  Sets whether this <code>DockableFrame</code> can be hidden by some user action.
	 * 
	 *  @param b a boolean value, where <code>true</code> means this dockable frame can be closed
	 */
	public void setHidable(boolean b) {
	}

	/**
	 *  Returns whether this <code>DockableFrame</code> can be closed by some user action.
	 * 
	 *  @return <code>true</code> if this dockable frame can be closed
	 */
	public boolean isHidable() {
	}

	/**
	 *  Returns whether this <code>DockableFrame</code> is currently hidden.
	 * 
	 *  @return <code>true</code> if this _dockable frame is hidden, <code>false</code> otherwise
	 */
	public boolean isHidden() {
	}

	/**
	 *  Sets the internal state of dockable frame to STATE_HIDDEN if the argument is <code>true</code>. It will fire
	 *  property change event on {@link DockableFrame#PROPERTY_HIDDEN}.
	 *  <p/>
	 * 
	 *  @param b can be <code>true</code> or <code>false<.code>
	 *  @throws java.beans.PropertyVetoException
	 *           when the attempt to set the property is vetoed by the <code>DockableFrame</code>
	 *  @see #isHidden()
	 */
	public void setHidden(boolean b) {
	}

	/**
	 *  Sets whether the <code>DockableFrame</code> can be docked by some user action.
	 * 
	 *  @param b a boolean, where <code>true</code> means this dockable frame can be docked
	 */
	public void setDockable(boolean b) {
	}

	/**
	 *  Returns whether the <code>DockableFrame</code> can be docked by some user action.
	 * 
	 *  @return <code>true</code> if this dockable frame can be dockable, <code>false</code> otherwise
	 */
	public boolean isDockable() {
	}

	/**
	 *  Sets whether the <code>DockableFrame</code> can be resized by some user action.
	 * 
	 *  @param b a boolean, where <code>true</code> means this dockable frame can be resized
	 */
	public void setAutohidable(boolean b) {
	}

	/**
	 *  Returns whether the <code>DockableFrame</code> can be autohidable by some user action.
	 * 
	 *  @return <code>true</code> if this dockable frame can be autohidable, <code>false</code> otherwise
	 */
	public boolean isAutohidable() {
	}

	/**
	 *  Sets the <code>floatable</code> property, which must be <code>true</code> for the user to be able to make the
	 *  <code>DockableFrame</code> floated.
	 * 
	 *  @param b a boolean, where <code>true</code> means this dockable frame can be floated
	 */
	public void setFloatable(boolean b) {
	}

	/**
	 *  Gets the <code>floatable</code> property, which by default is <code>false</code>.
	 * 
	 *  @return the value of the <code>floatable</code> property.
	 * 
	 *  @see #setFloatable
	 */
	public boolean isFloatable() {
	}

	/**
	 *  Sets whether the <code>DockableFrame</code> can be docked by some user action.
	 * 
	 *  @param b a boolean, where <code>true</code> means this dockable frame can be docked
	 */
	public void setRearrangable(boolean b) {
	}

	/**
	 *  Returns whether the <code>DockableFrame</code> can be docked by some user action.
	 * 
	 *  @return <code>true</code> if this dockable frame can be dockable, <code>false</code> otherwise
	 */
	public boolean isRearrangable() {
	}

	/**
	 *  Returns whether the <code>DockableFrame</code> is currently floating.
	 * 
	 *  @return <code>true</code> if this dockable frame is floating
	 */
	public boolean isFloated() {
	}

	/**
	 *  Returns whether the <code>DockableFrame</code> is currently docked.
	 * 
	 *  @return <code>true</code> if this dockable frame is docked, <code>false</code> otherwise
	 */
	public boolean isDocked() {
	}

	/**
	 *  Sets this frame to dock state.
	 * 
	 *  @param b Always pass in true.
	 *  @throws PropertyVetoException if the property change is vetoed.
	 */
	protected void setDocked(boolean b) {
	}

	/**
	 *  Sets this frame to float state.
	 * 
	 *  @param b Always pass in true.
	 *  @throws PropertyVetoException if the property change is vetoed.
	 */
	protected void setFloated(boolean b) {
	}

	/**
	 *  Sets this frame to auto-hide state.
	 * 
	 *  @param b Always pass in true.
	 *  @throws PropertyVetoException if the property change is vetoed.
	 */
	protected void setAutohide(boolean b) {
	}

	/**
	 *  Sets this frame to auto-hide-showing state.
	 * 
	 *  @param b Always pass in true.
	 *  @throws PropertyVetoException if the property change is vetoed.
	 */
	protected void setAutohideShowing(boolean b) {
	}

	/**
	 *  Sets the key of the <code>DockableFrame</code>. The key is used to uniquely identify a dockable frame in one
	 *  DockingManager. If this dockable frame has been added to DockingManager and you try to set a key that has been
	 *  used, IllegalArgumentException will be thrown.
	 * 
	 *  @param key a <code>String</code> containing this dockable frame's key
	 */
	public void setKey(String key) {
	}

	/**
	 *  Returns the key of the <code>DockableFrame</code>. The key is used to uniquely identify a dockable frame in one
	 *  DockingManager. The key is not displayed anywhere in the user interface so it is OK to be a non-localized string.
	 *  The strings for tabTitle, sideTitle, and title should be localized.
	 * 
	 *  @return a <code>String</code> containing this dockable frame's key
	 */
	public String getKey() {
	}

	/**
	 *  Returns the tab title of the <code>DockableFrame</code>. Tab title is displayed on the tab when the dockable
	 *  frame is docked in a tabbed pane. If tab title is never set, the <code>key</code> will be used by default.
	 * 
	 *  @return a <code>String</code> containing this dockable frame's tab title.
	 * 
	 *  @see #setTabTitle
	 */
	public String getTabTitle() {
	}

	/**
	 *  Sets the <code>DockableFrame</code> tab title.
	 * 
	 *  @param title the <code>String</code> to display on the tab.
	 *  @see #getTabTitle
	 */
	public void setTabTitle(String title) {
	}

	/**
	 *  Returns the side title of the <code>DockableFrame</code>. Side title is displayed on the side pane's tab when the
	 *  dockable frame is in autohide mode. If side title is never set, the <code>tabTitle</code> will be used by
	 *  default. If <code>tabTitle</code> is never set either, <code>key</code> will be used.
	 * 
	 *  @return a <code>String</code> containing this dockable frame's side title.
	 * 
	 *  @see #setSideTitle
	 */
	public String getSideTitle() {
	}

	/**
	 *  Sets the <code>DockableFrame</code> side title.
	 * 
	 *  @param title the <code>String</code> to display on the side pane.
	 *  @see #getSideTitle
	 */
	public void setSideTitle(String title) {
	}

	/**
	 *  Returns the title of the <code>DockableFrame</code>. Title is displayed on the title bar of dockable frame. As it
	 *  is displayed on title bar, it could be a longer string than <code>tabTitle</code>. It is also used as the tooltip
	 *  of the tab in tabbed pane. If <code>title</code> is never set, the <code>tabTitle</code> will be used by default.
	 *  If <code>tabTitle</code> is never set either, <code>key</code> will be used.
	 * 
	 *  @return a <code>String</code> containing this dockable frame's title bar.
	 * 
	 *  @see #setTitle(String)
	 */
	public String getTitle() {
	}

	/**
	 *  Sets the <code>DockableFrame</code> title.
	 * 
	 *  @param title the <code>String</code> to display in the title bar.
	 */
	public void setTitle(String title) {
	}

	/**
	 *  Returns whether the <code>DockableFrame</code> is currently autohidden.
	 * 
	 *  @return <code>true</code> if this dockable frame is currently autohidden.
	 */
	public boolean isAutohide() {
	}

	/**
	 *  Returns whether the <code>DockableFrame</code> is currently in autohide mode and is visible.
	 * 
	 *  @return <code>true</code> if this dockable frame is currently in autohide mode and is visible.
	 */
	public boolean isAutohideShowing() {
	}

	/**
	 *  Sets an image to be displayed in the titlebar of this dockable frame (usually in the top-left corner) or tab icon
	 *  if the dockable frame is tabbed with other frames.
	 *  <p/>
	 *  You may pass null to this method. However getFrameIcon will return default icon defined in UIManager
	 *  "DockableFrame.defaultIcon".
	 *  <p/>
	 *  By default, VSNET and OFFICE2003 style don't show icon on dockable frame title pane. ECLIPSE/ECLIPSE3X and XERTO
	 *  style do. But you can always change it by changing UIDefault "DockableFrameTitlePane.showIcon" to Boolean.TRUE to
	 *  show the icon. You can use LookAndFeelFactory.addUIDefaultsCustomizer to do it. The reason is the same icon will
	 *  be used on the tab when dockable frames are tabbed together and we don't want to display the same icon twice.
	 *  UIDefault "JideTabbedPane.showIconOnTab" can be used to control if icon is visible on tab.
	 * 
	 *  @param icon the <code>Icon</code> to display in the title bar
	 *  @see #getFrameIcon()
	 */
	public void setFrameIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Returns the image displayed in the title bar of this dockable frame(usually in the top-left corner).
	 *  <p/>
	 *  We don't allow null icon. So if the frameIcon was set to null, this method will return
	 *  UIManager.getIcon("DockableFrame.defaultIcon") instead of returning null.
	 * 
	 *  @return the <code>Icon</code> displayed in the title bar.
	 * 
	 *  @see #setFrameIcon
	 */
	public javax.swing.Icon getFrameIcon() {
	}

	/**
	 *  If this <code>DockableFrame</code> is active, returns the child that has focus. Otherwise, returns
	 *  <code>null</code>.
	 * 
	 *  @return the component with focus, or <code>null</code> if no children have focus
	 */
	protected java.awt.Component getFocusOwner() {
	}

	/**
	 *  Adds the specified listener to receive dockable frame events from this dockable frame. If you want to listen to
	 *  the events from all DockableFrames of a particular DockingManager, you can use {@link
	 *  DockingManager#addDockableFrameListener(com.jidesoft.docking.event.DockableFrameListener)} method.
	 * 
	 *  @param l the dockable frame listener
	 */
	public void addDockableFrameListener(event.DockableFrameListener l) {
	}

	/**
	 *  Removes the specified dockable frame listener so that it no longer receives dockable frame events from this
	 *  dockable frame.
	 * 
	 *  @param l the dockable frame listener
	 */
	public void removeDockableFrameListener(event.DockableFrameListener l) {
	}

	/**
	 *  Returns an array of all the <code>DockableFrameListener</code>s added to this <code>DockableFrame</code> with
	 *  <code>addDockableFrameListener</code>.
	 * 
	 *  @return all of the <code>DockableFrameListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addDockableFrameListener
	 */
	public event.DockableFrameListener[] getDockableFrameListeners() {
	}

	/**
	 *  Fires an dockable frame event.
	 * 
	 *  @param id                    the type of the event being fired; one of the following: If the event type is not
	 *                               one of the above, nothing happens.
	 *  @param oppositeDockableFrame the opposite dockable frame. This is only used for activated and deactivated event.
	 */
	protected void fireDockableFrameEvent(int id, DockableFrame oppositeDockableFrame) {
	}

	@java.lang.SuppressWarnings("ConstantConditions")
	protected void fireDockableFrameEvent(int id) {
	}

	/**
	 *  Get the <code>DockContext</code> used by <code>DockableFrame</code>.
	 * 
	 *  @return the DockContext used
	 */
	public DockContext getContext() {
	}

	/**
	 *  Sets the dock context.
	 * 
	 *  @param context the new context.
	 */
	public void setContext(DockContext context) {
	}

	/**
	 *  Sets the state before the component switches to hidden mode.
	 * 
	 *  @param state the previous state.
	 */
	public void setHiddenPreviousState(PreviousState state) {
	}

	/**
	 *  Gets the state before the component switches to hidden mode
	 * 
	 *  @return state
	 */
	public PreviousState getHiddenPreviousState() {
	}

	/**
	 *  Sets the state before the component switches between available and unavailable.
	 * 
	 *  @param state the previous state.
	 */
	public void setAvailablePreviousState(PreviousState state) {
	}

	/**
	 *  Gets the state before the component switches between available and unavailable
	 * 
	 *  @return state
	 */
	public PreviousState getAvailablePreviousState() {
	}

	/**
	 *  Sets the state before the component switches between maximized and restore.
	 * 
	 *  @param state the previous state.
	 */
	public void setMaximizedPreviousState(PreviousState state) {
	}

	/**
	 *  Gets the state before the component switches between maximized and restore
	 * 
	 *  @return state
	 */
	public PreviousState getMaximizedPreviousState() {
	}

	/**
	 *  Sets the state before the component before main JFrame is closed.
	 * 
	 *  @param state the previous state.
	 */
	public void setClosePreviousState(PreviousState state) {
	}

	/**
	 *  Gets the state before the component switch to hidden mode.
	 * 
	 *  @return state
	 */
	public PreviousState getClosePreviousState() {
	}

	/**
	 *  Save the state before the component switch to dock mode
	 * 
	 *  @param state the previous state.
	 */
	public void setDockPreviousState(PreviousState state) {
	}

	/**
	 *  Get the state before the component switch to dock mode
	 * 
	 *  @return state
	 */
	public PreviousState getDockPreviousState() {
	}

	/**
	 *  Save the state before the component switch to floating mode
	 * 
	 *  @param state the previous state.
	 */
	public void setFloatPreviousState(PreviousState state) {
	}

	/**
	 *  Get the state before the component switch to floating mode
	 * 
	 *  @return state
	 */
	public PreviousState getFloatPreviousState() {
	}

	/**
	 *  Save the state before the component switch to auto-hide mode
	 * 
	 *  @param state the previous state.
	 */
	public void setAutohidePreviousState(PreviousState state) {
	}

	/**
	 *  Get the state before the component switch to auto-hide mode
	 * 
	 *  @return state before it is auto-hided
	 */
	public PreviousState getAutohidePreviousState() {
	}

	/**
	 *  Gets if the dockable frame is active.
	 * 
	 *  @return if the dockable frame is active.
	 */
	public boolean isActive() {
	}

	/**
	 *  Set the active property and activate the dockable frame.
	 *  <p/>
	 *  If the dockable frame is added to DockingManager, you shouldn't call this method directly. Instead, call {@link
	 *  DockingManager#activateFrame(String)} to activate the dockable frame.
	 * 
	 *  @param active true if active
	 *  @throws PropertyVetoException if the property change is vetoed.
	 */
	public void setActive(boolean active) {
	}

	/**
	 *  Gets if the dockable frame is maximized.
	 * 
	 *  @return if the dockable frame is maximized.
	 */
	public boolean isMaximized() {
	}

	/**
	 *  Set the maximized property and activate the dockable frame.
	 * 
	 *  @param maximized true if maximized
	 *  @throws PropertyVetoException if the property change is vetoed.
	 */
	public void setMaximized(boolean maximized) {
	}

	/**
	 *  Set the last focused component toT focus. This method is used when the dockable frame state or visibility is
	 *  changed.
	 */
	public boolean requestFocusInInternalWindow() {
	}

	/**
	 *  Gets the default focus component for the dockable frame. When the dockable frame is activated for the first time,
	 *  this component will get focus.
	 *  <p/>
	 *  See also <code>setDefaultFocusComponent</code>, <code>getLastFocusedComponent</code>,
	 *  <code>setLastFocusedComponent</code>
	 * 
	 *  @return the default component.
	 */
	public java.awt.Component getDefaultFocusComponent() {
	}

	/**
	 *  Sets the default focus component for the dockable frame. When the dockable frame is activated for the first time,
	 *  this component will get focus.
	 *  <p/>
	 *  See also <code>getDefaultFocusComponent</code>, <code>getLastFocusedComponent</code>,
	 *  <code>setLastFocusedComponent</code>
	 * 
	 *  @param defaultFocusComponent the default component that will receive focus.
	 */
	public void setDefaultFocusComponent(java.awt.Component defaultFocusComponent) {
	}

	/**
	 *  Gets the subcomponent of the dockable frame which holds focus. If the dockable frame is not activated this is the
	 *  component the would receive focus if it becomes activate.
	 *  <p/>
	 *  See also <code>setLastFocusedComponent</code>, <code>getDefaultFocusComponent</code>,
	 *  <code>setDefaultFocusComponent</code>
	 * 
	 *  @return the last-focused subcomponent
	 */
	public java.awt.Component getFocusedComponent() {
	}

	/**
	 *  Sets the subcomponent of the dockable frame which currently has focus. When the dockable frame is reactivated
	 *  after being deactivated, this component will get focus returned to it.
	 *  <p/>
	 *  See also <code>getLastFocusedComponent</code>, <code>getDefaultFocusComponent</code>,
	 *  <code>setDefaultFocusComponent</code>
	 * 
	 *  @param lastFocusedComponent last-focused subcomponent
	 */
	protected void setLastFocusedComponent(java.awt.Component lastFocusedComponent) {
	}

	/**
	 *  Get the docking manager.
	 * 
	 *  @return the Docking Manager that manages this Dockable.
	 */
	public DockingManager getDockingManager() {
	}

	/**
	 *  Makes the component visible or invisible. Overrides <code>Component.setVisible</code>.
	 * 
	 *  @param aFlag true to make the component visible; false to make it invisible
	 */
	@java.lang.Override
	public void setVisible(boolean aFlag) {
	}

	/**
	 *  Set the docking manager for dockable frame.
	 * 
	 *  @param dockingManager the docking manager where this dockable frame is added to..
	 */
	public void setDockingManager(DockingManager dockingManager) {
	}

	/**
	 *  Set the width of docked state.
	 * 
	 *  @param dockedWidth width
	 */
	public void setDockedWidth(int dockedWidth) {
	}

	/**
	 *  Set the height when the component is docked inside a JFrame
	 * 
	 *  @param dockedHeight new height
	 */
	public void setDockedHeight(int dockedHeight) {
	}

	/**
	 *  Get the width when the component is docked inside a JFrame
	 * 
	 *  @return width
	 */
	public int getDockedWidth() {
	}

	/**
	 *  Get the height when the component is docked inside a JFrame
	 * 
	 *  @return height
	 */
	public int getDockedHeight() {
	}

	/**
	 *  Set the width when the component is auto-hide
	 * 
	 *  @param w new width
	 */
	public void setAutohideWidth(int w) {
	}

	/**
	 *  Set the height when the component is auto-hide
	 * 
	 *  @param autohideHeight new height
	 */
	public void setAutohideHeight(int autohideHeight) {
	}

	/**
	 *  Get the width of the component when it's in auto-hide mode
	 * 
	 *  @return width
	 */
	public int getAutohideWidth() {
	}

	/**
	 *  Get the height of the component when it's in auto-hide mode
	 * 
	 *  @return height
	 */
	public int getAutohideHeight() {
	}

	/**
	 *  Get the un-restricted bounds. Unrestricted means when the dockable component is in floating mode
	 * 
	 *  @return undocked bounds
	 */
	public java.awt.Rectangle getUndockedBounds() {
	}

	/**
	 *  Set the un-restricted bounds. Unrestricted means when the dockable component is in floating mode.
	 *  <p/>
	 *  This is one special case when x and y of the bounds are both -1. If so, we will use the width and height of the
	 *  bounds but will use the x and y at 20x20 below the location of the dockable frame's parent.
	 * 
	 *  @param undockedBounds new bounds
	 */
	public void setUndockedBounds(java.awt.Rectangle undockedBounds) {
	}

	/**
	 *  Get dock id.
	 * 
	 *  @return the an int id that unique identify the component.
	 */
	public int getDockID() {
	}

	public void setDockID(int id) {
	}

	public void resetDockID() {
	}

	/**
	 *  Checks if the frame is available.
	 * 
	 *  @return true if it's available.
	 */
	public boolean isAvailable() {
	}

	/**
	 *  Sets true to make the frame available.
	 * 
	 *  @param available true if to make the frame available. False to make it not available.
	 */
	public void setAvailable(boolean available) {
	}

	/**
	 *  Sets a component which is part of the dockable frame's title bar.
	 * 
	 *  @param component title bar component
	 */
	public void setTitleBarComponent(javax.swing.JComponent component) {
	}

	/**
	 *  Gets the component which is part of dockable frame's title bar.
	 * 
	 *  @return the title bar component.
	 */
	public javax.swing.JComponent getTitleBarComponent() {
	}

	/**
	 *  Sets a component which will be used to replace the default title. The default title label is used to display the
	 *  title and the icon. So if you use your own component, you have to set the title as the text on your component.
	 *  You can pass in null so that the default title label will be used.
	 * 
	 *  @param component title label component
	 */
	public void setTitleLabelComponent(javax.swing.JComponent component) {
	}

	/**
	 *  Gets the component which is used to replace the default title. Null if you never set it before.
	 * 
	 *  @return the title label component.
	 */
	public javax.swing.JComponent getTitleLabelComponent() {
	}

	/**
	 *  Gets the <code>AccessibleContext</code> associated with this <code>DockableFrame</code>. For dockable frames, the
	 *  <code>AccessibleContext</code> takes the form of an <code>AccessibleDockableFrame</code> object. A new
	 *  <code>AccessibleDockableFrame</code> instance is created if necessary.
	 * 
	 *  @return an <code>AccessibleDockableFrame</code> that serves as the <code>AccessibleContext</code> of this
	 *          <code>DockableFrame</code>
	 * 
	 *  @see AccessibleDockableFrame
	 */
	@java.lang.Override
	public javax.accessibility.AccessibleContext getAccessibleContext() {
	}

	/**
	 *  Checks if the gripper is visible.
	 * 
	 *  @return true if gripper is visible
	 */
	public boolean isShowGripper() {
	}

	/**
	 *  Sets the visibility of gripper.
	 *  <p/>
	 *  When dockable frame is added to DockingManager, this attribute will be reset to whatever value in docking manager
	 *  (dockingManager.isShowGripper()). If you want to all dockable frames to have or don't have the gripper, please
	 *  use dockingManager.setShowGripper(). If you just want to a particular dockable frame different from other frames,
	 *  you should call this method after it has been added docking manager.     *
	 * 
	 *  @param showGripper true to show gripper
	 */
	public void setShowGripper(boolean showGripper) {
	}

	/**
	 *  Checks if the title bar is visible.
	 * 
	 *  @return true if the title bar is visible.
	 */
	public boolean isShowTitleBar() {
	}

	/**
	 *  Sets the visibility of the title bar.
	 *  <p/>
	 *  When dockable frame is added to DockingManager, this attribute will be reset to whatever value in docking manager
	 *  (dockingManager.isShowTitleBar()). If you want to all dockable frames to have or don't have the title bar, please
	 *  use dockingManager.setShowTitleBar(). If you just want to a particular dockable frame different from other
	 *  frames, you should call this method after it has been added docking manager.
	 * 
	 *  @param showTitleBar true to show title bar.
	 */
	public void setShowTitleBar(boolean showTitleBar) {
	}

	/**
	 *  Checks if the content pane is visible.
	 * 
	 *  @return true if the content pane is visible.
	 */
	public boolean isShowContentPane() {
	}

	/**
	 *  Sets the visibility of the content pane.
	 * 
	 *  @param showContentPane true to show the content pane .
	 */
	public void setShowContentPane(boolean showContentPane) {
	}

	public boolean isMaximizable() {
	}

	public void setMaximizable(boolean maximizable) {
	}

	/**
	 *  Checks if the dockable frame is in notified mode. Notified mode can be used to tell users that there is something
	 *  important in the frame.
	 * 
	 *  @return true if the dockable frame is in notified mode.
	 */
	public boolean isNotified() {
	}

	/**
	 *  Sets the notified mode. Notified mode can be used to tell users that there is something important in the frame.
	 *  If the frame is active, nothing will happen. If the frame is docked in tabbed pane, the title of its tab will
	 *  flash for 10s then stay in red after 10s.
	 * 
	 *  @param notified true to notify the frame. False to stop notify frame.
	 */
	public void setNotified(boolean notified) {
	}

	/**
	 *  Checks if the frame should be notified. The frameContainer is the one that has this dockable frame. By default,
	 *  we only return true if the frame is not selected.
	 * 
	 *  @param frameContainer the FrameContainer
	 *  @return true to notify. Otherwise false.
	 */
	protected boolean shouldNotify(FrameContainer frameContainer) {
	}

	protected NotificationFlasher createNotificationFlasher(AutoHideContainer autoHideContainer) {
	}

	protected NotificationFlasher createNotificationFlasher(FrameContainer fc) {
	}

	/**
	 *  Checks if the frame can be shown while loading layout files. The default implementation is to just return false
	 *  to show every possible DockableFrame. You could override this method to let different users have different
	 *  DockableFrame show up with the same layout file.
	 * 
	 *  @return false by default. Subclass can override it to conditionally return true or false.
	 */
	public boolean shouldVetoShowing() {
	}

	/**
	 *  Checks if the frame can be hidden. This method gives dockable frame a chance to veto hideFrame() method call from
	 *  DockingManager. Subclass can override this method to conditionally return true so that the frame won't be hidden
	 *  in certain condition. <p>This method will only be called when user pressed the hide button on the title bar of
	 *  dockable frame. Calling hideFrame method directly will not trigger this method.
	 * 
	 *  @return false by default. Subclass can override it to conditionally return true or false.
	 */
	public boolean shouldVetoHiding() {
	}

	/**
	 *  Checks if the frame can be removed. This method gives dockable frame a chance to veto removeFrame() method call
	 *  from DockingManager. Subclass can override this method to conditionally return true so that the frame won't be
	 *  removed in certain condition. <p>Calling removeFrame method directly will not trigger this method.
	 * 
	 *  @return false by default. Subclass can override it to conditionally return true or false.
	 */
	public boolean shouldVetoRemoving() {
	}

	/**
	 *  This is a flag to determine the displaying behavior of a dockable frame when it is in autohidden mode. If this
	 *  flag is true, autohide window will slide out on top of other contents in the main container. If false, autohide
	 *  window will push the contents in the main container aside so no contents will be covered.
	 * 
	 *  @return true or false.
	 */
	public boolean isSlidingAutohide() {
	}

	/**
	 *  Sets the displaying behavior of a dockable frame when it is in autohidden mode.
	 *  <p/>
	 *  Please set the flag during initialization of the dockable frame. We don't support changing this flag on fly.
	 * 
	 *  @param slidingAutohide true or false.
	 *  @see #isSlidingAutohide()
	 */
	public void setSlidingAutohide(boolean slidingAutohide) {
	}

	/**
	 *  Clean up references so we can gc this frame and the docking manager.
	 */
	public void dispose() {
	}

	/**
	 *  Checks if the dockable frame is transient.
	 * 
	 *  @return true if dockable frame is transient. Otherwise false. It is false by default.
	 * 
	 *  @see #setTransient(boolean)
	 */
	public boolean isTransient() {
	}

	/**
	 *  Sets if the dockable frame is transient. If a dockable frame is transient, saving layout will not save any
	 *  information about this dockable frame. If you want to create a dockable frame on fly and temporarily use it, you
	 *  should set transient property to true.
	 * 
	 *  @param isTransient true or false.
	 */
	public void setTransient(boolean isTransient) {
	}

	/**
	 *  Gets initial state.
	 * 
	 *  @return initial state
	 */
	public int getInitMode() {
	}

	/**
	 *  Sets the initial state. The available states are defined in {@link com.jidesoft.docking.DockContext}. They are
	 *  <code>STATE_HIDDEN</code>, <code>STATE_FLOATING</code>, <code>STATE_AUTOHIDE</code> and
	 *  <code>STATE_FRAMEDOCKED</code>. It also supports a few negative value such as <code>STATE_HIDDEN -
	 *  STATE_FLOATING</code>, <code>STATE_HIDDEN - STATE_AUTOHIDE</code> and <code>STATE_HIDDEN -
	 *  STATE_FRAMEDOCKED</code>. In those negative cases, the frame will initially be hidden. But when showFrame is
	 *  called on this frame, it will use the corresponding mode to show the frame. For example, if initMode is set to
	 *  <code>STATE_HIDDEN - STATE_FLOATING</code>, the frame will initially be hidden. When showFrame is called, the
	 *  frame will be floated.
	 * 
	 *  @param initMode initial state
	 */
	public void setInitMode(int initMode) {
	}

	/**
	 *  Gets the initial side.
	 * 
	 *  @return the initial side.
	 */
	public int getInitSide() {
	}

	/**
	 *  Sets the initial side. The valid values are <code>DOCK_SIDE_EAST</code>, <code>DOCK_SIDE_WEST</code>,
	 *  <code>DOCK_SIDE_SOUTH</code>, <code>DOCK_SIDE_NORTH</code>, and <code>DOCK_SIDE_CENTER</code>, all defined in
	 *  <code>DockContext</code>. If you ever use <code>DOCK_SIDE_CENTER</code>, dockable frame will appear in workspace
	 *  area thus you need to cal {@link Workspace#setAcceptDockableFrame(boolean)} and set it to true. If so, you
	 *  shouldn't add any other arbitrary components to workspace area.
	 * 
	 *  @param initSide new initial side.
	 */
	public void setInitSide(int initSide) {
	}

	/**
	 *  Gets the init index.
	 * 
	 *  @return init index.
	 */
	public int getInitIndex() {
	}

	/**
	 *  Sets initial index. After setting initial side and mode, user can use this parameter to define initial position.
	 *  <br> If all frames' initMode are FRAMEDOCKED and initSide are SOUTH, the all frames with the same index will form
	 *  a tabbed pane. Frames with index 0 will appear before frames with index 1. In this case, only 0 and 1 is allowed.
	 *  <br> If initMode is AUTOHIDE, the same indexed frames will form a group. In this case, any index greater than 0
	 *  is allowed. <br> If initMode is FLOATING, the same indexed frames will form a tabbed pane and in one floating
	 *  window. In this case, any index greater than 0 is allowed.
	 * 
	 *  @param initIndex the initial index
	 */
	public void setInitIndex(int initIndex) {
	}

	protected java.beans.PropertyChangeListener createFocusChangeListener() {
	}

	/**
	 *  We've been added to the swing hierarchy, so start updating _lastFocusedComponent.
	 */
	@java.lang.Override
	public void addNotify() {
	}

	/**
	 *  We've been removed from the swing hierarchy, so stop updating _lastFocusedComponent. This is needed because
	 *  during the removal process, if we own focus, our nextFocusHelper() method transfers focus to other subcomponents.
	 *  This makes _lastFocusedComponent incorrect.
	 */
	@java.lang.Override
	public void removeNotify() {
	}

	/**
	 *  Gets preferred autohide side. By default the value is -1, meaning it will use current dock side as autohide
	 *  side.
	 * 
	 *  @return the preferred autohide side.
	 */
	public int getPreferredAutohideSide() {
	}

	/**
	 *  Sets preferred autohide side. A dockable frame can be autohidden into four sides. By default the value is -1,
	 *  meaning it will use current dock side as autohide side. By setting this value, you can determine which side a
	 *  dockable frame will be autohidden to. If you set all dockable frames' preferred autohide side to one side, you
	 *  indirectly disable side panes on other three sides.
	 * 
	 *  @param preferredAutohideSide preferred autohide side.
	 */
	public void setPreferredAutohideSide(int preferredAutohideSide) {
	}

	/**
	 *  Checks if tab dock is allowed. If a dockable frame doesn't allow tab dock, you cannot drag another dockable frame
	 *  and dock with this dockable frame together as a tabbed pane.
	 * 
	 *  @return true or false.
	 */
	public boolean isTabDockAllowed() {
	}

	/**
	 *  Sets tab dock allowed flag.
	 * 
	 *  @param tabDockAllowed true or false.
	 */
	public void setTabDockAllowed(boolean tabDockAllowed) {
	}

	/**
	 *  Checks if side dock is allowed. If a dockable frame doesn't allow side dock, you cannot drag another dockable
	 *  frame and dock to the side of this dockable frame to form a split pane.
	 * 
	 *  @return true or false.
	 */
	public boolean isSideDockAllowed() {
	}

	/**
	 *  Sets the side dock allowed flag.
	 * 
	 *  @param sideDockAllowed true or false.
	 */
	public void setSideDockAllowed(boolean sideDockAllowed) {
	}

	@java.lang.Override
	protected String paramString() {
	}

	/**
	 *  Gets the action for the close button. You can set it using {@link #setCloseAction(javax.swing.Action)}. If you
	 *  never set it, we will create {@link com.jidesoft.docking.DockableFrame.CloseAction} and use it.
	 * 
	 *  @return the action for the close button.
	 */
	public javax.swing.Action getCloseAction() {
	}

	/**
	 *  Sets the action for the close button. This action will be added as ActionListener to the close button as well as
	 *  set as the action for the close menu item. If you want to hide/show the button or enable/disable the menu item,
	 *  you can override isEnabled() method in Action to do it. <p>Property change event on {@link
	 *  #PROPERTY_CLOSE_ACTION} will be fired.
	 * 
	 *  @param closeAction the close action.
	 */
	public void setCloseAction(javax.swing.Action closeAction) {
	}

	public javax.swing.Action getHideAutohideAction() {
	}

	/**
	 *  Sets the action for the hide autohide button. This action will be added as ActionListener to the hide autohide
	 *  button as well as set as the action for the hide autohide menu item. If you want to hide/show the button or
	 *  enable/disable the menu item, you can override isEnabled() method in Action to do it. <p>Property change event on
	 *  {@link #PROPERTY_HIDE_AUTOHIDE_ACTION} will be fired.
	 * 
	 *  @param hideAutohideAction the hide autohide action.
	 */
	public void setHideAutohideAction(javax.swing.Action hideAutohideAction) {
	}

	/**
	 *  Gets the action for the floating button. You can set it using {@link #setFloatingAction(javax.swing.Action)}. If
	 *  you never set it, we will create {@link com.jidesoft.docking.DockableFrame.FloatingAction} and use it.
	 * 
	 *  @return the action for the floating button.
	 */
	public javax.swing.Action getFloatingAction() {
	}

	/**
	 *  Gets the action for the floating button. You can set it using {@link #setFloatingAction(javax.swing.Action)}. If
	 *  you never set it, we will create {@link com.jidesoft.docking.DockableFrame.FloatingAction} and use it.
	 * 
	 *  @param single if the menu item is triggered by a right mouse click on the tab, this flag will be true.
	 *  @return the action for the floating button.
	 */
	public javax.swing.Action getFloatingAction(boolean single) {
	}

	/**
	 *  Sets the action for the floating button. This action will be added as ActionListener to the floating button as
	 *  well as set as the action for the floating menu item. If you want to hide/show the button or enable/disable the
	 *  menu item, you can override isEnabled() method in Action to do it. <p>Property change event on {@link
	 *  #PROPERTY_FLOATING_ACTION} will be fired.
	 * 
	 *  @param floatingAction the floating action.
	 */
	public void setFloatingAction(javax.swing.Action floatingAction) {
	}

	/**
	 *  Gets the action for the autohide button. You can set it using {@link #setAutohideAction(javax.swing.Action)}. If
	 *  you never set it, we will create {@link com.jidesoft.docking.DockableFrame.AutohideAction} and use it.
	 * 
	 *  @return the action for the autohide button.
	 */
	public javax.swing.Action getAutohideAction() {
	}

	/**
	 *  Sets the action for the autohide button. This action will be added as ActionListener to the autohide button as
	 *  well as set as the action for the autohide menu item. If you want to hide/show the button or enable/disable the
	 *  menu item, you can override isEnabled() method in Action to do it. <p>Property change event on {@link
	 *  #PROPERTY_AUTOHIDE_ACTION} will be fired.
	 * 
	 *  @param autohideAction the autohide action.
	 */
	public void setAutohideAction(javax.swing.Action autohideAction) {
	}

	/**
	 *  Gets the action for the maximize button. You can set it using {@link #setMaximizeAction(javax.swing.Action)}. If
	 *  you never set it, we will create {@link com.jidesoft.docking.DockableFrame.MaximizeAction} and use it.
	 * 
	 *  @return the action for the maximize button.
	 */
	public javax.swing.Action getMaximizeAction() {
	}

	/**
	 *  Sets the action for the maximize button. This action will be added as ActionListener to the maximize button as
	 *  well as set as the action for the maximize menu item. If you want to hide/show the button or enable/disable the
	 *  menu item, you can override isEnabled() method in Action to do it. <p>Property change event on {@link
	 *  #PROPERTY_MAXIMIZE_ACTION} will be fired.
	 * 
	 *  @param maximizeAction the maximize action.
	 */
	public void setMaximizeAction(javax.swing.Action maximizeAction) {
	}

	/**
	 *  Gets the action for the dockable button. You can set it using {@link #setDockableAction(javax.swing.Action)}. If
	 *  you never set it, we will create {@link com.jidesoft.docking.DockableFrame.DockableAction} and use it.
	 * 
	 *  @return the action for the dockable button.
	 */
	public javax.swing.Action getDockableAction() {
	}

	/**
	 *  Sets the action for the dockable button. This action will be added as ActionListener to the dockable button as
	 *  well as set as the action for the dockable menu item. If you want to enable/disable the menu item, you can
	 *  override isEnabled() method in Action to do it. <p>Property change event on {@link #PROPERTY_DOCKABLE_ACTION}
	 *  will be fired.
	 * 
	 *  @param dockableAction the dockable action.
	 */
	public void setDockableAction(javax.swing.Action dockableAction) {
	}

	/**
	 *  Gets the action for the double click button.
	 * 
	 *  @return the action for the doubleclick button.
	 */
	public javax.swing.Action getCustomDoubleClickAction() {
	}

	/**
	 *  Sets the action for the double click on the title pane. This action will be triggered when
	 *  dockingManager#setDoubleClickAction is set to DOUBLE_CLICK_CUSTOMIZED.
	 * 
	 *  @param customDoubleClickAction the double click action on the title pane.
	 */
	public void setCustomDoubleClickAction(javax.swing.Action customDoubleClickAction) {
	}

	@java.lang.Override
	public void setPreferredSize(java.awt.Dimension preferredSize) {
	}

	/**
	 *  Checks if the context menu should be shown.
	 * 
	 *  @return true if context menu will be shown. Otherwise false.
	 */
	public boolean isShowContextMenu() {
	}

	/**
	 *  Sets the flag to show context menu or not.
	 * 
	 *  @param showContextMenu true or false.
	 */
	public void setShowContextMenu(boolean showContextMenu) {
	}

	/**
	 *  Checks if the mouse event is a valid dragging event. Subclass can override it to return true or false. By
	 *  default, we will check the source of the event. If the event is from titlePane or from gripper, we will return
	 *  true. Here is the default code.
	 *  <code><pre>
	 *  if (getDockingManager() == null) {
	 *      return false;
	 *  }
	 *  Object source = e.getSource();
	 *  return ((!isShowGripper() || (_dockingManager != null && !_dockingManager.isDragGripperOnly()))
	 *  && source == getUI().getTitlePane()) || source instanceof Gripper;
	 *  </pre></code>
	 *  If you override and return true, you can drag any empty space in DockableFrame to drag.
	 * 
	 *  @param e the MouseEvent
	 *  @return true to allow dragging. Otherwise false.
	 */
	protected boolean isDraggingTarget(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Gets the default action when the escape key is pressed in the dockable frame. Possible values are {@link
	 *  #ESCAPE_ACTION_TO_YIELD_FOCUS}, {@link #ESCAPE_ACTION_DO_NOTING}, {@link #ESCAPE_ACTION_TO_HIDE}, and {@link
	 *  #ESCAPE_ACTION_TO_REMOVE}.
	 * 
	 *  @return the default action when the escape key is pressed.
	 */
	public int getDefaultEscapeAction() {
	}

	/**
	 *  Sets the default action when the escape key is pressed in the dockable frame.
	 * 
	 *  @param defaultEscapeAction the behavior when the escape key is pressed in the dockable frame. Valid values are
	 *                             {@link #ESCAPE_ACTION_TO_YIELD_FOCUS}, {@link #ESCAPE_ACTION_DO_NOTING}, {@link
	 *                             #ESCAPE_ACTION_TO_HIDE}, and {@link #ESCAPE_ACTION_TO_REMOVE}.
	 */
	public void setDefaultEscapeAction(int defaultEscapeAction) {
	}

	/**
	 *  Gets the default action when the close button is clicked on the dockable frame. Possible values are {@link
	 *  #CLOSE_ACTION_TO_HIDE}, and {@link #CLOSE_ACTION_TO_REMOVE}.
	 * 
	 *  @return the default action when the close button is pressed.
	 */
	public int getDefaultCloseAction() {
	}

	/**
	 *  Sets the default action when the close button is clicked on the dockable frame.
	 * 
	 *  @param defaultCloseAction the behavior when the close key is pressed in the dockable frame. Valid values are
	 *                            {@link #CLOSE_ACTION_TO_HIDE}, and {@link #CLOSE_ACTION_TO_REMOVE}.
	 */
	public void setDefaultCloseAction(int defaultCloseAction) {
	}

	/**
	 *  Checks if the dockable frame will autohide even when the frame is active. By default, an active autohide_showing
	 *  dockable frame will not hide unless you click somewhere outside the dockable frame. But there is a need from user
	 *  that if the dockable frame has some dragable item, they want the autohide_showing frame to be auto-hidden when
	 *  dragging outside the frame even when the frame is active. That's where you need to set this flag to be true.
	 * 
	 *  @return true or false.
	 */
	public boolean isAutohideWhenActive() {
	}

	/**
	 *  Set the autohideWhenActive flag. By default, an active autohide_showing dockable frame will not hide unless you
	 *  click somewhere outside the dockable frame. But there is a need from user that if the dockable frame has some
	 *  dragable item, they want the autohide_showing frame to be auto-hidden when dragging outside the frame even when
	 *  the frame is active. That's where you need to set this flag to be true.
	 * 
	 *  @param autohideWhenActive true or false.
	 */
	public void setAutohideWhenActive(boolean autohideWhenActive) {
	}

	/**
	 *  Gets the buttons order.
	 * 
	 *  @return the buttons order.
	 */
	public int[] getButtonsOrder() {
	}

	/**
	 *  Sets the buttons order. It is an int array of {@link #BUTTON_CLOSE}, {@link #BUTTON_AUTOHIDE}, {@link
	 *  #BUTTON_HIDE_AUTOHIDE}, {@link #BUTTON_FLOATING}, and {@link #BUTTON_MAXIMIZE}. The order is from right to left.
	 * 
	 *  @param buttonsOrder the buttons order.
	 */
	public void setButtonsOrder(int[] buttonsOrder) {
	}

	/**
	 *  @return false
	 * 
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public boolean isActivateAfterSliding() {
	}

	/**
	 *  Adds an addtional button to the title bar. The button is added in front of the default buttons.
	 * 
	 *  @param action the action for the button, the icon and tooltip are taken from here
	 *  @param icon the icon of the button
	 */
	public void addAdditionalButtonActions(javax.swing.Action action, javax.swing.Icon icon) {
	}

	/**
	 *  Removes an addtional button from the title bar.
	 * 
	 *  @param action the action for the button to be removed
	 */
	public void removeAdditionalButtonActions(javax.swing.Action action) {
	}

	/**
	 *  Get icon for the designated action.
	 * 
	 *  @param action the action
	 *  @return the corresponding icon.
	 */
	public javax.swing.Icon getActionIcon(javax.swing.Action action) {
	}

	/**
	 *  Returns the additional button actions.
	 * 
	 *  @return the additional button actions.
	 */
	public java.util.List getAdditionalButtonActions() {
	}

	public class CloseAction {


		public DockableFrame.CloseAction() {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}

		@java.lang.Override
		public boolean isEnabled() {
		}
	}

	public class AutohideAction {


		public DockableFrame.AutohideAction() {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}

		@java.lang.Override
		public boolean isEnabled() {
		}
	}

	public class FloatingAction {


		public DockableFrame.FloatingAction() {
		}

		public DockableFrame.FloatingAction(boolean single) {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}

		@java.lang.Override
		public boolean isEnabled() {
		}

		public boolean isSingle() {
		}

		public void setSingle(boolean single) {
		}
	}

	public class HideAutohideAction {


		public DockableFrame.HideAutohideAction() {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}

		@java.lang.Override
		public boolean isEnabled() {
		}
	}

	public class MaximizeAction {


		public DockableFrame.MaximizeAction() {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}

		@java.lang.Override
		public boolean isEnabled() {
		}
	}

	public class DockableAction {


		public DockableFrame.DockableAction() {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}

		@java.lang.Override
		public boolean isEnabled() {
		}
	}

	/**
	 *  This class implements accessibility support for the <code>DockableFrame</code> class.  It provides an
	 *  implementation of the Java Accessibility API appropriate to dockable frame user-interface elements.
	 */
	protected class AccessibleDockableFrame {


		protected DockableFrame.AccessibleDockableFrame() {
		}

		/**
		 *  Get the accessible name of this object.
		 * 
		 *  @return the localized name of the object -- can be <code>null</code> if this object does not have a name
		 * 
		 *  @see #setAccessibleName
		 */
		@java.lang.Override
		public String getAccessibleName() {
		}

		/**
		 *  Get the role of this object.
		 * 
		 *  @return an instance of AccessibleRole describing the role of the object
		 * 
		 *  @see javax.accessibility.AccessibleRole
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleRole getAccessibleRole() {
		}

		/**
		 *  Gets the AccessibleValue associated with this object.  In the implementation of the Java Accessibility API
		 *  for this class, returns this object, which is responsible for implementing the <code>AccessibleValue</code>
		 *  interface on behalf of itself.
		 * 
		 *  @return this object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleValue getAccessibleValue() {
		}

		/**
		 *  Get the value of this object as a Number.
		 * 
		 *  @return value of the object -- can be <code>null</code> if this object does not have a value
		 */
		public Number getCurrentAccessibleValue() {
		}

		/**
		 *  Set the value of this object as a Number.
		 * 
		 *  @return <code>true</code> if the value was set
		 */
		public boolean setCurrentAccessibleValue(Number n) {
		}

		/**
		 *  Get the minimum value of this object as a Number.
		 * 
		 *  @return Minimum value of the object; <code>null</code> if this object does not have a minimum value
		 */
		public Number getMinimumAccessibleValue() {
		}

		/**
		 *  Get the maximum value of this object as a Number.
		 * 
		 *  @return Maximum value of the object; <code>null</code> if this object does not have a maximum value
		 */
		public Number getMaximumAccessibleValue() {
		}
	}
}
