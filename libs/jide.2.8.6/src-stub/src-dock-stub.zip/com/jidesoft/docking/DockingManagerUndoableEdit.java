/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  An <code>UndoableEdit</code> for DockingManager.
 */
public class DockingManagerUndoableEdit implements javax.swing.undo.UndoableEdit {
 {

	public DockingManagerUndoableEdit(String name, DockingManager dockingManager) {
	}

	public void undo() {
	}

	public boolean canUndo() {
	}

	public void redo() {
	}

	public boolean canRedo() {
	}

	public void die() {
	}

	public boolean addEdit(javax.swing.undo.UndoableEdit anEdit) {
	}

	public boolean replaceEdit(javax.swing.undo.UndoableEdit anEdit) {
	}

	public boolean isSignificant() {
	}

	public String getPresentationName() {
	}

	public String getUndoPresentationName() {
	}

	public String getRedoPresentationName() {
	}

	public String getName() {
	}

	public void setName(String name) {
	}

	public byte[] getUndoLayout() {
	}

	public void setUndoLayout(byte[] undoLayout) {
	}

	public byte[] getRedoLayout() {
	}

	public void setRedoLayout(byte[] redoLayout) {
	}
}
