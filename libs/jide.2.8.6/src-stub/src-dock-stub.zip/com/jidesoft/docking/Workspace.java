/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Container for document windows.
 */
@java.lang.SuppressWarnings("serial")
public class Workspace extends javax.swing.JPanel implements DockableHolder, Refocusable {
 {

	/**
	 *  Default constructor.
	 */
	public Workspace() {
	}

	public Workspace(DockingManager dockingManager) {
	}

	/**
	 *  Checks the adjustOpacityOnFly flag.
	 * 
	 *  @return true or false.
	 */
	public boolean isAdjustOpacityOnFly() {
	}

	/**
	 *  Sets the adjustOpacityOnFly flag. If true, the workspace will be opaque when there is no child component and be
	 *  transparent when a child component is added.
	 * 
	 *  @param adjustOpacityOnFly true or false.
	 */
	public void setAdjustOpacityOnFly(boolean adjustOpacityOnFly) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Checks if this workspace can accept dockable frame.
	 * 
	 *  @return true if it can accept dockable. Otherwise, false.
	 */
	public boolean isAcceptDockableFrame() {
	}

	/**
	 *  Sets if workspace can accept drag-n-drop dockable frame. If you set this flag to true, you should also call
	 *  <code>dockingManager.setEasyTabDock(true)</code> so that the dockable frame can be docked inside an empty
	 *  workspace when there is no existing dockable frame.
	 * 
	 *  @param acceptDockableFrame true to accept dockable frame in workspace area.
	 */
	public void setAcceptDockableFrame(boolean acceptDockableFrame) {
	}

	public boolean requestFocusInInternalWindow() {
	}

	public boolean requestFocusInInternalWindowNew() {
	}

	/**
	 *  Gets the last subcomponent which held focus. When the container is reactivated after being deactivated, this
	 *  component will get focus returned to it.
	 *  <p/>
	 *  See also <code>setLastFocusedComponent</code>, <code>getDefaultFocusComponent</code>,
	 *  <code>setDefaultFocusComponent</code>
	 * 
	 *  @return the last-focused subcomponent
	 */
	public java.awt.Component getFocusedComponent() {
	}

	/**
	 *  Sets the subcomponent which currently has focus. When the container is reactivated after being deactivated, this
	 *  component will get focus returned to it.
	 *  <p/>
	 *  See also <code>getLastFocusedComponent</code>, <code>getDefaultFocusComponent</code>,
	 *  <code>setDefaultFocusComponent</code>
	 * 
	 *  @param lastFocusedComponent the last-focused subcomponent
	 */
	protected void setLastFocusedComponent(java.awt.Component lastFocusedComponent) {
	}

	/**
	 *  Gets the default focus component. When the container is activated for the first time, this component will get
	 *  focus.
	 *  <p/>
	 *  See also <code>setDefaultFocusComponent</code>, <code>getLastFocusedComponent</code>,
	 *  <code>setLastFocusedComponent</code>
	 * 
	 *  @return the default component.
	 */
	public java.awt.Component getDefaultFocusComponent() {
	}

	/**
	 *  Sets the default focus component. When the container is activated for the first time, this component will get
	 *  focus.
	 *  <p/>
	 *  See also <code>getDefaultFocusComponent</code>, <code>getLastFocusedComponent</code>,
	 *  <code>setLastFocusedComponent</code>
	 * 
	 *  @param defaultFocusComponent the default focus component.
	 */
	public void setDefaultFocusComponent(java.awt.Component defaultFocusComponent) {
	}

	@java.lang.Override
	protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	}

	/**
	 *  Sets the docking manager.
	 * 
	 *  @param dockingManager the docking manager
	 */
	public void setDockingManager(DockingManager dockingManager) {
	}

	public DockingManager getDockingManager() {
	}

	/**
	 *  Gets the layout constraint of the Workspace. This constraint will be used to add to the JideBoxLayout. Valid
	 *  constraints are FIX, FLEXIBLE and VARY. If the constraint is not valid, we will get it from the system property -
	 *  "jide.workspaceConstraints". If there is no such a system property, JideBoxLayout.VARY will be used.
	 * 
	 *  @return the constraint.
	 */
	public String getLayoutConstraint() {
	}

	/**
	 *  Sets the layout constraint of the Workspace.
	 * 
	 *  @param layoutConstraint the layout constraint.
	 *  @see #getLayoutConstraint()
	 */
	public void setLayoutConstraint(String layoutConstraint) {
	}
}
