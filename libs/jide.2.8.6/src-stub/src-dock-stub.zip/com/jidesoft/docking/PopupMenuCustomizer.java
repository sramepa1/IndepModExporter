/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Interface to customer a popup menu for dockable frame.
 */
public interface PopupMenuCustomizer {

	/**
	 *  Allow user to customize the popup menu. Popup menu will be shown when user
	 *  right click on the tab of TdiPane or user drag a tab and drop in the middle
	 *  of a tab group. In the first case, <code>onTab</code> is true. In the second case,
	 *  <code>onTab</code> is false.
	 * 
	 *  @param menu           Popup menu to be customized
	 *  @param dockingManager the DockingManager
	 *  @param dockableFrame  the DockableFrame for the popup menu
	 *  @param onTab          true if the popup menu is trigger by right click on tab, false if on the title bar
	 */
	public void customizePopupMenu(javax.swing.JPopupMenu menu, DockingManager dockingManager, DockableFrame dockableFrame, boolean onTab);
}
