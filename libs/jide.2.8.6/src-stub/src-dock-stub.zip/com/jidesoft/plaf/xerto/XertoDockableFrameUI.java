package com.jidesoft.plaf.xerto;


/**
 *  XertoDockableFrameUI - Modified version of DockableFrameUI & DockableFrameTitlePane that supports vertical title bars
 *  custom title background painting.
 * 
 *  @author Created by Jasper Potts (10-Jun-2004)
 *  @version 1.0
 */
public class XertoDockableFrameUI extends com.jidesoft.plaf.vsnet.VsnetDockableFrameUI {

	public XertoDockableFrameUI(com.jidesoft.docking.DockableFrame dockableFrame) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent jcomponent) {
	}

	@java.lang.Override
	protected javax.swing.JComponent createNorthPane(com.jidesoft.docking.DockableFrame dockableframe) {
	}

	@java.lang.Override
	protected javax.swing.JComponent createWestPane(com.jidesoft.docking.DockableFrame dockableframe) {
	}

	@java.lang.Override
	public javax.swing.JComponent getNorthPane() {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize(javax.swing.JComponent jcomponent) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent jcomponent) {
	}

	/**
	 *  NEW returns a button panel for vertical cases to be added to the EAST of component
	 * 
	 *  @return the buttons panel.
	 */
	public javax.swing.JPanel getButtonsPanel() {
	}

	public class XertoDockableFrameTitlePane {


		public XertoDockableFrameUI.XertoDockableFrameTitlePane(com.jidesoft.docking.DockableFrame i_dockableFrame) {
		}

		@java.lang.Override
		protected void installTitlePane() {
		}

		public void updateButtonsPanel() {
		}

		@java.lang.Override
		public java.awt.Dimension getMinimumSize() {
		}

		@java.lang.Override
		protected void paintTitleBackground(java.awt.Graphics g) {
		}

		@java.lang.Override
		protected java.awt.LayoutManager createLayout() {
		}

		@java.lang.Override
		public java.awt.Component add(java.awt.Component comp) {
		}

		@java.lang.Override
		protected void addSubComponents() {
		}

		@java.lang.Override
		protected void enableButton(javax.swing.AbstractButton button, boolean b) {
		}

		@java.lang.Override
		protected javax.swing.AbstractButton createTitleBarButton() {
		}

		public class XertoNoFocusButton {


			public XertoDockableFrameUI.XertoDockableFrameTitlePane.XertoNoFocusButton() {
			}

			public XertoDockableFrameUI.XertoDockableFrameTitlePane.XertoNoFocusButton(javax.swing.Action action) {
			}

			/**
			 *  Resets the UI property to a value from the current look and feel.
			 * 
			 *  @see javax.swing.JComponent#updateUI
			 */
			@java.lang.Override
			public void updateUI() {
			}

			@java.lang.Override
			protected void paintComponent(java.awt.Graphics g) {
			}

			@java.lang.Override
			public boolean isFocusable() {
			}

			@java.lang.Override
			public void requestFocus() {
			}

			@java.lang.Override
			public void mouseDragged(java.awt.event.MouseEvent e) {
			}

			@java.lang.Override
			public void mouseMoved(java.awt.event.MouseEvent e) {
			}

			@java.lang.Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}

			@java.lang.Override
			public void mousePressed(java.awt.event.MouseEvent e) {
			}

			@java.lang.Override
			public void mouseReleased(java.awt.event.MouseEvent e) {
			}

			@java.lang.Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
			}

			@java.lang.Override
			public void mouseExited(java.awt.event.MouseEvent e) {
			}

			@java.lang.Override
			public int getType() {
			}

			@java.lang.Override
			public void setType(int type) {
			}
		}
	}
}
