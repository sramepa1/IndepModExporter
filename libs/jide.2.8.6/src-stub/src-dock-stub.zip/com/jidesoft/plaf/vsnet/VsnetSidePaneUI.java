package com.jidesoft.plaf.vsnet;


/**
 *  JideSidePane UI implementation
 */
public class VsnetSidePaneUI extends com.jidesoft.plaf.basic.BasicSidePaneUI {

	public VsnetSidePaneUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}
}
