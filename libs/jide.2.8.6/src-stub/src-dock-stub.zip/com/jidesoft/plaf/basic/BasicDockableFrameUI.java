package com.jidesoft.plaf.basic;


/**
 *  A basic L&F implementation of DockableFrame.
 */
public class BasicDockableFrameUI extends com.jidesoft.plaf.DockableFrameUI {

	protected com.jidesoft.docking.DockableFrame _frame;

	protected java.beans.PropertyChangeListener _propertyChangeListener;

	protected java.awt.LayoutManager _dockableFrameLayout;

	protected javax.swing.JComponent _northPane;

	protected javax.swing.JComponent _southPane;

	protected javax.swing.JComponent _westPane;

	protected javax.swing.JComponent _eastPane;

	protected BasicDockableFrameTitlePane _titlePane;

	public BasicDockableFrameUI() {
	}

	public BasicDockableFrameUI(com.jidesoft.docking.DockableFrame f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults() {
	}

	protected void installKeyboardActions() {
	}

	protected void installComponents() {
	}

	protected void installListeners() {
	}

	protected void uninstallDefaults() {
	}

	protected void uninstallComponents() {
	}

	protected void uninstallListeners() {
	}

	protected void uninstallKeyboardActions() {
	}

	@java.lang.Override
	public java.awt.Component getTitlePane() {
	}

	protected java.awt.LayoutManager createLayoutManager() {
	}

	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent x) {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize(javax.swing.JComponent x) {
	}

	@java.lang.Override
	public java.awt.Dimension getMaximumSize(javax.swing.JComponent x) {
	}

	/**
	 *  Installs necessary mouse handlers on <code>newPane</code> and adds it to the frame. Reverse process for the
	 *  <code>currentPane</code>.
	 */
	protected void replacePane(javax.swing.JComponent currentPane, javax.swing.JComponent newPane) {
	}

	protected void deinstallMouseHandlers(javax.swing.JComponent c) {
	}

	protected void installMouseHandlers(javax.swing.JComponent c) {
	}

	protected javax.swing.JComponent createNorthPane(com.jidesoft.docking.DockableFrame w) {
	}

	protected javax.swing.JComponent createSouthPane(com.jidesoft.docking.DockableFrame w) {
	}

	protected javax.swing.JComponent createWestPane(com.jidesoft.docking.DockableFrame w) {
	}

	protected javax.swing.JComponent createEastPane(com.jidesoft.docking.DockableFrame w) {
	}

	protected final boolean isKeyBindingRegistered() {
	}

	protected final void setKeyBindingRegistered(boolean b) {
	}

	public final boolean isKeyBindingActive() {
	}

	protected final void setKeyBindingActive(boolean b) {
	}

	protected void setupMenuOpenKey() {
	}

	protected void setupMenuCloseKey() {
	}

	public javax.swing.JComponent getNorthPane() {
	}

	protected void setNorthPane(javax.swing.JComponent c) {
	}

	public javax.swing.JComponent getSouthPane() {
	}

	protected void setSouthPane(javax.swing.JComponent c) {
	}

	public javax.swing.JComponent getWestPane() {
	}

	protected void setWestPane(javax.swing.JComponent c) {
	}

	public javax.swing.JComponent getEastPane() {
	}

	protected void setEastPane(javax.swing.JComponent c) {
	}

	public ThemePainter getPainter() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	public class DockableFramePropertyChangeListener {


		public BasicDockableFrameUI.DockableFramePropertyChangeListener() {
		}

		/**
		 *  Detects changes in state from the DockableFrame and handles actions.
		 */
		public void propertyChange(java.beans.PropertyChangeEvent evt) {
		}
	}

	public class DockableFrameLayout {


		public BasicDockableFrameUI.DockableFrameLayout() {
		}

		public void addLayoutComponent(String name, java.awt.Component c) {
		}

		public void removeLayoutComponent(java.awt.Component c) {
		}

		public java.awt.Dimension preferredLayoutSize(java.awt.Container c) {
		}

		public java.awt.Dimension minimumLayoutSize(java.awt.Container c) {
		}

		public void layoutContainer(java.awt.Container c) {
		}
	}
}
