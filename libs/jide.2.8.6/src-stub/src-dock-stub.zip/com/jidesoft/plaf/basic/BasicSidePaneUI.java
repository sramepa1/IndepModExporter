package com.jidesoft.plaf.basic;


/**
 *  A basic L&f implementation of SidePaneUI
 */
public class BasicSidePaneUI extends SidePaneUI {

	protected SidePane _sidePane;

	protected int _size;

	protected java.awt.Insets _margin;

	protected int _iconTextGap;

	protected int _textBorderGap;

	protected int _itemGap;

	protected int _groupGap;

	protected java.awt.Color _lineColor;

	protected java.awt.Color _background;

	protected java.awt.Color _buttonBackground;

	protected java.awt.Color _selectedButtonBackground;

	protected java.awt.Color _selectedButtonForeground;

	protected java.awt.Font _font;

	protected boolean _showText;

	protected boolean _alwaysShowText;

	protected boolean _highlightSelectedTab;

	/**
	 *  Rectangles that hold location of each icon/text
	 */
	protected java.awt.Rectangle[] _rects;

	public java.awt.dnd.DropTarget _dt;

	protected int _displayOrientation;

	public BasicSidePaneUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	/**
	 *  Invoked by <code>installUI</code> to create a layout manager object to manage the <code>JideSidePane</code>.
	 * 
	 *  @return a layout manager object
	 */
	protected java.awt.LayoutManager createLayoutManager() {
	}

	/**
	 *  Creates and installs any required subcomponents for the SidePane. Invoked by installUI.
	 * 
	 *  @since 1.4
	 */
	protected void installComponents() {
	}

	/**
	 *  Removes any installed subcomponents from the JTabbedPane. Invoked by uninstallUI.
	 * 
	 *  @since 1.4
	 */
	protected void uninstallComponents() {
	}

	protected void installDefaults() {
	}

	protected void uninstallDefaults() {
	}

	protected void installListeners() {
	}

	protected javax.swing.event.MouseInputListener createMouseInputListener() {
	}

	protected BasicSidePaneUI.DropListener createDropListener() {
	}

	protected void uninstallListeners() {
	}

	protected void installKeyboardActions() {
	}

	protected void uninstallKeyboardActions() {
	}

	public int getSelectedItemIndex(java.awt.Point p) {
	}

	public SidePaneGroup getGroupForIndex(int index) {
	}

	public SidePaneItem getItemForIndex(int index) {
	}

	protected java.awt.FontMetrics getFontMetrics() {
	}

	protected void initButtonRects() {
	}

	/**
	 *  Paints the specified component appropriate for the look and feel. This method is invoked from the
	 *  <code>ComponentUI.update</code> method when the specified component is being painted. Subclasses should override
	 *  this method and use the specified <code>Graphics</code> object to render the content of the component.
	 * 
	 *  @param g the <code>Graphics</code> context in which to paint
	 *  @param c the component being painted; this argument is often ignored, but might be used if the UI object is
	 *           stateless and shared by multiple components
	 *  @see #update
	 */
	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected void paintItemBackground(SidePaneItem item, java.awt.Graphics g, java.awt.Rectangle rect, int side) {
	}

	protected java.awt.Color[] getGradientColors(SidePaneItem item) {
	}

	protected boolean isItemHighlighted(SidePaneItem item) {
	}

	protected void drawWestPane(java.awt.Graphics g, javax.swing.JComponent c, java.awt.FontMetrics metrics) {
	}

	protected void drawEastPane(java.awt.Graphics g, javax.swing.JComponent c, java.awt.FontMetrics metrics) {
	}

	protected void drawNorthPane(java.awt.Graphics g, javax.swing.JComponent c, java.awt.FontMetrics metrics) {
	}

	protected void drawSouthPane(java.awt.Graphics g, javax.swing.JComponent c, java.awt.FontMetrics metrics) {
	}

	protected void paintBackground(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	/**
	 *  Returns the specified component's preferred size appropriate for the look and feel.  If <code>null</code> is
	 *  returned, the preferred size will be calculated by the component's layout manager instead (this is the preferred
	 *  approach for any component with a specific layout manager installed).  The default implementation of this method
	 *  returns <code>null</code>.
	 * 
	 *  @param c the component whose preferred size is being queried; this argument is often ignored, but might be used
	 *           if the UI object is stateless and shared by multiple components
	 *  @see JComponent#getPreferredSize
	 *  @see LayoutManager#preferredLayoutSize
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	protected int getPreferredWidthHorizontal() {
	}

	protected int getPreferredHeightVertical() {
	}

	public ThemePainter getPainter() {
	}

	protected boolean isRoundedCorner() {
	}
}
