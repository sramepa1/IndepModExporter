package com.jidesoft.plaf.eclipse;


/**
 *  DockableFrame UI implementation
 */
public class EclipseDockableFrameUI extends com.jidesoft.plaf.basic.BasicDockableFrameUI {

	public EclipseDockableFrameUI() {
	}

	public EclipseDockableFrameUI(com.jidesoft.docking.DockableFrame f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}

	@java.lang.Override
	protected javax.swing.JComponent createNorthPane(com.jidesoft.docking.DockableFrame w) {
	}
}
