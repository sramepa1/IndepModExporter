package com.jidesoft.plaf.aqua;


/**
 *  DockableFrame UI implementation
 */
public class AquaDockableFrameUI extends com.jidesoft.plaf.basic.BasicDockableFrameUI {

	public AquaDockableFrameUI() {
	}

	public AquaDockableFrameUI(com.jidesoft.docking.DockableFrame f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}

	@java.lang.Override
	protected javax.swing.JComponent createNorthPane(com.jidesoft.docking.DockableFrame w) {
	}
}
