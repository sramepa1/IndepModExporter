package com.jidesoft.plaf.office2003;

/**
 */
public class Office2003Utils {
}
