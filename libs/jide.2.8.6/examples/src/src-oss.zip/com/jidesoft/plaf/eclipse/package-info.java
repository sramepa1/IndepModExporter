/**
 * The package contains ComponentUI implementation for Eclipse and Eclipse3x style.
 */
package com.jidesoft.plaf.eclipse;