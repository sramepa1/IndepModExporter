package com.jidesoft.plaf.basic;


/**
 *  A Basic L&F implementation of CommandBarChevronUI.
 */
public class BasicChevronUI extends VsnetMenuUI {

	public static final int MARGIN = 3;

	protected java.awt.Color shadow;

	protected java.awt.Color highlight;

	protected int _size;

	protected boolean _alwaysVisible;

	public BasicChevronUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults(com.jidesoft.action.Chevron s) {
	}

	protected void uninstallDefaults(com.jidesoft.action.Chevron s) {
	}

	protected void installListeners(com.jidesoft.action.Chevron chevron) {
	}

	protected void uninstallListeners(com.jidesoft.action.Chevron chevron) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected void paintBackground(java.awt.Graphics g, com.jidesoft.action.Chevron chevron) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getMaximumSize(javax.swing.JComponent c) {
	}

	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}
}
