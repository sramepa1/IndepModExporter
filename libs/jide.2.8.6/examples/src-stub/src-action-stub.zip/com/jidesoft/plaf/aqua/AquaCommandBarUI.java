package com.jidesoft.plaf.aqua;


public class AquaCommandBarUI extends com.jidesoft.plaf.basic.BasicCommandBarUI {

	protected javax.swing.JMenuBar _menuBar;

	public AquaCommandBarUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	protected void installComponents() {
	}

	public void installUI(javax.swing.JComponent c) {
	}

	public void uninstallUI(javax.swing.JComponent c) {
	}
}
