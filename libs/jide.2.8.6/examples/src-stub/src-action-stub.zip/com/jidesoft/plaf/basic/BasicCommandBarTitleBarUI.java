package com.jidesoft.plaf.basic;


public class BasicCommandBarTitleBarUI extends com.jidesoft.plaf.CommandBarTitleBarUI {

	protected javax.swing.JLabel _title;

	protected java.beans.PropertyChangeListener propertyListener;

	public BasicCommandBarTitleBarUI(com.jidesoft.action.CommandBarTitleBar titleBar) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	public void installUI(javax.swing.JComponent c) {
	}

	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installComponents() {
	}

	protected void uninstallComponents() {
	}

	protected void installDefaults() {
	}

	protected void uninstallDefaults() {
	}

	protected void installListeners() {
	}

	protected void uninstallListeners() {
	}

	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected java.awt.LayoutManager createLayout() {
	}

	public ThemePainter getPainter() {
	}

	protected java.beans.PropertyChangeListener createPropertyListener() {
	}

	public class TitlePaneLayout {


		public BasicCommandBarTitleBarUI.TitlePaneLayout() {
		}

		public void addLayoutComponent(String name, java.awt.Component c) {
		}

		public void removeLayoutComponent(java.awt.Component c) {
		}

		public java.awt.Dimension preferredLayoutSize(java.awt.Container c) {
		}

		public java.awt.Dimension minimumLayoutSize(java.awt.Container c) {
		}

		public void layoutContainer(java.awt.Container c) {
		}
	}

	protected class PropertyListener {


		protected BasicCommandBarTitleBarUI.PropertyListener() {
		}

		public void propertyChange(java.beans.PropertyChangeEvent e) {
		}
	}
}
