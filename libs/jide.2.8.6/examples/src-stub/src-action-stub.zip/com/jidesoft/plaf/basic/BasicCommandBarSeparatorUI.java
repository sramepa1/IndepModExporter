package com.jidesoft.plaf.basic;


/**
 *  A Basic L&F implementation of CommandBarSeparatorUI.
 */
public class BasicCommandBarSeparatorUI extends com.jidesoft.plaf.CommandBarSeparatorUI {

	protected java.awt.Color shadow;

	protected java.awt.Color highlight;

	public BasicCommandBarSeparatorUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	public void installUI(javax.swing.JComponent c) {
	}

	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults(com.jidesoft.action.CommandBarSeparator s) {
	}

	protected void uninstallDefaults(com.jidesoft.action.CommandBarSeparator s) {
	}

	public ThemePainter getPainter() {
	}

	protected void installListeners(com.jidesoft.action.CommandBarSeparator s) {
	}

	protected void uninstallListeners(com.jidesoft.action.CommandBarSeparator s) {
	}

	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	public java.awt.Dimension getMinimumSize(javax.swing.JComponent c) {
	}

	public java.awt.Dimension getMaximumSize(javax.swing.JComponent c) {
	}

	protected class SeparatorPropertyChangeListener {


		protected BasicCommandBarSeparatorUI.SeparatorPropertyChangeListener() {
		}

		public void propertyChange(java.beans.PropertyChangeEvent evt) {
		}
	}
}
