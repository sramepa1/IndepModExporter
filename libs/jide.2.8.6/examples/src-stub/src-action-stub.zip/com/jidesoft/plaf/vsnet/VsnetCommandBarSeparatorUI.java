package com.jidesoft.plaf.vsnet;


public class VsnetCommandBarSeparatorUI extends com.jidesoft.plaf.basic.BasicCommandBarSeparatorUI {

	public VsnetCommandBarSeparatorUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}
}
