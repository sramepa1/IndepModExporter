package com.jidesoft.plaf;


public abstract class CommandBarSeparatorUI extends javax.swing.plaf.SeparatorUI {

	public CommandBarSeparatorUI() {
	}
}
