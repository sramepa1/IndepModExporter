/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


public interface DockableBarFactory {

	public DockableBar create(String key);
}
