/**
 *  The package contains events and listeners for JIDE Action Framework product.
 */
package com.jidesoft.action.event;


public class DockableBarStateTransition {

	protected java.awt.Component _component;

	protected int _transitionID;

	protected DockableBarState _preData;

	protected DockableBarState _postData;

	public DockableBarStateTransition() {
	}

	public java.awt.Component getComponent() {
	}

	public void setComponent(java.awt.Component newValue) {
	}

	public int getTransitionID() {
	}

	public void setTransitionID(int newValue) {
	}

	public DockableBarState getPreState() {
	}

	public void setPreState(DockableBarState newValue) {
	}

	public DockableBarState getPostState() {
	}

	public void setPostState(DockableBarState newValue) {
	}

	public void clear() {
	}
}
