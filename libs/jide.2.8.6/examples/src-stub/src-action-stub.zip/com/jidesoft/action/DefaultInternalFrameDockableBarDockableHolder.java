/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  A JInternalFrame implementation <code>DockableBarDockableHolder</code> which can support
 *  both DockableBars (of JIDE Action Framework) and DockableFrames (of JIDE Docking Framework).
 */
public class DefaultInternalFrameDockableBarDockableHolder extends DefaultInternalFrameDockableHolder implements DockableBarDockableHolder {
 {

	public DefaultInternalFrameDockableBarDockableHolder() {
	}

	public DefaultInternalFrameDockableBarDockableHolder(String title) {
	}

	public DefaultInternalFrameDockableBarDockableHolder(String title, boolean resizable) {
	}

	public DefaultInternalFrameDockableBarDockableHolder(String title, boolean resizable, boolean closable) {
	}

	public DefaultInternalFrameDockableBarDockableHolder(String title, boolean resizable, boolean closable, boolean maximizable) {
	}

	public DefaultInternalFrameDockableBarDockableHolder(String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
	}

	/**
	 *  Create a content container and add it to CENTER of JFrame content pane.
	 * 
	 *  @param container the container where the <code>DockableBarManager</code> is installed.
	 */
	@java.lang.Override
	protected void initFrame(java.awt.Container container) {
	}

	protected DockableBarManager createDockableBarManager(java.awt.Container contentContainer) {
	}

	protected com.jidesoft.swing.ContentContainer createContentContainer() {
	}

	/**
	 *  Gets the default dockable bar manager.
	 * 
	 *  @return dockable bar manager
	 */
	public DockableBarManager getDockableBarManager() {
	}

	/**
	 *  Gets the layout persistence. In the case of DefaultDockableBarDockableHolder,
	 *  it's an instance of LayoutPersistenceManager that manages both DockingManager
	 *  and DockableBarManager.
	 * 
	 *  @return layout persistence.
	 */
	@java.lang.Override
	public LayoutPersistence getLayoutPersistence() {
	}

	/**
	 *  Override in DefaultDockableBarHolder to return the menu bar in DockableBarManager.
	 * 
	 *  @return the menubar for this frame
	 */
	@java.lang.Override
	public javax.swing.JMenuBar getJMenuBar() {
	}

	@java.lang.Override
	public void dispose() {
	}
}
