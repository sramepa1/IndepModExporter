/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  This class is used by JIDE examples to make creation of comamnd bar and components on the command bars easier. It is
 *  not intended for public usage.
 */
public class CommandBarFactory {

	public CommandBarFactory() {
	}

	public static CommandBar createMenuCommandBar(javax.swing.JMenuBar menuBar) {
	}

	protected static JideButton createButton(javax.swing.Icon icon) {
	}

	protected static JideButton createButton(String text) {
	}

	protected static JideButton createButton(String text, javax.swing.Icon icon) {
	}

	protected static JideSplitButton createSplitButton(javax.swing.Icon icon) {
	}

	protected static JideSplitButton createSplitButton(String text) {
	}

	protected static JideSplitButton createSplitButton(String text, javax.swing.Icon icon) {
	}

	protected static JideToggleSplitButton createToggleSplitButton(String text, javax.swing.Icon icon) {
	}

	protected static JideMenu createMenu(javax.swing.Icon icon) {
	}

	protected static JideMenu createMenu(String text, char mnemonic) {
	}

	protected static JideMenu createMenu(String text, char mnemonic, javax.swing.Icon icon) {
	}

	protected static javax.swing.JComboBox createComboBox(String value) {
	}

	public static void addDemoMenus(javax.swing.JComponent menuBar, String[] menus) {
	}

	public static javax.swing.JMenu createLookAndFeelMenu(java.awt.Container container) {
	}

	public static CommandBar createLookAndFeelCommandBar(java.awt.Container container) {
	}

	public static CommandBar createDockingFrameworkCommandBar(DockingManager dockingManager, DocumentPane documentPane) {
	}
}
