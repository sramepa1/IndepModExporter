/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  This is the same as CommandBar with setMenuBar(true). And there is
 *  no difference either way if you are on operating system other than Mac. On
 *  Mac OS X, if you want to use screen menu bar, you should use this instead
 *  of using CommandBar with setMeunBar(true).
 */
public class CommandMenuBar extends CommandBar {

	public CommandMenuBar() {
	}

	public CommandMenuBar(int orientation) {
	}

	public CommandMenuBar(String key) {
	}

	public CommandMenuBar(String key, String title) {
	}

	public CommandMenuBar(String key, String title, int orientation) {
	}
}
