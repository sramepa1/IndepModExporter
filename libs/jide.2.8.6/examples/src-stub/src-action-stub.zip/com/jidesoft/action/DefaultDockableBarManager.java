/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  Default implementation of <code>DockableBarManager</code>. It is also the main interface that users need in order to
 *  access the features of <code>DockableBar</code>.
 */
public class DefaultDockableBarManager extends AbstractLayoutPersistence implements DockableBarManager, java.awt.event.AWTEventListener, javax.swing.SwingConstants {
 {

	public java.awt.event.ComponentAdapter _componentListener;

	protected DefaultDockableBarManager.DockableBarsSnapshot _preDragSnapshot;

	protected DefaultDockableBarManager.DockableBarsSnapshot _postDragSnapshot;

	/**
	 *  A list of event listeners for this component.
	 */
	protected javax.swing.event.EventListenerList listenerList;

	protected boolean _redispatchingKeyEventToFloaters;

	public static final String PROPERTY_INIT_BOUNDS = "initBounds";

	public static final String PROPERTY_INIT_STATE = "initState";

	public static final String PROPERTY_HIDABLE = "hidable";

	public static final String PROPERTY_FLOATABLE = "floatable";

	public static final String PROPERTY_REARRANGABLE = "rearrangable";

	public static final String PROPERTY_HIDE_FLOATING_DOCKABLE_BARS_WHEN_DEACTIVATE = "hideFloatingDockableBarsWhenDeactivate";

	public static final String PROPERTY_SHOW_CONTEXT_MENU = "showContextMenu";

	protected boolean _glassPaneVisibility;

	/**
	 *  Constructor. DockingManager must work with a RootPaneContainer. Once RootPaneContainer is initialized, user needs
	 *  to call <code>getWorkspace()</code> to get the workspace area, then add a <code>JDesktopPane</code> (for MDI) or
	 *  a <code>DocumentPane</code> (for TDI, part of JIDE Components) to it., <br>Note: It will automatically set
	 *  BorderLayout to ContentPane. User can call <code>getContentPane().add(comp, BorderLayout.NORTH)<code> with NORTH,
	 *  SOUTH, EAST or WEST as parameter, but never add a component to CENTER.
	 * 
	 *  @param rootContainer    the root pane container
	 *  @param contentContainer the container where the dockable bars will be added. This container should be empty.
	 */
	public DefaultDockableBarManager(javax.swing.RootPaneContainer rootContainer, java.awt.Container contentContainer) {
	}

	public void switchRootPaneContainer(javax.swing.RootPaneContainer rootContainer) {
	}

	public void setFloatingDockableBarsVisible(boolean show) {
	}

	/**
	 *  There is a bug that prevents setVisible() from working properly in a specific situation. If there is a
	 *  floatingContainer, a menu is open, and a menu is then selected in a different window, a race condition occurs
	 *  where the two windows repeatedly activate and deactivate opposite each other.
	 *  <p/>
	 *  Until that bug can be resolved, hide the floatingContainer by moving it far offscreen.
	 * 
	 *  @param floatingContainer the floating container
	 *  @param show              visible or invisible
	 */
	protected void hackSetFrameVisible(FloatingDockableBarContainer floatingContainer, boolean show) {
	}

	/**
	 *  There is a bug that prevents setVisible() from working properly in a specific situation. If there is a
	 *  floatingContainer, a menu is open, and a menu is then selected in a different window, a race condition occurs
	 *  where the two windows repeatedly activate and deactivate opposite each other.
	 *  <p/>
	 *  Until that bug can be resolved, a floatingContainer is hidden by moving it far offscreen. So it is "visible" if
	 *  it not far offscreen.
	 * 
	 *  @param floatingContainer the floating container
	 *  @return Is it visible?
	 */
	protected boolean hackIsFrameVisible(FloatingDockableBarContainer floatingContainer) {
	}

	/**
	 *  Is the specified window one of our floatingFrames?
	 * 
	 *  @param aWindow the window
	 *  @return Is it?
	 */
	protected boolean isOwnedFloatingDockableBar(java.awt.Window aWindow) {
	}

	/**
	 *  Is the specified window's ancestor is root pane container?
	 * 
	 *  @param aWindow the window
	 *  @return Is it?
	 */
	protected boolean isOwnedWindow(java.awt.Window aWindow) {
	}

	public void eventDispatched(java.awt.AWTEvent event) {
	}

	/**
	 *  Resets layout of frames to initial values. <br> This method is Swing thread-safe.
	 */
	public void resetToDefault() {
	}

	/**
	 *  Adds a dockable bar to this DockableBarManager. <br> This method is Swing thread-safe.
	 * 
	 *  @param bar the dockable bar to be added
	 */
	public void addDockableBar(DockableBar bar) {
	}

	/**
	 *  Removes all dockable bars from this DockingManager. <br> This method is Swing thread-safe.
	 */
	public void removeAllDockableBars() {
	}

	public void removeExtraContexts() {
	}

	/**
	 *  Removes a dockable bar from this DockableBarManager. <br> This method is Swing thread-safe.
	 * 
	 *  @param name name of dockable bar to be removed
	 */
	public void removeDockableBar(String name) {
	}

	/**
	 *  Removes a dockable bar from this DockableBarManager. This method has an option to keep previous state. In most
	 *  cases, you don't want to keep the previous states when removing dockable bar. That's what {@link
	 *  #removeDockableBar(String)} does. However if you just remove the dockable bar and will add it back later, you can
	 *  keep the state so that when the dockable bar is added back, it has the exact same state as before. <br> This
	 *  method is Swing thread-safe.
	 * 
	 *  @param key               the key of the dockable bar.
	 *  @param keepPreviousState
	 */
	public void removeDockableBar(String key, boolean keepPreviousState) {
	}

	/**
	 *  Sets the dockable bar visible using the key of that dockable bar. <br> This method is Swing thread-safe.
	 * 
	 *  @param key the key of the dockable bar to be shown
	 */
	public void showDockableBar(String key) {
	}

	/**
	 *  Gets the dockable bar using key.
	 * 
	 *  @param key
	 *  @return the dockable bar which has the key.
	 */
	public DockableBar getDockableBar(String key) {
	}

	/**
	 *  Sets the dockable bar invisible using the key of that dockable bar. <br> This method is Swing thread-safe.
	 * 
	 *  @param key the key of the dockable bar to be hidden
	 */
	public void hideDockableBar(String key) {
	}

	/**
	 *  Docks the dockable bar on the side and at the start. <br> This method is Swing thread-safe.
	 * 
	 *  @param bar          the dockable bar to be docked
	 *  @param side         four possible sides
	 *  @param row          the row index
	 *  @param createNewRow true to create a new row at the specified row index. Otherwise uses the existing row.
	 *  @param start        the starting position, in pixels.
	 *  @throws IllegalArgumentException if side is not a valid value.
	 */
	public void dockDockableBar(DockableBar bar, int side, int row, boolean createNewRow, int start) {
	}

	/**
	 *  Float the dockable bar. <br> This method is Swing thread-safe.
	 * 
	 *  @param bar    the dockable bar to be floated
	 *  @param bounds the bounds of the float dockable bar
	 */
	public void floatDockableBar(DockableBar bar, java.awt.Rectangle bounds) {
	}

	/**
	 *  This method is normally called when the user has indicated that they will begin dragging a component around. This
	 *  method should be called prior to any dragDockableBar() calls to allow the DockableBarManager to prepare any
	 *  necessary state. Normally <b>f</b> will be a DockableBar.
	 * 
	 *  @param f
	 *  @param mouseX
	 *  @param mouseY
	 *  @param relativeX
	 *  @param relativeY
	 *  @param startInFloat
	 */
	public void beginDraggingDockableBar(javax.swing.JComponent f, int mouseX, int mouseY, double relativeX, double relativeY, boolean startInFloat) {
	}

	/**
	 *  Take a snapshot of the currently showing DockableBars.
	 * 
	 *  @param possiblyMoved the component (should be a DockableBar) which is being moved
	 *  @return the snapshot of the currently showing DockableBars
	 */
	protected DefaultDockableBarManager.DockableBarsSnapshot createDockableBarsSnapshot(javax.swing.JComponent possiblyMoved) {
	}

	protected void sortDockableBarRowItems(java.util.List row) {
	}

	public void pauseDragDockableBar() {
	}

	/**
	 *  Cancel the dragging. <br> This method is Swing thread-safe.
	 */
	public void cancelDragging() {
	}

	/**
	 *  The user has moved the dockable bar. Calls to this method will be preceded by calls to
	 *  beginDraggingDockableBar(). Normally <b>f</b> will be a DockableBar.
	 * 
	 *  @param f
	 *  @param newX
	 *  @param newY
	 *  @param mouseModifiers
	 */
	public void dragDockableBar(javax.swing.JComponent f, int newX, int newY, int mouseModifiers) {
	}

	/**
	 *  This method signals the end of the dragging session. Any state maintained by the DockableBarManager can be
	 *  removed here.  Normally <b>f</b> will be a DockableBar.
	 */
	public void endDraggingDockableBar() {
	}

	/**
	 *  Compare the pre- and post-drag snapshots to determine if a DockableBar changed rows, changed position within a
	 *  row, or was resized. If so, fire an event.
	 */
	protected void checkForRearrangedDockableBars() {
	}

	/**
	 *  Adds the specified listener to receive DockableBarsRearrangedEvents from this DockableBarManager.
	 * 
	 *  @param l the DockableBarsRearrangedListener
	 */
	public void addDockableBarsRearrangedListener(event.DockableBarsRearrangedListener l) {
	}

	/**
	 *  Removes the specified DockableBarsRearrangedListener so that it no longer receives DockableBarsRearrangedEvents
	 *  from this DockableBarManager.
	 * 
	 *  @param l the DockableBarsRearrangedListener
	 */
	public void removeDockableBarsRearrangedListener(event.DockableBarsRearrangedListener l) {
	}

	/**
	 *  Returns an array of all the <code>DockableBarsRearrangedListener</code>s added to this
	 *  <code>DockableBarManager</code> with <code>addDockableBarsRearrangedListener</code>.
	 * 
	 *  @return all of the <code>DockableBarsRearrangedListener</code>s added or an empty array if no listeners have been
	 *          added
	 * 
	 *  @see #addDockableBarsRearrangedListener
	 *  @since 1.4
	 */
	public event.DockableBarsRearrangedListener[] getDockableBarsRearrangedListeners() {
	}

	/**
	 *  Fires a DockableBarsRearrangedEvent.
	 * 
	 *  @param event the event being fired
	 */
	protected void fireDockableBarsRearranged(event.DockableBarsRearrangedEvent event) {
	}

	protected event.DockableBarState findComponentInSnapshot(java.awt.Component component, DefaultDockableBarManager.DockableBarsSnapshot snapshot) {
	}

	/**
	 *  Find the nature of the transition of a moved Component.
	 * 
	 *  @param preState the original DockableBar state data
	 *  @return the state transition, including ID and pre- and post-data
	 */
	protected event.DockableBarStateTransition getTransition(event.DockableBarState preState) {
	}

	/**
	 *  This methods is normally called when the user has indicated that they will begin resizing the dockable bar. This
	 *  method should be called prior to any resizeDockableBar() calls to allow the DockableBarManager to prepare any
	 *  necessary state.  Normally <b>f</b> will be a DockableBar.
	 * 
	 *  @param f
	 *  @param direction
	 */
	public void beginResizingDockableBar(javax.swing.JComponent f, int direction) {
	}

	/**
	 *  The user has resized the component. Calls to this method will be preceded by calls to beginResizingDockableBar().
	 *  Normally <b>f</b> will be a DockableBar.
	 * 
	 *  @param f
	 *  @param newX
	 *  @param newY
	 *  @param newWidth
	 *  @param newHeight
	 */
	public void resizingDockableBar(javax.swing.JComponent f, int newX, int newY, int newWidth, int newHeight, int deltaX, int deltaY) {
	}

	/**
	 *  This method signals the end of the resize session. Any state maintained by the DockableBarManager can be removed
	 *  here.  Normally <b>f</b> will be a DockableBar.
	 * 
	 *  @param f
	 */
	public void endResizingDockableBar(javax.swing.JComponent f) {
	}

	public javax.swing.RootPaneContainer getRootPaneContainer() {
	}

	/**
	 *  Gets the main container. Main container is the container that contains all docked window within the main frame.
	 *  It doesn't include side bars, doesn't include toolbar or menu bar.
	 * 
	 *  @return main container
	 */
	public MainContainer getMainContainer() {
	}

	/**
	 *  Did the loadLayoutFrom(InputStream in) method load successfully from the input stream (false indicates that it
	 *  called resetToDefault to load the layout.) This method can be called immediately after the
	 *  loadLayoutFrom(InputStream in) call to determine if a specific LayoutPersistence was forced to call
	 *  resetToDefault.
	 * 
	 *  @return boolean did it load successfully from the input stream (false indicates that it called resetToDefault to
	 *          load the layout.)
	 */
	public boolean isLoadDataSuccessful() {
	}

	/**
	 *  Starts a process to add/remove dockable bar without showing on screen immediately. Any call to loadLayoutDataXxx
	 *  methods or resetToDefault() will mark the process.
	 */
	public void beginLoadLayoutData() {
	}

	/**
	 *  Load layout data from an InputStream that specified as <code>in</code> parameter. If any exception happens during
	 *  the read, it will call resetLayout() to use default layout.
	 *  <p/>
	 *  <br> If you use this method to load an InputStream you get from layout file that saved saveLayoutDataAsFile,
	 *  please call convertStream first.
	 * 
	 *  @param in the InputStream where the layout data will be read from.
	 *  @return boolean did it load successfully from the input stream (false indicates that it called resetToDefault to
	 *          load the layout.)
	 */
	public boolean loadLayoutFrom(java.io.InputStream in) {
	}

	public void setShowInitial(boolean value) {
	}

	public boolean isShowInitial() {
	}

	public void showInitial() {
	}

	/**
	 *  Save layout data to an OutputStream that specified as <code>out</code> parameter.
	 * 
	 *  @param out the OutputStream where the layout data will be written to.
	 *  @throws IOException
	 */
	public void saveLayoutTo(java.io.OutputStream out) {
	}

	/**
	 *  Toggle the dockable bar's state. If it's docked, change to floating mode; if it's floating, change to docked
	 *  mode.
	 * 
	 *  @param key the key of the dockable bar to be toggle state.
	 */
	public void toggleState(String key) {
	}

	public void toggleState(DockableBar bar) {
	}

	/**
	 *  Remove it from hidden dockable bar list.
	 * 
	 *  @param key the key of the dockable bar
	 */
	public void removeFromHiddenDockableBars(String key) {
	}

	/**
	 *  If the dockable bars can be rearranged.
	 * 
	 *  @return Return true if the dockable bars can be rearranged by user.
	 */
	public boolean isRearrangable() {
	}

	/**
	 *  Enable or disable the rearrangement of dockable bars. It will enable or disable all dockable bar.
	 * 
	 *  @param rearrangeable true if the dockable bars can be rearranged by user.
	 */
	public void setRearrangable(boolean rearrangeable) {
	}

	/**
	 *  Return true if floating is allowed for dockable bars.
	 * 
	 *  @return true if floating is allowed
	 */
	public boolean isFloatable() {
	}

	/**
	 *  Enable or disable floating of dockable bars.
	 * 
	 *  @param floatable
	 */
	public void setFloatable(boolean floatable) {
	}

	/**
	 *  Return true if hidden is allowed for dockable bars.
	 * 
	 *  @return true if hidden is allowed
	 */
	public boolean isHidable() {
	}

	/**
	 *  Enable or disable dockable bars from being hidden.
	 * 
	 *  @param hidable
	 */
	public void setHidable(boolean hidable) {
	}

	/**
	 *  Since there are several top level container in DockableBarManager, this method will call
	 *  <code>updateComponentTreeUI</code> to all of them to make sure everything changes after reset look and feel.
	 */
	public void updateComponentTreeUI() {
	}

	/**
	 *  Getss a collection of all dockable bars.
	 * 
	 *  @return the collection of all dockable bars.
	 */
	public java.util.Collection getAllDockableBars() {
	}

	/**
	 *  Gets a list of all dockable bars. It's clone of the list maintained by the DockableBarManager.
	 * 
	 *  @return the list of all dockable bars
	 */
	public java.util.List getAllDockableBarNames() {
	}

	/**
	 *  Gets initial bounds of the main frame. If init bounds is never set before, it will return the smaller one screen
	 *  size and {0, 0, 1024, 768)
	 * 
	 *  @return initial bounds
	 */
	public java.awt.Rectangle getInitBounds() {
	}

	/**
	 *  Sets the initial bounds of the main frame.
	 * 
	 *  @param initBounds
	 */
	public void setInitBounds(java.awt.Rectangle initBounds) {
	}

	/**
	 *  Gets initial state of the main frame. State could be the states that are specified in {@link
	 *  Frame#getExtendedState}. If user never sets the init state before, it will return Frame.NORMAL if the init bounds
	 *  is less than screen size. If init bounds is larger than screen size, it will return Frame.MAXIMIZED_BOTH (under
	 *  JDK 1.4 and above only) .
	 * 
	 *  @return the initial state
	 */
	public int getInitState() {
	}

	/**
	 *  Sets the initial state of the main frame. State can be the states that are specified in {@link
	 *  Frame#getExtendedState}.
	 * 
	 *  @param initState the initial state
	 *  @see Frame#setExtendedState(int)
	 *  @see Frame#getExtendedState
	 */
	public void setInitState(int initState) {
	}

	/**
	 *  Gets dock context of a dockable bar specified by key. If it has dock context, return the context; or else, return
	 *  null.
	 * 
	 *  @param key
	 *  @return If it has dock context, return the context; or else, return null
	 */
	public DockableBarContext getDockableBarContextOf(String key) {
	}

	/**
	 *  Gets the popup menu customizer.
	 * 
	 *  @return popup menu customizer
	 */
	public DockableBarPopupMenuCustomizer getDockableBarPopupMenuCustomizer() {
	}

	/**
	 *  Sets the popup customizerDockableBar.
	 *  <p/>
	 *  The menu passed in the the customizePopupMenu already have some menu items. You can remove all of them to add
	 *  your own, or you can remove some of them. All existing menu items have a unique names. Here are the names -
	 *  "DockableBar.rearrangeable", "DockableBar.hidable", "DockableBar.floatable" and the key of each dockable bar
	 *  which are used to show or hide the corresponding dockable bar. There are also constants beginning with
	 *  CONTEXT_MENU_xxx defined on DockableBarManager. The names should be very obvious to what the menu item do. So
	 *  instead of using absolute menu item index, it'd better to use the name to look up a particular menu item.
	 * 
	 *  @param customizerDockableBar
	 */
	public void setDockableBarPopupMenuCustomizer(DockableBarPopupMenuCustomizer customizerDockableBar) {
	}

	/**
	 *  Removes all used resources.
	 */
	public void dispose() {
	}

	public boolean isHideFloatingDockableBarsWhenDeactivate() {
	}

	public void setHideFloatingDockableBarsWhenDeactivate(boolean hideFloatingDockableBarsWhenDeactivate) {
	}

	public DockableBarContainer getDockableBarContainer(int side) {
	}

	public DockableBarContainer createDockableBarContainer() {
	}

	public void showContextMenu(java.awt.event.MouseEvent e, java.awt.Component component) {
	}

	public javax.swing.JPopupMenu getContextMenu() {
	}

	/**
	 *  Creates a window which contains the toolbar after it has been dragged out from its container
	 * 
	 *  @return a <code>FloatingDockableBarContainer</code> object, containing the toolbar.
	 */
	public FloatingDockableBarContainer createFloatingDockableBarContainer(java.awt.Window owner) {
	}

	/**
	 *  Checks if the context menu should be shown.
	 * 
	 *  @return true if context menu will be shown. Otherwise false.
	 */
	public boolean isShowContextMenu() {
	}

	/**
	 *  Sets the flag to show context menu or not.
	 * 
	 *  @param showContextMenu
	 */
	public void setShowContextMenu(boolean showContextMenu) {
	}

	/**
	 *  Give the floating windows a crack at a KeyEvent that has gone unconsumed in the main window.
	 * 
	 *  @param e the KeyEvent
	 *  @return boolean true if the event is consumed
	 */
	protected boolean redispatchKeyEventToFloatingContainers(java.awt.event.KeyEvent e) {
	}

	protected void processKeyBindingForFloatingDockableWindow(java.awt.event.KeyEvent e, javax.swing.JWindow dockableWindow) {
	}

	protected void processKeyBindingsForContainerInFloatingDockable(java.awt.event.KeyEvent e, java.awt.Container container) {
	}

	protected void processKeyBindingForComponentInFloatingDockable(java.awt.event.KeyEvent e, javax.swing.JComponent comp) {
	}

	public DockableBarFactory getDockableBarFactory() {
	}

	public void setDockableBarFactory(DockableBarFactory dockableBarFactory) {
	}

	public void loadInitialLayout(org.w3c.dom.Document layoutDocument) {
	}

	/**
	 *  Checks if we will use glass pane to change cursor.
	 * 
	 *  @return true or false.
	 */
	public boolean isUseGlassPaneEnabled() {
	}

	/**
	 *  Enables us to use glass pane to for cursor change purpose.
	 * 
	 *  @param useGlassPaneEnabled
	 */
	public void setUseGlassPaneEnabled(boolean useGlassPaneEnabled) {
	}

	/**
	 *  Sets available the dockable bar.
	 * 
	 *  @param key The key of the dockable bar.
	 */
	public void setDockableBarAvailable(String key) {
	}

	/**
	 *  Sets unavailable the dockable bar.
	 * 
	 *  @param key The key of the dockable bar.
	 */
	public void setDockableBarUnavailable(String key) {
	}

	public boolean isPreserveAvailableProperty() {
	}

	public void setPreserveAvailableProperty(boolean preserveAvailableProperty) {
	}

	protected void checkBarKey(String key, String methodName) {
	}

	protected class DockableBarsSnapshot {


		protected java.awt.Component _possiblyMoved;

		protected java.util.ArrayList _northBars;

		protected java.util.ArrayList _southBars;

		protected java.util.ArrayList _eastBars;

		protected java.util.ArrayList _westBars;

		protected java.util.ArrayList _floatingBars;

		protected DefaultDockableBarManager.DockableBarsSnapshot() {
		}

		protected void clear() {
		}
	}

	protected class FloaterKeyEventPostProcessor {


		protected DefaultDockableBarManager.FloaterKeyEventPostProcessor() {
		}

		public boolean postProcessKeyEvent(java.awt.event.KeyEvent e) {
		}
	}
}
