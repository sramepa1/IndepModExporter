package com.jidesoft.grid;


/**
 *  <tt>CalculatedTableModel</tt> allows user to create a new table model based on an existing table model using column
 *  based conversion. For example, you can only expose some columns in the existing table model to the new table model by
 *  using {@link #addColumn(CalculatedColumn)} with {@link SingleColumn}.
 */
public class CalculatedTableModel extends DefaultColumnTableModelWrapper {

	public CalculatedTableModel(javax.swing.table.TableModel model) {
	}

	public CalculatedColumn getCalculatedColumnAt(int columnIndex) {
	}

	@java.lang.Override
	public int getActualColumnAt(int column) {
	}

	@java.lang.Override
	public final int getVisualColumnAt(int actualColumn) {
	}

	@java.lang.Override
	public Object getValueAt(int row, int column) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int row, int column) {
	}

	@java.lang.Override
	public int getColumnCount() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	public Object getColumnIdentifier(int column) {
	}

	@java.lang.Override
	public Class getColumnClass(int column) {
	}

	@java.lang.Override
	public boolean isCellEditable(int row, int column) {
	}

	@java.lang.Override
	public Class getCellClassAt(int row, int column) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int row, int column) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int row, int column) {
	}

	@java.lang.Override
	public final int[] getIndexes() {
	}

	@java.lang.Override
	public final void setIndexes(int[] indexes) {
	}

	protected int[] getDependingColumnsOf(int column) {
	}

	@java.lang.Override
	public void tableCellsUpdated(int columnIndex, int firstRow, int lastRow) {
	}

	public void addAllColumns() {
	}

	public void addColumn(CalculatedColumn column) {
	}

	public void addColumns(java.util.Collection columns) {
	}

	public void removeColumn(CalculatedColumn column) {
	}

	public void removeColumns(java.util.Collection columns) {
	}
}
