/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  Default implementation of SummaryCalculator. In this implementation, it calculates seven statistics - Sum, Min, Max,
 *  Mean, Var, StdDev, Count - for numbers (all classes extending Number and primitives) and BigDecimals; Max, Min, Count
 *  for String and only Count for all other data types.
 *  <p/>
 *  You can always add your own summary. For example, you want to add a new summary called "Last Value". Here is the
 *  sample code.
 *  <pre><code>
 *  pivotDataModel.setSummaryCalculator(new DefaultSummaryCalculator(){
 *      final int SUMMARY_LAST_VALUE = PivotConstants.SUMMARY_RESERVED_MAX + 1;
 *      private double _lastValue;
 *      public void addValue(Object v) {
 *          super.addValue(v);
 *          if (object instanceof Number) {
 *              _lastValue = ((Number) object).doubleValue();
 *           }
 *      }
 *  <p/>
 *      public void clear() {
 *          super.clear();
 *          _lastValue = 0;
 *      }
 *  <p/>
 *      public int getNumberOfSummaries() {
 *          return super.getNumberOfSummaries() + 1;
 *      }
 *  <p/>
 *      public String getSummaryName(int type) {
 *          if(type == SUMMARY_LAST_VALUE) {
 *             return "Last Value";
 *          }
 *          return super.getSummaryName(type);
 *      }
 *  <p/>
 *      public Object getSummaryResult(int type) {
 *          if(type == SUMMARY_LAST_VALUE) {
 *              return new Double(_lastValue);
 *          }
 *          return super.getSummaryResult(type);
 *      }
 *  });
 *  </code></pre>
 *  In the example, we use the {@link DefaultSummaryCalculator} because we just need to add one more summary. If you want
 *  to provide your own way to calculate the summaries, you can implement {@link SummaryCalculator} interface directly.
 *  <p/>
 *  <code>DefaultSummaryCalculator</code> has built-in support for Numbers, BigDecimals, Dates/Calendars and Booleans. If
 *  you need to calculate other data types, you can create your own <code>SummaryCalculator</code> extending
 *  <code>DefaultSummaryCalculator</code>.
 */
public class DefaultSummaryCalculator implements SummaryCalculator, PivotConstants {
 {

	public DefaultSummaryCalculator() {
	}

	public void addValue(Object object) {
	}

	public void addValue(IPivotDataModel pivotDataModel, PivotField pivotField, int row, int column, Object object) {
	}

	public void clear() {
	}

	public long getCount() {
	}

	public int getNumberOfSummaries() {
	}

	public String getSummaryName(java.util.Locale locale, int summarySort) {
	}

	public Object getSummaryResult(int type) {
	}

	/**
	 *  Checks if the biasCorrect is set.
	 * 
	 *  @return true or false.
	 */
	public boolean isBiasCorrected() {
	}

	/**
	 *  Sets the biasCorrected flag. If true, variance will be calcuated dividing by n - 1. Otherwise, it will devide by
	 *  n. Default is true.
	 * 
	 *  @param biasCorrected true or false.
	 */
	public void setBiasCorrected(boolean biasCorrected) {
	}

	/**
	 *  Gets the MathContext.
	 * 
	 *  @return the MathContext.
	 */
	public java.math.MathContext getMathContext() {
	}

	/**
	 *  To calculate statistics for BigDecimals, a MathContext to control the precision. You can set it using this method.
	 *  This context is used in Mean, Var, StdDev calculation only for BigDecimal.
	 * 
	 *  @param mathContext the MathContext.
	 */
	public void setMathContext(java.math.MathContext mathContext) {
	}

	public int[] getAllowedSummaries(Class type) {
	}

	/**
	 *  Gets the allowed summary types.
	 * 
	 *  @param type the data type.
	 *  @return the allowed summary types.
	 */
	public int[] getAllowedSummaries(Class type, ConverterContext context) {
	}
}
