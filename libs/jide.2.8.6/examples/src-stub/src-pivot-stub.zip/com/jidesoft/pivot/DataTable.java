/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The table used by the PivotTablePane in the viewport area.
 */
public class DataTable extends CategorizedTable {

	public DataTable(PivotTablePane pivotTablePane) {
	}

	@java.lang.Override
	protected void configureEnclosingScrollPane() {
	}

	public PivotTablePane getPivotTablePane() {
	}

	public void setPivotTablePane(PivotTablePane pivotTablePane) {
	}

	@java.lang.Override
	public void addColumn(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Creates the mouse listener used to handle mouse click on +/- icon.
	 * 
	 *  @return a mouse listener.
	 */
	protected java.awt.event.MouseListener createPopupMenuMouseListener() {
	}

	/**
	 *  Sorts the PivotTablePane by the cell.
	 * 
	 *  @param rowIndex    the row index in the data table
	 *  @param columnIndex the column index in the data table
	 *  @param ascending   true to sort ascendingly and false to sort descending.
	 */
	public void sortBy(int rowIndex, int columnIndex, boolean ascending) {
	}

	protected class PopupMenuMouseListener {


		protected DataTable.PopupMenuMouseListener() {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}
	}
}
