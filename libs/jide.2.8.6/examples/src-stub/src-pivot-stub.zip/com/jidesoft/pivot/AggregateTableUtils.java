/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public class AggregateTableUtils {

	public AggregateTableUtils() {
	}

	protected static AggregateTablePane getAggregateTablePane(javax.swing.JTable table) {
	}

	public static boolean isColumnVisible(javax.swing.JTable table, int modelIndex) {
	}

	public static String getColumnName(javax.swing.JTable table, int modelIndex) {
	}

	public static Object getColumnIdentifier(javax.swing.JTable table, int modelIndex) {
	}

	public static javax.swing.JTable getColumnTable(javax.swing.JTable table, Object columnIdentifier) {
	}

	protected static int getInnerModelIndex(javax.swing.JTable table, Object identifier) {
	}

	protected static int getOuterModelIndex(javax.swing.JTable table, int innerModelIndex) {
	}

	protected static void hideColumn(javax.swing.JTable table, Object identifier, int modelIndex) {
	}

	protected static void showColumn(javax.swing.JTable table, Object identifier, int modelIndex) {
	}
}
