/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


public interface CategoryTickCalculator extends TickCalculator {
 {
}
