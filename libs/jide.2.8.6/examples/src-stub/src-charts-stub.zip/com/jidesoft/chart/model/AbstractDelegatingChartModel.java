/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  @author Simon White (swhite@catalysoft.com)
 */
public abstract class AbstractDelegatingChartModel implements AnnotatedChartModel, ChartModelListener {
 {

	public AbstractDelegatingChartModel() {
	}

	public AbstractDelegatingChartModel(AnnotatedChartModel[] newDelegates) {
	}

	protected void init() {
	}

	public abstract int getAnnotationCount() {
	}

	public abstract com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	public abstract Chartable getPoint(int n) {
	}

	public abstract int getPointCount() {
	}

	protected abstract void update() {
	}

	public String getName() {
	}

	public void setName(String newName) {
	}

	public AnnotatedChartModel getDelegate() {
	}

	public AnnotatedChartModel getDelegate(int i) {
	}

	public AnnotatedChartModel[] getDelegates() {
	}

	public void setDelegate(AnnotatedChartModel newDelegate) {
	}

	public void setDelegates(AnnotatedChartModel[] newDelegates) {
	}

	/**
	 *  Cyclical models are quite rare so we return a value of false here
	 */
	public boolean isCyclical() {
	}

	public void addChartModelListener(ChartModelListener listener) {
	}

	public void removeChartModelListener(ChartModelListener listener) {
	}

	protected void fireModelChanged() {
	}

	public void chartModelChanged() {
	}

	public java.util.Iterator iterator() {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
