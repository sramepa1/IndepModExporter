/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


public abstract class AbstractBarRenderer extends AbstractRenderer implements BarRenderer {
 {

	public AbstractBarRenderer() {
	}

	protected java.awt.Paint getBarColor(com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.Chartable p, com.jidesoft.chart.style.ChartStyle style, boolean isSelected, boolean hasRollover, boolean hasFocus) {
	}
}
