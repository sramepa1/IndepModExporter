/**
 *  When users have preferences for the visual appearance of their Chart,
 *  classes from this package can be used to acquire those settings.
 */
package com.jidesoft.chart.preference;


/**
 *  @author Simon White (swhite@catalysoft.com)
 */
public class PointShapeLabel extends javax.swing.JComponent implements javax.swing.ListCellRenderer {
 {

	public PointShapeLabel() {
	}

	public PointShapeLabel(java.awt.Color color) {
	}

	protected void init() {
	}

	public com.jidesoft.chart.PointShape getShape() {
	}

	public void setShape(com.jidesoft.chart.PointShape shape) {
	}

	public boolean isSelected() {
	}

	public void setSelected(boolean selected) {
	}

	@java.lang.Override
	public void paintComponent(java.awt.Graphics g) {
	}

	public java.awt.Component getListCellRendererComponent(javax.swing.JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
	}
}
