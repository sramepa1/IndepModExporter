/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  Renderer for a candlestick chart
 */
public class CandlestickPointRenderer extends AbstractPointRenderer {

	public static final String PROPERTY_CANDLESTICK_TYPE = "Candlestick Type";

	/**
	 *  Zero argument constructor
	 */
	public CandlestickPointRenderer() {
	}

	/**
	 *  Creates a Candlestick renderer and simultaneously sets the style of rendering
	 *  @param candlestickType the new style of rendering to use
	 */
	public CandlestickPointRenderer(CandlestickChartType candlestickType) {
	}

	/**
	 *  @return the style of candlestick currently rendered by this object
	 */
	public CandlestickChartType getCandlestickType() {
	}

	/**
	 *  Specify the style of rendering used for candlesticks
	 *  @param candlestickType the style of rendering to use
	 */
	public void setCandlestickType(CandlestickChartType candlestickType) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public java.awt.Shape renderPoint(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable point, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y) {
	}
}
