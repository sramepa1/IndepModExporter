/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  A zoom event where the zoom is on a rectangular selection.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class RectangleSelectionEvent extends ChartSelectionEvent {

	public RectangleSelectionEvent(Object source, java.awt.Rectangle selection) {
	}

	@java.lang.Override
	public java.awt.Rectangle getLocation() {
	}

	@java.lang.Override
	public ZoomDirection getDirection() {
	}
}
