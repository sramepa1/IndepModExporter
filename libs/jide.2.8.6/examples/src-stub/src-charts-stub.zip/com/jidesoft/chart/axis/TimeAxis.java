/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


public class TimeAxis extends Axis {

	/**
	 *  An axis that creates a tick calculator that generates time-formatted ticks
	 */
	public TimeAxis() {
	}

	public TimeAxis(String text) {
	}

	public TimeAxis(com.jidesoft.chart.annotation.AutoPositionedLabel label) {
	}

	public TimeAxis(long min, long max) {
	}

	public TimeAxis(TimeRange newRange) {
	}

	public TimeAxis(TimeRange newRange, String text) {
	}

	protected void init() {
	}

	public void setDateFormat(java.text.DateFormat dateFormat) {
	}

	public java.text.DateFormat getDateFormat() {
	}

	public TimeAxis withDateFormat(java.text.DateFormat dateFormat) {
	}

	public java.util.TimeZone getTimeZone() {
	}

	public void setTimeZone(java.util.TimeZone timeZone) {
	}
}
