/**
 *  When users have preferences for the visual appearance of their Chart,
 *  classes from this package can be used to acquire those settings.
 */
package com.jidesoft.chart.preference;


/**
 *  A component for selecting a new point size for points shown by a Chart component, and updating the point size for all
 *  traces whenever the selected size is changed.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class LineWidthChooser extends javax.swing.JSpinner implements javax.swing.event.ChangeListener {
 {

	public LineWidthChooser() {
	}

	public Integer getLineWidth() {
	}

	public void setLineWidth(Integer lineWidth) {
	}

	protected void init() {
	}

	public void stateChanged(javax.swing.event.ChangeEvent e) {
	}
}
