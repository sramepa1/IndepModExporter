/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  Represents an axis in the chart display.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class Axis implements java.beans.PropertyChangeListener {
 {

	public static final String PROPERTY_TICKS = "ticks";

	public static final String PROPERTY_RANGE = "range";

	public static final String PROPERTY_UPDATE_OTHER_AXES = "updateOtherAxes";

	public static final String PROPERTY_LABEL = "label";

	public static final String PROPERTY_TICK_CALCULATOR = "tickCalculator";

	public static final String PROPERTY_AXIS_COLOR = "axisColor";

	/**
	 *  No-args constructor
	 */
	public Axis() {
	}

	/**
	 *  Create an axis using the supplied text to create a label
	 * 
	 *  @param text the text of the label
	 */
	public Axis(String labelText) {
	}

	/**
	 *  Create an axis using the given label
	 * 
	 *  @param label
	 */
	public Axis(com.jidesoft.chart.annotation.AutoPositionedLabel label) {
	}

	/**
	 *  Create an axis using the supplied minimum and maximum values to set the range of the axis. This assumes we are
	 *  using a purely numerical axis (rather than categorical values or a time line).
	 * 
	 *  @param min the minimum value of the range
	 *  @param max the maximum value of the range
	 */
	public Axis(double min, double max) {
	}

	/**
	 *  Create an axis using the given range to define the minimum and maximum values
	 * 
	 *  @param newRange the new range of the axis
	 */
	public Axis(<any> newRange) {
	}

	/**
	 *  Create an Axis, using the text as the label
	 * 
	 *  @param newRange the range of the axis, defining minimum and maximum values
	 *  @param text     the text to use in the label for the axis
	 */
	public Axis(<any> newRange, String labelText) {
	}

	/**
	 *  A property change event will be fired when this axis changes its range.
	 * 
	 *  @param listener the listener to receive notification of changes
	 */
	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Remove a listener that receives notification of property changes.
	 * 
	 *  @param listener the listener
	 */
	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	@java.lang.SuppressWarnings("unchecked")
	public TickCalculator getTickCalculator() {
	}

	@java.lang.SuppressWarnings("unchecked")
	public void setTickCalculator(TickCalculator tickCalculator) {
	}

	public com.jidesoft.chart.render.AxisRenderer getAxisRenderer() {
	}

	public double getTickLabelRotation() {
	}

	public void setTickLabelRotation(double tickLabelRotation) {
	}

	/**
	 *  @return whether the axis is currently visible
	 */
	public boolean isVisible() {
	}

	/**
	 *  Specify whether the axis should be visible. An invisible axis takes up no space. Axes are visible by default.
	 *  @param visible true if the axis should be visible; false to make it invisible.
	 */
	public void setVisible(boolean visible) {
	}

	/**
	 *  @return whether the label should be visible
	 */
	public boolean isLabelVisible() {
	}

	/**
	 *  Specify whether the axis label is visible.
	 *  <p>Sometimes you might want to specify an axis label, but then set it to be invisible. This can help, 
	 *  for example, when aligning the charts in a multi-chart layout</p>
	 *  @param labelVisible whether the label should be visible
	 */
	public void setLabelVisible(boolean labelVisible) {
	}

	public Integer getLabelWidth() {
	}

	/**
	 *  The label width is the variable part of the width of the axis.
	 *  <p>
	 *  Use this only to fix the label width at a specific value; otherwise the label width is automatically computed.
	 *  </p>
	 *  @param labelWidth
	 */
	public void setLabelWidth(Integer labelWidth) {
	}

	/**
	 *  Determines how much space to allow for the tick labels at the side of a y axis
	 * 
	 *  @return the (maximum) tick label width in pixels
	 */
	public int labelWidth(java.awt.Graphics g, java.awt.Font tickFont, com.jidesoft.chart.Orientation orientation) {
	}

	/**
	 *  Sets the renderer for the axis
	 * 
	 *  @param axisRenderer
	 */
	public void setAxisRenderer(com.jidesoft.chart.render.AxisRenderer axisRenderer) {
	}

	/**
	 *  Sets the range for the axis to be a numeric range with the supplied minimum and maximum values
	 * 
	 *  @param min the minimum value for the range
	 *  @param max the maximum value for the range
	 */
	public void setRange(double min, double max) {
	}

	/**
	 *  Sets the range for the axis to be the supplied range
	 * 
	 *  @param newValue
	 */
	public void setRange(<any> newValue) {
	}

	/**
	 *  Set the range of the axis.
	 */
	public void setRange(<any> newValue, boolean updateOtherAxes) {
	}

	public <any> getDomain() {
	}

	public void setDomain(<any> domain) {
	}

	/**
	 *  Returns the range of values for this axis, after the transformation (if any) has been applied
	 * 
	 *  @return a Range
	 */
	public <any> getOutputRange() {
	}

	/**
	 *  @return the range of values for this axis, before the transformation (if any) has been applied
	 */
	public <any> getRange() {
	}

	public com.jidesoft.chart.model.InvertibleTransform getAxisTransform() {
	}

	public void setAxisTransform(com.jidesoft.chart.model.InvertibleTransform axisTransform) {
	}

	public com.jidesoft.chart.annotation.AutoPositionedLabel getLabel() {
	}

	public void setLabel(String text) {
	}

	public void setLabel(com.jidesoft.chart.annotation.AutoPositionedLabel newValue) {
	}

	/**
	 *  @return the maximum of the input range
	 */
	public double maximum() {
	}

	public double minimum() {
	}

	public double midPoint() {
	}

	public AxisPlacement getPlacement() {
	}

	public void setPlacement(AxisPlacement placement) {
	}

	public double getFloatingPosition() {
	}

	/**
	 *  Sets the floating position. The floating position is the real axis position when the axis is being displayed in
	 *  floating mode. By default it will be zero.
	 * 
	 *  @param floatingPos the new floating position as a real coordinate value
	 */
	public void setFloatingPosition(double floatingPos) {
	}

	/**
	 *  @return the color to use when painting the axis
	 */
	public java.awt.Color getAxisColor() {
	}

	/**
	 *  Specify the color to use when painting the axis
	 *  @param axisColor
	 */
	public void setAxisColor(java.awt.Color axisColor) {
	}

	public Tick[] getTicks() {
	}

	@java.lang.SuppressWarnings("unchecked")
	protected void updateTicks() {
	}

	/**
	 *  @return whether ticks are visible
	 */
	public boolean isTicksVisible() {
	}

	public void setTicksVisible(boolean ticksVisible) {
	}

	public boolean isFlipped() {
	}

	public void setFlipped(boolean flipped) {
	}

	/**
	 *  Adjusts this axis by zooming on the realValue and using the supplied magnification factor. It keeps the midpoint
	 *  of the axis static.
	 * 
	 *  @param axis                the axis to be zoomed
	 *  @param magnificationFactor the factor by which we wish to zoom
	 *  @return the new zoomed range
	 */
	public static <any> zoom(Axis axis, double magnificationFactor) {
	}

	/**
	 *  This method zooms by keeping the given position (for example, the origin) of an axis static
	 * 
	 *  @param axis
	 *  @param magnificationFactor
	 *  @return the new zoomed range for the axis
	 */
	public static <any> zoomFromPosition(Axis axis, double magnificationFactor, double position) {
	}

	/**
	 *  Render the axis onto the supplied graphics context
	 *  @param g the Graphics context
	 *  @param x the x coordinate for the axis
	 *  @param y the y coordinate for the axis
	 *  @param length the length of the axis
	 *  @param orientation the orientation of the axis; horizontal or vertical
	 */
	public void render(java.awt.Graphics g, int x, int y, int length, com.jidesoft.chart.Orientation orientation) {
	}

	@java.lang.Override
	public String toString() {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}
}
