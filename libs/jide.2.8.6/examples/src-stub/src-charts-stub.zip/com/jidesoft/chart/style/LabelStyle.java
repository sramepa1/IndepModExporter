/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


/**
 *  @author Simon White (swhite@catalysoft.com)
 */
public class LabelStyle extends AbstractStyle {

	public LabelStyle() {
	}

	public LabelStyle(java.awt.Font font) {
	}

	public LabelStyle(double rotation) {
	}

	public LabelStyle(java.awt.Color color, java.awt.Font font) {
	}

	public LabelStyle(java.awt.Color color, java.awt.Font font, double rotation) {
	}

	public java.awt.Font getFont() {
	}

	public void setFont(java.awt.Font font) {
	}

	public Double getRotation() {
	}

	public void setRotation(Double rotation) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
