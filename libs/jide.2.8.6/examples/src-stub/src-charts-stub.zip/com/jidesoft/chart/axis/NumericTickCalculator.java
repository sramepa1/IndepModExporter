/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


public interface NumericTickCalculator extends TickCalculator {
 {

	public java.text.NumberFormat getNumberFormat();

	public void setNumberFormat(java.text.NumberFormat numberFormat);

	/**
	 *  The string to use for the number format is as used
	 *  in the applyPattern method of <code>DecimalFormat</code>.
	 *  @param numberFormat
	 */
	public void setNumberFormat(String numberFormat);
}
