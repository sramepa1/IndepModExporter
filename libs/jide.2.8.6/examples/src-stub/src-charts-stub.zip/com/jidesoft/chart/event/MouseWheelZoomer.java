/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  Used for controlling zooming on a Chart component using the mouse wheel.
 *  
 *  @author Simon White (swhite@catalysoft.com)
 */
public class MouseWheelZoomer implements MouseHandler, java.awt.event.MouseWheelListener {
 {

	/**
	 *  Create a zooming facility and apply it to both the X and Y axes of the
	 *  supplied Chart component.
	 *  
	 *  @param newChart
	 */
	public MouseWheelZoomer(com.jidesoft.chart.Chart newChart) {
	}

	/**
	 *  Use of this constructor allows you to specify a zoom that is on just one
	 *  of the two axes. (You could have a zoom on neither, but what is the point
	 *  of that?)
	 *  
	 *  @param newChart
	 *             the Chart instance to which the zoomer should be added
	 *  @param zoomHorizontally
	 *             whether horizontal zooming should be allowed
	 *  @param zoomVertically
	 *             whether vertical zooming should be allowed
	 */
	public MouseWheelZoomer(com.jidesoft.chart.Chart newChart, boolean zoomHorizontally, boolean zoomVertically) {
	}

	public boolean isHorizontalZoom() {
	}

	/**
	 *  Specify whether the horizontal zoom is active
	 *  
	 *  @param horizontalZoom
	 *             a boolean to indicate whether a zoom should occur on the
	 *             horizontal axis
	 */
	public void setHorizontalZoom(boolean horizontalZoom) {
	}

	public boolean isVerticalZoom() {
	}

	/**
	 *  Specify whether the vertical zoom is active
	 *  
	 *  @param verticalZoom
	 *             a boolean to indicate whether a zoom should occur on the
	 *             vertical axis
	 */
	public void setVerticalZoom(boolean verticalZoom) {
	}

	public void addZoomListener(ZoomListener listener) {
	}

	public void removeZoomListener(ZoomListener listener) {
	}

	protected void fireZoom(java.awt.Point zoomPoint, ZoomDirection direction) {
	}

	public void mouseDragged(java.awt.event.MouseEvent event) {
	}

	public void mouseMoved(java.awt.event.MouseEvent event) {
	}

	public void mouseWheelMoved(java.awt.event.MouseWheelEvent e) {
	}

	public boolean isHandled() {
	}

	public void setHandled(boolean handled) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}
}
