/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


public class ChartUIDefaultsCustomizer {

	public ChartUIDefaultsCustomizer() {
	}

	public void customize(javax.swing.UIDefaults defaults) {
	}
}
