/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  @author Simon White (swhite@catalysoft.com) Specifies whether a zoom is "into" or "out of" the object of interest.
 */
public final class ZoomDirection extends Enum {

	public static final ZoomDirection IN;

	public static final ZoomDirection OUT;

	public static ZoomDirection[] values() {
	}

	public static ZoomDirection valueOf(String name) {
	}
}
