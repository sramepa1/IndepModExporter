/**
 *  Contains classes to support interpolation of chart models, either for aesthetics or for better approximations of functions.
 */
package com.jidesoft.chart.fit;


/**
 *  Uses Ordinary Least Squares regression to fit a line to a dataset
 * 
 *  @author Ian Fairman (ifairman@catalysoft.com)
 *  @author Simon White (swhite@catalysoft.com)
 *  @see <a href="http://en.wikipedia.org/wiki/Simple_linear_regression">Wikipedia on Simple Linear Regression</a>
 */
public class LineFitter implements CurveFitter {
 {

	public static LineFitter getInstance() {
	}

	/**
	 *  Performs linear regression on a ChartModel and returns a <code>ChartModel</code> that encodes the line
	 * 
	 *  @param model
	 *  @return a new ChartModel with two points defining the line of the regression
	 */
	public com.jidesoft.chart.model.AnnotatedChartModel performRegression(String name, com.jidesoft.chart.model.ChartModel model, <any> xRange, int numPoints) {
	}

	public com.jidesoft.chart.model.AnnotatedChartModel createModel(Polynomial line, <any> xRange, int numPoints) {
	}

	/**
	 *  @param name      the name of the new model
	 *  @param line      the line that the new model should describe
	 *  @param xRange    the range over which the line segment should be given
	 *  @param numPoints ignored for linear models
	 *  @return a ChartModel to approximate the supplied polynomial
	 */
	public com.jidesoft.chart.model.AnnotatedChartModel createModel(String name, Polynomial line, <any> xRange, int numPoints) {
	}

	public com.jidesoft.chart.model.AnnotatedChartModel createModel(String name, Polynomial polynomial, Double[] xs) {
	}

	/**
	 *  Performs linear regression on a ChartModel and returns a <code>Line</code>
	 * 
	 *  @param model
	 *  @return a line summarising the supplied ChartModel
	 */
	public Polynomial performRegression(com.jidesoft.chart.model.ChartModel model) {
	}

	public Polynomial performRegression(java.util.List points) {
	}
}
