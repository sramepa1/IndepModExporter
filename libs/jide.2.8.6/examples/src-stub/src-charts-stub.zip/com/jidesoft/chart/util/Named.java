/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


public interface Named {

	public String getName();
}
