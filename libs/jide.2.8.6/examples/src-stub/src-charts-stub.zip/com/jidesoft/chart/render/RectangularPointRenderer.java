/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


public class RectangularPointRenderer extends AbstractPointRenderer {

	public RectangularPointRenderer() {
	}

	public java.awt.Shape renderPoint(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable point, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y) {
	}
}
