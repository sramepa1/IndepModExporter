/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


public interface Product {
}
