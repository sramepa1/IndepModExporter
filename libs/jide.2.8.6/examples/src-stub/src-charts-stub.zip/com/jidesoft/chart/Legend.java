/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  A graphical component to display a legend corresponding to a Chart.
 *  
 *  @author Simon White (swhite@catalysoft.com)
 */
public class Legend extends javax.swing.JPanel {

	/**
	 *  Create a Legend object. You will need to call addChart() to specify the chart(s) to which the legend
	 *  applies.
	 */
	public Legend() {
	}

	/**
	 *  Create a Legend from the supplied chart and using 1 column for the layout of the entries
	 *  @param chart the chart for which to create a legend
	 */
	public Legend(Chart chart) {
	}

	/**
	 *  Create a Legend from the supplied chart and using the supplied number of columns
	 *  @param chart the chart for which to create a legend
	 *  @param cols the number of columns to use in the layout of the legend
	 */
	public Legend(Chart chart, int cols) {
	}

	/**
	 *  Add a chart to the legend; i.e. allow the legend component to extract the chart models and their styles from
	 *  the supplied chart object and add them to the legend.
	 *  @param chart
	 */
	public void addChart(Chart chart) {
	}

	/**
	 *  Remove the models contained by the supplied chart from the legend
	 *  @param chart the chart for which the models should be removed
	 */
	public void removeChart(Chart chart) {
	}

	/**
	 *  Set the number of columns to use for the items in the legend
	 *  @param columns
	 */
	public void setColumns(int columns) {
	}

	/**
	 *  Clear references to all charts from this legend object.
	 */
	public void clear() {
	}

	/**
	 *  @return the title of the legend
	 */
	public String getTitle() {
	}

	/**
	 *  Set the title to use for this legend. Internally, this creates a JLabel. To customize the appearance of the
	 *  label, you can either retrieve it using <code>getTitleLabel()</code> and then modify it; or create the label
	 *  yourself and supply it using the <code>setTitleLabel()</code> method.
	 *  @param title the title to use for the legend
	 *  @see #getTitleLabel()
	 *  @see #setTitleLabel(JLabel)
	 */
	public void setTitle(String title) {
	}

	/**
	 *  @return the title label
	 */
	public javax.swing.JLabel getTitleLabel() {
	}

	/**
	 *  Sets the title for this legend
	 *  @param titleLabel the ready-made JLabel to use for the title
	 */
	public void setTitleLabel(javax.swing.JLabel titleLabel) {
	}

	public boolean isGenerateFromPoints() {
	}

	public void setGenerateFromPoints(boolean generateFromPoints) {
	}

	public boolean isOrderReversed() {
	}

	/**
	 *  Specify whether the order of iterating through the models should be reversed when
	 *  generating the legend. By default, the order is the order in which the models were added
	 *  to the Chart.
	 *  @param orderReversed whether to reverse the order
	 */
	public void setOrderReversed(boolean orderReversed) {
	}

	/**
	 *  Recreate the legend object, taking account of the specified number of columns
	 */
	protected void updateLegend() {
	}
}
