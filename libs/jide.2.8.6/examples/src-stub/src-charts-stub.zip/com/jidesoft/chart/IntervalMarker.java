/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  A Drawable object that can be added to a Chart to mark an interval on one of the axes.
 *  The orientation determines whether the interval applies to the x or y axis.
 *  By default, the orientation is vertical.
 */
public class IntervalMarker implements Drawable {
 {

	public static final String PROPERTY_VISIBLE = "Visible";

	public static final String PROPERTY_ORIENTATION = "Orientation";

	public static final String PROPERTY_CHART = "Chart";

	public static final String PROPERTY_COLOR = "Color";

	public static final String PROPERTY_PAINT = "Paint";

	public static final String PROPERTY_MAX = "Maximum";

	public static final String PROPERTY_MIN = "Minimum";

	protected final java.beans.PropertyChangeSupport support;

	/**
	 *  Zero-argument Constructor. Usually you would create an IntervalMarker with one of the other constructors
	 *  that sets properties at object creation time.
	 */
	public IntervalMarker() {
	}

	/**
	 *  Create a marker and set the Chart object to which this marker applies
	 *  @param newChart the chart object to which this marker applies.
	 */
	public IntervalMarker(Chart newChart) {
	}

	/**
	 *  Create an IntervalMarker and set some properties
	 *  @param newChart the chart to which this marker applies
	 *  @param min the minimum value for the interval
	 *  @param max the maximum value for the interval
	 *  @param c the color for the interval
	 */
	public IntervalMarker(Chart newChart, double min, double max, java.awt.Color c) {
	}

	/**
	 *  Create an IntervalMarker and set properties
	 *  @param newChart the chart to which this marker applies
	 *  @param orientation the orientation of the interval. Effectively this specifies whether the interval
	 *  applies to the x or the y axis
	 *  @param min the minimum value for the interval
	 *  @param max the maximum value for the interval
	 *  @param c the color for the interval
	 */
	public IntervalMarker(Chart newChart, Orientation orientation, double min, double max, java.awt.Color c) {
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  @return the Chart object with which this Interval marker is associated
	 */
	public Chart getChart() {
	}

	/**
	 *  @param chart sets the Chart object with which this Interval marker is associated
	 */
	public void setChart(Chart chart) {
	}

	/**
	 *  @return whether the marker object is currently visible
	 */
	public boolean isVisible() {
	}

	/**
	 *  Specify whether this marker object should be drawn. Sometimes it may be useful to keep it associated with
	 *  the chart but to temporarily remove it visually from the chart.
	 *  @param visible whether the marker should be drawn
	 */
	public void setVisible(boolean visible) {
	}

	/**
	 *  @return the color of the marker object. If a paint is used that is not a color, this returns null.
	 */
	public java.awt.Color getColor() {
	}

	/**
	 *  Specify the color of the marker object
	 *  @param color the new color
	 */
	public void setColor(java.awt.Color color) {
	}

	/**
	 *  @return the paint used for the marker object
	 */
	public java.awt.Paint getPaint() {
	}

	/**
	 *  Specify the paint to use for the marker object. If the paint happens to be a Color, you could call
	 *  either this method or setColor - the end result is the same.
	 *  @param paint the new paint.
	 */
	public void setPaint(java.awt.Paint paint) {
	}

	/**
	 *  @return the orientation of the interval
	 */
	public Orientation getOrientation() {
	}

	/**
	 *  If the orientation of the interval is vertical it means it is applied to the x axis; if horizontal it
	 *  is applied to the y axis.
	 *  @param orientation the orientation of the interval
	 */
	public void setOrientation(Orientation orientation) {
	}

	/**
	 *  @return the minimum value of the range
	 */
	public double getMin() {
	}

	/**
	 *  @return the maximum value of the range
	 */
	public double getMax() {
	}

	/**
	 *  Specify the minimum value for the interval
	 *  @param p the new minimum
	 */
	public void setMin(double p) {
	}

	/**
	 *  Specify the maximum value for the interval
	 *  @param p
	 */
	public void setMax(double p) {
	}

	/**
	 *  Sets the interval with minimum and maximum values
	 *  @param min the new minimum for the interval
	 *  @param max the new maximum for the interval
	 */
	public void setInterval(double min, double max) {
	}

	/**
	 *  The callback method to draw the object. It cannot be drawn if the chart property is not set or if
	 *  either the xInterval or yInterval is null.
	 */
	public void draw(java.awt.Graphics g) {
	}
}
