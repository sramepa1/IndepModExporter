/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  @author Simon White (swhite@catalysoft.com)
 *  A trivial implementation of Positionable
 */
public class RealPosition {

	public RealPosition(double position) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public double position() {
	}

	@java.lang.Override
	public String toString() {
	}

	public int compareTo(Positionable o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
