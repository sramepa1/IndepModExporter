/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  A class that contains a pair of the same type of object. Note that you can use wildcards when creating Pairs: <code>
 *  Pair<? extends Number> p = new Pair<Integer>(1, 2); </code>
 * 
 *  @author swhite@catalysoft.com
 *  @param <T>
 */
public class Pair {

	public Pair() {
	}

	public Pair(Object newFirst, Object newSecond) {
	}

	public void setFirst(Object first) {
	}

	public void setSecond(Object second) {
	}

	public Object getFirst() {
	}

	public Object getSecond() {
	}

	@java.lang.Override
	public String toString() {
	}
}
