/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  @author Simon White (swhite@catalysoft.com)
 */
public interface PanListener {

	public void panChanged(PanEvent event);
}
