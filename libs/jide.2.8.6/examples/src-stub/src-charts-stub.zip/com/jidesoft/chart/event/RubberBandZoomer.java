/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  This class listens to mouse movements and draws 'rubber band' selections when added to an instance of Chart.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class RubberBandZoomer implements com.jidesoft.chart.Drawable, java.awt.event.MouseMotionListener, java.awt.event.MouseListener {
 {

	public RubberBandZoomer(javax.swing.JComponent component) {
	}

	public void addZoomListener(ZoomListener listener) {
	}

	public void removeZoomListener(ZoomListener listener) {
	}

	protected void fireZoomIn(java.awt.Rectangle selection) {
	}

	protected void fireZoomOut(java.awt.Point p) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	public void draw(java.awt.Graphics g) {
	}
}
