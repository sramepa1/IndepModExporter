/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  A common parent class for SelectionZoomEvents and PointZoomEvents
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public abstract class ChartSelectionEvent extends java.util.EventObject {

	/**
	 *  @param source
	 */
	public ChartSelectionEvent(Object source) {
	}

	public abstract ZoomDirection getDirection() {
	}

	public abstract Object getLocation() {
	}
}
