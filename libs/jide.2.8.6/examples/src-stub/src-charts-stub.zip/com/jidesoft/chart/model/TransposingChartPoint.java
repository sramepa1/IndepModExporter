/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A class that represents a point but makes it easy to swap X and Y values. Use this instead of ChartPoint if you want
 *  to be able to transpose a graph
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class TransposingChartPoint extends ChartPoint {

	public TransposingChartPoint(double x, double y) {
	}

	public TransposingChartPoint(Positionable x, Positionable y) {
	}

	public TransposingChartPoint(Positionable x, Positionable y, Highlight newHighlight) {
	}

	public TransposingChartPoint(ChartPoint source) {
	}

	public boolean isTransposing() {
	}

	public void setTransposing(boolean transposing) {
	}

	@java.lang.Override
	public Positionable getX() {
	}

	@java.lang.Override
	public Positionable getY() {
	}

	@java.lang.Override
	public String toString() {
	}
}
