/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A chart point in user/domain coordinates. A ChartPoint can have any number of highlights associated with it. A
 *  highlight is a semantic tag that may be interpreted by a view component and may affect the rendering.
 * 
 *  @author swhite@catalysoft.com
 */
public class ChartPoint implements Chartable, Highlightable {
 {

	public ChartPoint() {
	}

	public ChartPoint(double x, double y) {
	}

	public ChartPoint(double x, double y, Highlight h) {
	}

	public ChartPoint(Positionable x, Positionable y) {
	}

	public ChartPoint(Positionable x, double y) {
	}

	public ChartPoint(Positionable x, double y, Highlight h) {
	}

	public ChartPoint(double x, Positionable y) {
	}

	public ChartPoint(Positionable x, Positionable y, Highlight h) {
	}

	public ChartPoint(ChartPoint source) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public Positionable getX() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public Positionable getY() {
	}

	public void setX(Positionable newXPos) {
	}

	public void setY(Positionable newYPos) {
	}

	public Highlight getHighlight() {
	}

	/**
	 *  Is the highlight for this chart point the same as the supplied highlight?
	 *  If the supplied highlight is null, this always returns false.
	 *  @param h the highlight to test
	 *  @return true if the supplied highlight is the same as the result of getHighlight()
	 */
	public boolean isHighlight(Highlight h) {
	}

	public void setHighlight(Highlight h) {
	}

	public int compareTo(Chartable other) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	@java.lang.Override
	public String toString() {
	}
}
