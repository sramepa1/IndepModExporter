/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  Sorts the points of a chart model in increasing order
 *  @author Simon
 */
public class SortedChartModel implements AnnotatedChartModel, ChartModelListener {
 {

	public SortedChartModel() {
	}

	public SortedChartModel(ChartModel delegate, com.jidesoft.chart.Orientation orientation) {
	}

	public com.jidesoft.chart.Orientation getOrientation() {
	}

	public void setOrientation(com.jidesoft.chart.Orientation orientation) {
	}

	public void setDelegate(ChartModel newDelegate) {
	}

	public ChartModel getDelegate() {
	}

	public void addChartModelListener(ChartModelListener listener) {
	}

	public void removeChartModelListener(ChartModelListener listener) {
	}

	protected void fireModelChanged() {
	}

	public void chartModelChanged() {
	}

	public Integer getDelegateIndex(int n) {
	}

	public void update() {
	}

	public String getName() {
	}

	public Chartable getPoint(int n) {
	}

	public int getPointCount() {
	}

	public boolean isCyclical() {
	}

	public java.util.Iterator iterator() {
	}

	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	public int getAnnotationCount() {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}
}
