/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


/**
 *  The style for a line of the chart
 * 
 *  @author Simon
 */
public class LineStyle extends AbstractStyle {

	public static final int DEFAULT_WIDTH = 1;

	public static final java.awt.BasicStroke DEFAULT_STROKE;

	public LineStyle() {
	}

	public LineStyle(int width) {
	}

	public LineStyle(java.awt.BasicStroke stroke) {
	}

	/**
	 *  @return the currently used fill paint
	 */
	public java.awt.Paint getFill() {
	}

	/**
	 *  When set, this specifies a fill to use between the line of the model and the x axis.
	 * 
	 *  @param fill a paint - often a GradientPaint
	 */
	public void setFill(java.awt.Paint fill) {
	}

	public void setWidth(int width) {
	}

	public int getWidth() {
	}

	public java.awt.BasicStroke getStroke() {
	}

	public void setStroke(java.awt.BasicStroke stroke) {
	}

	@java.lang.Override
	public String toString() {
	}
}
