/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  @author Simon White (swhite@catalysoft.com)
 */
public interface ZoomListener {

	public void zoomChanged(ChartSelectionEvent event);
}
