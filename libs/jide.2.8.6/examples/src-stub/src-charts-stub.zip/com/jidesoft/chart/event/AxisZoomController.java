/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  A GUI element for controlling the zooming of an axis. As the user of this component in the user interface you can
 *  elect to zoom in or out by pressing the appropriate button. When the user does this, the component fires a ZoomEvent
 *  to its listeners and the listener can determine how much to zoom. The listener will probably effect a zoom by using
 *  the <code>zoom()</code> method on the Axis class.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class AxisZoomController extends javax.swing.JPanel {

	public AxisZoomController() {
	}

	public AxisZoomController(com.jidesoft.chart.axis.Axis[] newAxes) {
	}

	protected void init() {
	}

	public void addZoomListener(ZoomListener listener) {
	}

	public void removeZoomListener(ZoomListener listener) {
	}

	protected void fireZoomAction(ZoomDirection direction) {
	}

	public void setZoomOutText(String text) {
	}

	public void setZoomInText(String text) {
	}

	public void setZoomOutIcon(javax.swing.Icon icon) {
	}

	public void setZoomInIcon(javax.swing.Icon icon) {
	}
}
