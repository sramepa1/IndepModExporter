/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


/**
 *  The style to use when displaying bar charts
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class BarStyle extends AbstractStyle {

	public BarStyle() {
	}

	public Integer getBarWidth() {
	}

	public void setBarWidth(Integer barWidth) {
	}

	public com.jidesoft.chart.Orientation getOrientation() {
	}

	public void setOrientation(com.jidesoft.chart.Orientation orientation) {
	}
}
