/**
 *  This package contains classes to support the dynamic generation of charts to serve up from a web server.
 */
package com.jidesoft.chart.servlet;


/**
 *  This class is intended for use in servlet-based web servers (such as Apache Tomcat), so that charts can be generated
 *  dynamically and included in a web page. <br> <b>Note:</b> This class has not been extensively tested and should be
 *  treated as a proof of concept/experimental!
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartServlet extends HttpServlet {

	public ChartServlet() {
	}

	@java.lang.Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
	}
}
