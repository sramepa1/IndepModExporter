/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  An affine transform does not provide for logarithmic conversions so we need a more general conversion mechanism. This
 *  class contains an affine transform but can also contain other transform(s) so that we can support the logarithmic and
 *  other transformations.
 * 
 *  @author Simon White
 */
public class UserToPixelTransform {

	public UserToPixelTransform() {
	}

	public UserToPixelTransform(java.awt.geom.AffineTransform affineT) {
	}

	public java.awt.geom.AffineTransform getAffineTransform() {
	}

	public void setAffineTransform(java.awt.geom.AffineTransform affineTransform) {
	}

	public void setTranslation(Double x, Double y) {
	}

	public model.Transform getXTransform() {
	}

	public void setXTransform(model.InvertibleTransform transform) {
	}

	public model.Transform getYTransform() {
	}

	public void setYTransform(model.InvertibleTransform transform) {
	}

	/**
	 *  Transforms a user coordinate to a pixel coordinate
	 * 
	 *  @param src the user coordinate
	 *  @return a pixel coordinate
	 */
	public java.awt.geom.Point2D transform(java.awt.geom.Point2D src) {
	}

	/**
	 *  Transforms a pixel coordinate to a user coordinate
	 * 
	 *  @param src the source point in pixel coordinates
	 *  @return a point in user coordinates
	 * 
	 *  @throws NoninvertibleTransformException
	 */
	public java.awt.geom.Point2D inverseTransform(java.awt.geom.Point2D src) {
	}
}
