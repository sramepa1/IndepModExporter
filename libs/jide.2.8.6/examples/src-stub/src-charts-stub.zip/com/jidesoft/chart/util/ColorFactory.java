/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  The idea of this class is to produce any number of colors, but the colors should be different to one another so that
 *  they can picked out visually in a chart.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ColorFactory {

	public ColorFactory() {
	}

	/**
	 *  This constructor allows you to set the transparency of the generated colors as well as provide a sequence of
	 *  colors to use initially
	 * 
	 *  @param transparency     a value between 0 (transparent) and 255 (opaque)
	 *  @param newInitialColors
	 */
	public ColorFactory(int transparency, java.awt.Color[] newInitialColors) {
	}

	/**
	 *  Sets up a predetermined sequence of colors to use initially
	 * 
	 *  @param newInitialColors the colors to start with
	 */
	public ColorFactory(java.awt.Color[] newInitialColors) {
	}

	/**
	 *  @return the transparency value
	 */
	public int getTransparency() {
	}

	/**
	 *  Sets the transparency value
	 * 
	 *  @param transparency the new transparency value
	 */
	public void setTransparency(int transparency) {
	}

	/**
	 *  Clear the set of generated colors
	 */
	public void clear() {
	}

	/**
	 *  Create and return a new color. The color is chosen randomly, but an attempt is made to make the color different
	 *  to colors generated thus far.
	 * 
	 *  @return a new color
	 */
	public java.awt.Color create() {
	}

	/**
	 *  The Euclidean distance between the two colors in red, green, blue space.
	 * 
	 *  @param color1 a color
	 *  @param color2 another color
	 *  @return the distance between the two colors
	 */
	public static double distance(java.awt.Color color1, java.awt.Color color2) {
	}

	/**
	 *  Intensify a colour by applying the supplied offset
	 *  @param c the original colour
	 *  @param offset a value between -255 and 255 to add to each of the rgb components
	 *  @return a new colour with the offset applied. If the new colour would be negative it is set to 0 and if 
	 *  greater than 255 it is set to 255.
	 */
	public static java.awt.Color intensify(java.awt.Color c, int offset) {
	}

	/**
	 *  This method of intensifying a colour distributes intensity wherever it can. If one of the primary colours gets 
	 *  to 255, then the colour points that the colour would have received are given to the other colours.
	 *  @param c
	 *  @param offset
	 *  @return
	 */
	public static java.awt.Color intensify2(java.awt.Color c, int offset) {
	}
}
