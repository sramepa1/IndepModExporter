/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


public class DefaultNumericTickCalculator implements NumericTickCalculator {
 {

	public static final String PROPERTY_NUMBER_FORMAT = "numberFormat";

	public DefaultNumericTickCalculator() {
	}

	public java.text.NumberFormat getNumberFormat() {
	}

	/**
	 *  By default the number format used for generating the ticks uses a maximum of 2 digits for the fractional part.
	 * 
	 *  @param numberFormat the new number format object
	 */
	public void setNumberFormat(java.text.NumberFormat numberFormat) {
	}

	/**
	 *  The string to use for the number format is as used
	 *  in the applyPattern method of <code>DecimalFormat</code>.
	 *  @param numberFormat
	 */
	public void setNumberFormat(String numberFormat) {
	}

	/**
	 *  Works out where to place the tick markers
	 */
	public Tick[] calculateTicks(<any> r) {
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}
}
