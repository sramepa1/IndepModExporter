/**
 *  The package contains classes for annotating a chart with images and/or labels in JIDE Charts product.
 */
package com.jidesoft.chart.annotation;


/**
 *  A label that is centred on the chart. Usually used for the title of a Chart
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class AutoPositionedLabel extends AbstractLabel {

	/**
	 *  Zero-argument constructor
	 */
	public AutoPositionedLabel() {
	}

	/**
	 *  @param label the text to use for the label
	 *  @param color the color of the label
	 *  @param font the font
	 */
	public AutoPositionedLabel(String label, java.awt.Color color, java.awt.Font font) {
	}

	/**
	 *  @param label the text to use for the label
	 *  @param color the color of the label
	 */
	public AutoPositionedLabel(String label, java.awt.Color color) {
	}

	/**
	 *  @param label the text to use for the label
	 */
	public AutoPositionedLabel(String label) {
	}
}
