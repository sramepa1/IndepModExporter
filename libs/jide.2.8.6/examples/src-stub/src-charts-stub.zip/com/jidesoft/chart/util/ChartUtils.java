/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


public class ChartUtils {

	public ChartUtils() {
	}

	public static void writeGifToFile(java.awt.Component c, java.io.File file) {
	}

	public static void writeJpegToFile(java.awt.Component c, java.io.File file) {
	}

	public static void writePngToFile(java.awt.Component c, java.io.File file) {
	}

	/**
	 *  Paints the component as a PNG image to the supplied output stream
	 *  @param c
	 *  @param stream
	 */
	public static void writeToStream(java.awt.Component c, java.io.OutputStream stream) {
	}

	/**
	 *  Creates a buffered image of type TYPE_INT_RGB 
	 *  from the supplied component. 
	 *  @param component the component to draw
	 *  @return an image of the component
	 */
	public static java.awt.image.BufferedImage createImage(java.awt.Component component) {
	}

	/**
	 *  Creates a buffered image (of the specified type) 
	 *  from the supplied component.
	 *  @param component the component to draw
	 *  @param imageType the type of buffered image to draw
	 *  
	 *  @return an image of the component
	 */
	public static java.awt.image.BufferedImage createImage(java.awt.Component component, int imageType) {
	}

	/**
	 *  Utility method to create a texture paint from a graphics file
	 *  @param observer
	 *  @param fileName the name of a file on the classpath, e.g., com/mycompany/project/images/widget.gif 
	 *  @return a TexturePaint instance
	 */
	public static java.awt.TexturePaint createTexture(javax.swing.JComponent observer, String fileName) {
	}

	/**
	 *  Creates an image from a file on the classpath
	 *  @param path
	 *  @return
	 */
	public static java.awt.Image createImage(String path) {
	}

	/**
	 *  <p>Returns an array of pixels, stored as integers, from a <code>BufferedImage</code>. The pixels are grabbed from
	 *  a rectangular area defined by a location and two dimensions. Calling this method on an image of type different
	 *  from <code>BufferedImage.TYPE_INT_ARGB</code> and <code>BufferedImage.TYPE_INT_RGB</code> will unmanage the
	 *  image.</p>
	 * 
	 *  @param img    the source image
	 *  @param x      the x location at which to start grabbing pixels
	 *  @param y      the y location at which to start grabbing pixels
	 *  @param w      the width of the rectangle of pixels to grab
	 *  @param h      the height of the rectangle of pixels to grab
	 *  @param pixels a pre-allocated array of pixels of size w*h; can be null
	 *  @return <code>pixels</code> if non-null, a new array of integers otherwise
	 * 
	 *  @throws IllegalArgumentException is <code>pixels</code> is non-null and of length &lt; w*h
	 */
	public static int[] getPixels(java.awt.image.BufferedImage img, int x, int y, int w, int h, int[] pixels) {
	}

	/**
	 *  <p>Writes a rectangular area of pixels in the destination <code>BufferedImage</code>. Calling this method on an
	 *  image of type different from <code>BufferedImage.TYPE_INT_ARGB</code> and <code>BufferedImage.TYPE_INT_RGB</code>
	 *  will unmanage the image.</p>
	 * 
	 *  @param img    the destination image
	 *  @param x      the x location at which to start storing pixels
	 *  @param y      the y location at which to start storing pixels
	 *  @param w      the width of the rectangle of pixels to store
	 *  @param h      the height of the rectangle of pixels to store
	 *  @param pixels an array of pixels, stored as integers
	 *  @throws IllegalArgumentException is <code>pixels</code> is non-null and of length &lt; w*h
	 */
	public static void setPixels(java.awt.image.BufferedImage img, int x, int y, int w, int h, int[] pixels) {
	}
}
