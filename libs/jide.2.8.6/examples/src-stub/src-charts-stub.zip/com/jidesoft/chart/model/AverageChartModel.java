/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  @author Simon White (swhite@catalysoft.com)
 */
public class AverageChartModel extends AbstractDelegatingChartModel {

	public AverageChartModel(AnnotatedChartModel[] newDelegates) {
	}

	public AverageChartModel(String name, AnnotatedChartModel[] newDelegates) {
	}

	@java.lang.Override
	public int getAnnotationCount() {
	}

	@java.lang.Override
	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	@java.lang.Override
	protected void update() {
	}

	public static Double average(java.util.List values) {
	}

	/**
	 *  Takes the (y axis) average of the nth points of the supplied chart models. Note that this may not necessarily be
	 *  what you expect.
	 */
	@java.lang.Override
	public Chartable getPoint(int n) {
	}

	@java.lang.Override
	public int getPointCount() {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}

	@java.lang.Override
	public boolean isCyclical() {
	}
}
