/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  <p>A ChartValueReporter shows the position of the 'focus' point as x and y coordinates.
 *  ChartValueReporter supports numeric and time axes. To display a formatted string for a time axis,
 *  use something like the following: </p>
 *  <pre>chartValueReporter.setFormatString("x = %1$tH:%1$tM; y = %2$.3f");</pre>
 *  <p>
 *  This displays the hours and minutes of the time on the x axis, along with a numeric value for the
 *  y axis, given to 3 decimal places.
 *  </p>
 *  @see java.util.Formatter
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartValueReporter extends javax.swing.JPanel implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener {
 {

	/**
	 *  @param newChart the Chart instance for which we wish to create a ChartValueReporter
	 */
	public ChartValueReporter(com.jidesoft.chart.Chart newChart) {
	}

	/**
	 *  Clears the reported value and resets the last known cursor position.
	 */
	protected void clearChartValue() {
	}

	/**
	 *  Updates the reported value with the supplied x and y coordinates
	 *  @param x the x value in user coordinate space
	 *  @param y the y value in user coordinate space
	 */
	protected void updateChartValue(double x, double y) {
	}

	/**
	 *  @return the format string used for reporting the current value in the chart
	 */
	public String getFormatString() {
	}

	/**
	 *  Sets the format string used for displaying the current chart value.
	 *  The string used should be suitable for displaying two floating point values. For example, it could be
	 *  "x = %.3f, y = %.3f"
	 *  @param formatString the format string to use
	 */
	public void setFormatString(String formatString) {
	}

	public String getNoSelectionText() {
	}

	/**
	 *  Set the text to use when no point is selected and there is no chart value to report.
	 *  @param noSelectionText
	 */
	public void setNoSelectionText(String noSelectionText) {
	}

	/**
	 *  @return the x coordinate (in user coordinates) of the current chart value
	 */
	public Double getChartX() {
	}

	/**
	 *  @return the y coordinate (in user coordinates) of the current chart value
	 */
	public Double getChartY() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	/**
	 *  @return the model of interest, if any
	 */
	public com.jidesoft.chart.model.ChartModel getModel() {
	}

	/**
	 *  If you set the model of the ChartValueReporter, then only points from that model will be reported.
	 *  Otherwise points from the nearest model will be reported.
	 *  @param model the model from which points should be reported
	 */
	public void setModel(com.jidesoft.chart.model.ChartModel model) {
	}

	/**
	 *  Update the reported value using the latest known cursor position.
	 *  You should not need to call this method directly.
	 */
	public void update() {
	}
}
