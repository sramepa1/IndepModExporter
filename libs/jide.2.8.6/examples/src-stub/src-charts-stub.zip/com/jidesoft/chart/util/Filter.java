/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  A simple filter interface
 * 
 *  @author swhite@catalysoft.com
 *  @param <T> the type of object that the filter can operate on
 */
public interface Filter {

	/**
	 *  Specifies whether the object should be removed by the filter
	 * 
	 *  @param other
	 *  @return a boolean to indicate whether the object is to be removed
	 */
	public boolean isValueFiltered(Object other);
}
