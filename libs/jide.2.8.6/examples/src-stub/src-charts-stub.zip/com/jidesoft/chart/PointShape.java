/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  Provides predefined shapes for points
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public final class PointShape extends Enum {

	public static final PointShape CIRCLE;

	public static final PointShape DISC;

	public static final PointShape SQUARE;

	public static final PointShape BOX;

	public static final PointShape DIAMOND;

	public static final PointShape DOWN_TRIANGLE;

	public static final PointShape UP_TRIANGLE;

	public static final PointShape HORIZONTAL_LINE;

	public static final PointShape VERTICAL_LINE;

	public static final PointShape UPRIGHT_CROSS;

	public static PointShape[] values() {
	}

	public static PointShape valueOf(String name) {
	}
}
