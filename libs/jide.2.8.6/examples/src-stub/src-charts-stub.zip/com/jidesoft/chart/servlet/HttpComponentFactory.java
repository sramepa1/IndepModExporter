/**
 *  This package contains classes to support the dynamic generation of charts to serve up from a web server.
 */
package com.jidesoft.chart.servlet;


/**
 *  Here, we define a factory interface that returns a Component in response to
 *  an HTTP Request. This means we can have a general server-side mechanism that
 *  generates custom components on demand. 
 *  @author swhite@catalysoft.com
 */
public interface HttpComponentFactory {

	public java.awt.Component getInstance(HttpServletRequest request);
}
