/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  A MouseListener and MouseMotionListener that effects a pan by changing the ranges of the supplied Chart's axes when
 *  the mouse is dragged. <p> As a user of this class, you can find out when a pan has occurred by registering as a
 *  <code>PanListener</code> </p>
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class MouseDragPanner implements MouseHandler {
 {

	public MouseDragPanner(com.jidesoft.chart.Chart newChart) {
	}

	public MouseDragPanner(com.jidesoft.chart.Chart newChart, boolean panHorizontally, boolean panVertically) {
	}

	public boolean isHorizontalPan() {
	}

	public boolean isVerticalPan() {
	}

	public void addPanListener(PanListener listener) {
	}

	public void removePanListener(PanListener listener) {
	}

	protected void firePan() {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseClicked(java.awt.event.MouseEvent event) {
	}

	public void mouseEntered(java.awt.event.MouseEvent event) {
	}

	public void mouseExited(java.awt.event.MouseEvent event) {
	}

	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent event) {
	}

	/**
	 *  If this returns true, the handler has consumed the event.
	 */
	public boolean isHandled() {
	}

	public void setHandled(boolean handled) {
	}

	public void mouseWheelMoved(java.awt.event.MouseWheelEvent e) {
	}
}
