/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


public interface MouseHandler extends java.awt.event.MouseListener, java.awt.event.MouseMotionListener, java.awt.event.MouseWheelListener {
 {

	public void setHandled(boolean handled);

	public boolean isHandled();
}
