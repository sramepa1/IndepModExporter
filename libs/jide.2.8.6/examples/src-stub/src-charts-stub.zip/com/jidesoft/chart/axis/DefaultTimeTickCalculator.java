/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  @author Simon White (swhite@catalysoft.com)
 */
public class DefaultTimeTickCalculator extends AbstractTimeTickCalculator {

	public DefaultTimeTickCalculator() {
	}

	@java.lang.Override
	public Tick[] calculateTicks(<any> r) {
	}

	public static java.util.Calendar min(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double yearsDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double weeksDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double daysDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double hoursDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double minutesDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double secondsDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static long millisDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}
}
