/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


public interface AnnotationModel {

	/**
	 *  @return the number of positioned labels to chart
	 */
	public int getAnnotationCount();

	/**
	 *  Gets the nth annotation.
	 * 
	 *  @param n the index.
	 *  @return the nth annotation
	 */
	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n);

	public boolean isAnnotationsVisible();

	public void setAnnotationsVisible(boolean visible);
}
