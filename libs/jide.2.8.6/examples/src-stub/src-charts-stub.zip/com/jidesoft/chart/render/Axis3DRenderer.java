/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


public class Axis3DRenderer implements AxisRenderer {
 {

	public Axis3DRenderer() {
	}

	/**
	 *  When rendering horizontally the supplied y coordinate is the centre of the rendered breadth
	 */
	public void renderAxis(java.awt.Graphics g, int x, int y, int length, com.jidesoft.chart.Orientation orientation) {
	}

	public int getBreadth() {
	}

	public void setBreadth(int breadth) {
	}
}
