/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  Enables you to iterate through the points in a ChartModel. This is used by some ChartModel implementations to make
 *  the class iterable and therefore usable in a Java 5 for.. loop
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartModelIterator implements java.util.Iterator {
 {

	public ChartModelIterator(ChartModel newModel) {
	}

	public boolean hasNext() {
	}

	public Chartable next() {
	}

	public void remove() {
	}
}
