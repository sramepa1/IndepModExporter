/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


public class NumericAxis extends Axis {

	/**
	 *  Default Constructor
	 */
	public NumericAxis() {
	}

	public NumericAxis(String text) {
	}

	public NumericAxis(com.jidesoft.chart.annotation.AutoPositionedLabel label) {
	}

	public NumericAxis(double min, double max) {
	}

	public NumericAxis(<any> newRange) {
	}

	public NumericAxis(<any> newRange, String text) {
	}

	protected void init() {
	}

	/**
	 *  Sets the number format used when rendering ticks on the axis
	 *  @param numberFormat the format to use
	 *  @see NumberFormat
	 */
	public void setNumberFormat(java.text.NumberFormat numberFormat) {
	}

	/**
	 *  Sets the number format used when rendering ticks on the axis.
	 *  For example, "#0.00" will display the string to 2 decimal places
	 *  @param numberFormat the format string to use
	 *  @see DecimalFormat
	 */
	public void setNumberFormat(String numberFormat) {
	}
}
