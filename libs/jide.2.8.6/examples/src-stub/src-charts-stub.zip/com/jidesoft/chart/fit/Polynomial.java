/**
 *  Contains classes to support interpolation of chart models, either for aesthetics or for better approximations of functions.
 */
package com.jidesoft.chart.fit;


/**
 *  TODO: Could add a special treatment for other powers of x, like square roots
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class Polynomial {

	/**
	 *  Create a polynomial using the supplied coefficients for successive powers of x starting from a constant.
	 *  Therefore for 2x+4, supply the arguments [4, 2].
	 * 
	 *  @param coeffs
	 */
	public Polynomial(Double[] coeffs) {
	}

	public Polynomial(double[] coeffs) {
	}

	public java.util.List getCoefficients() {
	}

	public Double getCoefficient(int index) {
	}

	public void setCoefficients(java.util.List coefficients) {
	}

	public void setCoefficients(Double[] coeffs) {
	}

	/**
	 *  Compute the value of the polynomial for a given x value. This works by starting at the coefficient of the highest
	 *  order term and iteratively multiplying by x and adding the coefficient of the next lower term.
	 * 
	 *  @param x the x value to plug into the expression
	 *  @return the value of the polynomial for the given x value.
	 */
	public double eval(double x) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	@java.lang.Override
	public String toString() {
	}
}
