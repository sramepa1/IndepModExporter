/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


public class RectangularPoint extends ChartPointND {

	public RectangularPoint(double x, double y, double width, double height) {
	}
}
