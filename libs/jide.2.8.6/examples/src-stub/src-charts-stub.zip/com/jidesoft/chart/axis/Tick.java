/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  <code>Tick</code>s are generated at regular intervals along an axis and displayed as little dashed lines on the axis
 *  to give an indication of the gradation.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class Tick {

	/**
	 *  Construct a Tick object. By default the position along the axis is zero.
	 */
	public Tick() {
	}

	/**
	 *  Create a Tick object with the supplied position and label
	 * 
	 *  @param position the new position of the tick along the axis
	 *  @param label    the new label
	 */
	public Tick(double position, String label) {
	}

	/**
	 *  @return the label for this tick
	 */
	public String getLabel() {
	}

	/**
	 *  Sets the label for this tick
	 * 
	 *  @param label
	 */
	public void setLabel(String label) {
	}

	/**
	 *  @return the position of the tick along the axis
	 */
	public double getPosition() {
	}

	/**
	 *  Sets the position of the tick along the axis
	 * 
	 *  @param position
	 */
	public void setPosition(double position) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	@java.lang.Override
	public String toString() {
	}
}
