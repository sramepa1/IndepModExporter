/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


public class ZoomFrame {

	public ZoomFrame(<any> xRange, <any> yRange) {
	}

	public <any> getXRange() {
	}

	public void setXRange(<any> range) {
	}

	public <any> getYRange() {
	}

	public void setYRange(<any> range) {
	}

	@java.lang.Override
	public String toString() {
	}
}
