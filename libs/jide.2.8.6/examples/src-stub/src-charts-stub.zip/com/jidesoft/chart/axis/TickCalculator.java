/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


public interface TickCalculator {

	/**
	 *  Calculate the ticks for this range of values
	 *  @return an array of tick values
	 */
	public Tick[] calculateTicks(<any> range);

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener);
}
