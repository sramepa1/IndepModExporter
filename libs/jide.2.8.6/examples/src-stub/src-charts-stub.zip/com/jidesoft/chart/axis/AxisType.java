/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  Occasionally useful for specifying which of the axis you want to apply some processing to.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public final class AxisType extends Enum {

	public static final AxisType x;

	public static final AxisType y;

	public static AxisType[] values() {
	}

	public static AxisType valueOf(String name) {
	}
}
