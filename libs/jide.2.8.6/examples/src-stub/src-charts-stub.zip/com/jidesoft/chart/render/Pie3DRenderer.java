/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A 3D Pie chart renderer
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class Pie3DRenderer extends AbstractPieSegmentRenderer {

	public Pie3DRenderer() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void renderSegments(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, java.awt.Point center, int radius, int[] angles) {
	}

	/**
	 *  Renders the outlines for a 3d pie chart, only when rollover is activated
	 */
	protected void renderOutlines(boolean isForSelection, java.awt.Graphics2D g2d, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, java.awt.Point center, int w, int h, int[] angles, com.jidesoft.chart.style.ChartStyle style) {
	}
}
