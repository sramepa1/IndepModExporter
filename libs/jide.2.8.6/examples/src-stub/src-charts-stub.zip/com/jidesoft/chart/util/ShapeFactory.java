/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  This class contains some useful static factory methods for generating shapes.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ShapeFactory {

	/**
	 *  Generates an equilateral triangle with one horizontal side and a vertex pointing downwards. The centre coordinates
	 *  provided here are at the centroid of the generated triangle. Note that this means it is not half way in the vertical
	 *  direction, because the centroid divides a cross-section across a triangle in the ratio 2:1 from the vertex to the
	 *  opposing side. <p> <a href="http://en.wikipedia.org/wiki/Triangle">Wikipedia</a> says: <cite> A median of a triangle
	 *  is a straight line through a vertex and the midpoint of the opposite side, and divides the triangle into two equal
	 *  areas. The three medians intersect in a single point, the triangle's centroid. This is also the triangle's center of
	 *  gravity: if the triangle were made out of wood, say, you could balance it on its centroid, or on any line through
	 *  the centroid. The centroid cuts every median in the ratio 2:1, i.e. the distance between a vertex and the centroid
	 *  is twice as large as the distance between the centroid and the midpoint of the opposite side. </cite> </p>
	 * 
	 *  @param xCentre - the x coordinate of the centroid of the generated triangle
	 *  @param yCentre - the y coordinate of the centroid of the generated triangle
	 *  @param side    - the length of the side
	 *  @return a <code>java.awt.Polygon</code> representing the Triangle
	 */
	public static java.awt.Polygon createDownTriangle(double xCentre, double yCentre, int side) {
	}

	/**
	 *  Generates an equilateral triangle with one horizontal side and a vertex pointing upwards. The centre coordinates
	 *  provided here are at the centroid of the generated triangle. Note that this means it is not half way in the vertical
	 *  direction, because the centroid divides a cross-section across a triangle in the ratio 2:1 from the vertex to the
	 *  opposing side. <p> <a href="http://en.wikipedia.org/wiki/Triangle">Wikipedia</a> says: <cite> A median of a triangle
	 *  is a straight line through a vertex and the midpoint of the opposite side, and divides the triangle into two equal
	 *  areas. The three medians intersect in a single point, the triangle's centroid. This is also the triangle's center of
	 *  gravity: if the triangle were made out of wood, say, you could balance it on its centroid, or on any line through
	 *  the centroid. The centroid cuts every median in the ratio 2:1, i.e. the distance between a vertex and the centroid
	 *  is twice as large as the distance between the centroid and the midpoint of the opposite side. </cite> </p>
	 * 
	 *  @param xCentre - the x coordinate of the centroid of the generated triangle
	 *  @param yCentre - the y coordinate of the centroid of the generated triangle
	 *  @param side    - the length of the side
	 *  @return a <code>java.awt.Polygon</code> representing the Triangle
	 */
	public static java.awt.Polygon createUpTriangle(double xCentre, double yCentre, int side) {
	}

	public static java.awt.Polygon createDiamond(double xCentre, double yCentre, int pointSize) {
	}
}
