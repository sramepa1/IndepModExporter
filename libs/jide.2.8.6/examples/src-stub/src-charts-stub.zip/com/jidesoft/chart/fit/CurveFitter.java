/**
 *  Contains classes to support interpolation of chart models, either for aesthetics or for better approximations of functions.
 */
package com.jidesoft.chart.fit;


/**
 *  Changed interface to use lists of points. The points can be ints or doubles or floats depending on which subclass of
 *  Point2D is used
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public interface CurveFitter {

	public com.jidesoft.chart.model.AnnotatedChartModel performRegression(String name, com.jidesoft.chart.model.ChartModel model, <any> xRange, int numPoints);

	public Polynomial performRegression(com.jidesoft.chart.model.ChartModel model);

	public com.jidesoft.chart.model.AnnotatedChartModel createModel(String name, Polynomial polynomial, <any> xRange, int numPoints);

	public com.jidesoft.chart.model.AnnotatedChartModel createModel(Polynomial polynomial, <any> xRange, int numPoints);
}
