/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  The main charting component. By default, used for XY charts, categorical charts, time series charts and bar charts.
 *  Also used for pie charts by changing the chartType property.
 * 
 *  @author swhite@catalysoft.com
 */
public class Chart extends javax.swing.JComponent implements model.ChartModelChangeListener, java.beans.PropertyChangeListener, Animatable, AnimatedChart {
 {

	public static final String PROPERTY_ANIMATE_ON_SHOW = "Animate on Show";

	public static final String PROPERTY_ANIMATION_POSITION = "Animation Position";

	public static final String PROPERTY_ANTI_ALIASING = "AntiAliasing";

	public static final String PROPERTY_AXIS_COLOR = "AxisColor";

	public static final String PROPERTY_BAR_RENDERER = "BarRenderer";

	public static final String PROPERTY_BAR_GAP = "BarGap";

	public static final String PROPERTY_BAR_GROUP_GAP = "BarGroupGap";

	public static final String PROPERTY_BARS_GROUPED = "BarsGrouped";

	public static final String PROPERTY_CHART_BACKGROUND = "ChartBackground";

	public static final String PROPERTY_CURRENT_CHART_POINT = "ChartFocusPoint";

	public static final String PROPERTY_CHART_TYPE = "ChartType";

	public static final String PROPERTY_GRID_COLOR = "GridColor";

	public static final String PROPERTY_HIGHLIGHT_STYLE = "HighlightStyle";

	public static final String PROPERTY_HIGH_QUALITY = "HighQuality";

	public static final String PROPERTY_HORIZONTAL_GRIDLINES_VISIBLE = "HorizontalGridLinesVisible";

	public static final String PROPERTY_HORIZONTAL_GRID_STROKE = "HorizontalGridStroke";

	public static final String PROPERTY_LABEL_COLOR = "LabelColor";

	public static final String PROPERTY_LABELLING_TRACES = "LabellingTraces";

	public static final String PROPERTY_LAZY_RENDERING_THRESHOLD = "LazyRenderingThreshold";

	public static final String PROPERTY_LINE_RENDERER = "LineRenderer";

	public static final String PROPERTY_MODEL = "Model";

	public static final String PROPERTY_PANEL_BACKGROUND = "PanelBackground";

	public static final String PROPERTY_PIE_SEGMENT_RENDERER = "PieSegmentRenderer";

	public static final String PROPERTY_POINT_RENDERER = "PointRenderer";

	public static final String PROPERTY_ROLLOVER_VISIBLE = "Rollover Visible";

	public static final String PROPERTY_SELECTABLE = "Selectable";

	public static final String PROPERTY_SELECTION_SHOWS_EXPLODED_SEGMENTS = "SelectionShowsExplodedSegments";

	public static final String PROPERTY_SELECTION_SHOWS_OUTLINE = "SelectionShowsOutlines";

	public static final String PROPERTY_SHADOW_VISIBLE = "ShadowVisible";

	public static final String PROPERTY_CHART_STYLE = "ChartStyle";

	public static final String PROPERTY_TICK_COLOR = "TickColor";

	public static final String PROPERTY_TICK_FONT = "TickFont";

	public static final String PROPERTY_TICK_LENGTH = "TickLength";

	public static final String PROPERTY_TITLE = "Title";

	public static final String PROPERTY_TITLE_VISIBLE = "TitleVisible";

	public static final String PROPERTY_VERTICAL_GRIDLINES_VISIBLE = "VerticalGridLinesVisible";

	public static final String PROPERTY_VERTICAL_GRID_STROKE = "VerticalGridStroke";

	public static final String PROPERTY_X_AXIS = "XAxis";

	public static final String PROPERTY_Y_AXIS = "YAxis";

	public static int MIN_LEFT_MARGIN;

	public static int MIN_RIGHT_MARGIN;

	public static int MIN_TOP_MARGIN;

	public static int MIN_BOTTOM_MARGIN;

	public Chart() {
	}

	/**
	 *  Create a chart from the supplied model
	 * 
	 *  @param model
	 */
	public Chart(model.ChartModel model) {
	}

	/**
	 *  The idea of this constructor is to encourage the naming of chart components. As a JComponent, it inherits the
	 *  <code>setName</code> method, but many programmers do not use this method. Naming the chart instance is optional
	 *  but can help with testing and debugging.
	 * 
	 *  @param name the name of the Chart instance
	 */
	public Chart(String name) {
	}

	public Chart(java.awt.Dimension size) {
	}

	/**
	 *  Initialise the component by setting defaults and listeners
	 */
	protected void init() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  @return the type of chart, eg. whether XY chart or Pie chart
	 */
	public ChartType getChartType() {
	}

	/**
	 *  Specify the type of chart, eg. whether XY chart or pie chart. By default this is an XY chart.
	 *  @param chartType the new chart type
	 */
	public void setChartType(ChartType chartType) {
	}

	/**
	 *  @return the renderer object responsible for rendering points
	 */
	public render.PointRenderer getPointRenderer() {
	}

	/**
	 *  Specify the point renderer to use
	 *  @param pointRenderer the new point renderer
	 */
	public void setPointRenderer(render.PointRenderer pointRenderer) {
	}

	/**
	 *  @return the renderer object responsible for rendering bars of a bar chart
	 */
	public render.BarRenderer getBarRenderer() {
	}

	/**
	 *  Specify the bar renderer to use
	 *  @param barRenderer the new bar renderer
	 */
	public void setBarRenderer(render.BarRenderer barRenderer) {
	}

	/**
	 *  Specify the diameter of the pie chart, in pixels. Only used when displaying pie charts.
	 *  When this property is not set, a 'best fit' size will be calculated.
	 *  @param diameter the new diameter of pie charts
	 */
	public void setPieDiameter(Integer diameter) {
	}

	/**
	 *  @return the diameter of the pie in a pie chart, in pixels
	 */
	public Integer getPieDiameter() {
	}

	/**
	 *  @return the Stroke used for the style of horizontal lines of the grid
	 */
	public java.awt.Stroke getHorizontalGridStroke() {
	}

	/**
	 *  Sets the stroke used for the style of horizontal lines in the grid of an XY chart
	 *  @param horizontalGridStroke the new Stroke
	 */
	public void setHorizontalGridStroke(java.awt.Stroke horizontalGridStroke) {
	}

	/**
	 *  @return the Stroke currently used for vertical lines of the grid 
	 */
	public java.awt.Stroke getVerticalGridStroke() {
	}

	/**
	 *  Sets the stroke used for the style of vertical lines in the grid of an XY chart
	 *  @param verticalGridStroke the new Stroke
	 */
	public void setVerticalGridStroke(java.awt.Stroke verticalGridStroke) {
	}

	/**
	 *  @return the point corresponding to the shape under the mouse cursor
	 */
	public model.Chartable getCurrentChartPoint() {
	}

	/**
	 *  Determines whether there is a shape rendered that contains the supplied pixel point. If so, a descriptor is
	 *  returned for the corresponding point in the chart model.
	 * 
	 *  @param p a coordinate in pixel space
	 *  @return a point descriptor for the corresponding point in the chart model, if any; otherwise null.
	 */
	public event.PointDescriptor containingShape(java.awt.Point p) {
	}

	/**
	 *  You can use this method to test whether the supplied pixel point is contained by the rendering of a bar. 
	 * 
	 *  @param p the point to be tested
	 *  @return the model point corresponding to the bar, or null if the point is not over a bar
	 */
	public event.PointDescriptor containingBar(java.awt.Point p) {
	}

	/**
	 *  Determines whether the supplied pixel point is contained by the rendering of a segment in a pie chart.
	 *  @param p a coordinate in pixel space
	 *  @return a point descriptor for the corresponding point in the chart model, if any; otherwise null.
	 */
	public event.PointDescriptor containingSegment(java.awt.Point p) {
	}

	/**
	 *  Determines whether the supplied pixel point is contained by the rendering of a (model) point in a chart.
	 *  @param p a coordinate in pixel space
	 *  @return a point descriptor for the corresponding point in the chart model, if any; otherwise null.
	 */
	public event.PointDescriptor containingPoint(java.awt.Point p) {
	}

	/**
	 *  @return the renderer used for rendering the segments of a pie chart
	 */
	public render.PieSegmentRenderer getPieSegmentRenderer() {
	}

	/**
	 *  Specify the renderer to use for drawing pie charts
	 *  @param segmentRenderer the new pie segment renderer
	 */
	public void setPieSegmentRenderer(render.PieSegmentRenderer segmentRenderer) {
	}

	/**
	 *  @return the renderer to use for drawing lines in a chart
	 */
	public render.LineRenderer getLineRenderer() {
	}

	/**
	 *  Specify the renderer to use for drawing lines in a chart
	 *  @param lineRenderer the new line renderer
	 */
	public void setLineRenderer(render.LineRenderer lineRenderer) {
	}

	/**
	 *  Specify the pixel gap between bars in a bar chart
	 *  @param barGap the new pixel gap
	 */
	public void setBarGap(int barGap) {
	}

	/**
	 *  @return the pixel gap between bars in a bar chart
	 */
	public int getBarGap() {
	}

	/**
	 *  Specify the gap (in pixels) between groups of bars in a grouped bar chart
	 *  @param barGroupGap the new gap between groups of bars
	 */
	public void setBarGroupGap(int barGroupGap) {
	}

	/**
	 *  Specify whether bars should be grouped or stacked when they have the same axis value
	 *  @param barsGrouped
	 */
	public void setBarsGrouped(boolean barsGrouped) {
	}

	/**
	 *  @return whether bars are grouped
	 */
	public boolean isBarsGrouped() {
	}

	/**
	 *  Specify the bar resize policy when bars are assigned a width and the space available does not match the widths
	 *  @param policy the bar resize policy
	 */
	public void setBarResizePolicy(BarResizePolicy policy) {
	}

	/**
	 *  @return the current bar resize policy
	 */
	public BarResizePolicy getBarResizePolicy() {
	}

	/**
	 *  @deprecated as this has been incorporated into the repaint() method
	 */
	public void updateLazyCharts() {
	}

	public long lazyImageLastModified() {
	}

	/**
	 *  @deprecated as we now interrupt any painting that has started, which is a better approach than waiting before
	 *              starting
	 */
	public void setLazyUpdateDelay(int delay) {
	}

	public int getLazyUpdateDelay() {
	}

	public boolean isHighQuality() {
	}

	/**
	 *  Specify whether to invest additional computational effort to try to avoid the possibility of pixel 
	 *  value rounding errors. This is false by default and you should not normally need to set it to true.
	 *  @param highQuality whether to try to avoid pixel value rounding errors
	 */
	public void setHighQuality(boolean highQuality) {
	}

	/**
	 *  @return whether the vertical lines of the grid are visible
	 */
	public boolean isVerticalGridLinesVisible() {
	}

	/**
	 *  Specify whether the vertical lines of the grid should be painted
	 *  @param gridLinesVisible should the lines be painted?
	 */
	public void setVerticalGridLinesVisible(boolean gridLinesVisible) {
	}

	/**
	 *  @return whether the horizontal lines of the grid are visible
	 */
	public boolean isHorizontalGridLinesVisible() {
	}

	/**
	 *  Specify whether horizontal grid lines should be visible
	 *  @param gridLinesVisible whether horizontal grid lines are to be visible
	 */
	public void setHorizontalGridLinesVisible(boolean gridLinesVisible) {
	}

	/**
	 *  @return whether the chart should display a title
	 */
	public boolean isTitleVisible() {
	}

	/**
	 *  Specify whether the chart should display a title
	 *  @param titleVisible whether to display a title for the chart
	 */
	public void setTitleVisible(boolean titleVisible) {
	}

	/**
	 *  @return the font used for tick labels
	 */
	public java.awt.Font getTickFont() {
	}

	/**
	 *  Specify the font used for tick labels
	 *  @param font the new font for tick labels
	 */
	public void setTickFont(java.awt.Font font) {
	}

	/**
	 *  @return the color of the axes
	 */
	public java.awt.Color getAxisColor() {
	}

	/**
	 *  Specify the color to use for the axes
	 *  @param axisColor the new axis color
	 */
	public void setAxisColor(java.awt.Color axisColor) {
	}

	/**
	 *  @return the color used for the grid
	 */
	public java.awt.Color getGridColor() {
	}

	/**
	 *  Specify the color to use for the grid
	 *  @param gridColor the new color for the grid lines
	 */
	public void setGridColor(java.awt.Color gridColor) {
	}

	/**
	 *  @return The background used for the area surrounding the main chart area
	 */
	public java.awt.Paint getPanelBackground() {
	}

	/**
	 *  Note that we can't call this method setBackground, as that method already exists and expects a Color rather than
	 *  a Paint. That's OK for the setter but we can't override the getter. For consistency, this method calls
	 *  setBackground() internally if the value supplied is a Color.
	 */
	public void setPanelBackground(java.awt.Paint background) {
	}

	/**
	 *  @return the background used for the area displaying the chart
	 */
	public java.awt.Paint getChartBackground() {
	}

	/**
	 *  Specify the paint to use for the main chart area. This can be a java.awt.Color or it can be something more
	 *  complex, like a gradient fill, an image or a textured paint.
	 *  @param chartBackground the new paint to use
	 */
	public void setChartBackground(java.awt.Paint chartBackground) {
	}

	public UserToPixelTransform getUserToPixelTransform() {
	}

	public boolean isAntiAliasing() {
	}

	/**
	 *  Specify whether to use anti-aliasing when drawing. By default this is true.
	 *  Charts look better with it switched on, but you might want to switch it off for performance reasons.
	 *  @param antiAliasing whether to use antialiasing
	 */
	public void setAntiAliasing(boolean antiAliasing) {
	}

	public boolean isLabellingTraces() {
	}

	public void setLabellingTraces(boolean labellingTraces) {
	}

	public Chart addMouseZoomer() {
	}

	public Chart addMouseZoomer(boolean horizontalZoom, boolean verticalZoom) {
	}

	public Chart removeMouseZoomer() {
	}

	/**
	 *  Makes it possible for the user to 'pan' the chart easily by clicking and dragging the mouse. Panning is a
	 *  translation of the chart domain, but it is very natural when this is done with a click and drag action of the
	 *  mouse.
	 * 
	 *  @return this chart instance (so you can chain method calls)
	 */
	public Chart addMousePanner() {
	}

	/**
	 *  Make it possible for the user to pan the chart easily, but specifying whether panning is allowed in the
	 *  horizontal and/or vertical axes.
	 * 
	 *  @param horizontalPan do we allow horizontal panning
	 *  @param verticalPan   do we allow vertical panning
	 *  @return this Chart instance (so you can chain method calls)
	 */
	public Chart addMousePanner(boolean horizontalPan, boolean verticalPan) {
	}

	/**
	 *  Remove the panning ability for this chart.
	 * 
	 *  @return this chart instance (so you can chain method calls)
	 */
	public Chart removeMousePanner() {
	}

	public void setRolloverEnabled(boolean rollover) {
	}

	public boolean isRolloverEnabled() {
	}

	/**
	 *  Specify whether the displayed chart should respond to selections. By default
	 *  selection is switched off.
	 *  @param selectable whether selection is switched on
	 */
	public void setSelectionEnabled(boolean selectable) {
	}

	public boolean isSelectionEnabled() {
	}

	/**
	 *  @return Are we currently using an explosion effect to indicate selection of segments?
	 */
	public boolean isSelectionShowsExplodedSegments() {
	}

	/**
	 *  Specify whether to use an explosion effect to indicate selection of segments
	 * 
	 *  @param selectionShowsExplodedSegments
	 */
	public void setSelectionShowsExplodedSegments(boolean selectionShowsExplodedSegments) {
	}

	/**
	 *  @return are selection outlines currently shown?
	 */
	public boolean isSelectionShowsOutline() {
	}

	/**
	 *  Specify whether segment selection should be indicated by an outline on the segment
	 * 
	 *  @param selectionShowsOutline should selection outlines be visible?
	 */
	public void setSelectionShowsOutline(boolean selectionShowsOutline) {
	}

	public void addDoubleClickListener(java.awt.event.ActionListener listener) {
	}

	public void removeDoubleClickListener(java.awt.event.ActionListener listener) {
	}

	/**
	 *  This is the method of the ChartModelListener interface; it is called whenever the chart model has changed
	 *  and all points need to be updated.
	 */
	public void chartModelChanged() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void chartModelChanged(model.ChartModelChangeEvent changeEvent) {
	}

	/**
	 *  @return whether shadows are being drawn on the rendering of the chart
	 */
	public boolean isShadowVisible() {
	}

	/**
	 *  Use to specify whether shadows should be drawn under lines, points etc. on the chart.
	 * 
	 *  @param shadowVisible boolean to indicate whether shadows should be drawn
	 */
	public void setShadowVisible(boolean shadowVisible) {
	}

	/**
	 *  Updates margins and coordinate systems according to the size of the component. This method is used internally and
	 *  it is rare that you should have to call this. (A possible exception is forcing an update to the component prior
	 *  to painting to a different graphics canvas.)
	 */
	public void update() {
	}

	/**
	 *  You should not need to call this method often. It uses lazy rendering for drawing but does not wait to see if
	 *  multiple requests come soon after one another. Instead, it starts the background drawing immediately. If this
	 *  gets called too often it could damage performance rather than improve it, so take care at what point this is
	 *  invoked.
	 */
	public void drawInBackground() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void propertyChange(java.beans.PropertyChangeEvent pce) {
	}

	/**
	 *  Adds an object that implements the drawable callback method. Use this method to add custom shapes to a chart.
	 *  @param d the Drawable to add
	 *  @return this chart object (so calls to this method can be cascaded)
	 */
	public Chart addDrawable(Drawable d) {
	}

	/**
	 *  Removes a drawable from the chart (and all references to the Drawable from the chart object too).
	 *  <p><b>Note:</b> Make sure your Drawables have good implementations of equals() and hashCode()</p>
	 *  @param d the Drawable to remove
	 *  @return this chart object
	 */
	public Chart removeDrawable(Drawable d) {
	}

	/**
	 *  Removes all drawables from the chart
	 *  @return this chart object
	 */
	public Chart removeDrawables() {
	}

	/**
	 *  Determines whether this chart object already contains the supplied Drawable.
	 *  For this method to work as expected, the Drawable is expected to have a good implementation of equals() and hashCode()
	 *  @param drawable the Drawable object to test
	 *  @return this Chart object
	 */
	public boolean containsDrawable(Drawable drawable) {
	}

	/**
	 *  @return a Collection of drawable objects known by the Chart
	 */
	public java.util.Collection getDrawables() {
	}

	/**
	 *  @deprecated in favour of removeDrawables
	 */
	public void clearDrawables() {
	}

	/**
	 *  @return the width of the supplied axis due to rendering of ticks and labels
	 */
	public int axisWidth(axis.Axis axis) {
	}

	/**
	 *  @return the pixel x coordinate start of the drawing area relative to the canvas on which it is painted
	 */
	public int getXStart() {
	}

	/**
	 *  @return the pixel x coordinate end of the drawing area relative to the canvs on which it is painted
	 */
	public int getXEnd() {
	}

	/**
	 *  @return the width of the drawing area in pixels
	 */
	public int getChartWidth() {
	}

	/**
	 *  @return the y coordinate start of the drawing area relative to the canvas on which it is painted. <p>For the y
	 *          axis, the 'start' is the bottom of the chart region and therefore has a numeric value greater than or
	 *          equal to the yEnd property</p>
	 */
	public int getYStart() {
	}

	/**
	 *  @return the y coordinate end of the drawing area relative to the canvas on which it is painted. <p>For the y
	 *          axis, the 'end' is at the top of the chart region</p>
	 */
	public int getYEnd() {
	}

	public int getChartHeight() {
	}

	/**
	 *  @param model
	 *  @return the sum of the y values of the supplied ChartModel
	 */
	public double getYSum(model.ChartModel model) {
	}

	/**
	 *  @return the length of ticks, in pixels
	 */
	public int getTickLength() {
	}

	/**
	 *  Specify the length of ticks, in pixels
	 *  @param newTickLength
	 */
	public void setTickLength(int newTickLength) {
	}

	/**
	 *  @return the current tick color
	 */
	public java.awt.Color getTickColor() {
	}

	/**
	 *  Specify the color to use for ticks along the axes
	 *  @param tickColor
	 */
	public void setTickColor(java.awt.Color tickColor) {
	}

	/**
	 *  @return the color of the axis labels
	 */
	public java.awt.Color getLabelColor() {
	}

	/**
	 *  Specify the color to use for the labels of the axes
	 *  @param labelColor
	 */
	public void setLabelColor(java.awt.Color labelColor) {
	}

	/**
	 *  Set the x axis
	 *  @param newAxis the new x axis
	 */
	public void setXAxis(axis.Axis newAxis) {
	}

	/**
	 *  @return the chart's x axis
	 */
	public axis.Axis getXAxis() {
	}

	/**
	 *  Set the primary y axis
	 *  @param newAxis the new y axis
	 */
	public void setYAxis(axis.Axis newAxis) {
	}

	/**
	 *  Adds a y axis
	 *  @param newAxis the new y axis
	 *  @return this Chart object
	 */
	public Chart addYAxis(axis.Axis newAxis) {
	}

	/**
	 *  @return the primary y axis
	 */
	public axis.Axis getYAxis() {
	}

	/**
	 *  Sets the (optional) title for the chart
	 *  @param title the new title of the chart
	 */
	public void setTitle(String title) {
	}

	/**
	 *  @return the current title of the chart
	 */
	public annotation.AbstractAnnotation getTitle() {
	}

	/**
	 *  Specify the title of the chart
	 *  @param title the new title label for the chart
	 */
	public void setTitle(annotation.AbstractLabel title) {
	}

	public int getLazyRenderingThreshold() {
	}

	/**
	 *  How large does a dataset have to be before we switch into lazy rendering mode?
	 * 
	 *  @param lazyRenderingThreshold the total number of points in all the loaded chart models before Chart starts using
	 *                                lazy rendering. If this value is set to zero, then Chart automatically uses lazy
	 *                                rendering.
	 */
	public void setLazyRenderingThreshold(int lazyRenderingThreshold) {
	}

	protected boolean isLazyRendering() {
	}

	/**
	 *  First removes any models held by this object, then sets the supplied model as the single known model. You can
	 *  still add more models by calling addModel
	 * 
	 *  @param model the model to add
	 */
	public void setModel(model.ChartModel model) {
	}

	/**
	 *  First removes any models held by this object, then sets the supplied model as the single known model with the
	 *  supplied style
	 * 
	 *  @param model the model to add
	 *  @param style the style of the model
	 */
	public void setModel(model.ChartModel model, style.ChartStyle style) {
	}

	/**
	 *  Adds the supplied ChartModel to the Chart so that it is drawn in the chart area. <p>The Chart instance should not
	 *  already contain the supplied ChartModel.</p>
	 * 
	 *  @param newModel the <code>ChartModel</code> being added
	 */
	public Chart addModel(model.ChartModel newModel) {
	}

	/**
	 *  Adds the supplied ChartModel to the Chart, but does not force a repaint. This means that multiple models can be
	 *  added to the chart and we can perform an update after they have all been added.
	 * 
	 *  @param newModel
	 *  @param makeDirty
	 */
	public Chart addModel(model.ChartModel newModel, boolean makeDirty) {
	}

	/**
	 *  Adds the supplied ChartModel to the Chart, also assigning the supplied style to the chart. <p>Note that storing
	 *  the style directly without making a separate call to <code>setStyle</code> potentially saves a screen update, as
	 *  setStyle causes a repaint() itself.</p>
	 * 
	 *  @param newModel the new ChartModel to display
	 *  @param style    the style of the added ChartModel
	 */
	public Chart addModel(model.ChartModel newModel, style.ChartStyle style) {
	}

	/**
	 *  Adds the supplied ChartModel to the Chart, also assigning the model to the supplied axis. This means that the
	 *  model will be rescaled whenever the axis is rescaled.
	 * 
	 *  @param newModel
	 *  @param axis
	 */
	public Chart addModel(model.ChartModel newModel, axis.Axis axis) {
	}

	/**
	 *  @return the first <code>ChartModel</code>. Useful when we can safely assume that there is only one. Returns null
	 *          if there are no <code>ChartModel</code>s.
	 */
	public model.ChartModel getModel() {
	}

	/**
	 *  @param i - zero based index
	 *  @return the ith <code>ChartModel</code>
	 */
	public model.ChartModel getModel(int i) {
	}

	/**
	 *  Returns the model with the specified name; null otherwise
	 * 
	 *  @param modelName
	 *  @return the ChartModel with the specified name
	 */
	public model.ChartModel getModel(String modelName) {
	}

	public java.util.List getModels() {
	}

	/**
	 *  The number of chart models currently loaded into the chart component
	 * 
	 *  @return the number of models
	 */
	public int modelCount() {
	}

	/**
	 *  @return the total number of points contained in all the known models
	 */
	public int pointCount() {
	}

	/**
	 *  Asserts that the supplied model should be chartted against the supplied axis rather than the default axis
	 * 
	 *  @param model
	 *  @param axis
	 */
	public void setModelAxis(model.ChartModel model, axis.Axis axis) {
	}

	/**
	 *  @deprecated as we have renamed it to getAxisForModel()
	 */
	public axis.Axis getModelAxis(model.ChartModel model) {
	}

	public axis.Axis getAxisForModel(model.ChartModel model) {
	}

	public javax.swing.ListSelectionModel getSelectionsForModel(model.ChartModel model) {
	}

	public void setSelectionsForModel(model.ChartModel chartModel, javax.swing.ListSelectionModel selectionModel) {
	}

	public UserToPixelTransform getTransformForModel(model.ChartModel model) {
	}

	public void setStyle(model.ChartModel model, style.ChartStyle style) {
	}

	public void setStyle(model.ChartModel model, style.ChartStyle style, boolean makeDirty) {
	}

	public style.ChartStyle getStyle(model.ChartModel model) {
	}

	public void setHighlightStyle(model.Highlight highlight, style.ChartStyle style) {
	}

	public style.ChartStyle getHighlightStyle(model.Highlight h) {
	}

	public Chart clearHighlights() {
	}

	public style.AbstractStyle getStyle(model.ChartModel model, model.Chartable chartable) {
	}

	public boolean containsModel(model.ChartModel model) {
	}

	/**
	 *  @param model the model to remove
	 */
	public Chart removeModel(model.ChartModel model) {
	}

	/**
	 *  Removes all the ChartModels by repeated calls to removeModel()
	 */
	public Chart removeModels() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  This fixes a painting problem with the shadow rendering code when a tooltip
	 *  disappears. We issue a repaint request when the tooltip disappears. 
	 *  See forum posting from Fri Jan 08, 2010
	 */
	@java.lang.Override
	public javax.swing.JToolTip createToolTip() {
	}

	public void paintYAxisTicks(java.awt.Graphics g, axis.Axis axis, java.awt.Point midPoint, int xPixelCoord) {
	}

	protected void paintYAxisTicks(java.awt.Graphics g, axis.Axis axis, UserToPixelTransform transform, java.awt.Point midPoint, int xPixelCoord, boolean withHorizontalGridLine) {
	}

	/**
	 *  Paints a string but only if the whole of the string will be visible according to the clipping region
	 * 
	 *  @param g the <code>Graphics</code> context
	 *  @param s the string to draw
	 *  @param x the bottom left x coordinate of the drawn string
	 *  @param y the bottom elft y coordinate of the drawn string
	 */
	protected void drawStringIfWithinClip(java.awt.Graphics g, String s, int x, int y) {
	}

	/**
	 *  
	 *  @param g the Graphics context into which to draw
	 *  @param s the string to draw
	 *  @param x the x coordinate of where the string should be drawn
	 *  @param y the y coordinate of where the string should be drawn
	 *  @param rotation the rotation to use, in radians
	 */
	protected void drawRotatedStringIfWithinClip(java.awt.Graphics g, String s, int x, int y, double rotation) {
	}

	/**
	 *  Draws
	 *  @param g the Graphics context into which to draw
	 *  @param axis the Axis from which the tick comes. This is needed so we can find out the orientation and placement for the text
	 *  @param s the text string to draw
	 *  @param x the x coordinate of the tick
	 *  @param y the y coordinate of the tick
	 */
	protected void drawXAxisTickLabel(java.awt.Graphics g, axis.Axis axis, String s, int x, int y) {
	}

	/**
	 *  Paint a single Y axis
	 * 
	 *  @param g         the Graphics context
	 *  @param axis      the y axis to paint
	 *  @param xPosition the xPosition at which to paint the axis
	 */
	protected void paintYAxis(java.awt.Graphics2D g, axis.Axis axis, int xPosition) {
	}

	/**
	 *  Paints the X axis onto the Graphics context
	 * 
	 *  @param g the graphics context
	 */
	protected void paintXAxis(java.awt.Graphics2D g) {
	}

	protected void paintXAxisTicks(java.awt.Graphics2D g, axis.Tick[] ticks) {
	}

	protected void paintXAxisGridLines(java.awt.Graphics2D g, axis.Tick[] ticks) {
	}

	/**
	 *  Paint all axes
	 * 
	 *  @param g the Graphics context onto which the axis will be painted The axis width needs to be calculated as the
	 *           width of a tick plus the width of a tick label
	 */
	protected void paintAxes(java.awt.Graphics2D g) {
	}

	/**
	 *  Paint all y axis labels
	 * 
	 *  @param g the Graphics context onto which the axis will be painted The axis width needs to be calculated as the
	 *           width of a tick plus the width of a tick label
	 */
	protected void paintYAxisLabels(java.awt.Graphics2D g) {
	}

	/**
	 *  Returns the nearest point to a specified pixel point from a given ChartModel To find the nearest point we only
	 *  need to compute the distance squared to each of the other points - no need to take the square root
	 * 
	 *  @param hitPoint
	 *  @param model
	 *  @return the nearest point in a model to the specified pixel point
	 */
	public event.PointSelection nearestPoint(java.awt.Point hitPoint, model.ChartModel model) {
	}

	/**
	 *  Note that the current implementation may take some time to execute for larger datasets. This will be optimized in
	 *  a future release.
	 * 
	 *  @return the nearest model to the last known cursor point
	 */
	public model.ChartModel nearestModel(java.awt.Point p) {
	}

	/**
	 *  We need to specify which model the point belongs to, so that we know which axis and therefore which point ranges
	 *  to apply.
	 * 
	 *  @return whether the point is within the viewable region of the chart
	 */
	public boolean isUserPointViewable(java.awt.geom.Point2D userPoint, model.ChartModel model) {
	}

	public boolean isPixelPointViewable(int x, int y) {
	}

	/**
	 *  Returns the nearest point in a model to the specified real point. Note that this calculates the nearest point in
	 *  user coordinates rather than pixel coordinates and therefore, depending on the scaling of the axes, may produce
	 *  correct, but unexpected, results. Consider using <code>nearestPoint(Point, ChartModel)</code> instead.
	 * 
	 *  @param realPoint
	 *  @param model
	 *  @return the nearest point
	 */
	public util.Pair nearestPoint(java.awt.geom.Point2D realPoint, model.ChartModel model) {
	}

	public static double distanceSq(java.awt.geom.Point2D point, model.Chartable chartable) {
	}

	public static double distance(java.awt.geom.Point2D point, model.Chartable chartable) {
	}

	/**
	 *  Calculate the pixel coordinates of a point using the default y axis.
	 * 
	 *  @return the Point calculated in pixel space (i.e., pixel coordinates)
	 *  or null if the point cannot be calculated.
	 */
	public java.awt.Point calculatePixelPoint(java.awt.geom.Point2D userPoint) {
	}

	/**
	 *  Calculate the pixel coordinates of a point using the default y axis.
	 * 
	 *  @return the Point2D calculated in pixel space (i.e., pixel coordinates)
	 *  or null if the point cannot be calculated.
	 */
	public java.awt.geom.Point2D calculatePixelPoint2D(java.awt.geom.Point2D userPoint) {
	}

	/**
	 *  Calculate the pixel coordinates of a point using the supplied y axis
	 * 
	 *  @param userPoint the point in user coordinates
	 *  @param axis      the y axis used for the y value
	 *  @return a pixel point
	 */
	public java.awt.Point calculatePixelPoint(java.awt.geom.Point2D userPoint, axis.Axis axis) {
	}

	/**
	 *  Calculate the pixel coordinates of a point using the supplied y axis
	 * 
	 *  @param userPoint the point in user coordinates
	 *  @param axis      the y axis used for the y value
	 *  @return a pixel point
	 */
	public java.awt.geom.Point2D calculatePixelPoint2D(java.awt.geom.Point2D userPoint, axis.Axis axis) {
	}

	/**
	 *  Calculates the pixel point using the supplied transform. There is a transform associated with each y axis and you
	 *  can retrieve it using <code>getTransformForAxis()</code> or <code>getTransformForModel(ChartModel model)</code>.
	 * 
	 *  @param userPoint the point in user coordinates
	 *  @param transform the transform used for the calculation. You do not create these, but retrieve them using the
	 *                   supplied methods (see above).
	 *  @return a pixel point
	 */
	public java.awt.Point calculatePixelPoint(java.awt.geom.Point2D userPoint, UserToPixelTransform transform) {
	}

	public java.awt.geom.Point2D calculatePixelPoint2D(java.awt.geom.Point2D userPoint, UserToPixelTransform transform) {
	}

	/**
	 *  Calculates the point in the user's coordinate system for the pixel coordinate given by <code>p</code>. TODO: We
	 *  probably need a version of this method that accepts an axis, and uses the conversion appropriate for that axis.
	 * 
	 *  @param p
	 *  @return the point calculated in user space; or null if this cannot be computed
	 * 
	 *  @throws ChartException
	 */
	public java.awt.geom.Point2D calculateUserPoint(java.awt.Point p) {
	}

	/**
	 *  @deprecated in favour of calculateUserPoint
	 */
	public java.awt.geom.Point2D calculateRealPoint(java.awt.Point p) {
	}

	protected void paintModels(java.awt.Graphics2D g, java.awt.Shape clipBounds, java.awt.Shape chartAreaClip) {
	}

	/**
	 *  @param yAxis
	 *  @return the Transform associated with the given y axis
	 */
	protected UserToPixelTransform getTransformForAxis(axis.Axis yAxis) {
	}

	protected void paintAnnotation(java.awt.Graphics g, annotation.ChartLabel label) {
	}

	protected void paintAnnotation(java.awt.Graphics2D g, annotation.ChartImage chartImage) {
	}

	protected void paintAnnotations(java.awt.Graphics2D g) {
	}

	public double getAnimationPosition() {
	}

	public void setAnimationPosition(double position) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	public boolean isAnimateOnShow() {
	}

	public void setAnimateOnShow(boolean animateOnShow) {
	}

	public void startAnimation() {
	}

	public void stopAnimation() {
	}
}
