/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


/**
 *  Contains style information for a point
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartStyle {

	public ChartStyle() {
	}

	public ChartStyle(ChartStyle style) {
	}

	/**
	 *  Constructs a style for showing the lines only
	 * 
	 *  @param color
	 */
	public ChartStyle(java.awt.Color color) {
	}

	/**
	 *  Constructs a style for showing the points only
	 */
	public ChartStyle(java.awt.Color pointColor, com.jidesoft.chart.PointShape shape) {
	}

	/**
	 *  Constructs a style for showing the points only
	 */
	public ChartStyle(java.awt.Color pointColor, com.jidesoft.chart.PointShape shape, int pointSize) {
	}

	/**
	 *  Constructs a style for showing lines and/or points of the same color
	 * 
	 *  @param color
	 *  @param pointsVisible
	 *  @param linesVisible
	 */
	public ChartStyle(java.awt.Color color, boolean pointsVisible, boolean linesVisible) {
	}

	/**
	 *  Constructs a style for showing lines, points and bars of the same color
	 * 
	 *  @param color
	 *  @param pointsVisible
	 *  @param linesVisible
	 */
	public ChartStyle(java.awt.Color color, boolean pointsVisible, boolean linesVisible, boolean barsVisible) {
	}

	/**
	 *  Constructs a style for showing lines and points with specified colors
	 * 
	 *  @param pointColor
	 *  @param shape
	 *  @param lineColor
	 */
	public ChartStyle(java.awt.Color pointColor, com.jidesoft.chart.PointShape shape, java.awt.Color lineColor) {
	}

	/**
	 *  A chaining style method that specifies that we want to use points only
	 *  @return this ChartStyle instance
	 */
	public ChartStyle withPoints() {
	}

	/**
	 *  A chaining style method that specifies that we want to use lines only
	 *  @return this ChartStyle instance
	 */
	public ChartStyle withLines() {
	}

	/**
	 *  A chaining style method that specifies that we want to use bars only
	 *  @return this ChartStyle instance
	 */
	public ChartStyle withBars() {
	}

	/**
	 *  A chaining style method that specifies that we want to use points and lines
	 *  @return this ChartStyle instance
	 */
	public ChartStyle withPointsAndLines() {
	}

	/**
	 *  @return the Color used for painting points for any model to which this style is applied
	 */
	public java.awt.Color getPointColor() {
	}

	/**
	 *  Set the Color used for painting points
	 *  @param color
	 */
	public void setPointColor(java.awt.Color color) {
	}

	/**
	 *  @return the size of points used according to this style (in pixels)
	 */
	public int getPointSize() {
	}

	/**
	 *  Set the size of points (in pixels)
	 *  @param newSize the new size
	 */
	public void setPointSize(int newSize) {
	}

	/**
	 *  @return the shape of points, as defined by the PointShape enum
	 */
	public com.jidesoft.chart.PointShape getPointShape() {
	}

	/**
	 *  Set the shape of points used by this style 
	 *  @param newShape the new shape of points
	 */
	public void setPointShape(com.jidesoft.chart.PointShape newShape) {
	}

	/**
	 *  @return the color of lines used in this style
	 */
	public java.awt.Color getLineColor() {
	}

	/**
	 *  Sets the color of lines used in this style
	 *  @param lineColor the new line color
	 */
	public void setLineColor(java.awt.Color lineColor) {
	}

	/**
	 *  @return whether lines are visible in this style
	 */
	public boolean isLinesVisible() {
	}

	/**
	 *  Sets the visibility of lines in this style
	 *  @param linesVisible
	 */
	public void setLinesVisible(boolean linesVisible) {
	}

	/**
	 *  @return whether points are visible in this style
	 */
	public boolean isPointsVisible() {
	}

	/**
	 *  Determine whether points are visible in this style
	 *  @param pointsVisible specifies whether points should be rendered for this style
	 */
	public void setPointsVisible(boolean pointsVisible) {
	}

	/**
	 *  @return whether bars are visible in this style
	 */
	public boolean isBarVisible() {
	}

	/**
	 *  @deprecated please use setBarsVisible instead
	 */
	public void setBarVisible(boolean visible) {
	}

	/**
	 *  Specify whether bars are visible in this style (that is, the bars of a bar chart)
	 *  @param visible state whether bars should be rendered
	 */
	public void setBarsVisible(boolean visible) {
	}

	/**
	 *  @return whether the fill (now bar) is visible
	 * 
	 *  @deprecated in favour of <code>isBarVisible()</code>
	 */
	public boolean isFillVisible() {
	}

	/**
	 *  @deprecated in favour of <code>setBarVisible</code>
	 */
	public void setFillVisible(boolean visible) {
	}

	/**
	 *  @return the color of bars for this style
	 */
	public java.awt.Color getBarColor() {
	}

	/**
	 *  @return the paint used for rendering bars
	 */
	public java.awt.Paint getBarPaint() {
	}

	/**
	 *  Specify the bar color for rendering bars
	 *  @param color the new color
	 */
	public void setBarColor(java.awt.Color color) {
	}

	/**
	 *  Specify the bar paint for rendering bars
	 *  @param paint
	 */
	public void setBarPaint(java.awt.Paint paint) {
	}

	/**
	 *  @return the preferred width of bars according to this style. This might not be used depending on other layout
	 *  factors.
	 */
	public Integer getBarWidth() {
	}

	/**
	 *  Specify the width of bars
	 *  @param barWidth
	 */
	public void setBarWidth(Integer barWidth) {
	}

	/**
	 *  @return the shape of points
	 *  @deprecated in favour of <code>getPointShape()</code> 
	 */
	public com.jidesoft.chart.PointShape getShape() {
	}

	/**
	 *  Sets the shape to use for rendering points. This may be overridden by a custom renderer.
	 *  @param shape the shape to use
	 *  @deprecated in favour of <code>setPointShape()</code>
	 */
	public void setShape(com.jidesoft.chart.PointShape shape) {
	}

	/**
	 *  @return the style to use when rendering lines
	 */
	public LineStyle getLineStyle() {
	}

	/**
	 *  Specify the style to use when rendering lines
	 *  @param lineStyle the new line style
	 */
	public void setLineStyle(LineStyle lineStyle) {
	}

	/**
	 *  @return the style to use for rendering the bars of a bar chart
	 */
	public BarStyle getBarStyle() {
	}

	/**
	 *  Set the style to use when rendering the bars of a bar chart
	 *  @param barStyle
	 */
	public void setBarStyle(BarStyle barStyle) {
	}

	/**
	 *  The paint to use in area charts when filling from the line to the axis
	 *  @return the paint
	 */
	public java.awt.Paint getLinePaint() {
	}

	/**
	 *  Specify the paint to use in area charts when filling from the line to the axis
	 *  @param fill
	 */
	public void setLineFill(java.awt.Paint fill) {
	}

	/**
	 *  @return the width of lines
	 */
	public int getLineWidth() {
	}

	/**
	 *  Set the width of lines
	 *  @param width the width in pixels
	 */
	public void setLineWidth(int width) {
	}

	/**
	 *  Set the stroke to use for lines
	 *  @param stroke
	 */
	public void setLineStroke(java.awt.BasicStroke stroke) {
	}

	/**
	 *  @return the current Stroke used when rendering lines
	 */
	public java.awt.BasicStroke getLineStroke() {
	}

	/**
	 *  @return the style used for rendering points
	 */
	public PointStyle getPointStyle() {
	}

	/**
	 *  Specify the style to use when rendering points
	 *  @param pointStyle the new point style
	 */
	public void setPointStyle(PointStyle pointStyle) {
	}

	/**
	 *  @return the orientation of bars when drawing bar charts
	 */
	public com.jidesoft.chart.Orientation getBarOrientation() {
	}

	/**
	 *  Specify the orientation of bars when drawing bar charts
	 *  @param orientation
	 */
	public void setBarOrientation(com.jidesoft.chart.Orientation orientation) {
	}
}
