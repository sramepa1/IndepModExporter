/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A simple implementation of a FilteringChartModel. TODO: Not the best implementation, as it maintains a model of its
 *  own instead of delegating all calls
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class FilterableChartModel extends AbstractDelegatingChartModel {

	public FilterableChartModel() {
	}

	/**
	 *  Constructor
	 * 
	 *  @param delegate
	 */
	public FilterableChartModel(AnnotatedChartModel delegate) {
	}

	/**
	 *  @see com.jidesoft.chart.model.AbstractDelegatingChartModel#getAnnotationCount()
	 */
	@java.lang.Override
	public int getAnnotationCount() {
	}

	/**
	 *  @see com.jidesoft.chart.model.AbstractDelegatingChartModel#getAnnotation(int)
	 */
	@java.lang.Override
	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}

	/**
	 *  @see com.jidesoft.chart.model.AbstractDelegatingChartModel#getPoint(int)
	 */
	@java.lang.Override
	public Chartable getPoint(int n) {
	}

	/**
	 *  @see com.jidesoft.chart.model.AbstractDelegatingChartModel#getPointCount()
	 */
	@java.lang.Override
	public int getPointCount() {
	}

	public com.jidesoft.chart.util.Filter getFilter() {
	}

	public void setFilter(com.jidesoft.chart.util.Filter filter) {
	}

	protected synchronized void applyFilter() {
	}

	/**
	 *  @see com.jidesoft.chart.model.AbstractDelegatingChartModel#update()
	 */
	@java.lang.Override
	protected void update() {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
