/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  A Drawable object that can be added to a Chart to mark a rectangular region.
 *  If you set the chart property, then the chart will automatically be repainted when the color or
 *  intervals of the region change.
 */
public class RectangularRegionMarker implements Drawable {
 {

	public static final String PROPERTY_VISIBLE = "Visible";

	public static final String PROPERTY_COLOR = "Color";

	public static final String PROPERTY_PAINT = "Paint";

	public static final String PROPERTY_CHART = "Chart";

	public static final String PROPERTY_X_INTERVAL = "X Interval";

	public static final String PROPERTY_Y_INTERVAL = "Y Interval";

	protected final java.beans.PropertyChangeSupport support;

	/**
	 *  Zero argument constructor. Usually you would use one of the other constructors to automatically
	 *  set some of the properties at object creation time.
	 */
	public RectangularRegionMarker() {
	}

	/**
	 *  Create a marker and set the Chart object to which this marker applies
	 *  @param newChart the chart object to which this marker applies.
	 */
	public RectangularRegionMarker(Chart newChart) {
	}

	/**
	 *  Create a rectangular marker and set all properties
	 *  @param newChart the chart to which this marker applies
	 *  @param xMin the minimum x value for the region
	 *  @param xMax the maximum x value for the region
	 *  @param yMin the minimum y value for the region
	 *  @param yMax the maximum y value for the region
	 *  @param c the color for the region
	 */
	public RectangularRegionMarker(Chart newChart, double xMin, double xMax, double yMin, double yMax, java.awt.Color c) {
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  @return the chart with which this marker is associated
	 */
	public Chart getChart() {
	}

	/**
	 *  Set the chart that this object will update if any of the properties change
	 *  @param chart the Chart object
	 */
	public void setChart(Chart chart) {
	}

	/**
	 *  @return whether the marker object is currently visible
	 */
	public boolean isVisible() {
	}

	/**
	 *  Specify whether this marker object should be drawn. Sometimes it may be useful to keep it associated with
	 *  the chart but to temporarily remove it visually from the chart.
	 *  @param visible whether the marker should be drawn
	 */
	public void setVisible(boolean visible) {
	}

	/**
	 *  @return the color of the marker object. If a paint is used that is not a color, this returns null.
	 */
	public java.awt.Color getColor() {
	}

	/**
	 *  Specify the color of the marker object
	 *  @param color the new color
	 */
	public void setColor(java.awt.Color color) {
	}

	/**
	 *  @return the paint used for the marker object
	 */
	public java.awt.Paint getPaint() {
	}

	/**
	 *  Specify the paint to use for the marker object. If the paint happens to be a Color, you could call
	 *  either this method or setColor - the end result is the same.
	 *  @param paint the new paint.
	 */
	public void setPaint(java.awt.Paint paint) {
	}

	/**
	 *  @return the x interval of the marker
	 */
	public NumericRange getXInterval() {
	}

	/**
	 *  @return the y interval of the marker
	 */
	public NumericRange getYInterval() {
	}

	/**
	 *  Specifies the upper and lower bounds of the rectangular region on the x axis
	 *  @param min the minimum x value
	 *  @param max the maximum x value
	 */
	public void setXInterval(double min, double max) {
	}

	/**
	 *  Specifies the upper and lower bounds of the rectangular region on the y axis
	 *  @param min the minimum y value
	 *  @param max the maximum y value
	 */
	public void setYInterval(double min, double max) {
	}

	/**
	 *  The callback method to draw the object. It cannot be drawn if the chart property is not set or if
	 *  either the xInterval or yInterval is null.
	 */
	public void draw(java.awt.Graphics g) {
	}
}
