/**
 *  The package contains the classes related JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  A marker that can be added to a chart and is drawn as either a horizontal or vertical line across the chart.
 */
public class LineMarker implements Drawable {
 {

	public static final String PROPERTY_VISIBLE = "Visible";

	public static final String PROPERTY_CHART = "Chart";

	public static final String PROPERTY_COLOR = "Color";

	public static final String PROPERTY_ORIENTATION = "Orientation";

	public static final String PROPERTY_POSITION = "Position";

	public static final String PROPERTY_STROKE = "Stroke";

	protected final java.beans.PropertyChangeSupport support;

	/**
	 *  Zero argument constructor. Usually you would construct a LineMarker by using one of the other constructors
	 *  that automatically set property values at object construction time.
	 */
	public LineMarker() {
	}

	/**
	 *  Create a marker and set the Chart object to which this marker applies
	 *  @param newChart the chart object to which this marker applies
	 */
	public LineMarker(Chart newChart) {
	}

	/**
	 *  Create a LineMarker and set some properties
	 *  @param newChart the chart to which this marker applies
	 *  @param orientation the orientation of the line
	 *  @param position the position on the appropriate axis
	 *  @param color the color for the line
	 */
	public LineMarker(Chart newChart, Orientation orientation, double position, java.awt.Color color) {
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  @return the chart object with which this marker is associated
	 */
	public Chart getChart() {
	}

	/**
	 *  Specify the chart object with which this marker is associated
	 *  @param chart the chart object
	 */
	public void setChart(Chart chart) {
	}

	/**
	 *  @return whether the marker is currently painted onto the chart's Graphics context when an update occurs
	 */
	public boolean isVisible() {
	}

	/**
	 *  Specify whether the marker should be painted
	 *  @param visible the visibility of the marker
	 */
	public void setVisible(boolean visible) {
	}

	/**
	 *  @return the color of the LineMarker
	 */
	public java.awt.Color getColor() {
	}

	/**
	 *  Specify the color for the LineMarker
	 *  @param color the new color
	 */
	public void setColor(java.awt.Color color) {
	}

	/**
	 *  @return the stroke used for drawing the line
	 */
	public java.awt.Stroke getStroke() {
	}

	/**
	 *  Specify the stroke for the line
	 *  @param stroke the new Stroke
	 */
	public void setStroke(java.awt.Stroke stroke) {
	}

	/**
	 *  @return the orientation of the LineMarker
	 */
	public Orientation getOrientation() {
	}

	/**
	 *  If the orientation of the interval is vertical it means it is applied to the x axis; if horizontal it
	 *  is applied to the y axis.
	 *  @param orientation the orientation of the line
	 */
	public void setOrientation(Orientation orientation) {
	}

	/**
	 *  @return the position of the marker along the axis
	 */
	public double getPosition() {
	}

	/**
	 *  Specify the position of the marker along the axis
	 *  @param pos the new position
	 */
	public void setPosition(double pos) {
	}

	/**
	 *  The callback method to draw the object. It cannot be drawn if the chart property is not set or if
	 *  either the xInterval or yInterval is null.
	 */
	public void draw(java.awt.Graphics g) {
	}
}
