/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


/**
 *  An abstract superclass for all styles used in Chart charts; for example LineStyles and ChartStyles. Styling is used
 *  to change the appearance of chart points and other chart annotations.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 *  @see LineStyle
 *  @see ChartStyle
 */
public abstract class AbstractStyle {

	public AbstractStyle() {
	}

	public java.awt.Color getColor() {
	}

	public void setColor(java.awt.Color color) {
	}

	public void setPaint(java.awt.Paint paint) {
	}

	public java.awt.Paint getPaint() {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
