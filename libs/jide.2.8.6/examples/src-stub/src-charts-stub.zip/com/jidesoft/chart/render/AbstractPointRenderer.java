/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


public abstract class AbstractPointRenderer extends AbstractRenderer implements PointRenderer {
 {

	public AbstractPointRenderer() {
	}

	protected com.jidesoft.chart.style.ChartStyle getStyle(com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus) {
	}
}
