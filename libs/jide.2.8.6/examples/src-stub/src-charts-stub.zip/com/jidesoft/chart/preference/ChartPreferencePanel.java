/**
 *  When users have preferences for the visual appearance of their Chart,
 *  classes from this package can be used to acquire those settings.
 */
package com.jidesoft.chart.preference;


/**
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartPreferencePanel extends javax.swing.JPanel {

	public ChartPreferencePanel() {
	}

	protected void init() {
	}

	public Integer getPointSize() {
	}

	public com.jidesoft.chart.PointShape getPointShape() {
	}

	public Integer getLineWidth() {
	}
}
