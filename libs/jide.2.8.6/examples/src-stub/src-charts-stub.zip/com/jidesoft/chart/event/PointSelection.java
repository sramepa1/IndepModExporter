/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


public class PointSelection {

	public PointSelection() {
	}

	public PointSelection(com.jidesoft.chart.model.Chartable chartable, Double distance) {
	}

	public PointSelection(com.jidesoft.chart.model.Chartable chartable, Double distance, int index) {
	}

	public com.jidesoft.chart.model.Chartable getSelected() {
	}

	public void setSelected(com.jidesoft.chart.model.Chartable selected) {
	}

	/**
	 *  @return The distance in user coordinates from the selected point
	 */
	public Double getDistance() {
	}

	public void setDistance(Double distance) {
	}

	public int getIndex() {
	}

	public void setIndex(int index) {
	}

	@java.lang.Override
	public String toString() {
	}
}
