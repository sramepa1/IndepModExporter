/**
 *  When users have preferences for the visual appearance of their Chart,
 *  classes from this package can be used to acquire those settings.
 */
package com.jidesoft.chart.preference;


/**
 *  A component for selecting a new point type for points shown by a Chart component, and updating the point size for all
 *  traces whenever the selected size is changed.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class PointShapeChooser extends javax.swing.JComboBox {

	public PointShapeChooser() {
	}

	protected void init() {
	}

	public com.jidesoft.chart.PointShape getPointShape() {
	}

	public void setPointShape(com.jidesoft.chart.PointShape pointShape) {
	}

	@java.lang.Override
	public void actionPerformed(java.awt.event.ActionEvent e) {
	}
}
