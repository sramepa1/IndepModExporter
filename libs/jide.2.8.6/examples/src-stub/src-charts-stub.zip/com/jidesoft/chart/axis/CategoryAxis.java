/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


public class CategoryAxis extends Axis {

	public CategoryAxis() {
	}

	public CategoryAxis(String text) {
	}

	public CategoryAxis(com.jidesoft.chart.annotation.AutoPositionedLabel label) {
	}

	public CategoryAxis(<any> newRange) {
	}

	public CategoryAxis(<any> newRange, String text) {
	}

	protected void init() {
	}
}
