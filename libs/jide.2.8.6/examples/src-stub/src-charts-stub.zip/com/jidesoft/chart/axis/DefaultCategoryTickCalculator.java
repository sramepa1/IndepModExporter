/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


public class DefaultCategoryTickCalculator implements CategoryTickCalculator {
 {

	public DefaultCategoryTickCalculator() {
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	@java.lang.SuppressWarnings("unchecked")
	public Tick[] calculateTicks(<any> range) {
	}
}
