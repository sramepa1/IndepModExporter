/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A chartable that also carries a value for the Z axis
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public interface Chartable3D extends Chartable {
 {

	/**
	 *  Gets the z coordinate of the Chartable object
	 *  @return the z coordinate
	 */
	public Positionable getZ();
}
