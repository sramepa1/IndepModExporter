/**
 *  The package contains classes for annotating a chart with images and/or labels in JIDE Charts product.
 */
package com.jidesoft.chart.annotation;


/**
 *  A chart point in domain coordinates
 * 
 *  @author swhite@catalysoft.com
 */
public class ChartLabel extends AbstractLabel implements com.jidesoft.chart.model.Chartable {
 {

	/**
	 *  Create a chart label annotation to be placed at the given position.
	 *  The X,Y coordinates are near the centre of the label
	 *  @param x the x coordinate in the user space
	 *  @param y the y coordinate in the user space
	 *  @param label the label to draw
	 */
	public ChartLabel(double x, double y, String label) {
	}

	public ChartLabel(Positionable x, Positionable y, String label) {
	}

	public ChartLabel(Positionable x, Positionable y, String label, java.awt.Color color) {
	}

	public ChartLabel(Positionable x, Positionable y, String label, java.awt.Color color, java.awt.Font font) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public Positionable getX() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public Positionable getY() {
	}

	public int compareTo(com.jidesoft.chart.model.Chartable other) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	@java.lang.Override
	public String toString() {
	}
}
