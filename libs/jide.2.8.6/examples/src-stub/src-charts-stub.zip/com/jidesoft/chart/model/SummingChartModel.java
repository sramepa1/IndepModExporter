/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A chart model that gets its y values by summing the corresponding values of its delegate chart models.
 *  The delegate chart models should have the same number of points.
 */
public class SummingChartModel extends AbstractDelegatingChartModel {

	/**
	 *  Default Constructor
	 */
	public SummingChartModel() {
	}

	/**
	 *  If your chart models are ChartModels rather than AnnotatedChartModels, consider using
	 *  the AnnotatedChartModelAdapter.
	 *  @param newDelegates the chart models that we wish to sum over
	 */
	public SummingChartModel(String modelName, AnnotatedChartModel[] newDelegates) {
	}

	/**
	 *  Currently unsupported, but may become supported in the future
	 */
	@java.lang.Override
	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	@java.lang.Override
	public int getAnnotationCount() {
	}

	@java.lang.Override
	public Chartable getPoint(int n) {
	}

	@java.lang.Override
	public int getPointCount() {
	}

	@java.lang.Override
	protected void update() {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}
}
