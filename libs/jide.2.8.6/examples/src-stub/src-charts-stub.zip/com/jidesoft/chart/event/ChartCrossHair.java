/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  This class can be used to track the mouse position as it moves along a trace.
 *  When the model property is not set, the class tracks the nearest point from all available models.
 *  When the model property is set, the points are limited to points from that model.
 *  <p>Note: This class used to be called <code>ChartValueFocus</code> but was renamed to avoid 
 *  overloading the term focus</p>
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartCrossHair implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener, com.jidesoft.chart.Drawable {
 {

	/**
	 *  @param newChart the Chart instance for which we wish to create a cross hair
	 */
	public ChartCrossHair(com.jidesoft.chart.Chart newChart) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	/**
	 *  @return the model of interest, if any
	 */
	public com.jidesoft.chart.model.ChartModel getModel() {
	}

	/**
	 *  If you set the model of the ChartValueReporter, then only points from that model will be reported.
	 *  Otherwise points from the nearest model will be reported.
	 *  @param model the model from which points should be reported
	 */
	public void setModel(com.jidesoft.chart.model.ChartModel model) {
	}

	/**
	 *  @return the color used for the cross hair
	 */
	public java.awt.Color getColor() {
	}

	/**
	 *  Set the color to use for the cross hair
	 *  @param color
	 */
	public void setColor(java.awt.Color color) {
	}

	/**
	 *  Update the cross hair using the latest known cursor position.
	 *  You should not need to call this method directly.
	 */
	public void update() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void draw(java.awt.Graphics g) {
	}

	/**
	 *  @return the diameter of the circle used for the centre of the cross hair
	 */
	public int getCircleDiameter() {
	}

	/**
	 *  Sets the diameter of the circle to use for the centre of the cross hair
	 *  @param circleDiameter given in pixels
	 */
	public void setCircleDiameter(int circleDiameter) {
	}
}
