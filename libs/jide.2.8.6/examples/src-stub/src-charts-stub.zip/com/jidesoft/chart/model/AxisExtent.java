/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A value class used to indicate a range of values along an axis.
 *  (We can't use the word 'Range' in the name though, because it already has a specific meaning
 *  in terms of allowable values. This is different to an extent, which covers all values from
 *  the min to the max, rather than allowing one value in that range.)
 *  @author Simon White (swhite@catalysoft.com)
 */
public class AxisExtent implements Comparable {
 {

	public AxisExtent(int minimum, int maximum) {
	}

	public AxisExtent(double minimum, double maximum) {
	}

	public double getMin() {
	}

	public double getMax() {
	}

	public double size() {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	@java.lang.Override
	public String toString() {
	}

	/**
	 *  Compares this AxisExtent to another AxisExtent object by looking at the
	 *  minimum value and, if equal, then the maximum value
	 */
	public int compareTo(AxisExtent other) {
	}
}
