/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


public class PointDescriptor {

	public PointDescriptor(com.jidesoft.chart.model.Chartable chartable, int pointIndex, com.jidesoft.chart.model.ChartModel model) {
	}

	public com.jidesoft.chart.model.Chartable getChartable() {
	}

	public com.jidesoft.chart.model.ChartModel getModel() {
	}

	public int getIndex() {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	@java.lang.Override
	public String toString() {
	}
}
