/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


public class PointStyle extends AbstractStyle {

	public static final int DEFAULT_SIZE = 5;

	public PointStyle() {
	}

	public PointStyle(java.awt.Color color) {
	}

	public PointStyle(java.awt.Color color, com.jidesoft.chart.PointShape shape) {
	}

	public PointStyle(java.awt.Color color, com.jidesoft.chart.PointShape shape, int size) {
	}

	public com.jidesoft.chart.PointShape getShape() {
	}

	public void setShape(com.jidesoft.chart.PointShape shape) {
	}

	public int getSize() {
	}

	public void setSize(int size) {
	}

	@java.lang.Override
	public String toString() {
	}
}
