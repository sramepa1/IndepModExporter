/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  <code>ShortcutSchemaManager</code> is a manager for {@link ShortcutSchema}.
 */
public class ShortcutSchemaManager {

	/**
	 *  List of listeners
	 */
	protected javax.swing.event.EventListenerList _listenerList;

	/**
	 *  Creates an empty <code>ShortcutSchemaManager</code>.
	 */
	public ShortcutSchemaManager() {
	}

	/**
	 *  This is a copy constructor for <code>ShortcutSchemaManager</code>.
	 * 
	 *  @param manager
	 */
	public ShortcutSchemaManager(ShortcutSchemaManager manager) {
	}

	/**
	 *  Gets an array of <code>ShortcutSchema</code> that are managed by this <code>ShortcutSchemaManager</code>.
	 * 
	 *  @return an array of <code>ShortcutSchema</code>.
	 */
	public ShortcutSchema[] getShortcutSchemas() {
	}

	/**
	 *  Adds a <code>ShortcutSchema</code> to <code>ShortcutSchemaManager</code>. It will fire SHORTCUT_SCHEMA_ADDED
	 *  event.
	 * 
	 *  @param shortcutSchema
	 *  @throws IllegalArgumentException if input shortcut schema is null or the name already exists in
	 *                                   ShortcutSchemaManager.
	 */
	public void addShortcutSchema(ShortcutSchema shortcutSchema) {
	}

	/**
	 *  Gets active shortcut schema name.
	 * 
	 *  @return active shortcut schema name.
	 */
	public String getActiveShortcutSchemaName() {
	}

	/**
	 *  Gets active shortcut schema.
	 * 
	 *  @return active shortcut schema.
	 */
	public ShortcutSchema getActiveShortcutSchema() {
	}

	/**
	 *  Gets the <code>ShortcutSchema</code> by its name.
	 * 
	 *  @param schemaName
	 *  @return <code>ShortcutSchema</code> with specified name.
	 */
	public ShortcutSchema getShortcutSchema(String schemaName) {
	}

	/**
	 *  Sets active shortcut schema. SHORTCUT_SCHEMA_ACTIVATED and SHORTCUT_SCHEMA_DEACTIVATED event will be fired by
	 *  this method.
	 * 
	 *  @param schemaName
	 */
	public void setActiveShortcutSchemaName(String schemaName) {
	}

	/**
	 *  Renames the schema. SHORTCUT_SCHEMA_RENAMED event will be fired if renaming is successful.
	 * 
	 *  @param oldName the old name
	 *  @param newName the new name
	 */
	public void renameSchema(String oldName, String newName) {
	}

	/**
	 *  Removes the shortcut schema with the specified name.
	 * 
	 *  @param shortcutSchemaName
	 */
	public void removeShortcutSchema(String shortcutSchemaName) {
	}

	/**
	 *  Removes all shortcut schema.
	 */
	public void clear() {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the shortcut schema occurs.
	 * 
	 *  @param l the SchemaListener
	 */
	public void addShortcutSchemaListener(ShortcutSchemaListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the shortcut schema occurs.
	 * 
	 *  @param l the SchemaListener
	 */
	public void removeShortcutSchemaListener(ShortcutSchemaListener l) {
	}

	/**
	 *  Returns an array of all the shortcut schema listeners registered on this shortcut schema manager.
	 * 
	 *  @return all of this model's <code>SchemaListener</code>s or an empty array if no shortcut schema listeners are
	 *          currently registered
	 * 
	 *  @see #addShortcutSchemaListener
	 *  @see #removeShortcutSchemaListener
	 */
	public ShortcutSchemaListener[] getShortcutSchemaListeners() {
	}

	/**
	 *  Forwards the given notification event to all <code>ShortcutSchemaListener</code> that registered themselves as
	 *  listeners for this shortcut schema manager.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addShortcutSchemaListener
	 *  @see ShortcutSchemaEvent
	 */
	public void fireShortcutSchemaChanged(ShortcutSchemaEvent e) {
	}

	/**
	 *  Gets an optional version string.
	 * 
	 *  @return version string.
	 */
	public String getVersion() {
	}

	/**
	 *  Sets version string.
	 * 
	 *  @param version
	 */
	public void setVersion(String version) {
	}
}
