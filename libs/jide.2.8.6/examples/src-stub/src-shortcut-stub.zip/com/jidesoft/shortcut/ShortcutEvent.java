/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  <code>ShortcutEvent</code> is used to notify interested parties that shortcuts in shortcut editor has changed in the
 *  event source.
 */
public class ShortcutEvent extends java.util.EventObject {

	/**
	 *  The first number in the range of ids used for shortcut events.
	 */
	public static final int SHORTCUT_EVENT_FIRST = 8999;

	public static final int SHORTCUT_ADDED = 9000;

	public static final int SHORTCUT_REMOVED = 9001;

	protected int _type;

	/**
	 *  Constructs a ShortcutEvent object.
	 * 
	 *  @param source the Object that is the source of the event (typically <code>this</code>)
	 */
	public ShortcutEvent(Object source, int type) {
	}

	public ShortcutEvent(Object source, int type, String command, Shortcut shortcut) {
	}

	public int getType() {
	}

	public Shortcut getShortcut() {
	}

	public String getCommand() {
	}

	/**
	 *  Returns a parameter string identifying this event. This method is useful for event logging and for debugging.
	 * 
	 *  @return a string identifying the event and its attributes
	 */
	public String paramString() {
	}

	@java.lang.Override
	public String toString() {
	}
}
