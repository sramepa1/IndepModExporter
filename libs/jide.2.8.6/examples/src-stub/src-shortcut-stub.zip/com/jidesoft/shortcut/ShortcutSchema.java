/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  A data structure for ShortcutSchema.
 *  <p/>
 */
public class ShortcutSchema {

	/**
	 *  List of listeners
	 */
	protected javax.swing.event.EventListenerList _listenerList;

	/**
	 *  Creates a <tt>ShortcutSchema</tt> without name.
	 */
	public ShortcutSchema() {
	}

	/**
	 *  Creates a <tt>ShortcutSchema</tt> with a specified name.
	 */
	public ShortcutSchema(String name) {
	}

	/**
	 *  Copy constructor for <tt>ShortcutSchema</tt>.
	 * 
	 *  @param shortcutSchema
	 */
	public ShortcutSchema(ShortcutSchema shortcutSchema) {
	}

	/**
	 *  Gets the name of the <tt>ShortcutSchema</tt>.
	 * 
	 *  @return the name of the <tt>ShortcutSchema</tt>.
	 */
	public String getName() {
	}

	/**
	 *  Sets the name of the <tt>ShortcutSchema</tt>.
	 * 
	 *  @param name the new name of the <tt>ShortcutSchema</tt>.
	 */
	public void setName(String name) {
	}

	/**
	 *  Checks if the <tt>ShortcutSchema</tt> is editable.
	 * 
	 *  @return true or false.
	 */
	public boolean isEditable() {
	}

	/**
	 *  Made <tt>ShortcutSchema</tt> editable or not editable.
	 * 
	 *  @param editable
	 */
	public void setEditable(boolean editable) {
	}

	/**
	 *  Gets the shortcuts for a particular command.
	 * 
	 *  @param command
	 *  @return an array of shortcut for the command.
	 */
	public Shortcut[] getShortcuts(String command) {
	}

	/**
	 *  Gets the shortcuts for a particular command that are defined in this <tt>ShortcutSchema</tt> only. {@link
	 *  #getShortcuts(String)} will return a combined list of shortcuts defined in this <tt>ShortcutSchema</tt> as well
	 *  as parent <tt>ShortcutSchema</tt> if any.
	 * 
	 *  @param command
	 *  @return an array of shortcut for the command.
	 * 
	 *  @see #getShortcuts(String)
	 */
	public Shortcut[] getLocalShortcuts(String command) {
	}

	/**
	 *  Sets shortcuts for a command.
	 * 
	 *  @param command
	 *  @param shortcuts
	 */
	public void setShortcuts(String command, java.util.List shortcuts) {
	}

	/**
	 *  Clears all shortcuts for all commands from this <tt>ShortcutSchema</tt>.
	 */
	public void clearAllShortcuts() {
	}

	/**
	 *  Clears all shortcuts for a command.
	 * 
	 *  @param command
	 */
	public void clearShortcuts(String command) {
	}

	/**
	 *  Adds a new shortcut for a command.
	 * 
	 *  @param command
	 *  @param shortcut
	 */
	public void addShortcut(String command, Shortcut shortcut) {
	}

	/**
	 *  Adds a new shortcut for a command.
	 * 
	 *  @param command
	 *  @param shortcut
	 *  @param replace  true to replace all previous defined shortcuts.
	 */
	public void addShortcut(String command, Shortcut shortcut, boolean replace) {
	}

	/**
	 *  Removes a shortcut from a command.
	 * 
	 *  @param command
	 *  @param shortcut
	 */
	public void removeShortcut(String command, Shortcut shortcut) {
	}

	/**
	 *  Gets the parent <tt>ShortcutSchema</tt>.
	 * 
	 *  @return the parent <tt>ShortcutSchema</tt>.
	 */
	public ShortcutSchema getParent() {
	}

	/**
	 *  Sets the parent <tt>ShortcutSchema</tt>.
	 * 
	 *  @param parent the parent <tt>ShortcutSchema</tt>.
	 */
	public void setParent(ShortcutSchema parent) {
	}

	/**
	 *  Checks if this <tt>ShortcutSchema</tt> is active. This is a read-only property. To make a <tt>ShortcutSchema</tt>
	 *  active, you should use {@link ShortcutSchemaManager#setActiveShortcutSchemaName(String)} to guarantee only one
	 *  <tt>ShortcutSchema</tt> is active at one time.
	 * 
	 *  @return true if the <tt>ShortcutSchema</tt> is active.
	 */
	public boolean isActive() {
	}

	public java.util.List getShortcutKeys() {
	}

	public java.util.List getLocalShortcutKeys() {
	}

	@java.lang.Override
	public String toString() {
	}

	public java.util.List findUsages(Shortcut shortcut) {
	}

	public java.util.List findConflicts(String command, Shortcut shortcut) {
	}

	public void removeConflicts(String command, Shortcut shortcut) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	/**
	 *  Checks if a command is overridden.
	 * 
	 *  @param command
	 *  @return true if command is overridden in this <tt>ShortcutSchema</tt>.
	 */
	public boolean isOverridden(String command) {
	}

	/**
	 *  Gets the icon for a command.
	 * 
	 *  @param command
	 *  @return the icon for a command.
	 */
	public javax.swing.Icon getCommandIcon(String command) {
	}

	/**
	 *  Assigned an icon for a command. The icon will appear on the command in the command list.
	 * 
	 *  @param command
	 *  @param icon
	 */
	public void setCommandIcon(String command, javax.swing.Icon icon) {
	}

	/**
	 *  Clears the icon for a command.
	 * 
	 *  @param command
	 */
	public void clearCommandIcon(String command) {
	}

	/**
	 *  Clears all command icons.
	 */
	public void clearAllCommandIcons() {
	}

	/**
	 *  Gets the description for a command.
	 * 
	 *  @param command
	 *  @return the description for a command.
	 */
	public String getCommandDescription(String command) {
	}

	/**
	 *  Assigned an description for a command. The description will appear on the command in the command list.
	 * 
	 *  @param command
	 *  @param description
	 */
	public void setCommandDescription(String command, String description) {
	}

	/**
	 *  Clears the description for a command.
	 * 
	 *  @param command
	 */
	public void clearCommandDescription(String command) {
	}

	/**
	 *  Clears all command descriptions.
	 */
	public void clearAllCommandDescriptions() {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the data model occurs.
	 * 
	 *  @param l the ShortcutListener
	 */
	public void addShortcutListener(ShortcutListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the data model occurs.
	 * 
	 *  @param l the ShortcutListener
	 */
	public void removeShortcutListener(ShortcutListener l) {
	}

	/**
	 *  Returns an array of all the table model listeners registered on this model.
	 * 
	 *  @return all of this model's <code>SchemaListener</code>s or an empty array if no table model listeners are
	 *          currently registered
	 * 
	 *  @see #addShortcutListener(ShortcutListener)
	 *  @see #removeShortcutListener(ShortcutListener)
	 *  @since 1.4
	 */
	public ShortcutListener[] getShortcutListeners() {
	}

	public void fireShortcutAdded(String command, Shortcut shortcut) {
	}

	public void fireShortcutRemoved(String command, Shortcut shortcut) {
	}

	/**
	 *  Forwards the given notification event to all <code>SchemaListeners</code> that registered themselves as listeners
	 *  for this table model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addShortcutListener(ShortcutListener)
	 *  @see ShortcutEvent
	 *  @see EventListenerList
	 */
	public void fireShortcutChanged(ShortcutEvent e) {
	}

	/**
	 *  Gets an iterator of all commands.
	 * 
	 *  @return an iterator of all commands.
	 */
	public java.util.Iterator getCommands() {
	}

	@java.lang.Override
	public int hashCode() {
	}
}
