/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  An interface for the margin component. Margin is used for as children component for {@link MarginArea} in {@link
 *  CodeEditor}.
 */
public interface Margin {

	/**
	 *  Gets the code editor.
	 * 
	 *  @return the code editor.
	 */
	public com.jidesoft.editor.CodeEditor getCodeEditor();

	/**
	 *  Sets the code editor.
	 * 
	 *  @param editor
	 */
	public void setCodeEditor(com.jidesoft.editor.CodeEditor editor);

	/**
	 *  Paints the margin.
	 * 
	 *  @param g
	 */
	public void paintMargin(java.awt.Graphics g);

	/**
	 *  Adds a margin painter to paint extra information on top of the current margin painted by paintMargin method.
	 * 
	 *  @param painter
	 */
	public void addMarginPainter(MarginPainter painter);

	/**
	 *  Removes a margin painter added by <code>addMarginPainter</code>.
	 * 
	 *  @param painter
	 */
	public void removeMarginPainter(MarginPainter painter);

	/**
	 *  Gets the preferred width of the margin. Since the margin is placed vertical besides the code editor, the height
	 *  is fixed. That's why it only needs to ask for the preferred width using this method.
	 * 
	 *  @return the preferred width.
	 */
	public int getPreferredWidth();

	/**
	 *  Gets the margin component. If you implement your margin by extending a Component, you simply "return this" when
	 *  implementing this method.
	 * 
	 *  @return the margin component.
	 */
	public java.awt.Component getMarginComponent();
}
