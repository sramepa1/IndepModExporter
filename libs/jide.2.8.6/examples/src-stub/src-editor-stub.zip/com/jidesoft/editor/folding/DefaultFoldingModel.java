/**
 *  The package contains classes for code folding for JIDE Code Editor product.
 */
package com.jidesoft.editor.folding;


/**
 *  Default implementation of FoldingModel.
 */
public class DefaultFoldingModel implements FoldingModel, javax.swing.event.DocumentListener {
 {

	protected javax.swing.event.EventListenerList _listenerList;

	public DefaultFoldingModel(com.jidesoft.editor.CodeEditor editor) {
	}

	public synchronized FoldingSpan addFoldingSpan(int startOffset, int endOffset, String description) {
	}

	/**
	 *  Creates the folding span. You can override this method to create your own folding span if you have to.
	 * 
	 *  @param startOffset the starting offset.
	 *  @param endOffset   the end offset.
	 *  @param description the description of the span.
	 *  @return a folding span.
	 */
	protected FoldingSpan createFoldingSpan(int startOffset, int endOffset, String description) {
	}

	public synchronized boolean removeFoldingSpan(FoldingSpan foldingSpan) {
	}

	public boolean isAdjusting() {
	}

	public void setAdjusting(boolean adjusting) {
	}

	public synchronized void expandFoldingSpan(FoldingSpan span) {
	}

	public synchronized void collapseFoldingSpan(FoldingSpan span) {
	}

	protected synchronized void expandAll(boolean expand) {
	}

	public synchronized void expandAll() {
	}

	public synchronized void collapseAll() {
	}

	public synchronized void foldingSpanUpdated(FoldingSpan span) {
	}

	public synchronized FoldingSpan[] getFoldingSpans() {
	}

	public synchronized void setEnabled(boolean enabled) {
	}

	public synchronized boolean isEnabled() {
	}

	protected void fireFoldingSpanChanged(FoldingSpan foldingSpan, int type, boolean isAdjusting) {
	}

	public void addFoldingSpanListener(FoldingSpanListener l) {
	}

	public void removeFoldingSpanListener(FoldingSpanListener l) {
	}

	public FoldingSpanListener[] getFoldingSpanListeners() {
	}

	public void rebuild() {
	}

	public int getLastTopLevelIndexBefore(int offset) {
	}

	public int getFoldedLinesCountBefore(int offset) {
	}

	public FoldingSpan[] getTopLevelSpans() {
	}

	public FoldingSpan getOutermostSpanAtOffset(int offset) {
	}

	public FoldingSpan[] getFoldedSpansAtOffset(int offset) {
	}

	public boolean hasAnySpan(int startOffset, int endOffset) {
	}

	public FoldingSpan[] getVisibleSpans() {
	}

	public void insertUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void removeUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void changedUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void resetCaretPosition() {
	}

	public static FoldingSpan findFoldingSpanStartingAtLine(com.jidesoft.editor.CodeEditor editor, int line) {
	}

	public static FoldingSpan[] getFoldingSpanAtOffset(com.jidesoft.editor.CodeEditor editor, int i) {
	}
}
