/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>CodeEditorSettings</code> contains all the possible settings for <code>CodeEditor</code>.
 */
public interface CodeEditorSettings {

	public static final String PROPERTY_CARET_VISIBLE = "caretVisible";

	public static final String PROPERTY_CARET_BLINKS = "caretBlinks";

	public static final String PROPERTY_BLOCK_CARET = "blockCaret";

	public static final String PROPERTY_CARET_COLOR = "caretColor";

	public static final String PROPERTY_SELECTION_COLOR = "selectionColor";

	public static final String PROPERTY_LINE_HIGHLIGHT_COLOR = "lineHighlightColor";

	public static final String PROPERTY_LINE_HIGHLIGHT_VISIBLE = "lineHighlight";

	public static final String PROPERTY_BRACKET_HIGHLIGHT_COLOR = "bracketHighlightColor";

	public static final String PROPERTY_BRACKET_HIGHLIGHT_VISIBLE = "bracketHighlight";

	public static final String PROPERTY_SPECIAL_CHARACTERS_COLOR = "specialCharactersColor";

	public static final String PROPERTY_SPECIAL_CHARACTERS_VISIBLE = "specialCharacters";

	public static final String PROPERTY_PAINT_INVALID = "paintInvalid";

	public static final String PROPERTY_VIRTUAL_SPACE_ALLOWED = "virtualSpaceAllowed";

	public static final String PROPERTY_ELECTRIC_SCROLL = "electricScroll";

	public static final String PROPERTY_STYLES = "styles";

	public static final String PROPERTY_FONT = "font";

	public static final String PROPERTY_TAB_SIZE = "tabSize";

	public static final String PROPERTY_LINE_BREAK = "lineBreakStyle";

	public static final String PROPERTY_INPUT_HANDLER = "inputHandler";

	public boolean isCaretVisible();

	public boolean isCaretBlinks();

	public boolean isBlockCaret();

	public int getElectricScroll();

	public int getTabSize();

	public SyntaxStyleSchema getStyles();

	public java.awt.Font getFont();

	public java.awt.Color getCaretColor();

	public java.awt.Color getSelectionColor();

	public java.awt.Color getLineHighlightColor();

	public boolean isLineHighlightVisible();

	public java.awt.Color getBracketHighlightColor();

	public boolean isBracketHighlightVisible();

	public java.awt.Color getSpecialCharactersColor();

	public boolean isSpecialCharactersVisible();

	public boolean isPaintInvalid();

	public boolean isVirtualSpaceAllowed();

	public int getLineBreakStyle();

	public action.InputHandler getInputHandler();

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener);
}
