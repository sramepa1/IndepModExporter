/**
 *  The package contains classes for code folding for JIDE Code Editor product.
 */
package com.jidesoft.editor.folding;


/**
 */
public class DefaultFoldingSpan extends com.jidesoft.editor.DefaultSpan implements FoldingSpan {
 {

	public DefaultFoldingSpan(com.jidesoft.editor.CodeEditor editor, int startOffset, int endOffset) {
	}

	public DefaultFoldingSpan(com.jidesoft.editor.CodeEditor editor, int startOffset, int endOffset, String description) {
	}

	public void setExpanded(boolean expanded) {
	}

	public boolean isExpanded() {
	}

	@java.lang.Override
	public void setStartOffset(int startOffset) {
	}

	@java.lang.Override
	public void setEndOffset(int endOffset) {
	}

	public void setDescription(String description) {
	}

	public String getDescription() {
	}
}
