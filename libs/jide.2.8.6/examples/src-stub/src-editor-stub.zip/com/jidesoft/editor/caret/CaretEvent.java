/**
 *  The package contains classes for caret event and caret model for JIDE Code Editor product.
 */
package com.jidesoft.editor.caret;


/**
 *  The event to represent a caret position change.
 */
public class CaretEvent extends java.util.EventObject {

	public static final int MODEL_POSITION = 0;

	public static final int VIEW_POSITION = 1;

	/**
	 *  Creates CaretEvent that represents a caret position change. Please note, both positions are the caret model
	 *  position, not caret view position.
	 * 
	 *  @param editor      the CodeEditor.
	 *  @param oldPosition the old caret position.
	 *  @param newPosition the new caret position.
	 */
	public CaretEvent(com.jidesoft.editor.CodeEditor editor, CaretPosition oldPosition, CaretPosition newPosition) {
	}

	/**
	 *  Creates CaretEvent that represents a caret position change. Please note, both positions are the caret model
	 *  position, not caret view position.
	 * 
	 *  @param editor      the CodeEditor.
	 *  @param type        the event type to indicate the event is for the MODEL_POSITION or for the VIEW_POSITION.
	 *  @param oldPosition the old caret position.
	 *  @param newPosition the new caret position.
	 */
	public CaretEvent(com.jidesoft.editor.CodeEditor editor, int type, CaretPosition oldPosition, CaretPosition newPosition) {
	}

	/**
	 *  Gets the CodeEditor associated with this CarentEvent.
	 * 
	 *  @return the CodeEditor.
	 */
	public com.jidesoft.editor.CodeEditor getCodeEditor() {
	}

	/**
	 *  Gets the old caret position.
	 * 
	 *  @return the old caret position.
	 */
	public CaretPosition getOldPosition() {
	}

	/**
	 *  Gets the new caret position.
	 * 
	 *  @return the new caret position.
	 */
	public CaretPosition getNewPosition() {
	}

	/**
	 *  Gets the type of the caret event. It could be either {@link #MODEL_POSITION} or {@link #VIEW_POSITION}.
	 * 
	 *  @return {@link #MODEL_POSITION} or {@link #VIEW_POSITION}.
	 */
	public int getType() {
	}

	@java.lang.Override
	public String toString() {
	}
}
