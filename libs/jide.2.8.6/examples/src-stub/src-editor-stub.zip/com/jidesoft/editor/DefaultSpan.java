/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  Default implementation of the interface Span.
 */
public class DefaultSpan implements Span {
 {

	public DefaultSpan(int startOffset, int endOffset) {
	}

	public int getStartOffset() {
	}

	public void setStartOffset(int startOffset) {
	}

	public int getEndOffset() {
	}

	public void setEndOffset(int endOffset) {
	}

	public boolean isValid() {
	}
}
