/**
 *  The package contains classes for input handlers for JIDE Code Editor product.
 */
package com.jidesoft.editor.action;


/**
 *  <code>MacOSXEditorShortcutSchema</code> is a ShortcutSchema for Code Editor on Mac OSX. It is
 *  derived from <code>EditorShortcutSchema</code> with the difference that all control mask is
 *  replaced by meta mask to follow the convention on Mac OSX.
 */
public class MacOSXEditorShortcutSchema extends ShortcutSchema {

	public MacOSXEditorShortcutSchema(ShortcutSchema defaultShortcutSchema) {
	}
}
