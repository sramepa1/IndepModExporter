/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>MarkerEye</code> is a panel to indicate the inspecting status.
 *  The paint of MarkerEye is done by a class called {@link MarkerEyePainter}.
 *  By default, {@link DefaultMarkerEyePainter} is used. You can always set your own
 *  painter by calling {@link #setPainter(MarkerEyePainter)}.
 * 
 *  @author Patrick Gotthardt
 */
public class MarkerEye extends javax.swing.JPanel {

	/**
	 *  Creates a <code>MarkerEye</code>.
	 * 
	 *  @param codeEditor
	 *  @param markerArea
	 */
	public MarkerEye(com.jidesoft.editor.CodeEditor codeEditor, MarkerArea markerArea) {
	}

	/**
	 *  Gets the painter.
	 * 
	 *  @return the painter.
	 */
	public MarkerEyePainter getPainter() {
	}

	/**
	 *  Sets the painter.
	 * 
	 *  @param painter
	 */
	public void setPainter(MarkerEyePainter painter) {
	}

	/**
	 *  Paints the component using {@link MarkerEyePainter}.
	 * 
	 *  @param g
	 */
	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Gets the tooltip text using {@link MarkerEyePainter}.
	 * 
	 *  @return the tooltip text.
	 */
	@java.lang.Override
	public String getToolTipText() {
	}
}
