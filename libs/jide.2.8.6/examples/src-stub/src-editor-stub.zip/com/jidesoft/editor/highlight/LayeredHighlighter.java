/**
 *  The package contains classes for code highlighter for JIDE Code Editor product.
 */
package com.jidesoft.editor.highlight;


/**
 *  @author Scott Violet
 *  @author Timothy Prinzing
 *  @see Highlighter
 */
public abstract class LayeredHighlighter implements Highlighter {
 {

	public LayeredHighlighter() {
	}

	/**
	 *  When leaf Views (such as LabelView) are rendering they should
	 *  call into this method. If a highlight is in the given region it will
	 *  be drawn immediately.
	 * 
	 *  @param g          Graphics used to draw
	 *  @param p0         starting offset of view
	 *  @param p1         ending offset of view
	 *  @param viewBounds Bounds of View
	 *  @param editor     CodeEditor
	 */
	public abstract void paintLayeredHighlights(java.awt.Graphics g, int p0, int p1, java.awt.Shape viewBounds, com.jidesoft.editor.CodeEditor editor) {
	}

	/**
	 *  Layered highlight renderer.
	 */
	public abstract static class LayerPainter {


		public LayeredHighlighter.LayerPainter() {
		}

		public abstract java.awt.Shape paintLayer(java.awt.Graphics g, int p0, int p1, java.awt.Shape viewBounds, com.jidesoft.editor.CodeEditor editor) {
		}
	}
}
