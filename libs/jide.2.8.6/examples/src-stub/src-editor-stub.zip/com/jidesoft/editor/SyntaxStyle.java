/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  A simple text style class. It can specify the color, italic flag, and bold flag of a run of text.
 * 
 *  @author Slava Pestov
 *  @version $Id: SyntaxStyle.java,v 1.6 1999/12/13 03:40:30 sp Exp $
 */
public class SyntaxStyle implements ColorStyle, FontStyle, EffectStyle {
 {

	public SyntaxStyle() {
	}

	/**
	 *  Creates a new SyntaxStyle.
	 * 
	 *  @param foreground The text color
	 *  @param fontStyle  as defined in Font.
	 */
	public SyntaxStyle(java.awt.Color foreground, int fontStyle) {
	}

	public SyntaxStyle(int effect, java.awt.Color effectColor) {
	}

	public SyntaxStyle(int effect, java.awt.Color effectColor, java.awt.Color stripeColor) {
	}

	public SyntaxStyle(java.awt.Color background) {
	}

	public SyntaxStyle(java.awt.Color background, java.awt.Color foreground) {
	}

	public SyntaxStyle(java.awt.Color background, java.awt.Color foreground, java.awt.Color stripeColor) {
	}

	/**
	 *  Returns the color specified in this style.
	 */
	public java.awt.Color getForeground() {
	}

	public void setForeground(java.awt.Color foreground) {
	}

	/**
	 *  Gets the font style.
	 * 
	 *  @return the font style.
	 */
	public int getFontStyle() {
	}

	/**
	 *  Sets the font style.
	 * 
	 *  @param fontStyle the font style
	 */
	public void setFontStyle(int fontStyle) {
	}

	/**
	 *  Returns true if italics is enabled for this style.
	 * 
	 *  @return true if italics is enabled for this style. Otherwise false.
	 */
	public boolean isItalic() {
	}

	/**
	 *  Returns true if boldface is enabled for this style.
	 * 
	 *  @return true if boldface is enabled for this style. Otherwise false.
	 */
	public boolean isBold() {
	}

	/**
	 *  Returns true if font style is not bold nor italic.
	 * 
	 *  @return true if font style is not bold nor italic. Otherwise false
	 */
	public boolean isPlain() {
	}

	public java.awt.Color getBackground() {
	}

	public void setBackground(java.awt.Color background) {
	}

	public java.awt.Color getEffectColor() {
	}

	public void setEffectColor(java.awt.Color effectColor) {
	}

	public int getEffect() {
	}

	public void setEffect(int effect) {
	}

	public java.awt.Color getStripeColor() {
	}

	public void setStripeColor(java.awt.Color stripeColor) {
	}

	/**
	 *  Returns the specified font, but with the style's bold and italic flags applied.
	 * 
	 *  @param font the current font
	 *  @return the specified font, but with the style's bold and italic flags applied.
	 */
	public java.awt.Font getStyledFont(java.awt.Font font) {
	}

	/**
	 *  Returns the font metrics for the styled font.
	 * 
	 *  @param font the font
	 *  @param g    the graphics
	 *  @return the font metrics for the specified font.
	 */
	public java.awt.FontMetrics getFontMetrics(java.awt.Font font, java.awt.Graphics g) {
	}

	/**
	 *  Sets the foreground color and font of the specified graphics context to that specified in this style.
	 * 
	 *  @param gfx  The graphics context
	 *  @param font The font to add the styles to
	 */
	public void setGraphicsFlags(java.awt.Graphics gfx, java.awt.Font font) {
	}

	/**
	 *  Returns a string representation of this object.
	 */
	@java.lang.Override
	public String toString() {
	}

	public void paintMarker(java.awt.Graphics g, int x1, int x2, int y, java.awt.FontMetrics fm) {
	}
}
