/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  Default implementation of <code>CodeEditorSettings</code>.
 */
public class DefaultCodeEditorSettings implements CodeEditorSettings {
 {

	public DefaultCodeEditorSettings() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method
	 *  should be used to remove PropertyChangeListeners that were registered
	 *  for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners
	 *  registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s
	 *          or an empty array if no property change
	 *          listeners are currently registered
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific
	 *  property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific
	 *  property. This method should be used to remove PropertyChangeListeners
	 *  that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated
	 *  with the named property.
	 * 
	 *  @return all of the <code>PropertyChangeListeners</code> associated with
	 *          the named property or an empty array if no listeners have
	 *          been added
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}

	public boolean isCaretVisible() {
	}

	public boolean isCaretVisibleSet() {
	}

	public void setCaretVisible(boolean caretVisible) {
	}

	public boolean isCaretBlinks() {
	}

	public boolean isCaretBlinksSet() {
	}

	public void setCaretBlinks(boolean caretBlinks) {
	}

	public int getElectricScroll() {
	}

	public void setElectricScroll(int electricScroll) {
	}

	public boolean isBlockCaret() {
	}

	public boolean isBlockCaretSet() {
	}

	public void setBlockCaret(boolean blockCaret) {
	}

	public int getTabSize() {
	}

	public void setTabSize(int tabSize) {
	}

	public SyntaxStyleSchema getStyles() {
	}

	public void setStyles(SyntaxStyleSchema styles) {
	}

	public java.awt.Font getFont() {
	}

	public void setFont(java.awt.Font font) {
	}

	public java.awt.Color getCaretColor() {
	}

	public void setCaretColor(java.awt.Color caretColor) {
	}

	public java.awt.Color getSelectionColor() {
	}

	public void setSelectionColor(java.awt.Color selectionColor) {
	}

	public java.awt.Color getLineHighlightColor() {
	}

	public void setLineHighlightColor(java.awt.Color lineHighlightColor) {
	}

	public boolean isLineHighlightVisible() {
	}

	public boolean isLineHighlightVisibleSet() {
	}

	public void setLineHighlightVisible(boolean lineHighlightVisible) {
	}

	public java.awt.Color getBracketHighlightColor() {
	}

	public void setBracketHighlightColor(java.awt.Color bracketHighlightColor) {
	}

	public boolean isBracketHighlightVisible() {
	}

	public boolean isBracketHighlightVisibleSet() {
	}

	public void setBracketHighlightVisible(boolean bracketHighlightVisible) {
	}

	public java.awt.Color getSpecialCharactersColor() {
	}

	public void setSpecialCharactersColor(java.awt.Color specialCharactersColor) {
	}

	public boolean isSpecialCharactersVisible() {
	}

	public boolean isSpecialCharactersSet() {
	}

	public void setSpecialCharactersVisible(boolean specialCharactersVisible) {
	}

	public boolean isPaintInvalid() {
	}

	public boolean isPaintInvalidSet() {
	}

	public void setPaintInvalid(boolean paintInvalid) {
	}

	public boolean isVirtualSpaceAllowed() {
	}

	public boolean isVirtualSpaceAllowedSet() {
	}

	public void setVirtualSpaceAllowed(boolean virtualSpaceAllowed) {
	}

	public int getLineBreakStyle() {
	}

	public void setLineBreakStyle(int lineBreakStyle) {
	}

	public action.InputHandler getInputHandler() {
	}

	public void setInputHandler(action.InputHandler inputHandler) {
	}
}
