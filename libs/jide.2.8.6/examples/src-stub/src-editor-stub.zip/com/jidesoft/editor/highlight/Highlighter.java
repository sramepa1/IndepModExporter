/**
 *  The package contains classes for code highlighter for JIDE Code Editor product.
 */
package com.jidesoft.editor.highlight;


/**
 *  An interface for an object that allows one to mark up the background
 *  with colored areas.
 * 
 *  @author Timothy Prinzing
 *  @version 1.22 12/19/03
 */
public interface Highlighter {

	/**
	 *  Called when the UI is being installed into the
	 *  interface of a CodeEditor.  This can be used
	 *  to gain access to the model that is being navigated
	 *  by the implementation of this interface.
	 * 
	 *  @param c the CodeEditor editor
	 */
	public void install(com.jidesoft.editor.CodeEditor c);

	/**
	 *  Called when the UI is being removed from the
	 *  interface of a CodeEditor.  This is used to
	 *  unregister any listeners that were attached.
	 * 
	 *  @param c the CodeEditor editor
	 */
	public void deinstall(com.jidesoft.editor.CodeEditor c);

	/**
	 *  Renders the highlights.
	 * 
	 *  @param g the graphics context.
	 */
	public void paint(java.awt.Graphics g);

	/**
	 *  Adds a highlight to the view.  Returns a tag that can be used
	 *  to refer to the highlight.
	 * 
	 *  @param p0 the beginning of the range >= 0
	 *  @param p1 the end of the range >= p0
	 *  @param p  the painter to use for the actual highlighting
	 *  @return an object that refers to the highlight
	 *  @throws javax.swing.text.BadLocationException
	 *           for an invalid range specification
	 */
	public Object addHighlight(int p0, int p1, Highlighter.HighlightPainter p);

	/**
	 *  Removes a highlight from the view.
	 * 
	 *  @param tag which highlight to remove
	 */
	public void removeHighlight(Object tag);

	/**
	 *  Removes all highlights this highlighter is responsible for.
	 */
	public void removeAllHighlights();

	/**
	 *  Changes the given highlight to span a different portion of
	 *  the document.  This may be more efficient than a remove/add
	 *  when a selection is expanding/shrinking (such as a sweep
	 *  with a mouse) by damaging only what changed.
	 * 
	 *  @param tag which highlight to change
	 *  @param p0  the beginning of the range >= 0
	 *  @param p1  the end of the range >= p0
	 *  @throws javax.swing.text.BadLocationException
	 *           for an invalid range specification
	 */
	public void changeHighlight(Object tag, int p0, int p1);

	/**
	 *  Fetches the current list of highlights.
	 * 
	 *  @return the highlight list
	 */
	public Highlighter.Highlight[] getHighlights();
}
