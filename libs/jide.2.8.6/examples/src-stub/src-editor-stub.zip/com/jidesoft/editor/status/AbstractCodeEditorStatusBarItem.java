/**
 *  The package contains classes for a code editor related status bar items for JIDE Code Editor product.
 */
package com.jidesoft.editor.status;


/**
 *  An abstract implementation of <code>CodeEditorStatusBarItem</code>. It extends {@link
 *  LabelStatusBarItem} and add abstract methods to register/unregister listener to a
 *  <code>CodeEditor</code>. Most pre-built status bar items we provided extend this class.
 */
public abstract class AbstractCodeEditorStatusBarItem extends LabelStatusBarItem implements CodeEditorStatusBarItem {
 {

	protected com.jidesoft.editor.CodeEditor _editor;

	public AbstractCodeEditorStatusBarItem() {
	}

	public AbstractCodeEditorStatusBarItem(String name) {
	}

	public com.jidesoft.editor.CodeEditor getCodeEditor() {
	}

	public void setCodeEditor(com.jidesoft.editor.CodeEditor editor) {
	}
}
