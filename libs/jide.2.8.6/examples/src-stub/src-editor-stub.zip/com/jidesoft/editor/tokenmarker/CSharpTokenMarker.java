/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  C# token marker.
 */
public class CSharpTokenMarker extends CTokenMarker {

	public CSharpTokenMarker() {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
