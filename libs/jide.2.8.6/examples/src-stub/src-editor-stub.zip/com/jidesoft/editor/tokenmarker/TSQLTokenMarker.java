/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Transact-SQL token marker.
 * 
 *  @author mike dillon
 *  @version $Id: TSQLTokenMarker.java,v 1.9 1999/12/13 03:40:30 sp Exp $
 */
public class TSQLTokenMarker extends SQLTokenMarker {

	public TSQLTokenMarker() {
	}

	public static com.jidesoft.editor.KeywordMap getKeywordMap() {
	}
}
