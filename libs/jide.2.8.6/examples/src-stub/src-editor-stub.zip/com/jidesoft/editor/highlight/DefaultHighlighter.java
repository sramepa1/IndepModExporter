/**
 *  The package contains classes for code highlighter for JIDE Code Editor product.
 */
package com.jidesoft.editor.highlight;


/**
 *  Implements the Highlighter interfaces.  Implements a simple highlight painter that renders in a solid color.
 * 
 *  @author Timothy Prinzing
 *  @see Highlighter
 */
public class DefaultHighlighter extends LayeredHighlighter {

	/**
	 *  Default implementation of LayeredHighlighter.LayerPainter that can be used for painting highlights.
	 *  <p/>
	 *  As of 1.4 this field is final.
	 */
	public static final LayeredHighlighter.LayerPainter DefaultPainter;

	/**
	 *  Creates a new DefaultHighlighther object.
	 */
	public DefaultHighlighter() {
	}

	/**
	 *  Renders the highlights.
	 * 
	 *  @param g the graphics context
	 */
	public void paint(java.awt.Graphics g) {
	}

	/**
	 *  Get the highlight information of the designated index.
	 * 
	 *  @param index the highlight index
	 *  @return highlight information.
	 */
	public Object getHighlightInfo(int index) {
	}

	/**
	 *  Called when the UI is being installed into the interface of a CodeEditor.  Installs the editor, and removes any
	 *  existing highlights.
	 * 
	 *  @param c the editor component
	 *  @see javax.swing.text.Highlighter#install
	 */
	public void install(com.jidesoft.editor.CodeEditor c) {
	}

	/**
	 *  Called when the UI is being removed from the interface of a CodeEditor.
	 * 
	 *  @param c the component
	 *  @see javax.swing.text.Highlighter#deinstall
	 */
	public void deinstall(com.jidesoft.editor.CodeEditor c) {
	}

	/**
	 *  Adds a highlight to the view.  Returns a tag that can be used to refer to the highlight.
	 * 
	 *  @param p0 the start offset of the range to highlight >= 0
	 *  @param p1 the end offset of the range to highlight >= p0
	 *  @param p  the painter to use to actually render the highlight
	 *  @return an object that can be used as a tag to refer to the highlight
	 * 
	 *  @throws javax.swing.text.BadLocationException
	 *           if the specified location is invalid
	 */
	public Object addHighlight(int p0, int p1, Highlighter.HighlightPainter p) {
	}

	/**
	 *  Removes a highlight from the view.
	 * 
	 *  @param tag the reference to the highlight
	 */
	public void removeHighlight(Object tag) {
	}

	/**
	 *  Removes all highlights.
	 */
	public void removeAllHighlights() {
	}

	/**
	 *  Changes a highlight.
	 * 
	 *  @param tag the highlight tag
	 *  @param p0  the beginning of the range >= 0
	 *  @param p1  the end of the range >= p0
	 *  @throws javax.swing.text.BadLocationException
	 *           if the specified location is invalid
	 */
	public void changeHighlight(Object tag, int p0, int p1) {
	}

	/**
	 *  Makes a copy of the highlights.  Does not actually clone each highlight, but only makes references to them.
	 * 
	 *  @return the copy
	 * 
	 *  @see javax.swing.text.Highlighter#getHighlights
	 */
	public Highlighter.Highlight[] getHighlights() {
	}

	/**
	 *  When leaf Views (such as LabelView) are rendering they should call into this method. If a highlight is in the
	 *  given region it will be drawn immediately.
	 * 
	 *  @param g          Graphics used to draw
	 *  @param p0         starting offset of view
	 *  @param p1         ending offset of view
	 *  @param viewBounds Bounds of View
	 *  @param editor     CodeEditor
	 */
	@java.lang.Override
	public void paintLayeredHighlights(java.awt.Graphics g, int p0, int p1, java.awt.Shape viewBounds, com.jidesoft.editor.CodeEditor editor) {
	}

	/**
	 *  If true, highlights are drawn as the Views draw the text. That is the Views will call into
	 *  <code>paintLayeredHighlight</code> which will result in a rectangle being drawn before the text is drawn (if the
	 *  offsets are in a highlighted region that is). For this to work the painter supplied must be an instance of
	 *  LayeredHighlightPainter.
	 * 
	 *  @param newValue the setting
	 */
	public void setDrawsLayeredHighlights(boolean newValue) {
	}

	public boolean getDrawsLayeredHighlights() {
	}

	/**
	 *  Simple highlight painter that fills a highlighted area with a solid color.
	 */
	public static class DefaultHighlightPainter {


		/**
		 *  Constructs a new highlight painter. If <code>c</code> is null, the CodeEditor will be queried for its
		 *  selection color.
		 * 
		 *  @param c the color for the highlight
		 */
		public DefaultHighlighter.DefaultHighlightPainter(java.awt.Color c) {
		}

		/**
		 *  Returns the color of the highlight.
		 * 
		 *  @return the color
		 */
		public java.awt.Color getColor() {
		}

		/**
		 *  Paints a highlight.
		 * 
		 *  @param g      the graphics context
		 *  @param offs0  the starting model offset >= 0
		 *  @param offs1  the ending model offset >= offs1
		 *  @param bounds the bounding box for the highlight
		 *  @param c      the editor
		 */
		public void paint(java.awt.Graphics g, int offs0, int offs1, java.awt.Shape bounds, com.jidesoft.editor.CodeEditor c) {
		}

		/**
		 *  Paints a portion of a highlight.
		 * 
		 *  @param g      the graphics context
		 *  @param offs0  the starting model offset >= 0
		 *  @param offs1  the ending model offset >= offs1
		 *  @param bounds the bounding box of the view, which is not necessarily the region to paint.
		 *  @param c      the editor
		 *  @return region drawing occurred in
		 */
		@java.lang.Override
		public java.awt.Shape paintLayer(java.awt.Graphics g, int offs0, int offs1, java.awt.Shape bounds, com.jidesoft.editor.CodeEditor c) {
		}
	}
}
