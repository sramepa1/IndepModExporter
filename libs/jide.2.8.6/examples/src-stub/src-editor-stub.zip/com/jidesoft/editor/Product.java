/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


public interface Product {
}
