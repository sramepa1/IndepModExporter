/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  JavaScript token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: JavaScriptTokenMarker.java,v 1.3 1999/12/13 03:40:29 sp Exp $
 */
public class JavaScriptTokenMarker extends CTokenMarker {

	public JavaScriptTokenMarker() {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
