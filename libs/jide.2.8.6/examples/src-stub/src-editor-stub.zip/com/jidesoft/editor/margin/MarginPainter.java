/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  A painter interface to paint the margin area. This painter is mainly used to add extra content to an existing margin.
 *  For example, you have a code folding margin. Now you want to use the same space to add extra information about
 *  bracket matching. You can certainly create a new margin to do it but it will take extra space. So we can use this
 *  <code>MarginPainter</code> to paint a layer on top of the code folding margin.
 *  <p/>
 *  You can add many <code>MarginPainter</code>s to <code>AbstractMargin</code>. In order to decide the order to paint
 *  them, each <code>MarginPainter</code> has layer index. The lower the layer index is, the earlier it gets painted. In
 *  the other word, the painter has a higher index will overwrite those that have lower index. The default layer index is
 *  defined as {@link #LAYER_DEFAULT_INDEX}. The original content of the margin is painted on this layer. For example, in
 *  code folding margin, code folding information is painted on <code>LAYER_DEFAULT_INDEX</code>. If you want to your
 *  painter painted before code folding information, use a layer index smaller than <code>LAYER_DEFAULT_INDEX</code>. If
 *  you want it painted after code folding, use an index larger than <code>LAYER_DEFAULT_INDEX</code>.
 */
public interface MarginPainter {

	/**
	 *  The default layer index. The original content of the margin is painted on this layer.
	 */
	public static final int LAYER_DEFAULT_INDEX = 1000;

	/**
	 *  Paints the margin.
	 * 
	 *  @param g
	 *  @param editor The Code Editor
	 */
	public void paintMargin(java.awt.Graphics g, com.jidesoft.editor.CodeEditor editor);

	/**
	 *  Gets the layer index. The painter has a higher index will overwrite those that have lower index.
	 * 
	 *  @return the layer index.
	 */
	public int getLayer();
}
