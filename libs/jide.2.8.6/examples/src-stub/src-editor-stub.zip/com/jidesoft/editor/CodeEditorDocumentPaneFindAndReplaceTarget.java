/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  A <code>FindAndReplaceTarget</code> implementation for <code>CodeEditorDocumentPane</code>. This is a target that
 *  supports multiple code editors.
 */
public class CodeEditorDocumentPaneFindAndReplaceTarget implements com.jidesoft.search.FindAndReplaceTarget, javax.swing.event.DocumentListener {
 {

	public CodeEditorDocumentPaneFindAndReplaceTarget(CodeEditorDocumentPane codeEditorDocumentPane) {
	}

	public com.jidesoft.search.FindResultIntepreter getIntepreter() {
	}

	public CodeEditor getCodeEditor() {
	}

	public javax.swing.JComponent getConfigurationPanel() {
	}

	public boolean hasNext() {
	}

	public void next() {
	}

	public boolean hasPrevious() {
	}

	public void previous() {
	}

	public int getCurrentPosition(boolean forward) {
	}

	public void highlight(int start, int end) {
	}

	public void replace(int offset, int len, String str) {
	}

	public java.awt.Window getPromptDialogParent() {
	}

	public java.awt.Point getPromptDialogLocation() {
	}

	public String getCurrentName() {
	}

	public String getCurrentText() {
	}

	public void showMessage(String message) {
	}

	public void replaceAllStarts() {
	}

	public void replaceAllEnds() {
	}

	protected void changeCurrentEditor(CodeEditor newCodeEditor, String newCodeEditorName) {
	}

	protected void setTargetChanged(boolean targetChanged) {
	}

	public boolean isTargetChanged() {
	}

	public void insertUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void removeUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void changedUpdate(javax.swing.event.DocumentEvent e) {
	}
}
