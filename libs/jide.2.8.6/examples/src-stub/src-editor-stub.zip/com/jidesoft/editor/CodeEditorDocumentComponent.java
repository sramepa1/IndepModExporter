/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>CodeEditorDocumentComponent</code> is a <code>DocumentComponent</code> for <code>CodeEditor</code>.
 *  There is <code>setLanguageName</code> method that you can use to set the language of the <code>CodeEditor</code> as long as
 *  the language name is registered in {@link LanguageSpecManager}.
 */
public class CodeEditorDocumentComponent extends DocumentComponent {

	public CodeEditorDocumentComponent(String name) {
	}

	public CodeEditorDocumentComponent(String name, String title) {
	}

	public CodeEditorDocumentComponent(String name, String title, javax.swing.Icon icon) {
	}

	public CodeEditorDocumentComponent(javax.swing.JComponent component, String name, String title, javax.swing.Icon icon) {
	}

	protected void initComponents() {
	}

	/**
	 *  Creates status bar for this <code>CodeEditorDocumentComponent</code>.
	 *  Subclass can override this method to create their own status bar or even null
	 *  if they prefer to put the status bar somewhere else.
	 * 
	 *  @param editor the code editor.
	 *  @return the status bar.
	 */
	protected StatusBar createStatusBar(CodeEditor editor) {
	}

	/**
	 *  Creates the marker area.
	 * 
	 *  @param editor the code editor.
	 *  @return the marker area.
	 */
	protected marker.MarkerArea createMarkerArea(CodeEditor editor) {
	}

	public String getLanguageName() {
	}

	public void setLanguageName(String languageName) {
	}

	/**
	 *  Creates the code editor.
	 * 
	 *  @return the code editor.
	 */
	protected CodeEditor createCodeEditor() {
	}

	public void setCodeEditor(CodeEditor codeEditor) {
	}

	public CodeEditor getCodeEditor() {
	}

	/**
	 *  Opens a file in the code editor.
	 * 
	 *  @param fileName
	 *  @throws IOException
	 */
	public void open(String fileName) {
	}

	/**
	 *  Opens a file in the code editor using the specified charset.
	 * 
	 *  @param fileName
	 *  @throws IOException
	 */
	public void open(String fileName, String charsetName) {
	}

	public void open(ClassLoader classLoader, String resourceName) {
	}

	/**
	 *  Opens a SyntaxDocument and sets it to the code editor.
	 * 
	 *  @param document
	 */
	public void open(SyntaxDocument document) {
	}

	/**
	 *  Opens an input stream.
	 * 
	 *  @param in
	 *  @throws IOException
	 */
	public void open(java.io.InputStream in) {
	}

	/**
	 *  Opens an input stream using the specified charset.
	 * 
	 *  @param in
	 *  @param charsetName
	 *  @throws IOException
	 */
	public void open(java.io.InputStream in, String charsetName) {
	}

	/**
	 *  Saves the content of the code editor to a file.
	 * 
	 *  @param fileName
	 *  @throws IOException
	 */
	public void save(String fileName) {
	}

	/**
	 *  Saves the content of the code editor to a file.
	 * 
	 *  @param fileName
	 *  @param charsetName
	 *  @throws IOException
	 */
	public void save(String fileName, String charsetName) {
	}

	/**
	 *  Saves the content of an output stream.
	 * 
	 *  @param out
	 *  @throws IOException
	 */
	public void save(java.io.OutputStream out) {
	}

	/**
	 *  Saves the content of an output stream.
	 * 
	 *  @param out
	 *  @throws IOException
	 */
	public void save(java.io.OutputStream out, String charsetName) {
	}

	@java.lang.Override
	public Object clone() {
	}

	/**
	 *  Clones the DocumentComponent. It will simply do
	 *  <code><pre>
	 *  return new CodeEditorDocumentComponent(getName(), getTitle(), getIcon());
	 *  </pre></code>
	 *  This method is called by {@link #clone()}.
	 * 
	 *  @return a new DocumentComponent with the same name, title and icon of this one.
	 */
	protected CodeEditorDocumentComponent cloneDocumentComponent() {
	}
}
