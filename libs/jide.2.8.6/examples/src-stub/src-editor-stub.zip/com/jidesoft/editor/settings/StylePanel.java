/**
 *  The package contains classes for settings panel for JIDE Code Editor product.
 */
package com.jidesoft.editor.settings;


/**
 *  A panel to configure the style property for a CodeEditor.
 */
public class StylePanel extends javax.swing.JPanel {

	public StylePanel() {
	}

	protected void installComponents() {
	}

	public void loadData() {
	}

	public void saveData() {
	}

	public com.jidesoft.editor.SyntaxStyle getStyle() {
	}

	public void setStyle(com.jidesoft.editor.SyntaxStyle style) {
	}

	protected String getResourceString(String key) {
	}
}
