/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  C++ token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: CCTokenMarker.java,v 1.6 1999/12/13 03:40:29 sp Exp $
 */
public class CCTokenMarker extends CTokenMarker {

	public CCTokenMarker() {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
