/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>SyntaxStyleSchema</code> contains a list of <code>SyntaxStyle</code>s that can be used by <code>CodeEditor</code>.
 */
public class SyntaxStyleSchema {

	public SyntaxStyleSchema() {
	}

	protected java.util.Map getStyleMap() {
	}

	protected java.util.List getStyleList() {
	}

	public SyntaxStyle getStyle(int id) {
	}

	public void addStyle(int id, SyntaxStyle style) {
	}

	public int getStyleCount() {
	}

	public SyntaxStyle getStyleByIndex(int index) {
	}

	public void setStyleByIndex(int index, SyntaxStyle style) {
	}
}
