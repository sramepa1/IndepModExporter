/**
 *  The package contains classes for language spec for JIDE Code Editor product.
 */
package com.jidesoft.editor.language;


/**
 *  <code>LanguageSpec</code> defines the necessary properties for a language type. <code>CodeEditor</code> will use the
 *  information provided by this class.
 */
public class LanguageSpec {

	public static final String PROPERTY_NONWORD_DELIMITERS = "nonwordDelimiters";

	public static final String PROPERTY_LINE_COMMENT = "lineComment";

	public static final String PROPERTY_BLOCK_COMMENT_START = "blockCommentStart";

	public static final String PROPERTY_BLOCK_COMMENT_END = "blockCommentEnd";

	public LanguageSpec(String name, String suffixes, com.jidesoft.editor.tokenmarker.TokenMarker tokenMarker, String noWordDelimiters, String lineComment) {
	}

	public LanguageSpec(String name, String suffixes, com.jidesoft.editor.tokenmarker.TokenMarker tokenMarker, String noWordDelimiters, String lineComment, String blockCommentStart, String blockCommentEnd) {
	}

	/**
	 *  Gets the name of this language.
	 * 
	 *  @return the name of this language.
	 */
	public String getName() {
	}

	/**
	 *  Gets the suffixes of this language.
	 * 
	 *  @return the suffixes of this language.
	 */
	public java.util.List getSuffixes() {
	}

	/**
	 *  Adds a new suffix to this language.
	 * 
	 *  @param suffix
	 */
	public void addSuffix(String suffix) {
	}

	/**
	 *  Adds several new suffix to this language.
	 * 
	 *  @param suffixes
	 */
	public void addSuffixes(String[] suffixes) {
	}

	/**
	 *  Removes the suffix from this language.
	 * 
	 *  @param suffix
	 */
	public void removeSuffix(String suffix) {
	}

	/**
	 *  Removes all suffixes from this language.
	 */
	public void clearSuffixes() {
	}

	/**
	 *  Gets the icon associated with this language.
	 * 
	 *  @return the icon.
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Sets the icon associated with this language.
	 * 
	 *  @param icon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Gets the token marker.
	 * 
	 *  @return the token marker.
	 */
	public com.jidesoft.editor.tokenmarker.TokenMarker getTokenMarker() {
	}

	/**
	 *  Sets the token marker.
	 * 
	 *  @param tokenMarker
	 */
	public void setTokenMarker(com.jidesoft.editor.tokenmarker.TokenMarker tokenMarker) {
	}

	/**
	 *  Gets the characters that are not considered as a word delimiter. By default, If Character.isLetterOrDigit return
	 *  false, it will be consdiered as a word delimiter, unless it is in the string of this nonwordDelimiters.
	 * 
	 *  @return the characters that are not considered as a word delimiter.
	 */
	public String getNonwordDelimiters() {
	}

	/**
	 *  Sets the characters that are not considered as a word delimiter.
	 * 
	 *  @param nonwordDelimiters
	 *  @see #setNonwordDelimiters(String)
	 */
	public void setNonwordDelimiters(String nonwordDelimiters) {
	}

	/**
	 *  Gets string for the line comment.
	 * 
	 *  @return the string for the line comment.
	 */
	public String getLineComment() {
	}

	/**
	 *  Sets the string for the line comment.
	 * 
	 *  @param lineComment the new string for the line comment.
	 */
	public void setLineComment(String lineComment) {
	}

	/**
	 *  Gets the start string for block comment.
	 * 
	 *  @return the start string for block comment.
	 */
	public String getBlockCommentStart() {
	}

	/**
	 *  Sets the start string for block comment.
	 * 
	 *  @param blockCommentStart
	 */
	public void setBlockCommentStart(String blockCommentStart) {
	}

	/**
	 *  Gets the end string for block comment.
	 * 
	 *  @return the end string for block comment.
	 */
	public String getBlockCommentEnd() {
	}

	/**
	 *  Sets the end string for block comment.
	 * 
	 *  @param blockCommentEnd
	 */
	public void setBlockCommentEnd(String blockCommentEnd) {
	}

	/**
	 *  Configures the code editor to set the properties onto CodeEditor's Document as document properties. All those
	 *  properties are defined in LanguageSpec as constants.
	 * 
	 *  @param codeEditor
	 */
	public void configureCodeEditor(com.jidesoft.editor.CodeEditor codeEditor) {
	}

	@java.lang.Override
	public String toString() {
	}
}
