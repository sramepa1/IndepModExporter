/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>Marker</code> represents a range of text in code editor used by the {@link MarkerModel}. It has a start offset
 *  and an end offset. By default, there are two types of markers - error and warning. But you can always define your own
 *  types of markers. You can also associate a tooltip with a marker. The tooltip will be shown when user mouse moves
 *  over the marker stripe.
 */
public class Marker {

	/**
	 *  Problem which prevents the tool's normal completion.
	 */
	public static final int TYPE_ERROR = 0;

	/**
	 *  Problem which does not usually prevent the tool from completing normally.
	 */
	public static final int TYPE_WARNING = 1;

	/**
	 *  Problem similar to a warning, but is mandated by the tool's specification.  For example, the Java&trade; Language
	 *  Specification, 3rd Ed. mandates warnings on certain unchecked operations and the use of deprecated methods.
	 */
	public static final int TYPE_MANDATORY_WARNING = 2;

	/**
	 *  Informative message from the tool.
	 */
	public static final int TYPE_NOTE = 3;

	/**
	 *  Diagnostic which does not fit within the other kinds.
	 */
	public static final int TYPE_OTHER = 4;

	/**
	 *  Creates a <code>Marker</code>.
	 * 
	 *  @param startOffset
	 *  @param endOffset
	 *  @param type
	 *  @param tooltip
	 */
	public Marker(int startOffset, int endOffset, int type, String tooltip) {
	}

	/**
	 *  Gets the start offset.
	 * 
	 *  @return the start offset.
	 */
	public int getStartOffset() {
	}

	/**
	 *  Gets the end offset.
	 * 
	 *  @return the end offset.
	 */
	public int getEndOffset() {
	}

	/**
	 *  Gets the type.
	 * 
	 *  @return the type.
	 */
	public int getType() {
	}

	/**
	 *  Gets the tooltip text.
	 * 
	 *  @return the tooltip text.
	 */
	public String getToolTipText() {
	}

	@java.lang.Override
	public String toString() {
	}
}
