/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>MarkerListener</code> is a listener can be added to MarkerModel to listen to any marker changes in marker model.
 */
public interface MarkerListener extends java.util.EventListener {
 {

	/**
	 *  This method is called when any marker change happened.
	 * 
	 *  @param e
	 */
	public void markerChanged(MarkerEvent e);
}
