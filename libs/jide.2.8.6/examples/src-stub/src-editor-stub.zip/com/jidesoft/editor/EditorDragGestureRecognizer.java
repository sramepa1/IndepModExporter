/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  Default drag gesture recognition for drag operations performed by classes that have a <code>dragEnabled</code>
 *  property.  The gesture for a drag in this package is a mouse press over a selection followed by some movement by
 *  enough pixels to keep it from being treated as a click.
 * 
 *  @author Timothy Prinzing
 */
public class EditorDragGestureRecognizer implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener {
 {

	public EditorDragGestureRecognizer() {
	}

	protected int mapDragOperationFromModifiers(java.awt.event.MouseEvent e) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Determines if the following are true: <ul> <li>the press event is located over a selection <li>the dragEnabled
	 *  property is true <li>A TranferHandler is installed </ul>
	 *  <p/>
	 *  This is implemented to check for a TransferHandler. Subclasses should perform the remaining conditions.
	 */
	protected boolean isDragPossible(java.awt.event.MouseEvent e) {
	}

	protected javax.swing.JComponent getComponent(java.awt.event.MouseEvent e) {
	}
}
