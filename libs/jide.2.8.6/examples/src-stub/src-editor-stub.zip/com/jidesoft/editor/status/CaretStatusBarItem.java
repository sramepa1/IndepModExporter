/**
 *  The package contains classes for a code editor related status bar items for JIDE Code Editor product.
 */
package com.jidesoft.editor.status;


/**
 *  A special <code>StatusBarItem</code> which is used to show the information about caret position.
 *  It has one abstract method {@link #caretUpdated(com.jidesoft.editor.caret.CaretEvent)}. This method is called
 *  whenever caret position changes.
 */
public abstract class CaretStatusBarItem extends AbstractCodeEditorStatusBarItem implements com.jidesoft.editor.caret.CaretListener {
 {

	public CaretStatusBarItem() {
	}

	public CaretStatusBarItem(String name) {
	}

	public void initialize() {
	}

	public void registerListener(com.jidesoft.editor.CodeEditor editor) {
	}

	public void unregisterListener(com.jidesoft.editor.CodeEditor editor) {
	}

	public void caretUpdated(com.jidesoft.editor.caret.CaretEvent e) {
	}
}
