/**
 *  The package contains classes for settings panel for JIDE Code Editor product.
 */
package com.jidesoft.editor.settings;


/**
 *  A panel to configure the font property for a <code>CodeEditor</code>.
 */
public class FontPanel extends javax.swing.JPanel {

	public FontPanel() {
	}

	protected void installComponents() {
	}

	protected void installModel() {
	}

	public void loadData() {
	}

	public void saveData() {
	}

	public String getFontName() {
	}

	public void setFontName(String fontName) {
	}

	public int getFontSize() {
	}

	public void setFontSize(int fontSize) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string.
	 *  Available keys are defined in swing.properties that begin with "SearchableBar.".
	 * 
	 *  @param key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}
}
