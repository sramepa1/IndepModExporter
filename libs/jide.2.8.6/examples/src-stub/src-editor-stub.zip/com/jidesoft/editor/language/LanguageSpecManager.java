/**
 *  The package contains classes for language spec for JIDE Code Editor product.
 */
package com.jidesoft.editor.language;


/**
 *  <code>LanguageSpecManager</code> keeps a list of known <code>LanguageSpec</code>. We registered several lanaguages on
 *  it already. You can add more based on what you need. The languages we registered are Java, JSP, C, C++, HTML, XML,
 *  PHP, Python, PLSQL, TSQL, Perl, VHDL and Verilog.
 *  <p/>
 *  <code>LanguageSpecManager</code> is a singleton. You use it by calling {@link #getInstance()}.
 */
public class LanguageSpecManager {

	protected LanguageSpecManager() {
	}

	public static LanguageSpecManager getInstance() {
	}

	protected void initDefaultLanguageSpecs() {
	}

	/**
	 *  Gets the <code>LanguageSpec</code> that matches the specified name.
	 * 
	 *  @param langName the language name.
	 *  @return the <code>LanguageSpec</code> that matches the specified name. Null if it is not found or the langName
	 *          parameter is null.
	 */
	public LanguageSpec getLanguageSpec(String langName) {
	}

	/**
	 *  Gets all <code>LanguageSpec</code>s registered on this manager.
	 * 
	 *  @return all <code>LanguageSpec</code>s registered on this manager.
	 */
	public LanguageSpec[] getLanguageSpecs() {
	}

	/**
	 *  Registers a new <code>LanguageSpec</code>. Please note, if the new LanguageSpec has the same name as one of the
	 *  existing LanguageSpec, the new one will override the old one.
	 * 
	 *  @param spec the LanguageSpec to be registered.
	 */
	public void registerLanguageSpec(LanguageSpec spec) {
	}

	/**
	 *  Unregisters a <code>LanguageSpec</code>.
	 * 
	 *  @param langName the language name
	 */
	public void unregisterLanguageSpec(String langName) {
	}
}
