/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  A token marker splits lines of text into tokens. Each token carries
 *  a length field and an identification tag that can be mapped to a color
 *  for painting that token.<p>
 *  <p/>
 *  For performance reasons, the linked list of tokens is reused after each
 *  line is tokenized. Therefore, the return value of <code>markTokens</code>
 *  should only be used for immediate painting. Notably, it cannot be
 *  cached.
 * 
 *  @author Slava Pestov
 *  @version $Id: TokenMarker.java,v 1.32 1999/12/13 03:40:30 sp Exp $
 *  @see Token
 */
public abstract class TokenMarker {

	/**
	 *  The first token in the list. This should be used as the return
	 *  value from <code>markTokens()</code>.
	 *  @deprecated replaced by the first element of {@link #_tokens}
	 */
	@java.lang.Deprecated
	protected Token firstToken;

	/**
	 *  The last token in the list. New tokens are added here.
	 *  This should be set to null before a new line is to be tokenized.
	 *  @deprecated replaced by the second element of {@link #_tokens}
	 */
	@java.lang.Deprecated
	protected Token lastToken;

	/**
	 *  Token array to contain firstToken and lastToken so that the token marker process is thread safe.
	 *  The first element is firstToken while the second is lastToken.
	 */
	protected final Token[] _tokens;

	/**
	 *  An array for storing information about lines. It is enlarged and
	 *  shrunk automatically by the <code>insertLines()</code> and
	 *  <code>deleteLines()</code> methods.
	 */
	protected TokenMarker.LineInfo[] lineInfo;

	/**
	 *  The number of lines in the model being tokenized. This can be
	 *  less than the length of the <code>lineInfo</code> array.
	 */
	protected int length;

	/**
	 *  The last tokenized line.
	 */
	protected int lastLine;

	/**
	 *  True if the next line should be painted.
	 */
	protected boolean nextLineRequested;

	/**
	 *  Creates a new <code>TokenMarker</code>. This DOES NOT create
	 *  a lineInfo array; an initial call to <code>insertLines()</code>
	 *  does that.
	 */
	protected TokenMarker() {
	}

	/**
	 *  A wrapper for the lower-level <code>markTokensImpl</code> method
	 *  that is called to split a line up into tokens.
	 * 
	 *  @param line      The line
	 *  @param lineIndex The line number
	 *  @return the tokens.
	 */
	public Token markTokens(javax.swing.text.Segment line, int lineIndex) {
	}

	/**
	 *  An abstract method that splits a line up into tokens. It
	 *  should parse the line, and call <code>addToken()</code> to
	 *  add syntax tokens to the token list. Then, it should return
	 *  the initial token type for the next line.<p>
	 *  <p/>
	 *  For example if the current line contains the start of a
	 *  multiline comment that doesn't end on that line, this method
	 *  should return the comment token type so that it continues on
	 *  the next line.
	 * 
	 *  @param token     The initial token type for this line
	 *  @param line      The line to be tokenized
	 *  @param lineIndex The index of the line in the document,
	 *                   starting at 0
	 *  @return The initial token type for the next line
	 */
	protected abstract byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}

	/**
	 *  Returns if the token marker supports tokens that span multiple
	 *  lines. If this is true, the object using this token marker is
	 *  required to pass all lines in the document to the
	 *  <code>markTokens()</code> method (in turn).<p>
	 *  <p/>
	 *  The default implementation returns true; it should be overridden
	 *  to return false on simpler token markers for increased speed.
	 * 
	 *  @return true by default.
	 */
	public boolean supportsMultilineTokens() {
	}

	/**
	 *  Informs the token marker that lines have been inserted into
	 *  the document. This inserts a gap in the <code>lineInfo</code>
	 *  array.
	 * 
	 *  @param index The first line number
	 *  @param lines The number of lines
	 */
	public void insertLines(int index, int lines) {
	}

	/**
	 *  Informs the token marker that line have been deleted from
	 *  the document. This removes the lines in question from the
	 *  <code>lineInfo</code> array.
	 * 
	 *  @param index The first line number
	 *  @param lines The number of lines
	 */
	public void deleteLines(int index, int lines) {
	}

	/**
	 *  Returns the number of lines in this token marker.
	 * 
	 *  @return the line count.
	 */
	public int getLineCount() {
	}

	/**
	 *  Returns true if the next line should be repainted. This
	 *  will return true after a line has been tokenized that starts
	 *  a multiline token that continues onto the next line.
	 * 
	 *  @return true if the next line should be repainted. Otherwise false.
	 */
	public boolean isNextLineRequested() {
	}

	/**
	 *  Ensures that the <code>lineInfo</code> array can contain the
	 *  specified index. This enlarges it if necessary. No action is
	 *  taken if the array is large enough already.<p>
	 *  <p/>
	 *  It should be unnecessary to call this under normal
	 *  circumstances; <code>insertLine()</code> should take care of
	 *  enlarging the line info array automatically.
	 * 
	 *  @param index The array index
	 */
	protected void ensureCapacity(int index) {
	}

	/**
	 *  Adds a token to the token list.
	 * 
	 *  @param length The length of the token
	 *  @param id     The id of the token
	 */
	protected void addToken(int length, byte id) {
	}

	/**
	 *  Get the document the TokenMarker is parsing.
	 * 
	 *  @return the document.
	 */
	public com.jidesoft.editor.SyntaxDocument getDocument() {
	}

	/**
	 *  Set the document the TokenMarker is parsing.
	 *  <p/>
	 *  This method is invoked automatically by {@link com.jidesoft.editor.SyntaxDocument#setTokenMarker(TokenMarker)}. You
	 *  should always invoke that method to build correct relationship between SyntaxDocument and TokenMarker.
	 * 
	 *  @param document the document
	 */
	public void setDocument(com.jidesoft.editor.SyntaxDocument document) {
	}

	/**
	 *  Inner class for storing information about tokenized lines.
	 */
	public class LineInfo {


		/**
		 *  The id of the last token of the line.
		 */
		public byte token;

		/**
		 *  This is for use by the token marker implementations
		 *  themselves. It can be used to store anything that
		 *  is an object and that needs to exist on a per-line
		 *  basis.
		 */
		public Object obj;

		/**
		 *  Creates a new LineInfo object with token = Token.NULL
		 *  and obj = null.
		 */
		public TokenMarker.LineInfo() {
		}

		/**
		 *  Creates a new LineInfo object with the specified
		 *  parameters.
		 * 
		 *  @param token the token
		 *  @param obj the token related object
		 */
		public TokenMarker.LineInfo(byte token, Object obj) {
		}
	}
}
