/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  XML Token Marker Rewrite
 * 
 *  @author Tom Bradford
 *  @version $Id: XMLTokenMarker.java,v 1.5 2001/07/29 20:45:43 tom Exp $
 */
public class XMLTokenMarker extends TokenMarker {

	public XMLTokenMarker() {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}
}
