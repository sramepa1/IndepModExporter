/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  An abstract implementation of <code>LineMarginPainter</code> interface. It implements
 *  the {@link #getLayer()} method so that you can use {@link #setLayer(int)} to set the layer index.
 *  You still need to implement the other method <code>paintLineMargin</code>.
 */
public abstract class AbstractLineMarginPainter implements LineMarginPainter {
 {

	protected AbstractLineMarginPainter() {
	}

	protected AbstractLineMarginPainter(int layer) {
	}

	/**
	 *  Gets the layer index. The painter has a higher index will overwrite
	 *  those that have lower index.
	 * 
	 *  @return the layer index.
	 */
	public int getLayer() {
	}

	/**
	 *  Sets the layer index.
	 * 
	 *  @param layer
	 */
	public void setLayer(int layer) {
	}
}
