/**
 *  The package contains classes for a code editor related status bar items for JIDE Code Editor product.
 */
package com.jidesoft.editor.status;


/**
 *  <code>CodeEditorStatusBar</code> is a status bar for <code>CodeEditor</code>. Please note, you don't have to always
 *  use this in your application. Ideally, if you use <code>CodeEditor</code> in your application, you should integerate
 *  the status bar directly into the main application's status bar. You can do this by using several StatusBarItems we
 *  made for <code>CodeEditor</code>. This <code>CodeEditorStatusBar</code> is more or less a demo of all the available
 *  StatusBarItems for <code>CodeEditor</code>.
 */
public class CodeEditorStatusBar extends StatusBar {

	public static final String CARET_POSITION = "CARET_POSITION";

	public static final String CARET_VISUAL_POSITION = "CARET_VISUAL_POSITION";

	public static final String CARET_OFFSET = "CARET_OFFSET";

	public static final String CARET_CONTEXT = "CARET_CONTEXT";

	public static final String OVR_INS = "OVERRIDE_INSERT";

	public static final String EDITABLE = "EDITABLE";

	public static final String LINE_BREAK = "LINE_BREAK";

	public static final String PROPERTY_CODE_EDITOR = "codeEditor";

	protected CaretModelPositionStatusBarItem _caretModelPosition;

	protected CaretOverwriteStatusBarItem _ovrIns;

	protected LineBreakStatusBarItem _lineBreak;

	protected EditableStatusBarItem _editable;

	protected ProgressStatusBarItem _progress;

	public CodeEditorStatusBar() {
	}

	public CodeEditorStatusBar(com.jidesoft.editor.CodeEditor editor) {
	}

	@java.lang.Override
	public java.awt.Component add(java.awt.Component comp) {
	}

	protected void addStatusBarItems() {
	}

	public com.jidesoft.editor.CodeEditor getCodeEditor() {
	}

	public void setCodeEditor(com.jidesoft.editor.CodeEditor editor) {
	}
}
