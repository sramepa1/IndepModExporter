/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  Defines a few syntax style schema that mimic other famous code editors.
 */
public class PredefinedSyntaxStyleSchema {

	public PredefinedSyntaxStyleSchema() {
	}

	/**
	 *  @return the <code>SyntaxStyleSchema</code> that mimics IntelliJ IDEA's editor.
	 */
	public static SyntaxStyleSchema getIntellijSyntaxStyles() {
	}

	/**
	 *  @return the <code>SyntaxStyleSchema</code> that mimics Eclipse's editor.
	 */
	public static SyntaxStyleSchema getEclipseSyntaxStyles() {
	}

	/**
	 *  @return the <code>SyntaxStyleSchema</code> that mimics NetBeans's editor.
	 */
	public static SyntaxStyleSchema getNetBeansSyntaxStyles() {
	}

	/**
	 *  @return the <code>SyntaxStyleSchema</code> that mimics Visual Studio's editor.
	 */
	public static SyntaxStyleSchema getVisualStudioSyntaxStyles() {
	}
}
