/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  A margin component for code folding.
 */
public class CodeFoldingMargin extends AbstractMargin implements com.jidesoft.editor.folding.FoldingSpanListener, javax.swing.event.MouseInputListener {
 {

	protected CodeFoldingPainter _codeFoldingPainter;

	public CodeFoldingMargin() {
	}

	public CodeFoldingMargin(com.jidesoft.editor.CodeEditor editor) {
	}

	@java.lang.Override
	protected void installListenersOnEditor() {
	}

	@java.lang.Override
	protected void uninstallListenersOnEditor() {
	}

	public void paintMargin(java.awt.Graphics g) {
	}

	public void foldingSpanChanged(com.jidesoft.editor.folding.FoldingSpanEvent e) {
	}

	public CodeFoldingPainter getCodeFoldingPainter() {
	}

	public void setCodeFoldingPainter(CodeFoldingPainter codeFoldingPainter) {
	}

	@java.lang.Override
	protected void paintBackground(java.awt.Graphics g) {
	}

	public int getPreferredWidth() {
	}

	protected void paintFolding(java.awt.Graphics g, com.jidesoft.editor.folding.FoldingSpan span, int height) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	protected CodeFoldingMargin.HitInfo getSpanInfo(java.awt.Point p) {
	}

	protected static class HitInfo {


		protected CodeFoldingMargin.HitInfo() {
		}
	}
}
