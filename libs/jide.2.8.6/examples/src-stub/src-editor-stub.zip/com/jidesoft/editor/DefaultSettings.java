/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>DefaultSetting</code> creates a singleton for <code>DefaultCodeEditorSettings</code> so
 *  that you can change the settings for CodeEditors globally.
 */
public class DefaultSettings extends DefaultCodeEditorSettings {

	public DefaultSettings() {
	}

	/**
	 *  Returns a new TextAreaDefaults object with the default values filled in.
	 */
	public static DefaultSettings getDefaults() {
	}
}
