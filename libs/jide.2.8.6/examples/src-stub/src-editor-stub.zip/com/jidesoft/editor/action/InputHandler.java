/**
 *  The package contains classes for input handlers for JIDE Code Editor product.
 */
package com.jidesoft.editor.action;


/**
 *  An input handler converts the user's key strokes into concrete actions. It also takes care of macro recording and
 *  action repetition.<p>
 *  <p/>
 *  This class provides all the necessary support code for an input handler, but doesn't actually do any key binding
 *  logic. It is up to the implementations of this class to do so.
 * 
 *  @author Slava Pestov
 *  @version $Id: InputHandler.java,v 1.14 1999/12/13 03:40:30 sp Exp $
 *  @see com.jidesoft.editor.action.DefaultInputHandler
 *       <p/>
 *       08/12/2002	Clipboard actions	(Oliver Henning)
 */
public abstract class InputHandler extends java.awt.event.KeyAdapter {

	/**
	 *  If this client property is set to Boolean.TRUE on the text area, the home/end keys will support 'smart'
	 *  BRIEF-like behaviour (one press = start/end of line, two presses = start/end of viewscreen, three presses =
	 *  start/end of document). By default, this property is not set.
	 */
	public static final javax.swing.Action BACKSPACE;

	public static final javax.swing.Action BACKSPACE_WORD;

	public static final javax.swing.Action DELETE;

	public static final javax.swing.Action DELETE_WORD;

	public static final javax.swing.Action DELETE_LINE;

	public static final javax.swing.Action INSERT_BREAK;

	public static final javax.swing.Action SPLIT_LINE;

	public static final javax.swing.Action START_NEW_LINE;

	public static final javax.swing.Action INDENT_SELECTION;

	public static final javax.swing.Action UNINDENT_SELECTION;

	public static final javax.swing.Action JOIN_LINES;

	public static final javax.swing.Action END;

	public static final javax.swing.Action DOCUMENT_END;

	public static final javax.swing.Action SELECT_ALL;

	public static final javax.swing.Action SELECT_END;

	public static final javax.swing.Action SELECT_DOC_END;

	public static final javax.swing.Action HOME;

	public static final javax.swing.Action DOCUMENT_HOME;

	public static final javax.swing.Action SELECT_HOME;

	public static final javax.swing.Action SELECT_DOC_HOME;

	public static final javax.swing.Action NEXT_CHAR;

	public static final javax.swing.Action NEXT_LINE;

	public static final javax.swing.Action NEXT_PAGE;

	public static final javax.swing.Action NEXT_WORD;

	public static final javax.swing.Action SELECT_NEXT_CHAR;

	public static final javax.swing.Action SELECT_NEXT_LINE;

	public static final javax.swing.Action SELECT_NEXT_PAGE;

	public static final javax.swing.Action SELECT_NEXT_WORD;

	public static final javax.swing.Action OVERWRITE;

	public static final javax.swing.Action PREV_CHAR;

	public static final javax.swing.Action PREV_LINE;

	public static final javax.swing.Action PREV_PAGE;

	public static final javax.swing.Action PREV_WORD;

	public static final javax.swing.Action GOTO_LINE;

	public static final javax.swing.Action FIND;

	public static final javax.swing.Action FIND_NEXT;

	public static final javax.swing.Action FIND_PREVIOUS;

	public static final javax.swing.Action REPLACE;

	public static final javax.swing.Action QUICK_SEARCH;

	public static final javax.swing.Action SELECT_PREV_CHAR;

	public static final javax.swing.Action SELECT_PREV_LINE;

	public static final javax.swing.Action SELECT_PREV_PAGE;

	public static final javax.swing.Action SELECT_PREV_WORD;

	public static final javax.swing.Action SELECT_WORD;

	public static final javax.swing.Action SELECT_TO_MATCHING_BRACKET;

	public static final javax.swing.Action REPEAT;

	public static final javax.swing.Action TOGGLE_RECT;

	public static final javax.swing.Action DUPLICATE_SELECTION;

	public static final javax.swing.Action LINE_COMMENTS;

	public static final javax.swing.Action BLOCK_COMMENTS;

	public static final javax.swing.Action CLIP_COPY;

	public static final javax.swing.Action CLIP_PASTE;

	public static final javax.swing.Action CLIP_PASTE_WITH_DIALOG;

	public static final javax.swing.Action CLIP_CUT;

	public static final javax.swing.Action UNDO;

	public static final javax.swing.Action REDO;

	public static final javax.swing.Action FOLD_SELECTION;

	public static final javax.swing.Action EXPAND_FOLDING;

	public static final javax.swing.Action COLLAPSE_FOLDING;

	public static final javax.swing.Action EXPAND_ALL;

	public static final javax.swing.Action COLLAPSE_ALL;

	public static final javax.swing.Action INSERT_CHAR;

	public static final javax.swing.Action TOGGLE_CASE;

	public static final javax.swing.Action ESCAPE;

	protected static final java.util.Hashtable ACTIONS;

	protected javax.swing.Action _grabAction;

	protected boolean _repeat;

	protected int _repeatCount;

	protected InputHandler.MacroRecorder recorder;

	public InputHandler() {
	}

	protected static void initDefaultActions() {
	}

	/**
	 *  Adds an action to editor's action map.
	 * 
	 *  @param name   the name of the action. It must be unique. Otherwise, it will overwrite the previous action with
	 *                the same name.
	 *  @param action the action listener.
	 */
	public static void addAction(String name, javax.swing.Action action) {
	}

	/**
	 *  Adds an action to editor's action map.
	 * 
	 *  @param action the action. The name of the action must be unique. Otherwise, it will overwrite the previous action
	 *                with the same name.
	 */
	public static void addAction(javax.swing.Action action) {
	}

	/**
	 *  Removes the action.
	 * 
	 *  @param name the name of the action.
	 */
	public static void removeAction(String name) {
	}

	/**
	 *  Returns a named text area action.
	 * 
	 *  @param name the action name
	 *  @return the action.
	 */
	public static javax.swing.Action getAction(String name) {
	}

	/**
	 *  Returns the name of the specified text area action.
	 * 
	 *  @param listener the action listener
	 *  @return the action name.
	 */
	public static String getActionName(java.awt.event.ActionListener listener) {
	}

	/**
	 *  Gets the actions.
	 * 
	 *  @return an enumeration of all available actions.
	 */
	public static java.util.Enumeration getActions() {
	}

	/**
	 *  Handle a key pressed event. This will look up the binding for the key stroke and execute it.
	 */
	@java.lang.Override
	public void keyPressed(java.awt.event.KeyEvent evt) {
	}

	/**
	 *  Handle a key typed event. This inserts the key into the text area.
	 */
	@java.lang.Override
	public void keyTyped(java.awt.event.KeyEvent evt) {
	}

	/**
	 *  Finds the action associated with the keystroke.
	 * 
	 *  @param keyStroke the keystroke
	 *  @return the action associated with the keystroke.
	 */
	public abstract Object findAction(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Grabs the next key typed event and invokes the specified action with the key as a the action command.
	 * 
	 *  @param listener The action
	 */
	public void grabNextKeyStroke(javax.swing.Action listener) {
	}

	/**
	 *  Returns if repeating is enabled. When repeating is enabled, actions will be executed multiple times. This is
	 *  usually invoked with a special key stroke in the input handler.
	 * 
	 *  @return true or false.
	 */
	public boolean isRepeatEnabled() {
	}

	/**
	 *  Enables repeating. When repeating is enabled, actions will be executed multiple times. Once repeating is enabled,
	 *  the input handler should read a number from the keyboard.
	 * 
	 *  @param repeat the flag
	 */
	public void setRepeatEnabled(boolean repeat) {
	}

	/**
	 *  Returns the number of times the next action will be repeated.
	 * 
	 *  @return the count.
	 */
	public int getRepeatCount() {
	}

	/**
	 *  Sets the number of times the next action will be repeated.
	 * 
	 *  @param repeatCount The repeat count
	 */
	public void setRepeatCount(int repeatCount) {
	}

	/**
	 *  If this is non-null, all executed actions should be forwarded to the recorder.
	 * 
	 *  @return the macro recorder.
	 */
	public InputHandler.MacroRecorder getMacroRecorder() {
	}

	/**
	 *  Sets the macro recorder. If this is non-null, all executed actions should be forwarded to the recorder.
	 * 
	 *  @param recorder The macro recorder
	 */
	public void setMacroRecorder(InputHandler.MacroRecorder recorder) {
	}

	/**
	 *  Executes the specified action, repeating and recording it as necessary.
	 * 
	 *  @param listener      The action listener
	 *  @param source        The event source
	 *  @param actionCommand The action command
	 */
	public void executeAction(javax.swing.Action listener, Object source, String actionCommand) {
	}

	/**
	 *  Returns the text area that fired the specified event.
	 * 
	 *  @param evt The event
	 *  @return the CodeEditor.
	 */
	public static com.jidesoft.editor.CodeEditor getCodeEditor(java.util.EventObject evt) {
	}

	/**
	 *  If a key is being grabbed, this method should be called with the appropriate key event. It executes the grab
	 *  action with the typed character as the parameter.
	 * 
	 *  @param evt the key event
	 */
	protected void handleGrabAction(java.awt.event.KeyEvent evt) {
	}

	public String modifySelectionOnPaste(com.jidesoft.editor.CodeEditor syntaxArea, String selection) {
	}

	/**
	 *  If an action implements this interface, it should not be repeated. Instead, it will handle the repetition
	 *  itself.
	 */
	public static interface class NonRepeatable {

	}

	/**
	 *  If an action implements this interface, it should not be recorded by the macro recorder. Instead, it will do its
	 *  own recording.
	 */
	public static interface class NonRecordable {

	}

	/**
	 *  For use by EditAction.Wrapper only.
	 * 
	 *  @since jEdit 2.2final
	 */
	public static interface class Wrapper {

	}

	/**
	 *  Macro recorder.
	 */
	public static interface class MacroRecorder {


		public void actionPerformed(javax.swing.Action listener, String actionCommand) {
		}
	}
}
