/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  SQL token marker.
 * 
 *  @author mike dillon
 *  @version $Id: SQLTokenMarker.java,v 1.6 1999/04/19 05:38:20 sp Exp $
 */
public class SQLTokenMarker extends TokenMarker {

	protected boolean isTSQL;

	public SQLTokenMarker(com.jidesoft.editor.KeywordMap k) {
	}

	public SQLTokenMarker(com.jidesoft.editor.KeywordMap k, boolean tsql) {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}
}
