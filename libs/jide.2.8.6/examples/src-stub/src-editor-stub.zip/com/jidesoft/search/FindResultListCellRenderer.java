/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  The ListCellRenderer that renders <code>FindResult</code> and <code>FindResults</code> using StyledLabel.
 */
public class FindResultListCellRenderer extends StyledListCellRenderer {

	public FindResultListCellRenderer() {
	}

	@java.lang.Override
	protected void customizeStyledLabel(javax.swing.JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
	}
}
