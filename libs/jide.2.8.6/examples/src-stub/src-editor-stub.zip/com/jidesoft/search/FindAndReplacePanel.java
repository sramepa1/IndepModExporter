/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>FindAndReplacePanel</code> is the main UI for find and replace feature.
 */
public class FindAndReplacePanel extends javax.swing.JPanel {

	public FindAndReplacePanel(FindAndReplace findAndReplace) {
	}

	protected void installComponents() {
	}

	protected javax.swing.JComponent createFindComboBox() {
	}

	protected javax.swing.JComponent createReplaceComboBox() {
	}

	public FindAndReplaceTarget[] getTargets() {
	}

	protected javax.swing.JComponent createTargetPanel() {
	}

	protected javax.swing.JComponent createDirectionPanel() {
	}

	protected javax.swing.JComponent createOriginPanel() {
	}

	protected javax.swing.JComponent createOptionsPanel() {
	}

	protected void installListeners() {
	}

	protected java.util.ResourceBundle getResourceBundle() {
	}

	protected void installModel() {
	}

	protected void setupFindReplaceComboBox(javax.swing.JComboBox comboBox, javax.swing.DefaultComboBoxModel history, String text) {
	}

	public void saveData() {
	}

	public boolean isReplace() {
	}

	public void setReplace(boolean replace) {
	}

	public java.awt.Component getInitFocusedComponent() {
	}

	public void setFindText(String findText) {
	}

	public void setReplaceText(String replaceText) {
	}

	public FindAndReplace getFindAndReplace() {
	}

	protected javax.swing.JPopupMenu createRegexMenu(javax.swing.JComboBox combobox) {
	}

	protected javax.swing.JPopupMenu createWildcardsMenu(javax.swing.JComboBox combobox) {
	}

	protected javax.swing.Action createAction(javax.swing.JComboBox comboBox, String insertText, String description) {
	}

	protected javax.swing.Action createAction(javax.swing.JComboBox comboBox, String insertText, String insertEndText, String description) {
	}

	public static void main(String[] args) {
	}
}
