/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  The listener for FindAndReplaceEvent.
 */
public interface FindAndReplaceListener extends java.util.EventListener {
 {

	/**
	 *  This method will be called when whenever FindAndReplace status changes.
	 * 
	 *  @param e
	 */
	public void statusChanged(FindAndReplaceEvent e);
}
