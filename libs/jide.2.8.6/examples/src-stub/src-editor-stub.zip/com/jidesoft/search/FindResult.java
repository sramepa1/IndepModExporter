/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>FindResult</code> represents the text that is found by <code>FindAndReplace</code>. It has a start offset, a
 *  end offset and also a {@link FindResultIntepreter} which is used to interpret the find result.
 */
public class FindResult {

	public FindResult(int start, int end, FindResultIntepreter editor) {
	}

	@java.lang.Override
	public String toString() {
	}

	public int getStart() {
	}

	public int getEnd() {
	}

	/**
	 *  Gets the interpreter.
	 * 
	 *  @return theinterpreterr.
	 */
	public FindResultIntepreter getIntepreter() {
	}

	public boolean isValid() {
	}

	public void setValid(boolean valid) {
	}

	public String getStyledText() {
	}

	public void setStyledText(String text) {
	}
}
