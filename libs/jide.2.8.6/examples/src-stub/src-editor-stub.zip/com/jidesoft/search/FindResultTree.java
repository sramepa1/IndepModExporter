/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  A simple implementation to display FindResults in JTree.
 */
public class FindResultTree extends javax.swing.JTree {

	public FindResultTree() {
	}

	public void addSearchResult(FindResults results) {
	}
}
